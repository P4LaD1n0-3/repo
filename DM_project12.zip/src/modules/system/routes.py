"""
================================================================================
ENDPOINT COMPARTILHADO: CANCELAMENTO DE AUTOMAÇÃO (PLAYWRIGHT) ATIVA
================================================================================
Blueprint exclusivo para o botão "Cancelar" de QUALQUER tela do sistema
(Release task, Portal task, etc.). Não pertence a nenhum módulo de negócio
específico - fica em 'src/modules/system' justamente para ser reutilizado por
herança de template/JS em todas as telas, sem duplicar rota nenhuma.

Delega toda a lógica real para 'tools.job_registry.job_registry' (ver docstring
daquele módulo para o mecanismo completo de cancelamento entre threads).
"""

import os
import shutil
import asyncio
import logging
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from tools.job_registry import job_registry
from tools.servicenow_export_downloader import ServiceNowExportDownloader
from tools.temp_storage import create_path_temp
from src.models import db, ServiceNowExportConfig

logger = logging.getLogger("SystemJobs")

current_dir = os.path.dirname(os.path.abspath(__file__))
system_bp = Blueprint('system', __name__, template_folder=current_dir)

SERVICENOW_EXPORT_CONFIG_FIELDS = (
    'selected_region', 'validation_url',
    'mex_sctask_url', 'mex_inc_url', 'mex_prb_url',
    'brazil_sctask_url', 'brazil_inc_url', 'brazil_prb_url',
)


def _ensure_servicenow_export_columns():
    """Garante a integridade do schema de 'servicenow_export_configs', adicionando a
    coluna 'validation_url' se necessário - mesmo padrão usado em
    'release_task.routes._ensure_sqlite_columns'."""
    try:
        from sqlalchemy import inspect, text
        inspector = inspect(db.engine)
        if 'servicenow_export_configs' in inspector.get_table_names():
            existing_cols = [c['name'] for c in inspector.get_columns('servicenow_export_configs')]
            if 'validation_url' not in existing_cols:
                with db.engine.connect() as conn:
                    conn.execute(text("ALTER TABLE servicenow_export_configs ADD COLUMN validation_url TEXT DEFAULT ''"))
                    conn.commit()
    except Exception as e_col:
        logger.warning(f"⚠️ Verificação/migração de colunas SQLite em servicenow_export_configs: {e_col}")


@system_bp.route('/system/cancel_job', methods=['POST'])
@login_required
def cancel_job():
    """
    Cancela a automação Playwright ativa identificada por 'job_id' (gerado no
    navegador quando a automação é iniciada). Só o usuário dono do job pode
    cancelá-lo.
    """
    data = request.get_json() or {}
    job_id = (data.get('job_id') or '').strip()

    if not job_id:
        return jsonify({'status': 'error', 'message': "Nenhum 'job_id' informado."}), 400

    resultado = job_registry.cancel(job_id, current_user.id)
    logger.info(f"Cancelamento solicitado por usuário {current_user.id} para job '{job_id}': {resultado}")

    http_status = {
        'cancelled': 200,
        'pending': 200,
        'not_found': 404,
        'forbidden': 403,
        'error': 500,
    }.get(resultado.get('status'), 200)

    return jsonify(resultado), http_status


@system_bp.route('/system/job_logs/<job_id>', methods=['GET'])
@login_required
def job_logs(job_id):
    """
    Polling incremental do log em tempo real de um job ativo (ver 'JobRegistry.append_log'/
    'get_logs'). O front-end de QUALQUER tela (Release task, Portal task, etc.) chama este
    endpoint a cada poucos segundos enquanto a automação roda, informando 'since' (quantas
    linhas já exibiu) para receber só as linhas novas - em vez de esperar a automação
    inteira terminar para só então ver o log completo de uma vez.
    """
    since = request.args.get('since', 0, type=int)
    resultado = job_registry.get_logs(job_id, current_user.id, since=since)

    http_status = {
        'running': 200,
        'not_found': 404,
        'forbidden': 403,
    }.get(resultado.get('status'), 200)

    return jsonify(resultado), http_status


"""
================================================================================
ENDPOINTS COMPARTILHADOS: EXPORTS DO SERVICENOW (SCTASK / INC / PRB)
================================================================================
Config GLOBAL (não por usuário - ver 'ServiceNowExportConfig.get_or_create()')
e download via 'tools.servicenow_export_downloader.ServiceNowExportDownloader'.
Fica aqui pelo mesmo motivo do cancelamento de job acima: não pertence a
nenhum módulo de negócio específico - hoje é consumido pela tela Dashboard
('src/modules/dash/routes.py'), e a mesma rota será reaproveitada pela tela
Email Report no futuro, sem duplicar nada.
"""

REGION_URL_FIELDS = {
    'MEX': ('mex_sctask_url', 'mex_inc_url', 'mex_prb_url'),
    'BRAZIL': ('brazil_sctask_url', 'brazil_inc_url', 'brazil_prb_url'),
}


@system_bp.route('/system/servicenow_export/config', methods=['POST'])
@login_required
def save_servicenow_export_config():
    """Salva (parcialmente - só sobrescreve o que veio no JSON) a configuração
    global de URLs de exportação do ServiceNow, mesmo padrão de 'send_dml/save_config'."""
    try:
        _ensure_servicenow_export_columns()
        data = request.get_json() or {}
        config = ServiceNowExportConfig.get_or_create()
        for campo in SERVICENOW_EXPORT_CONFIG_FIELDS:
            if campo in data:
                setattr(config, campo, data[campo])
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Configuração de exportação do ServiceNow salva com sucesso!'})
    except Exception as e:
        db.session.rollback()
        logger.exception(f"Erro ao salvar configuração de exportação do ServiceNow: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@system_bp.route('/system/servicenow_export/download', methods=['POST'])
@login_required
def download_servicenow_export():
    """
    Baixa as 3 planilhas (SCTASK/INC/PRB) do ServiceNow para a região informada,
    usando as URLs salvas em 'ServiceNowExportConfig'. Qualquer tela pode chamar
    este endpoint (não é exclusivo do Dashboard) - ver docstring do bloco acima.

    Roda via Playwright (login Okta/MFA reaproveitado - ver
    'tools.servicenow_export_downloader'), seguindo o MESMO padrão assíncrono
    (asyncio.new_event_loop + job_registry) já usado por Portal Task/Release Task,
    inclusive com suporte ao botão "Cancelar" compartilhado (POST /system/cancel_job)
    via 'job_id' opcional gerado no navegador.
    """
    _ensure_servicenow_export_columns()
    data = request.get_json() or {}
    region = (data.get('region') or '').strip().upper()
    if region not in REGION_URL_FIELDS:
        return jsonify({'status': 'error', 'message': f"Região inválida: '{region}'. Use 'MEX' ou 'BRAZIL'."}), 400

    config = ServiceNowExportConfig.get_or_create()
    sctask_field, inc_field, prb_field = REGION_URL_FIELDS[region]
    urls = {
        'SCTASK': getattr(config, sctask_field) or '',
        'INC': getattr(config, inc_field) or '',
        'PRB': getattr(config, prb_field) or '',
    }

    if not any(urls.values()):
        return jsonify({
            'status': 'error',
            'message': f"Nenhuma URL de exportação configurada para a região {region}. "
                       f"Configure as 3 URLs (SCTASK/INC/PRB) antes de continuar."
        }), 400

    job_id = (data.get('job_id') or '').strip()
    headless = bool(data.get('headless', False))

    # Baixa direto para 'path_temp' (pasta temporária padrão do projeto - ver
    # tools/temp_storage.py), limpando TUDO que já estiver lá antes de começar -
    # inclusive arquivos de outros módulos (screenshots de reset, SQL gerado,
    # scripts de DML pendentes). Região não tem mais subpasta própria: baixar
    # outra região depois sobrescreve os xlsx da anterior - comportamento pedido
    # explicitamente (path_temp "plano", 1 região por vez).
    dest_dir = create_path_temp()
    for nome_antigo in os.listdir(dest_dir):
        caminho_antigo = os.path.join(dest_dir, nome_antigo)
        try:
            if os.path.isfile(caminho_antigo) or os.path.islink(caminho_antigo):
                os.remove(caminho_antigo)
            elif os.path.isdir(caminho_antigo):
                shutil.rmtree(caminho_antigo)
        except Exception as e_clean:
            logger.warning(f"⚠️ [ServiceNowExport] Falha ao limpar '{caminho_antigo}' de path_temp: {e_clean}")

    downloader = ServiceNowExportDownloader()

    if job_id:
        job_registry.register(job_id, current_user.id, module='system.servicenow_export')

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    if job_id:
        job_registry.set_loop(job_id, loop)

    try:
        resultados = loop.run_until_complete(
            downloader.baixar_planilhas(
                urls, dest_dir, job_id=job_id or None, headless=headless,
                validation_url=config.validation_url or '',
            )
        )
    except Exception as e:
        logger.exception(f"Erro ao baixar exports do ServiceNow (região={region}): {e}")
        return jsonify({'status': 'error', 'message': f'Falha inesperada ao baixar planilhas: {e}'}), 500
    finally:
        loop.close()

    falhas = {label: r['error'] for label, r in resultados.items() if r.get('status') != 'success'}
    if falhas:
        logger.warning(f"⚠️ [ServiceNowExport] Falha(s) ao baixar região {region}: {falhas}")
        return jsonify({
            'status': 'error',
            'message': 'Falha ao baixar ' + ', '.join(f"{label} ({erro})" for label, erro in falhas.items()),
            'region': region,
            'results': resultados,
        }), 502

    logger.info(f"✅ [ServiceNowExport] 3 planilha(s) baixada(s) com sucesso para a região {region}.")
    return jsonify({
        'status': 'success',
        'message': f'Planilhas SCTASK/INC/PRB da região {region} baixadas com sucesso.',
        'region': region,
        'results': resultados,
    })

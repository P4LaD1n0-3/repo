import os
import base64
import logging
from flask import Blueprint, redirect, url_for, request, jsonify
from flask_login import login_required
from tools.servicenow_export_downloader import FILENAMES
from tools.temp_storage import create_path_temp

logger = logging.getLogger("Dash")

current_dir = os.path.dirname(os.path.abspath(__file__))
dash_bp = Blueprint('dash', __name__, template_folder=current_dir)


@dash_bp.route('/dash')
@login_required
def launcher():
    """
    '/dash' existe só por compatibilidade com links/favoritos antigos - a tela
    separada de launcher foi unificada dentro de 'Email report' (ver
    'email_report.html', seção "Abrir Dashboard") para não duplicar navegação
    no app (Região Alvo + URLs de exportação + abrir/baixar dashboard, tudo
    numa tela só).
    """
    return redirect(url_for('email_report.index'))


@dash_bp.route('/dash/auto_data')
@login_required
def auto_data():
    """
    Serve as últimas planilhas baixadas (via '/system/servicenow_export/download')
    como JSON (base64), para 'index.html' consumir no carregamento automático
    (?autoload=1) - ver 'autoLoadServerData()'.
    """
    region = (request.args.get('region') or '').strip().upper()

    # 'path_temp' é ÚNICA (sem subpasta por região - ver '/system/servicenow_export/download')
    # - reflete sempre a última região baixada, seja qual for. 'region' aqui só
    # identifica a resposta/logs, não influencia mais onde os arquivos são lidos.
    export_dir = create_path_temp()

    files = []
    for label, filename in FILENAMES.items():
        file_path = os.path.join(export_dir, filename)
        if not os.path.exists(file_path):
            continue
        try:
            with open(file_path, 'rb') as f:
                content_base64 = base64.b64encode(f.read()).decode('ascii')
            files.append({'label': label, 'name': filename, 'content_base64': content_base64})
        except Exception as e:
            logger.warning(f"⚠️ [Dash] Falha ao ler '{file_path}' para auto_data: {e}")

    if not files:
        return jsonify({
            'status': 'error',
            'message': f'Nenhuma planilha encontrada para a região {region}.',
            'files': [],
        }), 404

    return jsonify({'status': 'success', 'region': region, 'files': files})

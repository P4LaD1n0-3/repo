import os
import logging
from difflib import SequenceMatcher
from typing import Dict, Any, Optional, Tuple, Union
from dotenv import load_dotenv
from playwright.async_api import Locator, Page
from tools.base_automation import BaseAutomation, SelectorManager
from tools.temp_storage import create_path_temp
from tools.validators import normalizar_texto

logger = logging.getLogger("UpmDriver")

# Sigla -> nome completo do estado, para o <select> de estado no cadastro de
# Corretora/Organização no UPM (mesmo dicionário de 'cadastro_usuario.txt').
ESTADOS_BR: Dict[str, str] = {
    "AC": "Estado do Acre",
    "AL": "Estado de Alagoas",
    "AP": "Estado do Amapa",
    "AM": "Estado do Amazonas",
    "BA": "Estado da Bahia",
    "CE": "Estado do Ceara",
    "DF": "Distrito Federal",
    "ES": "Estado de Espirito Santo",
    "GO": "Estado de Goias",
    "MA": "Estado do Maranhao",
    "MT": "Estado de Mato Grosso",
    "MS": "Estado de Mato Grosso do Sul",
    "MG": "Estado de Minas Gerais",
    "PA": "Estado do Para",
    "PB": "Estado da Paraiba",
    "PR": "Estado do Parana",
    "PE": "Estado de Pernambuco",
    "PI": "Estado do Piaui",
    "RJ": "Estado do Rio de Janeiro",
    "RN": "Estado do Rio Grande do Norte",
    "RS": "Estado do Rio Grande do Sul",
    "RO": "Estado de Rondonia",
    "RR": "Estado de Roraima",
    "SC": "Estado de Santa Catarina",
    "SP": "Estado de Sao Paulo",
    "SE": "Estado de Sergipe",
    "TO": "Estado de Tocantins",
}


def get_estado(sigla: Optional[str]) -> Optional[str]:
    """Converte a sigla (UF) no nome completo esperado pelo <select> de estado do UPM."""
    return ESTADOS_BR.get((sigla or "").strip().upper())


class UpmDriver(BaseAutomation):
    """
    ============================================================================
    DRIVER ESPECIALIZADO: AUTOMAÇÕES NO PORTAL UPM / PUMA
    ============================================================================
    Classe orientada a objetos especialista responsável por todas as rotinas no UPM.

    MÉTODOS PRIMITIVOS (reutilizados entre Cadastro, Alterar usuário e Reset de
    senha/MFA - eliminam a duplicação que existia entre os 3 fluxos no script
    legado, cada um com sua própria cópia de "buscar usuário"/"trocar status"):
        - `dividir_nome`: separa nome completo em primeiro/último nome.
        - `buscar_e_selecionar_usuario_upm`: menu 'Gerenciar usuário' -> busca -> seleciona.
        - `definir_status_conta_upm`: Ativo/Inativo com o mesmo laço de confirmação
          por 'sucesso' na mensagem usado em 'update_usuario.txt' (o UPM às vezes
          não aplica a alteração na primeira tentativa).
        - `vincular_organizacao_susep_upm`: busca+seleciona organização, adiciona
          SUSEP e vincula a designação 'Empresas'.

    MÉTODOS DE ORQUESTRAÇÃO (alto nível, compõem os primitivos acima):
        1. Login de Administrador UPM (`login_upm`)
        2. Cadastro de Usuários (`cadastrar_usuario_upm`)
        3. Reset de Senha / MFA com evidência screenshot (`resetar_senha_mfa_upm`)
        4. Gerenciamento de Status de Usuário Ativo/Inativo (`gerenciar_status_usuario_upm`)
        5. Cadastro de Corretoras / Organizações (`cadastrar_corretora_upm`)

    Herda de BaseAutomation e utiliza seletores desacoplados do servicenow_paths.json.
    """

    DEFAULT_UPM_URL = "https://upm-int.aig.net/puma/"
    DEFAULT_RESET_URL = "https://upm-int.aig.net/puma/jsf/ext/lar/resetLarUserPwd.jspx"
    SENHA_SENTINELA = "n_gerou_senha"
    MAX_TENTATIVAS_RESET = 5
    MAX_TENTATIVAS_STATUS = 6
    MAX_TENTATIVAS_SELECIONAR_ORGANIZACAO = 3

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)
        # Busca o .env a partir da raiz do projeto (find_dotenv sobe os diretórios a
        # partir deste arquivo) - o caminho fixo antigo 'src/documents/.env' não existe
        # nesta estrutura de projeto e fazia 'usuario_upm'/'senha_upm' sempre virem None.
        load_dotenv()

    # ========================================================================
    # LOGIN
    # ========================================================================

    async def login_upm(
        self,
        page: Page,
        username: Optional[str] = None,
        password: Optional[str] = None,
        url: Optional[str] = None
    ) -> bool:
        """
        Realiza a autenticação no portal UPM/PUMA com credenciais do .env ou parâmetros fornecidos.
        """
        login_url = url or self.DEFAULT_UPM_URL
        user = username or os.getenv("usuario_upm")
        pwd = password or os.getenv("senha_upm")

        logger.info(f"🔐 [UpmDriver] Efetuando login no UPM ({login_url}) com usuário: {user}")

        try:
            await page.goto(login_url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(1000)

            # Preenche login e senha via seletores desacoplados
            if user:
                await self.fill_input(page, "upm_username", user)
            if pwd:
                await self.fill_input(page, "upm_password", pwd)

            await self.click_element(page, "upm_login_btn")
            await page.wait_for_timeout(2000)

            logger.info("✅ [UpmDriver] Login efetuado no UPM com sucesso.")
            return True
        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao efetuar login no UPM: {e}")
            raise e

    async def _ler_mensagem_upm(self, page: Page, timeout: int = 10000) -> str:
        """
        Lê a mensagem de retorno do UPM (componente '<ul id="adminUI:messages">').

        Substitui os antigos pontos onde uma exceção ao ler a mensagem era
        SILENCIOSAMENTE trocada por um texto fixo inventado (ex.: "Usuário
        cadastrado") - isso fazia a máquina de estados do cadastro nunca
        reconhecer o retorno real do UPM e pular o reset de senha/MFA. Agora,
        em caso de falha, devolve string vazia e REGISTRA um aviso, em vez de
        fabricar uma mensagem que não corresponde a nada.

        Junta o texto de TODOS os '<li>' do componente (em vez de olhar só o
        primeiro ou um índice fixo) - o script legado às vezes lia o item [1]
        e não o [0] porque esse componente pode renderizar um '<li>' vazio/
        decorativo antes do texto real; concatenar e filtrar os vazios é
        robusto independente da posição exata em cada tela do UPM.
        """
        try:
            selector = self.get_selector("upm_message_result")
            locator = page.locator(selector)
            await locator.first.wait_for(state="attached", timeout=timeout)
            textos = [t.strip() for t in await locator.all_inner_texts() if t and t.strip()]
            mensagem = " ".join(textos)
            if not mensagem:
                logger.warning("⚠️ [UpmDriver] Componente de mensagens do UPM encontrado, porém sem texto.")
            return mensagem
        except Exception as e:
            logger.warning(f"⚠️ [UpmDriver] Não foi possível ler a mensagem de retorno do UPM: {e}")
            return ""

    # ========================================================================
    # PRIMITIVOS REUTILIZÁVEIS
    # ========================================================================

    @staticmethod
    def dividir_nome(nome_completo: str) -> Tuple[str, str]:
        """Separa 'Nome Completo' em (primeiro_nome, sobrenome) - mesma regra usada em
        'cadastro_usuario.txt' e 'update_usuario.txt' (corta no primeiro espaço)."""
        nome_completo = (nome_completo or "").strip()
        if not nome_completo:
            return "", ""
        partes = nome_completo.split(" ", 1)
        return partes[0], (partes[1] if len(partes) > 1 else "")

    async def buscar_e_selecionar_usuario_upm(self, page: Page, email: str) -> Dict[str, Any]:
        """
        Menu 'Gerenciar usuário' -> preenche e-mail -> busca -> seleciona o primeiro
        resultado encontrado. Equivalente ao início de 'updateBrokerUpm' e do laço de
        busca em 'resetRegistro' (reset_senha_mfa_usuario.txt / update_usuario.txt).
        """
        logger.info(f"🔎 [UpmDriver] Buscando usuário no UPM: {email}")
        resultado: Dict[str, Any] = {"email": email, "encontrado": False, "mensagem": None}

        try:
            await self.click_element(page, "upm_menu_manage_user")
            await page.wait_for_timeout(800)

            await self.fill_input(page, "upm_manage_email_search", email)
            await self.click_element(page, "upm_manage_search_btn")
            await page.wait_for_timeout(1200)

            mensagem = await self._ler_mensagem_upm(page)

            if mensagem and "Nenhum Registro Encontrado" in mensagem:
                resultado["mensagem"] = mensagem
                logger.warning(f"⚠️ [UpmDriver] Usuário '{email}' não encontrado no UPM.")
                return resultado

            # A busca por e-mail também pode devolver mais de um resultado - seleciona o
            # que mais se assemelha ao e-mail buscado, em vez de assumir cegamente o
            # índice 0 (mesma robustez aplicada à busca de organização/corretora, usada
            # por 'resolver_cpf_existente', 'alterar_usuario_upm' e o reset de senha/MFA).
            await self._selecionar_melhor_resultado(page, "upm_manage_result_rows", email, timeout=30000)
            resultado["encontrado"] = True
            resultado["mensagem"] = mensagem or None
            logger.info(f"✅ [UpmDriver] Usuário '{email}' localizado e selecionado no UPM.")
        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao buscar usuário '{email}' no UPM: {e}")
            resultado["mensagem"] = str(e)

        return resultado

    # ========================================================================
    # SELEÇÃO ROBUSTA DE RESULTADOS DE BUSCA (ORGANIZAÇÃO/CORRETORA E USUÁRIO)
    # ========================================================================
    # O UPM filtra ambas as buscas (organização por razão social e usuário por
    # e-mail) pelo operador LIKE - por isso pode devolver MAIS DE UM resultado
    # parecido. O script legado (e a 1ª versão desta porta) só reconhecia o
    # índice 0 (`agency_result:0:select_org` / `result:0:select_usr`), então uma
    # busca com múltiplos resultados clicava na linha ERRADA (ou nenhuma, se o
    # índice 0 não fosse o layout renderido). Os métodos abaixo enumeram TODAS as
    # linhas devolvidas e escolhem a mais parecida com o valor buscado.

    @staticmethod
    def _similaridade_texto(candidato: str, alvo: str) -> float:
        """
        Pontua (0..1) a semelhança entre o texto de uma linha de resultado e o valor
        buscado, tolerante a acento/caixa (via 'normalizar_texto'). Usada para
        escolher, entre vários resultados de uma busca LIKE do UPM, o que mais se
        assemelha ao valor procurado - em vez de assumir cegamente o 1º resultado.
        """
        candidato_norm = normalizar_texto(candidato)
        alvo_norm = normalizar_texto(alvo)
        if not candidato_norm or not alvo_norm:
            return 0.0
        if alvo_norm in candidato_norm:
            return 1.0
        pontuacao = SequenceMatcher(None, candidato_norm, alvo_norm).ratio()
        if candidato_norm.startswith(alvo_norm) or alvo_norm.startswith(candidato_norm):
            pontuacao = max(pontuacao, 0.9)
        return pontuacao

    @staticmethod
    async def _texto_da_linha(linha: Locator) -> str:
        """Texto completo da linha/registro (<tr> ancestral) que contém o botão/input de seleção."""
        try:
            return (await linha.locator("xpath=ancestor::tr[1]").inner_text()).strip()
        except Exception:
            return ""

    async def _selecionar_melhor_resultado(
        self, page: Page, selector_key: str, valor_buscado: str, timeout: int = 15000
    ) -> str:
        """
        Aguarda a(s) linha(s) de resultado de uma busca no UPM (organização OU
        usuário, conforme 'selector_key') ficarem visíveis e clica na que tiver o
        texto mais parecido com 'valor_buscado'. Com um único resultado, seleciona-o
        diretamente (sem gastar tempo comparando). Propaga a exceção de timeout do
        Playwright quando NENHUM resultado aparece a tempo (mesmo comportamento do
        'wait_for_element' que este método substitui - quem chama já trata isso).
        """
        selector = self.get_selector(selector_key)
        linhas = page.locator(selector)
        await linhas.first.wait_for(state="visible", timeout=timeout)
        total = await linhas.count()

        if total == 1:
            texto = await self._texto_da_linha(linhas.first)
            await linhas.first.click(timeout=timeout)
            return texto or valor_buscado

        melhor_idx = 0
        melhor_texto = ""
        melhor_pontuacao = -1.0
        for idx in range(total):
            texto_linha = await self._texto_da_linha(linhas.nth(idx))
            pontuacao = self._similaridade_texto(texto_linha, valor_buscado)
            logger.info(
                f"🔎 [UpmDriver] Resultado #{idx} para '{valor_buscado}': "
                f"'{texto_linha[:80]}' (similaridade={pontuacao:.2f})"
            )
            if pontuacao > melhor_pontuacao:
                melhor_pontuacao, melhor_idx, melhor_texto = pontuacao, idx, texto_linha

        logger.info(
            f"✅ [UpmDriver] {total} resultado(s) retornado(s) pela busca (LIKE) - selecionando #{melhor_idx} "
            f"(similaridade={melhor_pontuacao:.2f}) para '{valor_buscado}'."
        )
        await linhas.nth(melhor_idx).click(timeout=timeout)
        return melhor_texto or valor_buscado

    async def _fechar_popup_busca_organizacao(self, page: Page) -> None:
        """
        Fecha o popup/modal de busca de organização, se ainda estiver aberto de uma
        tentativa anterior. Sem isto, o campo/botão de busca da tela principal
        ('upm_org_search'/'upm_org_find_btn') ficam bloqueados atrás do modal e a
        tentativa seguinte de buscar+selecionar nunca chega a ser efetivada (bug
        relatado em produção: o retry pula para a próxima tentativa, mas a tela do
        modal vigente não é encerrada). Tenta o botão "Cancelar" do popup primeiro
        e, se não existir/não responder, o "X" do cabeçalho do popup - falha
        silenciosamente se nenhum dos dois estiver presente (o popup já pode ter
        sido fechado automaticamente ao selecionar um resultado).
        """
        for selector_key in ("upm_org_popup_cancel_btn", "upm_org_popup_close_btn"):
            try:
                await self.click_element(page, selector_key, timeout=2000)
                await page.wait_for_timeout(300)
                logger.info(f"ℹ️ [UpmDriver] Popup de busca de organização fechado via '{selector_key}'.")
                return
            except Exception:
                continue

    async def definir_status_conta_upm(
        self, page: Page, status: str, max_tentativas: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Define o status Ativo ('A')/Inativo ('I') da conta ASSUMINDO que a página de
        edição do usuário já está aberta (após 'buscar_e_selecionar_usuario_upm').
        Repete seleção+salvar até confirmar 'sucesso' na mensagem de retorno - mesmo
        laço 'while True: ... if inativacao contains sucesso or tentativas>6: break'
        de 'update_usuario.txt' (o UPM às vezes não aplica a troca na 1ª tentativa).
        """
        max_tentativas = max_tentativas or self.MAX_TENTATIVAS_STATUS
        logger.info(f"⚙️ [UpmDriver] Definindo status da conta para '{status}' (máx. {max_tentativas} tentativa(s))...")
        resultado: Dict[str, Any] = {"status_alvo": status, "status": "success", "mensagem": None, "tentativas": 0}

        for tentativa in range(1, max_tentativas + 1):
            resultado["tentativas"] = tentativa
            mensagem = await self._ler_mensagem_upm(page)

            if "sucesso" in (mensagem or "").lower():
                resultado["mensagem"] = mensagem
                logger.info(f"✅ [UpmDriver] Status '{status}' confirmado na tentativa {tentativa}.")
                return resultado

            try:
                await self.select_option(page, "upm_account_status_select", status)
                await self.click_element(page, "upm_save_btn")
                await page.wait_for_timeout(1200)
            except Exception as e:
                resultado["mensagem"] = str(e)
                logger.warning(f"⚠️ [UpmDriver] Tentativa {tentativa}/{max_tentativas} de definir status falhou: {e}")

        resultado["status"] = "error"
        logger.error(f"❌ [UpmDriver] Não foi possível confirmar o status '{status}' após {max_tentativas} tentativa(s).")
        return resultado

    async def vincular_organizacao_susep_upm(
        self, page: Page, razao_social: str, susep: str, vincular_empresas: bool = True
    ) -> Dict[str, Any]:
        """
        Busca+seleciona a organização pelo início da razão social, adiciona o SUSEP
        (com o clique de 'forçar adicionar' de fallback) e vincula a designação
        'Empresas' - trecho extraído de 'cadastrar_usuario_upm' para ser reaproveitado
        também por 'Alterar usuário' (branch 'nova_razao' de update_usuario.txt).
        """
        logger.info(f"🏢 [UpmDriver] Vinculando organização '{razao_social}' (SUSEP='{susep}')...")
        resultado: Dict[str, Any] = {"status": "success", "mensagem": None}

        try:
            if razao_social:
                # Porta fiel do 'await4Click' do legado: o clique em "buscar" dispara
                # um POSTBACK completo da página JSF (confirmado em produção pelo log
                # do Playwright: "waiting for .../addLarUser.jspx navigation to
                # finish... navigated to .../addLarUser.jspx") - um único clique com
                # espera fixa de 1s não é suficiente, então repetimos busca+clique até
                # conseguir selecionar a organização, em vez de desistir na 1ª falha.
                organizacao_selecionada = False
                for tentativa in range(1, self.MAX_TENTATIVAS_SELECIONAR_ORGANIZACAO + 1):
                    if tentativa > 1:
                        # Fecha o popup de busca ainda aberto da tentativa anterior -
                        # sem isso, o campo/botão de busca da tela principal ficam
                        # bloqueados atrás do modal e esta nova tentativa nunca chega
                        # a ser efetivada (bug relatado em produção).
                        await self._fechar_popup_busca_organizacao(page)

                    await self.fill_input(page, "upm_org_search", razao_social[:15])
                    await self.click_element(page, "upm_org_find_btn")
                    try:
                        # A busca usa o operador LIKE no UPM e pode devolver mais de
                        # uma corretora com nome parecido - seleciona a que mais se
                        # assemelha à razão social buscada, em vez de assumir
                        # cegamente o 1º resultado (índice 0).
                        texto_selecionado = await self._selecionar_melhor_resultado(
                            page, "upm_org_result_rows", razao_social, timeout=15000
                        )
                        logger.info(f"✅ [UpmDriver] Organização selecionada: '{texto_selecionado}'.")
                        organizacao_selecionada = True
                        break
                    except Exception as e_sel:
                        logger.warning(
                            f"⚠️ [UpmDriver] Tentativa {tentativa}/{self.MAX_TENTATIVAS_SELECIONAR_ORGANIZACAO} "
                            f"de selecionar a organização '{razao_social}' falhou: {e_sel}"
                        )
                        await page.wait_for_timeout(1000)

                if not organizacao_selecionada:
                    # Mesmo assim segue em frente (fiel ao 'except: print(e)' do legado,
                    # que também não interrompe o cadastro) - mas agora com um log
                    # visível de ERRO, para o problema não passar despercebido, e
                    # fechando qualquer popup remanescente para não bloquear os
                    # próximos passos da tela (preencher SUSEP, salvar, etc.).
                    await self._fechar_popup_busca_organizacao(page)
                    logger.error(
                        f"❌ [UpmDriver] Não foi possível clicar na organização encontrada para "
                        f"'{razao_social}' após {self.MAX_TENTATIVAS_SELECIONAR_ORGANIZACAO} tentativa(s)."
                    )

            susep_val = susep or "000000000"
            await self.fill_input(page, "upm_susep_input", susep_val)
            await self.click_element(page, "upm_addsusep_btn")
            try:
                await self.click_element(page, "upm_addsusep_force_btn")
            except Exception:
                pass

            if vincular_empresas:
                try:
                    await self.click_element(page, "upm_designation_option")
                    await self.click_element(page, "upm_designation_add_btn")
                except Exception as e_desig:
                    logger.warning(f"⚠️ [UpmDriver] Aviso ao vincular designação 'Empresas': {e_desig}")

        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao vincular organização/SUSEP: {e}")
            resultado["status"] = "error"
            resultado["mensagem"] = str(e)

        return resultado

    async def preencher_dados_pessoais_upm(
        self, page: Page, email: Optional[str] = None, nome_completo: Optional[str] = None, cpf: Optional[str] = None
    ) -> None:
        """Preenche e-mail/CPF/nome+sobrenome na página de edição do usuário (usada tanto
        ao ADICIONAR quanto ao ALTERAR - mesmos campos do formulário no UPM)."""
        if email:
            await self.fill_input(page, "upm_user_email", email)
        if cpf:
            await self.fill_input(page, "upm_user_cpf", cpf)
        if nome_completo:
            primeiro, ultimo = self.dividir_nome(nome_completo)
            await self.fill_input(page, "upm_user_first_name", primeiro)
            await self.fill_input(page, "upm_user_last_name", ultimo)

    # ========================================================================
    # ORQUESTRAÇÃO DE ALTO NÍVEL
    # ========================================================================

    async def cadastrar_usuario_upm(self, page: Page, dados_usuario: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cadastra um novo usuário no portal UPM (E-mail, CPF, Nome, Razão Social, SUSEP, Permissões).
        """
        email = dados_usuario.get("email_master", "").strip()
        cpf = dados_usuario.get("cpf", "").strip()
        nome_completo = dados_usuario.get("nome_completo", "").strip()
        razao_social = dados_usuario.get("razao_social", "").strip()
        susep = dados_usuario.get("susep", "").strip()
        is_assessoria = dados_usuario.get("is_assessoria", False)

        logger.info(f"👤 [UpmDriver] Cadastrando usuário UPM: Email='{email}' | CPF='{cpf}'")

        res: Dict[str, Any] = {
            "email": email,
            "cpf": cpf,
            "status": "success",
            "mensagem": None,
            "senha_gerada": None
        }

        try:
            # Navega até o menu 'Adicionar Usuário'
            await self.click_element(page, "upm_menu_add_user")
            await page.wait_for_timeout(1000)

            await self.preencher_dados_pessoais_upm(page, email=email, nome_completo=nome_completo, cpf=cpf)

            # Busca e associa Organização / Corretora + SUSEP + designação 'Empresas'
            susep_val = "000000000" if is_assessoria else susep
            await self.vincular_organizacao_susep_upm(page, razao_social=razao_social, susep=susep_val)

            # Salva o cadastro
            await self.click_element(page, "upm_save_btn")
            await page.wait_for_timeout(2000)

            # Obtém a mensagem de retorno do UPM. IMPORTANTE: nunca inventar um
            # texto de fallback aqui - um texto fabricado não bate com nenhum
            # dos estados tratados por 'processar_resultado_cadastro_upm' e faz
            # o cadastro cair silenciosamente em "mensagem não tratada", sem
            # disparar o reset de senha/MFA (bug já observado em produção).
            msg = await self._ler_mensagem_upm(page)
            res["mensagem"] = msg
            logger.info(f"📢 [UpmDriver] Mensagem do UPM: {msg}")

            logger.info(f"✅ [UpmDriver] Cadastro de usuário finalizado para {email}")

        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao cadastrar usuário {email}: {e}")
            res["status"] = "error"
            res["mensagem"] = str(e)

        return res

    async def resetar_senha_mfa_upm(
        self,
        page: Page,
        email: str,
        type_reset: str = "reset",
        save_screenshot: bool = True
    ) -> Dict[str, Any]:
        """
        Executa a troca/reset de senha ou reset de MFA no UPM para o e-mail informado e tira screenshot de evidência.

        Baseado no 'resetRegistro' de reset_senha_mfa_usuario.txt: o UPM às vezes confirma o
        clique sem retornar a senha na mensagem — por isso a confirmação é repetida até
        obter uma senha válida (ou esgotar as tentativas), em vez de aceitar a sentinela
        'n_gerou_senha' na primeira resposta.
        """
        logger.info(f"🔑 [UpmDriver] Executando Reset ('{type_reset}') no UPM para: {email}")
        res: Dict[str, Any] = {
            "email": email,
            "type_reset": type_reset,
            "senha_gerada": None,
            "screenshot_path": None,
            "status": "success",
            "error": None
        }

        try:
            # Navega até a página de reset de senha do LAR/UPM
            await page.goto(self.DEFAULT_RESET_URL, wait_until="domcontentloaded", timeout=30000)
            await self.fill_input(page, "upm_reset_email_input", email)
            await self.click_element(page, "upm_reset_search_btn")
            await page.wait_for_timeout(1500)

            # Verifica se o e-mail informado é válido/ativo (mesma checagem de 'resetRegistro':
            # a mensagem de retorno contém 'ativo' quando a conta já está pronta para reset).
            mensagem_busca = await self._ler_mensagem_upm(page)

            # Porta fiel de 'resetRegistro' (reset_senha_mfa_usuario.txt): quando a
            # mensagem da 1ª busca menciona "ativo" (cobre tanto "conta ativa"
            # quanto "usuário não está ativo" - ambas contêm o substring), o UPM só
            # aceita o clique em "Reset MFA" depois de uma SEGUNDA busca, agora com
            # o e-mail em MAIÚSCULAS. Sem essa 2ª busca, o botão de reset não reage.
            if "ativo" in mensagem_busca.lower():
                await self.fill_input(page, "upm_reset_email_input", email.upper())
                await self.click_element(page, "upm_reset_search_btn")
                await page.wait_for_timeout(1500)

            # Executa a ação de reset de MFA ou geração de Senha
            if type_reset.lower() == "reset":
                # Clica no botão de Reset MFA primeiro
                try:
                    await self.click_element(page, "upm_reset_mfa_btn")
                    await page.wait_for_timeout(1000)
                except Exception:
                    pass

                senha_gerada = self.SENHA_SENTINELA
                for tentativa in range(1, self.MAX_TENTATIVAS_RESET + 1):
                    # Clica no botão de Confirmação de Gerar Nova Senha
                    await self.click_element(page, "upm_reset_confirm_pwd_btn")
                    await page.wait_for_timeout(1500)

                    raw_text = await self._ler_mensagem_upm(page)
                    if ": " in raw_text:
                        senha_gerada = raw_text.split(": ", 1)[1].strip()
                    else:
                        senha_gerada = raw_text.strip() or self.SENHA_SENTINELA

                    if senha_gerada and senha_gerada != self.SENHA_SENTINELA:
                        break

                    logger.warning(
                        f"⚠️ [UpmDriver] Tentativa {tentativa}/{self.MAX_TENTATIVAS_RESET} não retornou senha válida para '{email}'."
                    )
                    await page.wait_for_timeout(500)

                if senha_gerada == self.SENHA_SENTINELA:
                    res["status"] = "error"
                    res["error"] = f"Não foi possível gerar senha para '{email}' após {self.MAX_TENTATIVAS_RESET} tentativa(s)."
                    logger.error(f"❌ [UpmDriver] {res['error']}")

                res["senha_gerada"] = senha_gerada
                res["mensagem_busca"] = mensagem_busca
            else:
                # Reset exclusivo de MFA
                await self.click_element(page, "upm_reset_mfa_btn")
                await page.wait_for_timeout(1000)
                res["senha_gerada"] = "MFA_Resetado"
                res["mensagem_busca"] = mensagem_busca

            # Salva screenshot de evidência na pasta temporária padrão do projeto ('path_temp')
            if save_screenshot:
                ss_path = os.path.join(create_path_temp(), f"{email.replace('@', '_at_')}.png")
                await self.take_screenshot(page, ss_path)
                res["screenshot_path"] = ss_path

            logger.info(f"✅ [UpmDriver] Reset de {email} concluído. Resultado: {res['senha_gerada']}")

        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao resetar {email}: {e}")
            res["status"] = "error"
            res["error"] = str(e)

        return res

    async def gerenciar_status_usuario_upm(self, page: Page, email: str, status: str = "A") -> Dict[str, Any]:
        """
        Altera o status da conta do usuário no UPM ("A" = Ativo, "I" = Inativo).
        Composição de 'buscar_e_selecionar_usuario_upm' + 'definir_status_conta_upm'.
        """
        logger.info(f"⚙️ [UpmDriver] Alterando status da conta de '{email}' para '{status}'...")

        busca = await self.buscar_e_selecionar_usuario_upm(page, email)
        if not busca["encontrado"]:
            return {"email": email, "status": status, "resultado": "error", "error": busca["mensagem"] or "Usuário não encontrado no UPM."}

        await page.wait_for_timeout(500)
        confirmacao = await self.definir_status_conta_upm(page, status)

        return {
            "email": email,
            "status": status,
            "resultado": confirmacao["status"],
            "mensagem": confirmacao["mensagem"],
            "error": None if confirmacao["status"] == "success" else confirmacao["mensagem"],
        }

    async def cadastrar_corretora_upm(self, page: Page, dados_corretora: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cadastra uma nova Corretora / Organização no portal UPM.
        """
        nome = dados_corretora.get("nome_organizacao", "")
        endereco_1 = dados_corretora.get("endereco_1", "")
        endereco_2 = dados_corretora.get("endereco_2", "")
        cidade = dados_corretora.get("cidade", "")
        cep = dados_corretora.get("cep", "")
        estado_sigla = dados_corretora.get("estado", "")

        logger.info(f"🏢 [UpmDriver] Cadastrando Corretora/Organização no UPM: {nome}")
        res: Dict[str, Any] = {"nome": nome, "status": "success"}

        try:
            await self.click_element(page, "upm_menu_add_org")
            await page.wait_for_timeout(1000)

            await self.fill_input(page, "upm_org_name_input", nome)
            await self.fill_input(page, "upm_org_address1_input", endereco_1)
            await self.fill_input(page, "upm_org_address2_input", endereco_2)
            await self.fill_input(page, "upm_org_city_input", cidade)
            await self.fill_input(page, "upm_org_cep_input", cep)

            estado_nome = get_estado(estado_sigla)
            if estado_nome:
                try:
                    # Seleciona pelo TEXTO visível da opção (equivalente a
                    # 'Select(...).select_by_visible_text()' do script legado) -
                    # 'select_option' por padrão casa pelo atributo 'value', não pelo texto.
                    await self.select_option(page, "upm_org_state_select", {"label": estado_nome})
                except Exception as e_estado:
                    logger.warning(f"⚠️ [UpmDriver] Aviso ao selecionar estado '{estado_nome}': {e_estado}")

            await page.wait_for_timeout(500)
            await self.click_element(page, "upm_save_btn")
            await page.wait_for_timeout(2000)

            res["mensagem"] = await self._ler_mensagem_upm(page) or None

            logger.info(f"✅ [UpmDriver] Corretora '{nome}' cadastrada no UPM com sucesso.")
        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao cadastrar corretora {nome}: {e}")
            res["status"] = "error"
            res["error"] = str(e)

        return res

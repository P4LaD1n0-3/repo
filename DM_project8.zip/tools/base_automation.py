import os
import json
import logging
import asyncio
import weakref
from typing import Any, Optional, Union, List, Dict

from playwright.async_api import (
    async_playwright,
    BrowserContext,
    Page,
    FrameLocator,
    Locator,
    TimeoutError as PlaywrightTimeoutError
)

logger = logging.getLogger("BaseAutomation")

class SelectorManager:
    """
    Gerenciador desacoplado de seletores (Paths) de elementos web.
    Integrado à arquitetura base de automação para carregar paths de:
    - Dicionário Python direto
    - Arquivo JSON externo (editável como um .env)
    - Variáveis de ambiente
    """

    DEFAULT_CONFIG_PATH = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "config",
        "servicenow_paths.json"
    )

    def __init__(self, paths: Optional[Union[Dict[str, str], str]] = None):
        """
        Inicializa o gerenciador de seletores.
        :param paths: Pode ser um dicionário {"key": "selector"}, o caminho para um JSON ou None para carregar o default.
        """
        self._selectors: Dict[str, str] = {}
        
        if isinstance(paths, dict):
            self._selectors = paths.copy()
            logger.info(f"SelectorManager inicializado com dicionário contendo {len(self._selectors)} seletores.")
        elif isinstance(paths, str) and os.path.exists(paths):
            self.load_from_json(paths)
        elif os.path.exists(self.DEFAULT_CONFIG_PATH):
            self.load_from_json(self.DEFAULT_CONFIG_PATH)
        else:
            logger.warning("Nenhum arquivo ou dicionário de seletores foi fornecido. SelectorManager iniciado vazio.")

    def load_from_json(self, filepath: str) -> Dict[str, str]:
        """Carrega e mescla seletores a partir de um arquivo JSON."""
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    self._selectors.update(data)
                    logger.info(f"✅ Seletores carregados com sucesso de '{filepath}' ({len(data)} itens).")
                else:
                    raise ValueError("O conteúdo do JSON deve ser um objeto/dicionário chave-valor.")
        except Exception as e:
            logger.error(f"❌ Erro ao carregar arquivo de seletores '{filepath}': {e}")
            raise e
        return self._selectors

    def get(self, key: str, fallback_selector: Optional[str] = None) -> str:
        """
        Obtém o seletor correspondente à chave informada.
        Lança KeyError se a chave não existir e não for um seletor direto.
        """
        if key in self._selectors:
            return self._selectors[key]
        
        if fallback_selector:
            logger.warning(f"⚠️ Chave de seletor '{key}' não encontrada no dicionário. Usando fallback: '{fallback_selector}'")
            return fallback_selector
        
        # Se a chave informada já parecer um seletor Playwright/CSS/XPath (ex: contiver '#', '.', '//', 'iframe'),
        # permite o uso logando um aviso, para flexibilidade.
        if any(char in key for char in ["#", ".", "//", "[", ">", "="]):
            logger.warning(f"⚠️ Chave '{key}' não encontrada no dicionário de paths, mas parece um seletor direto. Utilizando como seletor.")
            return key

        available_keys = ", ".join(list(self._selectors.keys())[:10])
        raise KeyError(
            f"❌ Chave de seletor '{key}' não encontrada no dicionário de paths! "
            f"Chaves disponíveis: [{available_keys}...]. "
            f"Edite seu arquivo de configuração de paths para adicionar esta chave."
        )

    def set(self, key: str, selector: str):
        """Define ou atualiza um seletor dinamicamente."""
        self._selectors[key] = selector

    def get_all(self) -> Dict[str, str]:
        """Retorna uma cópia de todos os seletores cadastrados."""
        return self._selectors.copy()


class BaseAutomation:
    """
    Classe base orientada a objetos para automações web com Playwright.
    Gerencia contexto do navegador, escopos de iFrame e injeção de dicionário desacoplado de paths.
    Pode ser estendida via herança por qualquer módulo da aplicação.
    """

    DEFAULT_USER_DATA_DIR = "./playwright_user_data"

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        """
        Inicializa a automação com suporte a dicionário de paths configurável.
        :param selectors: Dicionário {"key": "selector"}, instância de SelectorManager ou caminho para JSON.
        :param user_data_dir: Diretório de perfil/cookies persistente do Playwright.
        """
        if isinstance(selectors, SelectorManager):
            self.selector_manager = selectors
        else:
            self.selector_manager = SelectorManager(paths=selectors)

        self.user_data_dir = user_data_dir or self.DEFAULT_USER_DATA_DIR
        os.makedirs(self.user_data_dir, exist_ok=True)

        # Cache do escopo de iFrame (gsft_main) já resolvido por página - evita repetir a
        # espera de até 'timeout' ms em toda chamada auxiliar (fill/click/select/etc.) quando
        # o escopo já foi validado (com sucesso OU com fallback) para a página atual.
        # Invalidado automaticamente a cada navegação real de topo (evento 'framenavigated'
        # do Playwright) - equivalente a validar o iFrame uma única vez por navegação real,
        # como no legado ('switch_to.frame' chamado uma vez, não a cada campo acessado).
        self._iframe_scope_cache: "weakref.WeakKeyDictionary" = weakref.WeakKeyDictionary()
        self._pages_com_listener_navegacao: "weakref.WeakSet" = weakref.WeakSet()

        # Identificador do job de automação atual (ver 'tools.job_registry'). Definido ao
        # chamar 'launch_persistent_context(..., job_id=...)'; permite que o botão "Cancelar"
        # de qualquer tela encerre à força esta automação, por herança, sem código extra
        # em nenhuma classe filha (ServiceNowDriver, ReleaseOpenService, TaskEncerrarService, etc.).
        self.job_id: Optional[str] = None

    def get_selector(self, key_or_selector: str) -> str:
        """Resolve uma chave do dicionário de paths para o seletor correspondente."""
        return self.selector_manager.get(key_or_selector)

    async def launch_persistent_context(
        self,
        p,
        headless: bool = False,
        viewport: Optional[dict] = None,
        job_id: Optional[str] = None
    ) -> BrowserContext:
        """
        Inicia um contexto de navegador persistente para armazenar cookies, tokens e sessão.

        :param job_id: identificador do job de automação (ver 'tools.job_registry'). Quando
            informado, registra este contexto no 'JobRegistry' compartilhado - é isso que
            permite que o botão "Cancelar" de QUALQUER tela encerre à força este navegador.
        """
        viewport = viewport or {"width": 1280, "height": 800}
        logger.info(f"Iniciando navegador persistente em '{self.user_data_dir}' (headless={headless})...")

        if job_id:
            self.job_id = job_id

        context = await p.chromium.launch_persistent_context(
            user_data_dir=self.user_data_dir,
            headless=headless,
            args=["--disable-blink-features=AutomationControlled"],
            viewport=viewport
        )

        if self.job_id:
            from tools.job_registry import job_registry
            job_registry.attach_context(self.job_id, context)

        return context

    def _invalidar_escopo_iframe(self, page: Page, frame) -> None:
        """Limpa o cache de escopo quando a página principal (top-level) navega de fato."""
        if frame == page.main_frame and self._iframe_scope_cache.pop(page, None) is not None:
            logger.debug("Navegação da página principal detectada - cache de escopo de iFrame invalidado.")

    async def get_iframe_scope(
        self,
        page: Page,
        iframe_key_or_selector: str = "gsft_main",
        timeout: int = 20000,
        force_refresh: bool = False
    ) -> Union[Page, FrameLocator]:
        """
        Identifica se a página contém um iFrame e retorna o escopo do FrameLocator.
        Converte a chave informada pelo dicionário de paths ou usa fallback seguro.

        O resultado é CACHEADO por página: a primeira chamada após cada navegação de topo
        (page.goto) faz a espera/detecção real; chamadas subsequentes na MESMA página (sem
        navegação nova) reaproveitam o escopo já validado - iFrame OU fallback de página
        principal - sem esperar novamente. Isso evita repetir, a cada campo preenchido, uma
        espera de até 'timeout' ms num ambiente onde o iFrame simplesmente não existe.
        Use 'force_refresh=True' para forçar uma nova detecção mesmo sem navegação detectada.
        """
        if not force_refresh and page in self._iframe_scope_cache:
            return self._iframe_scope_cache[page]

        if page not in self._pages_com_listener_navegacao:
            page.on("framenavigated", lambda frame, _page=page: self._invalidar_escopo_iframe(_page, frame))
            self._pages_com_listener_navegacao.add(page)

        try:
            selector = self.get_selector(iframe_key_or_selector)
        except KeyError:
            selector = iframe_key_or_selector

        logger.info(f"Aguardando iFrame '{iframe_key_or_selector}' ({selector}) (timeout={timeout}ms)...")
        try:
            await page.wait_for_selector(selector, state="attached", timeout=timeout)
            logger.info("✅ iFrame identificado com sucesso! Alterando contexto para o iFrame.")

            if "gsft_main" in selector:
                scope = page.frame_locator("iframe#gsft_main, iframe[name='gsft_main']")
            else:
                scope = page.frame_locator(selector)
        except PlaywrightTimeoutError:
            logger.warning("⚠️ iFrame não localizado no tempo limite. Utilizando contexto da página principal (fallback).")
            scope = page

        self._iframe_scope_cache[page] = scope
        return scope

    async def wait_for_element(
        self, 
        scope: Union[Page, FrameLocator], 
        selector_key: str, 
        timeout: int = 20000, 
        state: str = "visible"
    ) -> Locator:
        """Aguarda a presença/visibilidade de um elemento no escopo fornecido utilizando a chave de path."""
        selector = self.get_selector(selector_key)
        logger.info(f"Aguardando elemento [{selector_key}] -> '{selector}' (state={state})...")
        locator = scope.locator(selector).first
        await locator.wait_for(state=state, timeout=timeout)
        return locator

    async def click_element(
        self, 
        scope: Union[Page, FrameLocator], 
        selector_key: str, 
        timeout: int = 30000
    ):
        """Clica em um elemento mapeado pelo dicionário de paths com tratamento de espera automático."""
        selector = self.get_selector(selector_key)
        logger.info(f"Clicando no elemento [{selector_key}] -> '{selector}'...")
        locator = scope.locator(selector).first
        await locator.click(timeout=timeout)

    async def fill_input(
        self, 
        scope: Union[Page, FrameLocator], 
        selector_key: str, 
        value: str, 
        timeout: int = 30000
    ):
        """Preenche um campo de entrada de texto utilizando a chave do dicionário de paths."""
        selector = self.get_selector(selector_key)
        logger.info(f"Preenchendo campo [{selector_key}] -> '{selector}' com '{value}'...")
        locator = scope.locator(selector).first
        await locator.fill(value, timeout=timeout)

    @staticmethod
    def _resolver_criterio_select_option(
        values: Union[str, List[str], Dict[str, Any], List[Dict[str, Any]]]
    ) -> Dict[str, Any]:
        """
        Converte o parâmetro 'values' de 'select_option' no(s) kwarg(s) que o Playwright
        Python realmente espera ('value=', 'label=' ou 'index='). Diferente da API JS, a API
        Python NÃO aceita um dict bruto como valor posicional: passar {"label": "X"} direto
        faz o Playwright tratar o dict como uma sequência e iterar suas CHAVES como se fossem
        valores de <option> (ex.: {"label": "Deploy/Launch"} virava, na prática, uma tentativa
        de selecionar a opção cujo value fosse a string literal "label" - nunca encontrada,
        gerando "did not find some options" e timeout de 30s). Esta função corrige o bug.
        """
        if isinstance(values, dict):
            entradas = [values]
        elif isinstance(values, (list, tuple)) and values and isinstance(values[0], dict):
            entradas = list(values)
        else:
            # Compatibilidade retroativa: string ou lista de strings -> casa pelo atributo 'value'.
            return {"value": values}

        criterio: Optional[str] = None
        selecionados: List[Any] = []
        for entrada in entradas:
            chave_encontrada = next((k for k in ("value", "label", "index") if k in entrada), None)
            if chave_encontrada is None:
                raise ValueError(
                    f"Dict de opção inválido para select_option, esperado 'value', 'label' ou 'index': {entrada}"
                )
            if criterio is None:
                criterio = chave_encontrada
            elif criterio != chave_encontrada:
                raise ValueError("Todos os itens de 'values' devem usar o mesmo critério (value/label/index).")
            selecionados.append(entrada[chave_encontrada])

        return {criterio: selecionados}

    async def select_option(
        self,
        scope: Union[Page, FrameLocator],
        selector_key: str,
        values: Union[str, List[str], Dict[str, Any], List[Dict[str, Any]]],
        timeout: int = 30000
    ) -> List[str]:
        """
        Seleciona uma ou múltiplas opções em um elemento de menu dropdown/select.
        :param values: string/lista de strings (casa pelo atributo HTML 'value'), ou
            dict/lista de dicts no formato {"value": ...} / {"label": ...} / {"index": ...}
            para casar pelo critério explícito - ex.: {"label": "Deploy/Launch"}.
        """
        selector = self.get_selector(selector_key)
        logger.info(f"Selecionando opção(ões) no elemento [{selector_key}] -> '{selector}': {values}")
        locator = scope.locator(selector).first
        kwargs = self._resolver_criterio_select_option(values)
        selected = await locator.select_option(timeout=timeout, **kwargs)
        return selected

    async def get_text(
        self, 
        scope: Union[Page, FrameLocator], 
        selector_key: str, 
        timeout: int = 10000
    ) -> str:
        """Obtém o texto interno de um elemento identificado pela chave do dicionário."""
        selector = self.get_selector(selector_key)
        locator = scope.locator(selector).first
        await locator.wait_for(state="attached", timeout=timeout)
        text = await locator.inner_text()
        return text.strip()

    async def download_file(
        self, 
        page: Page, 
        trigger_click_fn, 
        save_directory: str = "./downloads"
    ) -> str:
        """Captura e salva o download de um arquivo disparado por uma ação."""
        os.makedirs(save_directory, exist_ok=True)
        async with page.expect_download() as download_info:
            await trigger_click_fn()
        
        download = await download_info.value
        saved_path = os.path.join(save_directory, download.suggested_filename)
        await download.save_as(saved_path)
        logger.info(f"✅ Arquivo baixado e salvo em: {saved_path}")
        return saved_path

    async def take_screenshot(self, page: Page, filepath: str) -> str:
        """Captura a tela atual da página."""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        await page.screenshot(path=filepath, full_page=True)
        logger.info(f"📸 Screenshot salva em: {filepath}")
        return filepath

    async def close_context(self, context: BrowserContext, close_browser: bool = True):
        """
        Fecha o contexto do navegador e libera o job do 'JobRegistry' (se houver).
        Tolerante a contexto já fechado (ex.: quando a automação foi CANCELADA pelo
        botão "Cancelar" de outra requisição, que já derrubou este mesmo contexto).

        :param close_browser: quando False, NÃO fecha o navegador/contexto (apenas
            libera o job do JobRegistry) - usado por fluxos que deliberadamente
            deixam o navegador aberto após uma falha parcial, para inspeção manual
            (ver 'ReleaseOpenService.executar_abertura').
        """
        if context and close_browser:
            logger.info("Fechando contexto do navegador...")
            try:
                await context.close()
            except Exception as e:
                logger.debug(f"Contexto já estava fechado/inacessível (provável cancelamento): {e}")

        if self.job_id:
            from tools.job_registry import job_registry
            job_registry.unregister(self.job_id)

    async def run_concurrent_tasks(
        self,
        context: BrowserContext,
        items: List[Any],
        task_fn,
        max_concurrency: int = 3,
        keep_open_on_error: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Executa tarefas de automação de forma assíncrona concorrente com controle de semáforo.
        Pode ser herdado e executado por qualquer classe derivada de BaseAutomation.
        Interrompe itens ainda não iniciados assim que o job for cancelado (ver 'tools.job_registry').

        :param keep_open_on_error: quando True, a aba de um item que terminou com
            status "error" NÃO é fechada automaticamente (fica aberta para inspeção/
            conclusão manual). Default False preserva o comportamento original para
            quem já usa este método (ex.: varredura em lote de várias SCTASKs, onde
            deixar abas com erro abertas indefinidamente não é desejável).
        """
        return await ConcurrencyHelper.run_concurrently(
            context, items, task_fn, max_concurrency, job_id=self.job_id, keep_open_on_error=keep_open_on_error
        )



class ConcurrencyHelper:
    """
    Helper utilitário para gerenciar a execução assíncrona concorrente de tarefas Playwright.
    Utiliza um Semaphore para limitar abas abertas simultaneamente, evitando sobrecarga de processamento.
    """
    @staticmethod
    async def run_concurrently(
        context: BrowserContext,
        items: List[Any],
        task_fn,
        max_concurrency: int = 3,
        job_id: Optional[str] = None,
        keep_open_on_error: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Executa concorrentemente uma função de automação assíncrona sobre uma coleção de itens (ex: URLs).
        :param context: Contexto do navegador Playwright.
        :param items: Coleção Python (List, Tuple, etc.) contendo as URLs ou tarefas.
        :param task_fn: Função assíncrona executada para cada item. Recebe os parâmetros (page, item).
        :param max_concurrency: Número máximo de abas/páginas abertas ao mesmo tempo (Semáforo).
        :param job_id: identificador do job (ver 'tools.job_registry'). Itens ainda não iniciados
            são pulados assim que o cancelamento for sinalizado (checagem cooperativa - o
            encerramento imediato do item em andamento é feito à força pelo 'JobRegistry',
            derrubando o contexto do navegador).
        :param keep_open_on_error: quando True, a aba de um item que termina com
            status "error" (seja porque 'task_fn' retornou esse status, seja porque
            lançou uma exceção não tratada) NÃO é fechada - fica aberta exatamente
            no ponto onde falhou, para inspeção/conclusão manual. Cada item continua
            isolado (uma aba com erro nunca afeta as demais, que seguem seu próprio
            ciclo de vida independentemente).
        """
        semaphore = asyncio.Semaphore(max_concurrency)

        job_registry = None
        if job_id:
            from tools.job_registry import job_registry as _job_registry
            job_registry = _job_registry

        async def worker(item: Any):
            async with semaphore:
                if job_registry and job_registry.is_cancelled(job_id):
                    logger.warning(f"⏭️ [ConcurrencyHelper] Job '{job_id}' cancelado - pulando item não iniciado: {item}")
                    return {"item": item, "status": "cancelled", "error": "Automação cancelada pelo usuário."}

                page = await context.new_page()
                try:
                    logger.info(f"🟢 [ConcurrencyHelper] Iniciando aba Playwright para item: {item}")
                    resultado = await task_fn(page, item)
                except Exception as e:
                    logger.error(f"❌ [ConcurrencyHelper] Falha na aba assíncrona ao processar item {item}: {e}")
                    resultado = {
                        "item": item,
                        "status": "error",
                        "error": str(e)
                    }

                terminou_com_erro = isinstance(resultado, dict) and resultado.get("status") == "error"
                if keep_open_on_error and terminou_com_erro:
                    logger.warning(
                        f"⚠️ [ConcurrencyHelper] Item '{item}' terminou com erro - aba MANTIDA ABERTA "
                        f"(sem fechamento automático) para inspeção/conclusão manual."
                    )
                else:
                    try:
                        await page.close()
                    except Exception:
                        pass

                return resultado

        tasks = [worker(item) for item in items]
        return await asyncio.gather(*tasks)


import os
import sys

# Auto-detecta o ambiente virtual (.venv) local caso executado fora dele
try:
    import flask
except ImportError:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    venv_site_packages = os.path.join(
        base_dir, '.venv', 'lib',
        f'python{sys.version_info.major}.{sys.version_info.minor}', 'site-packages'
    )
    if os.path.exists(venv_site_packages):
        sys.path.insert(0, venv_site_packages)
    elif os.path.exists(os.path.join(base_dir, '.venv')):
        import glob
        matches = glob.glob(os.path.join(base_dir, '.venv', 'lib', 'python*', 'site-packages'))
        if matches:
            sys.path.insert(0, matches[0])

from flask import Flask
from flask_login import LoginManager

def resource_path(relative_path):
    """Retorna o caminho absoluto do recurso (funciona em Dev e auto-py-to-exe/PyInstaller)"""
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(os.path.dirname(__file__))
    return os.path.join(base_path, relative_path)

def create_app():
    shared_templates = resource_path(os.path.join('src', 'shared', 'templates'))
    shared_static = resource_path(os.path.join('src', 'shared', 'static'))

    app = Flask(__name__, template_folder=shared_templates, static_folder=shared_static)
    app.config['SECRET_KEY'] = 'automacao-web-secret-key-12345'

    # Localização do banco de dados SQLite persistente
    if getattr(sys, 'frozen', False):
        app_dir = os.path.dirname(sys.executable)
    else:
        app_dir = os.path.abspath(os.path.dirname(__file__))

    db_dir = os.path.join(app_dir, 'instance')
    os.makedirs(db_dir, exist_ok=True)
    db_path = os.path.join(db_dir, 'database.db')

    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Importa modelos e inicializa o DB
    from src.models import db, User
    db.init_app(app)

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Por favor, faça login para acessar esta página.'
    login_manager.login_message_category = 'warning'

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    with app.app_context():
        db.create_all()

    # Registro dos Blueprints ativos por módulo
    from src.modules.auth.routes import auth_bp
    from src.modules.apps.routes import apps_bp
    from src.modules.monitoring.routes import monitoring_bp
    from src.modules.portal_task.routes import portal_task_bp
    from src.modules.release_task.routes import release_task_bp
    from src.modules.send_dml.routes import send_dml_bp
    from src.modules.email_report.routes import email_report_bp
    from src.modules.system.routes import system_bp
    # pyrefly: ignore [missing-import]
    from src.modules.dash.email_bridge import email_bridge_bp
    from src.modules.dash.routes import dash_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(apps_bp)
    app.register_blueprint(monitoring_bp)
    app.register_blueprint(portal_task_bp)
    app.register_blueprint(release_task_bp)
    app.register_blueprint(send_dml_bp)
    app.register_blueprint(email_report_bp)
    app.register_blueprint(system_bp)
    app.register_blueprint(email_bridge_bp)
    app.register_blueprint(dash_bp)

    return app

app = create_app()

if __name__ == '__main__':
    print("Iniciando App Flask de Automação Web em http://127.0.0.1:5790...")
    # threaded=True é necessário para que o botão "Cancelar" funcione: ele dispara uma
    # requisição HTTP separada que precisa ser processada CONCORRENTEMENTE enquanto uma
    # automação Playwright de outra requisição ainda está em andamento (ver tools/job_registry.py).
    app.run(host='127.0.0.1', port=5790, debug=True, threaded=True)

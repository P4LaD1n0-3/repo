import os
import base64
import logging
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from src.models import ServiceNowExportConfig
from tools.servicenow_export_downloader import FILENAMES

logger = logging.getLogger("Dash")

current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.abspath(os.path.join(current_dir, '..', '..', '..'))
dash_bp = Blueprint('dash', __name__, template_folder=current_dir)


@dash_bp.route('/dash')
@login_required
def launcher():
    """
    Tela intermediária de escolha do Dashboard: "Iniciar dashboard direto" (abre
    'dashboard_standalone' em branco, upload manual como hoje) ou "Iniciar dashboard
    com dados" (baixa SCTASK/INC/PRB do ServiceNow via '/system/servicenow_export/*'
    e abre o dashboard já carregado - ver 'index.html:autoLoadServerData()').
    """
    config = ServiceNowExportConfig.get_or_create()
    return render_template('dash_launcher.html', user=current_user, active_page='dashboard', config=config)


@dash_bp.route('/dash/auto_data')
@login_required
def auto_data():
    """
    Serve as últimas planilhas baixadas (via '/system/servicenow_export/download')
    para a região informada, como JSON (base64), para 'index.html' consumir no
    carregamento automático (?autoload=1&region=...) - ver 'autoLoadServerData()'.
    """
    region = (request.args.get('region') or '').strip().upper()
    if not region:
        return jsonify({'status': 'error', 'message': "Parâmetro 'region' não informado.", 'files': []}), 400

    export_dir = os.path.join(root_dir, 'instance', 'uploads', 'servicenow_exports', region)
    if not os.path.isdir(export_dir):
        return jsonify({
            'status': 'error',
            'message': f'Nenhum dado baixado ainda para a região {region}.',
            'files': [],
        }), 404

    files = []
    for label, filename in FILENAMES.items():
        file_path = os.path.join(export_dir, filename)
        if not os.path.exists(file_path):
            continue
        try:
            with open(file_path, 'rb') as f:
                content_base64 = base64.b64encode(f.read()).decode('ascii')
            files.append({'label': label, 'name': filename, 'content_base64': content_base64})
        except Exception as e:
            logger.warning(f"⚠️ [Dash] Falha ao ler '{file_path}' para auto_data: {e}")

    if not files:
        return jsonify({
            'status': 'error',
            'message': f'Nenhuma planilha encontrada para a região {region}.',
            'files': [],
        }), 404

    return jsonify({'status': 'success', 'region': region, 'files': files})

import os
import sys
import logging
import traceback
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from src.models import db, EmailReportConfig

# Garantir que a raiz do projeto esteja no sys.path (necessário para "tools.smtp"
# em execuções empacotadas/PyInstaller onde o cwd pode não ser a raiz do projeto)
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

try:
    from tools.smtp import enviar_email_automatico
except ImportError:
    enviar_email_automatico = None

try:
    import pandas as pd
    from .analyst_report_builder import build_analyst_report
    from .report_builder import build_report
    from .data_loader import load_all, load_sctask, load_inc, load_prb
    from . import metrics as m
    from .config import CONFIG as REPORT_ENGINE_CONFIG
except Exception as e_imp:
    build_analyst_report = None
    build_report = None
    REPORT_ENGINE_CONFIG = {}

logger = logging.getLogger("EmailReport")

current_dir = os.path.dirname(os.path.abspath(__file__))
email_report_bp = Blueprint('email_report', __name__, template_folder=current_dir)

def _ensure_sqlite_columns():
    """Garante a integridade do schema da tabela email_report_configs adicionando colunas do Reporte 2 se necessário."""
    try:
        from sqlalchemy import inspect, text
        inspector = inspect(db.engine)
        if 'email_report_configs' in inspector.get_table_names():
            existing_cols = [c['name'] for c in inspector.get_columns('email_report_configs')]
            with db.engine.connect() as conn:
                if 'analyst_to' not in existing_cols:
                    conn.execute(text("ALTER TABLE email_report_configs ADD COLUMN analyst_to TEXT DEFAULT ''"))
                if 'analyst_cc' not in existing_cols:
                    conn.execute(text("ALTER TABLE email_report_configs ADD COLUMN analyst_cc TEXT DEFAULT ''"))
                if 'analyst_subject_prefix' not in existing_cols:
                    conn.execute(text("ALTER TABLE email_report_configs ADD COLUMN analyst_subject_prefix VARCHAR(200) DEFAULT 'IT Analyst Performance Comparison - Dashboard'"))
                if 'analyst_send_email_enabled' not in existing_cols:
                    conn.execute(text("ALTER TABLE email_report_configs ADD COLUMN analyst_send_email_enabled BOOLEAN DEFAULT 1"))
                conn.commit()
    except Exception as e_col:
        logger.warning(f"⚠️ Verificação/migração de colunas SQLite em email_report_configs: {e_col}")

@email_report_bp.route('/email_report')
@login_required
def index():
    """Renderiza a aba Email Report com as configurações persistidas no SQLite."""
    _ensure_sqlite_columns()
    config = EmailReportConfig.get_or_create(current_user.id)
    return render_template('email_report.html', user=current_user, active_page='email_report', config=config)

def _update_config_from_request(config, data):
    """Atualiza as propriedades do EmailReportConfig (Reporte 1 e Reporte 2)."""
    # Reporte 1 (Dashboard Executivo)
    if 'selected_region' in data:
        config.selected_region = data.get('selected_region', config.selected_region)
    if 'brazil_to' in data:
        config.brazil_to = data.get('brazil_to', config.brazil_to)
    if 'brazil_cc' in data:
        config.brazil_cc = data.get('brazil_cc', config.brazil_cc)
    if 'mex_to' in data:
        config.mex_to = data.get('mex_to', config.mex_to)
    if 'mex_cc' in data:
        config.mex_cc = data.get('mex_cc', config.mex_cc)
    if 'subject_prefix' in data:
        config.subject_prefix = data.get('subject_prefix', config.subject_prefix)
    if 'send_email_enabled' in data:
        raw_val = data.get('send_email_enabled')
        config.send_email_enabled = str(raw_val).lower() in ('true', '1', 'on', 'yes')

    # Reporte 2 (Analyst Comparison)
    if 'analyst_to' in data:
        config.analyst_to = data.get('analyst_to', config.analyst_to)
    if 'analyst_cc' in data:
        config.analyst_cc = data.get('analyst_cc', config.analyst_cc)
    if 'analyst_subject_prefix' in data:
        config.analyst_subject_prefix = data.get('analyst_subject_prefix', config.analyst_subject_prefix)
    if 'analyst_send_email_enabled' in data:
        raw_val2 = data.get('analyst_send_email_enabled')
        config.analyst_send_email_enabled = str(raw_val2).lower() in ('true', '1', 'on', 'yes')

    if 'output_directory' in data:
        config.output_directory = data.get('output_directory', config.output_directory)

@email_report_bp.route('/api/email_report/save_config', methods=['POST'])
@login_required
def save_config():
    """Salva no banco SQLite as configurações de e-mail e opções dos Reportes 1 e 2."""
    _ensure_sqlite_columns()
    data = request.get_json(silent=True)
    if not data:
        data = request.form
    
    config = EmailReportConfig.get_or_create(current_user.id)
    _update_config_from_request(config, data)
    db.session.commit()
    
    report_target = data.get('target_report', 'Configurações')
    logger.info(f"✅ Configuração salva no SQLite para o usuário ID {current_user.id} ({report_target}).")
    return jsonify({
        'status': 'success', 
        'message': f'Configurações do {report_target} salvas no banco SQLite com sucesso!'
    })

@email_report_bp.route('/api/email_report/execute', methods=['POST'])
@login_required
def execute_email_report():
    """
    ============================================================================
    EXECUÇÃO E DISPARO DE RELATÓRIOS VIA E-MAIL (REPORTE 1 & REPORTE 2)
    ============================================================================
    - Reporte 1: dashboard_report (Executive IT Dashboard - Opções Brasil/México)
    - Reporte 2: analyst_comparison_report (Analyst Performance Comparison - Opção Brasil)
    - Exige obrigatoriamente pelo menos 1 arquivo Excel (.xlsx) anexo.
    """
    _ensure_sqlite_columns()
    try:
        config = EmailReportConfig.get_or_create(current_user.id)
        form_data = request.form
        _update_config_from_request(config, form_data)
        db.session.commit()

        # Identificar qual reporte foi acionado (dashboard_report ou analyst_comparison_report)
        report_target = form_data.get('report_target', 'dashboard_report')

        # Upload & Validação Obrigatória de Anexos Excel (.xlsx)
        upload_dir = os.path.join(root_dir, 'instance', 'uploads', 'email_reports', f'user_{current_user.id}')
        os.makedirs(upload_dir, exist_ok=True)

        uploaded_files = request.files.getlist('anexos')
        attachments_list = []
        file_info_list = []
        xlsx_found = False

        for file_obj in uploaded_files:
            if file_obj and file_obj.filename:
                filename = secure_filename(file_obj.filename)
                file_path = os.path.join(upload_dir, filename)
                file_obj.save(file_path)
                
                size_kb = round(os.path.getsize(file_path) / 1024, 1)
                attachments_list.append(file_path)
                file_info_list.append(f"{filename} ({size_kb} KB)")

                if filename.lower().endswith(('.xlsx', '.xls')):
                    xlsx_found = True

        # Validação estrita: O envio de arquivo .xlsx é OBRIGATÓRIO
        if not attachments_list or not xlsx_found:
            return jsonify({
                'status': 'error',
                'message': 'É OBRIGATÓRIO anexar pelo menos um arquivo Excel (.xlsx) para gerar e disparar este relatório.'
            }), 400

        # Identificar caminhos dos dados
        sctask_path = next((p for p in attachments_list if 'sc_task' in p.lower() or 'sctask' in p.lower()), None)
        inc_path = next((p for p in attachments_list if 'inc' in p.lower()), None)
        prb_path = next((p for p in attachments_list if 'prob' in p.lower() or 'prb' in p.lower()), None)

        if not sctask_path and attachments_list:
            sctask_path = attachments_list[0]
        if not inc_path and len(attachments_list) > 1:
            inc_path = attachments_list[1]
        if not prb_path and len(attachments_list) > 2:
            prb_path = attachments_list[2]

        html_body = None
        report_display_name = ""
        target_to = ""
        target_cc = ""
        subject_prefix = ""
        is_send_enabled = False
        region_name = ""
        # Contagem de linhas efetivamente carregadas de cada planilha - mesmo formato do
        # console de 'dashboard_exemplo/main.py' ("-> SCTASK: X | INC: Y | PRB: Z records
        # loaded."), para comparar 1:1 com o script original e flagrar na hora se algum
        # arquivo foi casado com o tipo errado (ou não enviado) pela detecção por nome.
        data_summary = {
            'sctask_file': os.path.basename(sctask_path) if sctask_path else None,
            'sctask_rows': None,
            'inc_file': os.path.basename(inc_path) if inc_path else None,
            'inc_rows': None,
            'prb_file': os.path.basename(prb_path) if prb_path else None,
            'prb_rows': None,
        }

        if report_target == 'analyst_comparison_report':
            # --- REPORTE 2: Analyst Comparison Report (Apenas Brasil) ---
            region_name = "Brasil (BRAZIL)"
            # Sem endereço padrão de fábrica: se nada foi configurado no modal, o disparo
            # de e-mail é bloqueado mais abaixo (ver validação antes de 'enviar_email_automatico') -
            # em vez de silenciosamente cair num endereço de exemplo hardcoded.
            target_to = config.analyst_to or config.brazil_to or ""
            target_cc = config.analyst_cc or config.brazil_cc or ""
            subject_prefix = config.analyst_subject_prefix or "IT Analyst Performance Comparison - Dashboard"
            is_send_enabled = config.analyst_send_email_enabled
            report_display_name = "Analyst Performance Comparison Report (Reporte 2)"

            try:
                if not sctask_path or not os.path.exists(sctask_path):
                    raise FileNotFoundError("Arquivo SCTASK (.xlsx) não identificado entre os anexos enviados.")
                if not build_analyst_report:
                    raise RuntimeError("Motor de geração de relatórios (build_analyst_report) não está disponível "
                                        "— verifique o log de import no início de routes.py.")

                df_sctask = load_sctask(sctask_path)
                df_inc = load_inc(inc_path) if (inc_path and os.path.exists(inc_path)) else pd.DataFrame()
                df_prb = load_prb(prb_path) if (prb_path and os.path.exists(prb_path)) else None
                data_summary['sctask_rows'] = len(df_sctask)
                data_summary['inc_rows'] = len(df_inc)
                data_summary['prb_rows'] = len(df_prb) if df_prb is not None else 0
                logger.info(f"📊 [Analyst Comparison] Linhas carregadas -> {data_summary}")

                df_req, df_uam = m.split_uam(df_sctask, REPORT_ENGINE_CONFIG)
                ref_date = m.get_reference_date(REPORT_ENGINE_CONFIG)

                res = build_analyst_report(df_req, df_uam, df_inc, df_prb, REPORT_ENGINE_CONFIG, ref_date)
                html_body = res[0] if isinstance(res, (tuple, list)) else res
            except Exception as e_an:
                logger.error(f"❌ Erro ao gerar Analyst Comparison Report via engine: {e_an}", exc_info=True)
                return jsonify({
                    'status': 'error',
                    'message': f'Falha ao gerar o Analyst Performance Comparison Report a partir dos dados enviados: {e_an}'
                }), 500

        else:
            # --- REPORTE 1: Dashboard Report Executivo (Opções Brasil / México) ---
            region = (config.selected_region or "BRAZIL").upper()
            if region == "MEX":
                target_to = config.mex_to or ""
                target_cc = config.mex_cc or ""
                region_name = "México (MEX)"
            else:
                target_to = config.brazil_to or ""
                target_cc = config.brazil_cc or ""
                region_name = "Brasil (BRAZIL)"

            subject_prefix = config.subject_prefix or "IT Executive Dashboard — SCTASK x INC x PRB x UAM"
            is_send_enabled = config.send_email_enabled
            report_display_name = "IT Executive Dashboard (Reporte 1)"

            try:
                if not sctask_path or not os.path.exists(sctask_path):
                    raise FileNotFoundError("Arquivo SCTASK (.xlsx) não identificado entre os anexos enviados.")
                if not build_report:
                    raise RuntimeError("Motor de geração de relatórios (build_report) não está disponível "
                                        "— verifique o log de import no início de routes.py.")

                df_sctask = load_sctask(sctask_path)
                df_inc = load_inc(inc_path) if (inc_path and os.path.exists(inc_path)) else pd.DataFrame()
                df_prb = load_prb(prb_path) if (prb_path and os.path.exists(prb_path)) else None
                data_summary['sctask_rows'] = len(df_sctask)
                data_summary['inc_rows'] = len(df_inc)
                data_summary['prb_rows'] = len(df_prb) if df_prb is not None else 0
                logger.info(f"📊 [Executive Dashboard] Linhas carregadas -> {data_summary}")

                res = build_report(df_sctask, df_inc, df_prb, REPORT_ENGINE_CONFIG)
                html_body = res[0] if isinstance(res, (tuple, list)) else res
            except Exception as e_dash:
                logger.error(f"❌ Erro ao gerar Executive Dashboard via engine: {e_dash}", exc_info=True)
                return jsonify({
                    'status': 'error',
                    'message': f'Falha ao gerar o IT Executive Dashboard a partir dos dados enviados: {e_dash}'
                }), 500

        if not html_body:
            return jsonify({
                'status': 'error',
                'message': 'Não foi possível compilar o HTML do relatório nem carregar o modelo de fallback.'
            }), 500

        # Salvar HTML gerado no disco local
        out_filename = f"report_{report_target}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        out_file_path = os.path.join(upload_dir, out_filename)
        with open(out_file_path, "w", encoding="utf-8") as f:
            f.write(html_body)

        # Disparo de e-mail
        email_sent = False
        email_status_msg = "Envio desabilitado no modal/configurações."

        if is_send_enabled:
            if not target_to:
                email_status_msg = (
                    "Envio bloqueado: nenhum destinatário (TO) configurado para este relatório/região. "
                    "Preencha o(s) e-mail(s) no modal de Configurar Destinatários antes de ativar o disparo."
                )
            elif enviar_email_automatico is None:
                email_status_msg = "Módulo de disparo de e-mail (smtp.py) não disponível no servidor."
            else:
                full_subject = f"{subject_prefix} [{region_name}] - {datetime.now().strftime('%d/%m/%Y')}"
                try:
                    ok, msg = enviar_email_automatico(
                        to=target_to,
                        cc=target_cc,
                        subject=full_subject,
                        html_body=html_body,
                        attachments=attachments_list
                    )
                    email_sent = ok
                    email_status_msg = msg
                except Exception as e_mail:
                    email_status_msg = f"Falha ao acionar serviço de e-mail: {str(e_mail)}"

        return jsonify({
            'status': 'success',
            'report_target': report_target,
            'report_display_name': report_display_name,
            'region_name': region_name,
            'target_to': target_to,
            'target_cc': target_cc,
            'subject': subject_prefix,
            'attachments_count': len(attachments_list),
            'files_info': file_info_list,
            'data_summary': data_summary,
            'saved_report_html': out_file_path,
            'email_sent': email_sent,
            'email_status': email_status_msg
        })

    except Exception as e:
        logger.error(f"Erro ao executar relatório de e-mail: {str(e)}")
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': f"Falha interna no servidor: {str(e)}"
        }), 500


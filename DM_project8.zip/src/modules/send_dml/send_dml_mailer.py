"""
================================================================================
SERVIÇO EXCLUSIVO: E-MAIL DE APROVAÇÃO DE EXECUÇÃO DE DML
================================================================================
Módulo exclusivo do 'send_dml', responsável por disparar o e-mail de aprovação
montado em 'dml_mailer.montar_corpo_email' (por sua vez baseado em
'sendmail_exemplo/mail_sender.txt').

REUSO POR HERANÇA: 'DmlMailer' herda de 'tools.smtp.SmtpMailer' e reaproveita o
disparo multiplataforma (Outlook Windows/COM ou Outlook/Mail no Mac via
AppleScript) já usado por 'release_task.release_mailer.ReleaseMailer', sem
duplicar nenhuma lógica de envio - apenas monta o corpo HTML específico de DML.
"""

import logging
from typing import Tuple

from tools.smtp import SmtpMailer
from src.modules.send_dml.dml_mailer import montar_corpo_email

logger = logging.getLogger("DmlMailer")


class DmlMailer(SmtpMailer):
    """Especialização de SmtpMailer exclusiva para o e-mail de aprovação de execução de DML."""

    def __init__(self, default_cc: str = ""):
        super().__init__(
            default_to="",
            default_cc=default_cc,
            default_subject_prefix="Aprovação Requerida - Execução DML",
        )

    @staticmethod
    def _parse_nome_email(valor: str) -> Tuple[str, str]:
        """
        Interpreta o campo 'Destinatário' preenchido pelo usuário, aceitando os formatos:
          - "Nome Completo <email@dominio.com>"
          - "email@dominio.com"
          - "Nome Completo" (sem e-mail; usado somente como nome de exibição)
        Retorna a tupla (nome_exibicao, endereco_email) - usada SOMENTE para a
        saudação/link "mailto:" do corpo do e-mail (ver conteudo() em dml_mailer.py).

        Quando o nome precisa ser extraído do próprio endereço de e-mail (ex.:
        "wesley.simoes@dominio.com"), o resultado sai no formato "Sobrenome, Nome"
        (último trecho antes do "@" = sobrenome) em vez de "Nome Sobrenome" -
        ex.: "Simoes, Wesley".

        Quando 'valor' contém VÁRIOS destinatários (separados por ; ou ,), só o
        primeiro é considerado aqui (nome da saudação) - o envio em si NÃO passa
        por este método: 'send_approval_email' usa o 'valor' completo e original
        como destinatário, e quem separa múltiplos endereços é
        'tools.smtp._extract_email_addresses' (mesma função usada por TODOS os
        e-mails do sistema), então nenhum destinatário é perdido no envio.
        """
        valor = (valor or "").strip()
        if not valor:
            return "", ""

        if "<" in valor and ">" in valor:
            nome = valor.split("<")[0].strip().strip('"')
            email = valor.split("<")[1].split(">")[0].strip()
            return (nome or email), email

        if "@" in valor:
            partes = [p for p in valor.split("@")[0].replace(".", " ").replace("_", " ").split() if p]
            if len(partes) >= 2:
                nome_extraido = f"{partes[-1].title()}, {' '.join(partes[:-1]).title()}"
            else:
                nome_extraido = partes[0].title() if partes else ""
            return nome_extraido, valor

        return valor, ""

    def send_approval_email(
        self,
        change: str,
        ritm: str,
        send_to_valor: str,
        assinatura_nome: str,
        assinatura_email: str,
        scripts_por_ambiente: dict,
        lista: list,
        ambiente_execucao: str,
        respostas: dict,
        copia: str = "",
        observacao: str = "",
    ) -> Tuple[bool, str]:
        """Monta (via dml_mailer) e dispara o e-mail de aprovação de DML."""
        change = (change or "").strip()
        ritm = (ritm or "").strip()

        send_name, send_to_email = self._parse_nome_email(send_to_valor)
        # Destinatário do ENVIO é sempre o valor completo digitado pelo usuário (não o
        # 'send_to_email' extraído acima, que representa só o PRIMEIRO endereço) - isso
        # garante que múltiplos destinatários (separados por ; ou ,) cheguem todos, via
        # 'tools.smtp._extract_email_addresses' (chamada dentro de self.send() abaixo).
        destinatario = send_to_valor

        html_body = montar_corpo_email(
            change=change,
            nome=assinatura_nome,
            email=assinatura_email,
            send_to_valor=(send_to_email or send_name),
            send_name=send_name,
            scripts_por_ambiente=scripts_por_ambiente,
            lista=lista,
            ambiente_execucao=ambiente_execucao,
            respostas=respostas,
            observacao=observacao,
        )

        assunto = f"Aprovação Requerida - Execução DML - {ambiente_execucao} - {change} - {ritm}".strip(" -")

        logger.info(f"📧 [DmlMailer] Enviando e-mail de aprovação de DML {change}/{ritm} ({ambiente_execucao}) para '{destinatario}'...")
        sucesso, mensagem = self.send(html_body=html_body, subject=assunto, to=destinatario, cc=copia)

        if sucesso:
            logger.info(f"✅ [DmlMailer] E-mail enviado com sucesso. {change} - {ritm} ({ambiente_execucao})")
        else:
            logger.error(f"❌ [DmlMailer] Erro ao enviar e-mail. {change} - {ritm} ({ambiente_execucao}): {mensagem}")

        return sucesso, mensagem

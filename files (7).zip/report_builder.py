# -*- coding: utf-8 -*-
"""
Assembles the full dashboard HTML - visual language ported directly from the
reference "relatorio_email.html" template (soft card style, colored KPI
top-borders, gradient section headers) with SCTASK (blue) and INC (red)
kept in clearly separated, parallel sections, plus compact "smart card"
panels for critical/SLA-breaching tickets instead of long raw tables.
"""
import pandas as pd
from datetime import datetime
from config import QC, Colors
import metrics as m
import charts as c

CSS = """
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px 10px; }
        .email-container { max-width: 1300px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .header { background-color: #0B1E40; color: #ffffff; padding: 18px 20px; text-align: center; }
        .header h2 { margin: 0 0 6px 0; font-size: 22px; letter-spacing: 0.3px; }
        .header p { margin: 0; color: #9BBAD2; font-size: 13px; }
        .content { padding: 22px; }
        .kpi-container { width: 100%; margin-bottom: 22px; }
        .kpi-card { border: 1px solid #dddddd; border-radius: 6px; background-color: #fcfcfc; padding: 14px 8px; text-align: center; border-top: 4px solid #329EF4; }
        .kpi-card.blue { border-top-color: #329EF4; }
        .kpi-card.green { border-top-color: #649f40; }
        .kpi-card.red { border-top-color: #EB1E77; }
        .kpi-card.orange { border-top-color: #ff9800; }
        .kpi-card.purple { border-top-color: #9b59b6; }
        .kpi-title { color: #888888; font-size: 11px; text-transform: uppercase; font-weight: bold; margin-bottom: 6px; letter-spacing: 0.3px; }
        .kpi-value { color: #333333; font-size: 26px; font-weight: bold; margin-bottom: 4px; }
        .kpi-subtitle { font-size: 11px; color: #999999; }
        .kpi-trend-up { color: #EB1E77; font-weight: bold; }
        .kpi-trend-down { color: #649f40; font-weight: bold; }
        .stat-card { border: 1px solid #eeeeee; border-radius: 6px; background-color: #fcfcfc; padding: 12px 8px; text-align: center; border-top: 3px solid #cccccc; }
        .stat-card.warn { border-top-color: #ff9800; }
        .stat-card.danger { border-top-color: #EB1E77; }
        .stat-card.info { border-top-color: #329EF4; }
        .stat-card.flat { border: 1px solid #e0e0e0; border-top: 1px solid #e0e0e0; background-color: #fafafa; }
        .stat-title { color: #888888; font-size: 10px; text-transform: uppercase; font-weight: bold; margin-bottom: 5px; }
        .stat-value { color: #333333; font-size: 22px; font-weight: bold; }
        .stat-subtitle { font-size: 10px; color: #999999; margin-top: 3px; }
        .chart-card-full { border: 1px solid #eeeeee; border-radius: 6px; padding: 15px; margin-bottom: 18px; text-align: center; background-color: #ffffff; }
        .chart-title { color: #585858; font-size: 13px; font-weight: bold; text-transform: uppercase; margin-bottom: 10px; text-align: left; border-bottom: 1px solid #f4f4f4; padding-bottom: 8px; }
        .chart-img { max-width: 100%; height: auto; display: block; margin: 0 auto; }
        .grid-cell { border: 1px solid #eeeeee; border-radius: 6px; padding: 12px; background-color: #ffffff; vertical-align: top; }
        .data-table { width: 100%; border-collapse: collapse; font-size: 12px; color: #333333; }
        .data-table th { background-color: #f4f4f4; color: #585858; font-weight: bold; padding: 7px; border: 1px solid #dddddd; text-align: center; }
        .data-table td { padding: 6px; border: 1px solid #dddddd; text-align: center; }
        .data-table tr:nth-child(even) { background-color: #fcfcfc; }
        .data-table .total-row { font-weight: bold; background-color: #e2e8f0; font-size: 13px; }
        .text-left { text-align: left !important; }
        .table-note { font-size: 11px; color: #999999; text-align: right; margin-top: 6px; font-style: italic; }
        .section-divider { border: none; border-top: 2px solid #e8ecf0; margin: 26px 0 20px 0; }
        .section-header { background: linear-gradient(135deg, #0B1E40 0%, #1a3a6b 100%); color: #ffffff; padding: 11px 16px; border-radius: 6px; margin-bottom: 15px; font-size: 14px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; }
        .section-header.req { background: linear-gradient(135deg, #1565C0 0%, #1976D2 100%); }
        .section-header.inc { background: linear-gradient(135deg, #B71C1C 0%, #C62828 100%); }
        .section-header.prb { background: linear-gradient(135deg, #4A148C 0%, #6A1B9A 100%); }
        .sub-header { color: #585858; font-size: 12px; font-weight: bold; text-transform: uppercase; margin: 16px 0 10px 0; letter-spacing: 0.3px; }
        .mini-kpi-row { margin-bottom: 14px; }
        .mini-kpi { display: inline-block; background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; padding: 6px 14px; margin-right: 8px; margin-bottom: 6px; font-size: 11px; color: #555; }
        .mini-kpi strong { font-size: 15px; color: #222; display: block; }
        .footer { text-align: center; padding: 15px; font-size: 12px; color: #888888; background-color: #f4f4f4; border-top: 1px solid #dddddd; }
        @media only screen and (max-width: 768px) {
            body { padding: 8px 4px !important; }
            .content { padding: 12px !important; }
            .header { padding: 14px !important; }
            .header h2 { font-size: 18px !important; }
            .responsive-td-3 { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-bottom: 15px !important; }
            .grid-cell { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-bottom: 15px !important; }
            .spacer-hide-mobile { display: none !important; }
            .kpi-responsive-td { display: inline-block !important; width: 48% !important; box-sizing: border-box !important; margin-bottom: 12px !important; }
            .kpi-spacer { display: inline-block !important; width: 4% !important; }
            .kpi-value { font-size: 22px !important; }
            .stat-value { font-size: 18px !important; }
            .mini-kpi { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-right: 0 !important; }
            .data-table { font-size: 11px !important; }
            .chart-title { font-size: 12px !important; }
        }
"""


# ---------------------------------------------------------------------------
# Generic layout helpers - EVERY visual property is set as an inline style
# attribute directly on each element, not just via the <style> block above.
#
# Why: Outlook's HTMLBody/MAPI pipeline (used by smtp.py through win32com)
# is known to drop or mangle <style> blocks - especially compound class
# selectors like ".kpi-card.blue" - so cards can render with zero styling
# (exactly the "cards have no color" symptom). Inline styles survive that
# pipeline reliably. The class="..." attributes are kept too, purely as a
# progressive enhancement for clients that DO honor <style> + @media
# (Outlook Mobile/Mac/Web, Gmail, Apple Mail, etc.) - Outlook Windows
# desktop will just use the inline baseline, which already looks correct.
# ---------------------------------------------------------------------------
KPI_BORDER = {"blue": "#329EF4", "green": "#649f40", "red": "#EB1E77",
              "orange": "#ff9800", "purple": "#9b59b6", "": "#329EF4"}
STAT_BORDER = {"warn": "#ff9800", "danger": "#EB1E77", "info": "#329EF4",
               "flat": "#e0e0e0", "": "#cccccc"}
SECTION_BG = {"req": "#1976D2", "inc": "#C62828", "prb": "#6A1B9A", "": "#0B1E40"}

FONT_STACK = "Arial, Helvetica, sans-serif"


def kpi_row(cards):
    """cards: list of (color_class, title, value, subtitle_html)."""
    n = len(cards)
    spacer_total = (n - 1) * 2
    card_w = (100 - spacer_total) / n
    cells = []
    for i, (color_class, title, value, subtitle) in enumerate(cards):
        border = KPI_BORDER.get(color_class, "#329EF4")
        cells.append(f"""<td width="{card_w:.1f}%" class="kpi-responsive-td" style="padding:0 3px;">
            <table width="100%" cellpadding="0" cellspacing="0" border="0" class="kpi-card {color_class}"
                   style="border:1px solid #dddddd; border-top:4px solid {border}; border-radius:6px; background-color:#fcfcfc;">
                <tr><td align="center" style="padding:14px 8px; font-family:{FONT_STACK};">
                    <div class="kpi-title" style="color:#888888; font-size:11px; text-transform:uppercase; font-weight:bold; margin-bottom:6px; letter-spacing:0.3px; font-family:{FONT_STACK};">{title}</div>
                    <div class="kpi-value" style="color:#333333; font-size:26px; font-weight:bold; margin-bottom:4px; font-family:{FONT_STACK};">{value}</div>
                    <div class="kpi-subtitle" style="font-size:11px; color:#999999; font-family:{FONT_STACK};">{subtitle}</div>
                </td></tr>
            </table>
        </td>""")
        if i < n - 1:
            cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
    return f'<table class="kpi-container" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:20px;"><tr>{"".join(cells)}</tr></table>'


def stat_row(cards):
    """Small stat cards (compact critical panel). cards: list of
    (modifier_class, title, value, subtitle)."""
    n = len(cards)
    spacer_total = (n - 1) * 2
    card_w = (100 - spacer_total) / n
    cells = []
    for i, (mod, title, value, subtitle) in enumerate(cards):
        border = STAT_BORDER.get(mod, "#cccccc")
        bg = "#fafafa" if mod == "flat" else "#fcfcfc"
        cells.append(f"""<td width="{card_w:.1f}%" class="kpi-responsive-td" style="padding:0 3px;">
            <table width="100%" cellpadding="0" cellspacing="0" border="0" class="stat-card {mod}"
                   style="border:1px solid #eeeeee; border-top:3px solid {border}; border-radius:6px; background-color:{bg};">
                <tr><td align="center" style="padding:12px 8px; font-family:{FONT_STACK};">
                    <div class="stat-title" style="color:#888888; font-size:10px; text-transform:uppercase; font-weight:bold; margin-bottom:5px; font-family:{FONT_STACK};">{title}</div>
                    <div class="stat-value" style="color:#333333; font-size:22px; font-weight:bold; font-family:{FONT_STACK};">{value}</div>
                    <div class="stat-subtitle" style="font-size:10px; color:#999999; margin-top:3px; font-family:{FONT_STACK};">{subtitle}</div>
                </td></tr>
            </table>
        </td>""")
        if i < n - 1:
            cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
    return f'<table class="kpi-container" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:14px;"><tr>{"".join(cells)}</tr></table>'


def section_header(text, css_class=""):
    bg = SECTION_BG.get(css_class, "#0B1E40")
    return (f'<table width="100%" cellpadding="0" cellspacing="0" border="0" class="section-header {css_class}" '
            f'style="margin-bottom:15px;"><tr><td style="background-color:{bg}; color:#ffffff; padding:11px 16px; '
            f'border-radius:6px; font-size:14px; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; '
            f'font-family:{FONT_STACK};">{text}</td></tr></table>')


def sub_header(text):
    return (f'<div class="sub-header" style="color:#585858; font-size:12px; font-weight:bold; text-transform:uppercase; '
            f'margin:16px 0 10px 0; letter-spacing:0.3px; font-family:{FONT_STACK};">{text}</div>')


def chart_card(title, img_url):
    """Chart title + image. The <img> gets an explicit width="100%" HTML
    attribute (not just CSS) - Outlook's Word engine largely ignores
    max-width:100% unless the width attribute is also present, which is
    why charts were rendering at native/oversized pixel dimensions and
    overflowing their container instead of shrinking to fit."""
    return (f'<div class="chart-title" style="color:#585858; font-size:13px; font-weight:bold; text-transform:uppercase; '
            f'margin-bottom:10px; text-align:left; border-bottom:1px solid #f4f4f4; padding-bottom:8px; '
            f'font-family:{FONT_STACK};">{title}</div>'
            f'<img class="chart-img" src="{img_url}" width="100%" '
            f'style="max-width:100%; width:100%; height:auto; display:block; margin:0 auto; border:0;">')


def grid_row(cells, widths=None):
    """cells: list of inner-HTML strings, each wrapped in a card-styled cell."""
    n = len(cells)
    if widths is None:
        spacer_total = (n - 1) * 2
        w = (100 - spacer_total) / n
        widths = [w] * n
    html = '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 18px;"><tr>'
    for i, content in enumerate(cells):
        html += (f'<td width="{widths[i]:.1f}%" class="grid-cell responsive-td-3" valign="top" '
                 f'style="border:1px solid #eeeeee; border-radius:6px; padding:12px; background-color:#ffffff;">{content}</td>')
        if i < n - 1:
            html += '<td width="2%" class="spacer-hide-mobile">&nbsp;</td>'
    html += "</tr></table>"
    return html


def mini_kpi_row(items):
    """Small badge row. Uses a <table> of cells, NOT inline <span> pills:
    Outlook's Word engine reliably ignores border/padding/background-color
    on inline elements like <span>, which is exactly why these were
    rendering as unstyled, run-together text ("items glued together")."""
    n = len(items)
    if n == 0:
        return ""
    cell_w = max(100 / n, 14)
    cells = []
    for i, (label, value) in enumerate(items):
        cells.append(f"""<td style="padding:3px;">
            <table cellpadding="0" cellspacing="0" border="0" style="background-color:#f8f9fa; border:1px solid #dee2e6; border-radius:4px;">
                <tr><td style="padding:7px 14px; font-family:{FONT_STACK};">
                    <div style="font-size:11px; color:#555555; white-space:nowrap;">{label}</div>
                    <div style="font-size:16px; color:#222222; font-weight:bold;">{value}</div>
                </td></tr>
            </table>
        </td>""")
    # Wrap with a fixed number of columns per row so long rows reflow instead
    # of forcing the table wider than its container (which is what caused
    # the "everything glued in one line" look).
    per_row = 3 if n > 4 else n
    rows_html = ""
    for i in range(0, n, per_row):
        row_cells = cells[i:i + per_row]
        rows_html += f"<tr>{''.join(row_cells)}</tr>"
    return (f'<table class="mini-kpi-row" cellpadding="0" cellspacing="0" border="0" '
            f'style="margin-bottom:14px;">{rows_html}</table>')


def full_width_card(title, img_url):
    return (f'<div class="chart-card-full" style="border:1px solid #eeeeee; border-radius:6px; padding:15px; '
            f'margin-bottom:18px; text-align:center; background-color:#ffffff;">{chart_card(title, img_url)}</div>')


def two_col_row(left_html, right_html, widths=(49, 49)):
    return (f'<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 18px;"><tr>'
            f'<td width="{widths[0]}%" valign="top" class="responsive-td-3" style="padding-right:8px;">{left_html}</td>'
            f'<td width="2%" class="spacer-hide-mobile">&nbsp;</td>'
            f'<td width="{widths[1]}%" valign="top" class="responsive-td-3" style="padding-left:8px;">{right_html}</td>'
            f'</tr></table>')


# ---------------------------------------------------------------------------
# Data tables
# ---------------------------------------------------------------------------
def data_table(df, header_bg="#f4f4f4", header_color="#585858", show_totals=False,
                empty_message="No data available for this period."):
    if df is None or df.empty:
        return (f"<div style='padding:14px; color:{Colors.SUCCESS}; background-color:{Colors.SUCCESS_LIGHT}; "
                f"text-align:center; font-weight:bold; border:1px solid {Colors.SUCCESS}; border-radius:4px; "
                f"font-size:12px; font-family:{FONT_STACK};'>&#10003; {empty_message}</div>")

    html = (f"<table class='data-table' width='100%' cellpadding='0' cellspacing='0' border='0' "
            f"style='border-collapse:collapse; font-size:12px; color:#333333; font-family:{FONT_STACK};'>"
            f"<thead><tr>")
    for i, col in enumerate(df.columns):
        html += (f"<th style='background-color:{header_bg}; color:{header_color}; font-weight:bold; padding:7px; "
                 f"border:1px solid #dddddd; text-align:center;'>{col}</th>")
    html += "</tr></thead><tbody>"
    for r, (_, row) in enumerate(df.iterrows()):
        row_bg = "#fcfcfc" if r % 2 == 0 else "#ffffff"
        html += f"<tr style='background-color:{row_bg};'>"
        for j, val in enumerate(row):
            align = "left" if j == 0 else "center"
            html += f"<td style='padding:6px; border:1px solid #dddddd; text-align:{align};'>{val}</td>"
        html += "</tr>"
    html += "</tbody></table>"
    return html


def monthly_table_with_totals(df, css_scope="req"):
    if df.empty:
        return data_table(df)
    header_bg = "#1976D2" if css_scope == "req" else "#C62828"
    render = df.rename(columns={"NetFlow": "Net Flow", "BacklogAccum": "Backlog"})
    rows = ""
    for i, (_, r) in enumerate(render.iterrows()):
        sign = "+" if r["Net Flow"] > 0 else ""
        color = "#EB1E77" if r["Net Flow"] > 0 else ("#649f40" if r["Net Flow"] < 0 else "#585858")
        row_bg = "#fcfcfc" if i % 2 == 0 else "#ffffff"
        rows += (f"<tr style='background-color:{row_bg};'>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:left;'>{r['Month']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{r['Opened']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{r['Resolved']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center; color:{color}; font-weight:bold;'>{sign}{r['Net Flow']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center; font-weight:bold;'>{r['Backlog']}</td></tr>")
    tot_o, tot_c, tot_n = render["Opened"].sum(), render["Resolved"].sum(), render["Net Flow"].sum()
    last_backlog = render["Backlog"].iloc[-1]
    sign_t = "+" if tot_n > 0 else ""
    color_t = "#EB1E77" if tot_n > 0 else ("#649f40" if tot_n < 0 else "#585858")
    rows += (f"<tr style='background-color:#e2e8f0; font-weight:bold; font-size:13px;'>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:left;'>TOTAL</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{tot_o}</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{tot_c}</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center; color:{color_t};'>{sign_t}{tot_n}</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{last_backlog}</td></tr>")

    return (f"<table class='data-table' width='100%' cellpadding='0' cellspacing='0' border='0' "
            f"style='border-collapse:collapse; font-size:12px; font-family:{FONT_STACK};'><thead><tr>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd; text-align:left;'>Month</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Opened</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Resolved</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Net Flow</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Backlog</th>"
            f"</tr></thead><tbody>{rows}</tbody></table>")


def critical_panel(open_df, ticket_type_label, threshold, extra_threshold, id_cols,
                    compact_rows=6, accent="danger"):
    summary = m.critical_summary(open_df, threshold, extra_threshold)

    cards = [
        (accent, f"Aging {threshold}+ days", summary["count"], "tickets need attention"),
    ]
    if extra_threshold:
        cards.append((accent, f"Aging {extra_threshold}+ days", summary["count_extra"], "extra-critical"))
    cards.append(("warn", "Oldest Ticket", f"{summary['oldest_days']}d",
                   summary["oldest_number"] if summary["oldest_number"] != "\u2014" else "\u2014"))
    cards.append(("info", "Avg. Aging (critical)", f"{summary['avg_days']}d", "days open, on average"))

    panel = stat_row(cards)

    if summary["count"] == 0:
        panel += data_table(pd.DataFrame(), empty_message=f"No {ticket_type_label} above the aging threshold.")
        return panel

    crit = m.critical_table(open_df, threshold, top_n=compact_rows)
    render = crit.copy()
    render["Opened"] = render["Opened"].dt.strftime("%d/%m/%Y")
    cols = ["Number"] + id_cols + ["State", "Opened", "AgingDays"]
    render = render[cols].rename(columns={"AgingDays": "Aging (d)"})
    panel += data_table(render)

    if summary["count"] > compact_rows:
        panel += (f"<div class='table-note' style='font-size:11px; color:#999999; text-align:right; "
                   f"margin-top:6px; font-style:italic; font-family:{FONT_STACK};'>"
                   f"+ {summary['count'] - compact_rows} additional critical "
                   f"{ticket_type_label} not shown here (see the full export for details).</div>")
    return panel


# ---------------------------------------------------------------------------
# Parallel SCTASK / INC section builder (shared structure, type-specific colors)
# ---------------------------------------------------------------------------
def build_ticket_type_section(df, ref, config, *, ticket_type, css_class, label,
                                donut_colors, bar_color, bar_color_soft, requester_col,
                                id_cols, critical_threshold, extra_critical=None):
    sla_days = config["SLA_DAYS"][ticket_type]
    open_df = m.add_open_aging(df, ref, sla_days)

    # This is a day-to-day operations snapshot: "Opened/Resolved" only ever
    # look at the current month, and the backlog counts are always the LIVE
    # open queue - never an all-time total of closed tickets.
    opened_month, resolved_month = m.current_month_flow(df, ref)
    backlog = len(open_df)
    mttr = round(m.mttr_days_month(df, ref), 1)
    inside, outside = m.sla_inside_outside(open_df)

    html = section_header(label, css_class)
    html += mini_kpi_row([
        ("Open Backlog", backlog), ("Inside SLA", inside), ("Outside SLA", outside),
        ("Opened (month)", opened_month), ("Resolved (month)", resolved_month),
        ("MTTR (month)", f"{mttr}d"),
    ])

    html += sub_header(f"Critical {ticket_type}s")
    html += critical_panel(open_df, ticket_type, critical_threshold, extra_critical,
                             id_cols, config["CRITICAL_TABLE_COMPACT_ROWS"],
                             accent="danger")

    return html, open_df


# ---------------------------------------------------------------------------
# Combined Distribution & SLA section (1A/1B donuts + both SLA pies together)
# ---------------------------------------------------------------------------
def build_distribution_sla_section(open_sctask, open_inc, config):
    an_s_l, an_s_v = m.top_analysts(open_sctask, config["TOP_N_ANALYSTS"])
    an_i_l, an_i_v = m.top_analysts(open_inc, config["TOP_N_ANALYSTS"])
    # Varied, easy-to-tell-apart palette for both donuts (a single-hue gradient
    # makes similarly-sized slices indistinguishable at a glance).
    img_an_s = c.donut(an_s_l, an_s_v, QC["varied"], center_color="#1976D2")
    img_an_i = c.donut(an_i_l, an_i_v, QC["varied"], center_color="#C62828")

    in_s, out_s = m.sla_inside_outside(open_sctask)
    in_i, out_i = m.sla_inside_outside(open_inc)
    img_sla_s = c.sla_pie(in_s, out_s, center_color="#1976D2")
    img_sla_i = c.sla_pie(in_i, out_i, center_color="#C62828")

    return section_header("Distribution & SLA (Donut / Pie Charts)") + grid_row([
        chart_card("1A. Top Analysts - SCTASK", img_an_s),
        chart_card("1B. Top Analysts - INC", img_an_i),
        chart_card("SCTASK: Inside vs Outside SLA", img_sla_s),
        chart_card("INC: Inside vs Outside SLA", img_sla_i),
    ])


# ---------------------------------------------------------------------------
# Combined Status & Aging section (3A/3B aging bars + both status bars)
# ---------------------------------------------------------------------------
def build_status_aging_section(open_sctask, open_inc, config):
    aging_s = m.aging_bucket_table(open_sctask, "SCTASK")
    aging_i = m.aging_bucket_table(open_inc, "INC")
    img_aging_s = c.horizontal_bar_scale(aging_s["Bucket"], aging_s["Count"])
    img_aging_i = c.horizontal_bar_scale(aging_i["Bucket"], aging_i["Count"])

    st_s_l, st_s_v = m.status_distribution(open_sctask, config["TOP_N_ANALYSTS"])
    st_i_l, st_i_v = m.status_distribution(open_inc, config["TOP_N_ANALYSTS"])
    img_st_s = c.horizontal_bar(st_s_l, st_s_v, QC["blue_a"])
    img_st_i = c.horizontal_bar(st_i_l, st_i_v, QC["red_a"])

    return section_header("Status & Aging of Open Tickets (Bar Charts)") + grid_row([
        chart_card("3A. Aging Detail - SCTASK", img_aging_s),
        chart_card("3B. Aging Detail - INC", img_aging_i),
        chart_card("SCTASK: Status (Open)", img_st_s),
        chart_card("INC: Status (Open)", img_st_i),
    ])


# ---------------------------------------------------------------------------
# Side-by-side trend comparison panels (SCTASK vs INC) - styled to match the
# reference screenshot exactly: colored top border per panel, bold colored
# title, 3 plain stat boxes (Opened / Closed / Net Balance) and a rich
# dual-axis chart with datalabels on both the bars and the line.
# ---------------------------------------------------------------------------
def build_trend_panel(number_label, ticket_type, df_metrics, border_color, title_color,
                        color_opened, color_closed, color_line, line_label, current_backlog=None,
                        w=780, h=340):
    label_col = "Month" if "Month" in df_metrics.columns else "Date"
    total_opened = int(df_metrics["Opened"].sum())
    total_closed = int(df_metrics["Resolved"].sum())
    net_balance = total_opened - total_closed
    net_html = (f"<span style='color:#EB1E77;'>+{net_balance}</span>" if net_balance > 0
                else (f"<span style='color:#649f40;'>{net_balance}</span>" if net_balance < 0
                      else f"<span style='color:#585858;'>0</span>"))

    cards = []
    if current_backlog is not None:
        cards.append(("info", "Current", current_backlog, "open right now"))
    cards += [
        ("flat", "Opened", total_opened, ""),
        ("flat", "Closed", total_closed, ""),
        ("flat", line_label, net_html, ""),
    ]
    stats = stat_row(cards)

    img = c.dual_axis_trend_rich(
        df_metrics[label_col], df_metrics["Opened"], df_metrics["Resolved"], df_metrics["BacklogAccum"],
        color_opened, color_closed, color_line, line_label=line_label, w=w, h=h)

    return f"""
    <div style="border-top: 4px solid {border_color}; border-left: 1px solid #eeeeee; border-right: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee; border-radius: 6px; padding: 16px; background-color:#ffffff;">
        <div style="color:{title_color}; font-size:16px; font-weight:bold; margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #f4f4f4; font-family:{FONT_STACK};">{number_label}. {ticket_type} - Opened / Closed / {line_label}</div>
        {stats}
        <img class="chart-img" src="{img}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; margin-top:14px; border:0;">
    </div>"""


def build_trend_comparison_section(section_title, sctask_metrics, inc_metrics,
                                     label_a, label_b, line_label="Net Balance", css_class="",
                                     layout="side_by_side", sctask_backlog=None, inc_backlog=None):
    if layout == "stacked":
        panel_sctask = build_trend_panel(label_a, "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
                                           QC["blue"], QC["bright_green"], QC["red"], line_label,
                                           current_backlog=sctask_backlog, w=1180, h=380)
        panel_inc = build_trend_panel(label_b, "INC", inc_metrics, "#C62828", "#B71C1C",
                                        QC["coral"], QC["purple"], QC["orange"], line_label,
                                        current_backlog=inc_backlog, w=1180, h=380)
        body = (f'<div style="margin-bottom: 18px;">{panel_sctask}</div>'
                f'<div style="margin-bottom: 18px;">{panel_inc}</div>')
        return section_header(section_title, css_class) + body

    panel_sctask = build_trend_panel(label_a, "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
                                       QC["blue"], QC["bright_green"], QC["red"], line_label,
                                       current_backlog=sctask_backlog)
    panel_inc = build_trend_panel(label_b, "INC", inc_metrics, "#C62828", "#B71C1C",
                                    QC["coral"], QC["purple"], QC["orange"], line_label,
                                    current_backlog=inc_backlog)
    return section_header(section_title, css_class) + two_col_row(panel_sctask, panel_inc)


# ---------------------------------------------------------------------------
# Combined Monthly Tracking Table (SCTASK + INC side by side, one section)
# ---------------------------------------------------------------------------
def build_monthly_tracking_section(monthly_sctask, monthly_inc):
    left = (f'<div class="chart-card-full" style="border:1px solid #eeeeee; border-radius:6px; padding:15px; '
            f'background-color:#ffffff; margin-bottom:0;">'
            f'{_chart_title_div("Throughput - SCTASK")}'
            f'{monthly_table_with_totals(monthly_sctask, css_scope="req")}</div>')
    right = (f'<div class="chart-card-full" style="border:1px solid #eeeeee; border-radius:6px; padding:15px; '
             f'background-color:#ffffff; margin-bottom:0;">'
             f'{_chart_title_div("Throughput - INC")}'
             f'{monthly_table_with_totals(monthly_inc, css_scope="inc")}</div>')
    return section_header("Monthly Tracking Table: Opened x Resolved x Backlog") + two_col_row(left, right)


# ---------------------------------------------------------------------------
# Cross-type conversions (offenders)
# ---------------------------------------------------------------------------
def _chart_title_div(title):
    return (f'<div class="chart-title" style="color:#585858; font-size:13px; font-weight:bold; '
            f'text-transform:uppercase; margin-bottom:10px; text-align:left; border-bottom:1px solid #f4f4f4; '
            f'padding-bottom:8px; font-family:{FONT_STACK};">{title}</div>')


def breakdown_card(title, labels, values, show_pct=False):
    if not labels:
        return _chart_title_div(title) + data_table(pd.DataFrame(), empty_message="No records this period.")
    total = sum(values) or 1
    if show_pct:
        rows = [{"Name": l, "Count": v, "%": f"{v / total * 100:.1f}%"} for l, v in zip(labels, values)]
    else:
        rows = [{"Name": l, "Count": v} for l, v in zip(labels, values)]
    return _chart_title_div(title) + data_table(pd.DataFrame(rows))


def build_conversions_section(sctask, inc, ref, config):
    r = m.classification_errors(sctask, inc, ref, config)

    html = section_header("Cross-Type Conversions (SCTASK &harr; INC)")
    html += ('<div style="font-size:11px; color:#999999; margin-bottom:12px;">'
              'How canceled/incomplete tickets in SCTASK and INC reconcile with genuine '
              'cross-type misclassifications (tracked in both directions).</div>')

    # ---- Reconciliation panel ----
    html += sub_header("Canceled Reconciliation (Current Month)")
    html += stat_row([
        ("warn", "INC Canceled", r["inc_cancel_total"], "Total in INC"),
        ("info", "SCTASK Canceled", r["sctask_cancel_total"], "Total in SCTASK"),
        ("", "Total Canceled", r["inc_cancel_total"] + r["sctask_cancel_total"], "INC + SCTASK"),
        ("danger", "Incorrect Classif.", r["total_month"], "Confirmed misclassification"),
        ("", "Other Reasons", r["other_reasons"], "Non-classification cancels"),
    ])
    html += mini_kpi_row([
        ("INC \u2192 SCTASK (reclassified)", r["i2s_month"]),
        ("SCTASK \u2192 INC (reclassified)", r["s2i_month"]),
    ])

    # ---- KPI cards (all scoped to the current month) ----
    html += stat_row([
        ("danger", "Incorrect Tickets (Month)", r["total_month"], "Volume detected this period"),
        ("warn", "Top Offending Group", r["top_group_count"], r["top_group_name"]),
        ("info", "MTTR (Month)", f"{r['mttr_month']}d", "Average correction time"),
        ("", "Maximum Delay (Month)", f"{r['max_delay_month']}d", "Longest response time"),
    ])

    # ---- Analytical breakdowns (current month only) ----
    req_l, req_v = r["by_requester"]
    grp_l, grp_v = r["by_group"]
    an_l, an_v = r["by_analyst"]
    html += grid_row([
        breakdown_card("By Requester (Month)", req_l, req_v),
        breakdown_card("By Group (Month)", grp_l, grp_v),
        breakdown_card("By Analyst (Month)", an_l, an_v),
    ], widths=[32, 32, 32])

    # ---- Detailed list (compact) ----
    html += sub_header("Detailed List of Incorrect Classifications (Current Month)")
    recent = r["recent_rows"]
    if recent is None or recent.empty:
        html += data_table(pd.DataFrame(), empty_message="No incorrect classifications identified in the period.")
    else:
        render = recent.copy()
        render["Opened"] = render["Opened"].dt.strftime("%d/%m/%Y")
        render["Closed"] = render["Closed"].apply(lambda d: d.strftime("%d/%m/%Y") if pd.notna(d) else "\u2014")
        render["AgingDays"] = render["AgingDays"].round(1)
        cols = ["Number", "Direction", "LinkedTicket", "Requester", "Assigned to",
                "Assignment group", "Reason", "State", "Opened", "Closed", "AgingDays"]
        render = render[cols].rename(columns={"LinkedTicket": "Linked Ticket", "AgingDays": "Aging (d)"})
        html += data_table(render)
        if r["total_month"] > len(recent):
            html += (f"<div class='table-note' style='font-size:11px; color:#999999; text-align:right; "
                      f"margin-top:6px; font-style:italic; font-family:{FONT_STACK};'>"
                      f"+ {r['total_month'] - len(recent)} additional misclassified "
                      f"tickets not shown here (see the full export for details).</div>")

    return html



# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def build_report(sctask, inc, prb, config):
    ref = m.get_reference_date(config)
    crit = config["CRITICAL_AGING_THRESHOLD"]

    open_sctask_quick = m.add_open_aging(sctask, ref, config["SLA_DAYS"]["SCTASK"])
    open_inc_quick = m.add_open_aging(inc, ref, config["SLA_DAYS"]["INC"])
    open_prb_quick = m.add_open_aging(prb, ref, config["SLA_DAYS"]["PRB"])
    total_backlog = len(open_sctask_quick) + len(open_inc_quick)
    mttr_overall = round((m.mttr_days_month(sctask, ref) + m.mttr_days_month(inc, ref)) / 2, 1)

    overview = kpi_row([
        ("blue", "Total Backlog", total_backlog, "SCTASK + INC open, right now"),
        ("blue", "SCTASK Open", len(open_sctask_quick), "Service requests"),
        ("red", "INC Open", len(open_inc_quick), "Incidents"),
        ("purple", "PRB Open", len(open_prb_quick), f"of {len(prb)} total"),
        ("orange", "MTTR (month)", f"{mttr_overall}d", "Current-month resolution time"),
    ])

    sctask_html, open_sctask = build_ticket_type_section(
        sctask, ref, config, ticket_type="SCTASK", css_class="req", label="SCTASK \u2014 Service Requests",
        donut_colors=QC["req_donut"], bar_color=QC["blue_a"], bar_color_soft=QC["blue_a"],
        requester_col="Requester", id_cols=["Assigned to", "Requester"],
        critical_threshold=crit["SCTASK"], extra_critical=config.get("SCTASK_EXTRA_CRITICAL_DAYS"))

    inc_html, open_inc = build_ticket_type_section(
        inc, ref, config, ticket_type="INC", css_class="inc", label="INC \u2014 Incidents",
        donut_colors=QC["inc_donut"], bar_color=QC["red_a"], bar_color_soft=QC["red_a"],
        requester_col="Caller", id_cols=["Assigned to", "Caller"],
        critical_threshold=crit["INC"], extra_critical=None)

    distribution_sla_html = build_distribution_sla_section(open_sctask, open_inc, config)
    status_aging_html = build_status_aging_section(open_sctask, open_inc, config)

    daily_current_sctask = m.daily_trend_current_month(sctask, ref)
    daily_current_inc = m.daily_trend_current_month(inc, ref)

    daily_trend_html = build_trend_comparison_section(
        "Daily Evolution by Ticket Type (Current Month)",
        daily_current_sctask, daily_current_inc, "2A", "2B", line_label="Net Balance",
        layout="stacked", sctask_backlog=len(open_sctask), inc_backlog=len(open_inc))

    conversions_html = build_conversions_section(sctask, inc, ref, config)

    ini, _ = m.month_bounds(ref)
    period_label = ini.strftime("%m/%Y")
    sla = config["SLA_DAYS"]

    divider = '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="border-top:2px solid #e8ecf0; font-size:1px; line-height:1px;">&nbsp;</td></tr></table><div style="height:20px; line-height:20px;">&nbsp;</div>'

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Executive Dashboard</title>
    <style>{CSS}</style>
</head>
<body style="font-family:{FONT_STACK}; background-color:#f4f4f4; margin:0; padding:20px 10px;">
    <table class="email-container" width="100%" cellpadding="0" cellspacing="0" border="0" align="center"
           style="max-width:1300px; margin:0 auto; background-color:#ffffff; border-radius:8px;">
        <tr><td>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
            <tr><td align="center" style="background-color:#0B1E40; color:#ffffff; padding:18px 20px; border-radius:8px 8px 0 0; font-family:{FONT_STACK};">
                <h2 style="margin:0 0 6px 0; font-size:22px; letter-spacing:0.3px; color:#ffffff; font-family:{FONT_STACK};">IT Executive Dashboard &mdash; SCTASK x INC x PRB</h2>
                <p style="margin:0; color:#9BBAD2; font-size:13px; font-family:{FONT_STACK};">Period: {period_label} &nbsp;|&nbsp; Generated: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')} &nbsp;|&nbsp;
                   SLA SCTASK={sla['SCTASK']}d &nbsp; SLA INC={sla['INC']}d &nbsp; SLA PRB={sla['PRB']}d</p>
            </td></tr>
        </table>
        <div class="content" style="padding:22px;">

            {section_header("Overview")}
            {overview}

            {sctask_html}

            {divider}
            {inc_html}

            {divider}
            {distribution_sla_html}

            {divider}
            {status_aging_html}

            {divider}
            {daily_trend_html}

            {divider}
            {conversions_html}

        </div>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="footer">
            <tr><td align="center" style="padding:15px; font-size:12px; color:#888888; background-color:#f4f4f4; border-top:1px solid #dddddd; border-radius:0 0 8px 8px; font-family:{FONT_STACK};">
                Automated report generated by the IT Metrics Dashboard script &middot; {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
            </td></tr>
        </table>
        </td></tr>
    </table>
</body>
</html>"""

    kpis = {
        "total_backlog": total_backlog, "open_sctask": len(open_sctask_quick),
        "open_inc": len(open_inc_quick), "open_prb": len(open_prb_quick),
        "mttr_overall": mttr_overall, "period_label": period_label,
    }
    return html, kpis, ref

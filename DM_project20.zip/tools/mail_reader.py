"""
================================================================================
LEITURA DE E-MAIL: RESPOSTAS DE APROVAÇÃO (OUTLOOK, SÓ WINDOWS)
================================================================================
Único ponto do projeto que LÊ e-mail (tools/smtp.py só ENVIA). Usado pela tela
'Create ctask' para varrer a Caixa de Entrada do Outlook procurando respostas
às aprovações de Change disparadas pela tela Feature Release (ver
'release_task.release_mailer.ReleaseMailer.send_approval_email' - mesmo
assunto usado para casar a resposta aqui, devolvido por aquela função
justamente para isso).

SÓ WINDOWS (Outlook COM via 'win32com.client' + 'pythoncom', import feito só
dentro da função) - mesmo mecanismo já usado para ENVIAR e-mail em
'tools/smtp.py:send_outlook_windows' (inclusive o CoInitialize/CoUninitialize
por thread). Não existe equivalente Mac/IMAP: fora do Windows, devolve um erro
claro em vez de tentar e falhar silenciosamente.
"""

import os
import platform
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List

from tools.temp_storage import create_path_temp

logger = logging.getLogger("MailReader")

IS_WINDOWS = platform.system() == "Windows"

# Palavras que indicam aprovação no CORPO da resposta - inclui grafias/erros de
# digitação comuns observados no uso real (mesma lista do fluxo de referência
# que originou esta tela), comparadas em minúsculas.
PALAVRAS_APROVACAO = [
    "aprovado", "aproavdo", "aproado", "approvado", "aprovada",
    "aprovaod", "approved", "approve", "aprove", "aproved",
]

OUTLOOK_INBOX_FOLDER = 6  # olFolderInbox
DIAS_LOOKBACK_PADRAO = 30  # respostas mais antigas que isso não são varridas (performance)
OL_MSG_FORMAT = 3  # olMSG - formato usado por MailItem.SaveAs para preservar anexos


def _salvar_evidencia(item, pendente_id) -> List[str]:
    """Salva a resposta de aprovação como '.msg' (preserva o e-mail original,
    incluindo cabeçalhos) e cada anexo do item, numa subpasta isolada por
    pendente dentro de 'path_temp' - NUNCA limpa o resto de 'path_temp'
    (diferente do fluxo legado, que apagava a pasta inteira antes de salvar;
    aqui ela é compartilhada com outras automações). Nunca lança exceção:
    falha em salvar evidência não deve derrubar a verificação de aprovação."""
    arquivos: List[str] = []
    try:
        destino = os.path.join(create_path_temp(), "ctask_evidencias", str(pendente_id))
        os.makedirs(destino, exist_ok=True)

        caminho_msg = os.path.join(destino, f"aprovacao_{pendente_id}.msg")
        item.SaveAs(caminho_msg, OL_MSG_FORMAT)
        arquivos.append(caminho_msg)

        for anexo in item.Attachments:
            try:
                caminho_anexo = os.path.join(destino, str(anexo.FileName))
                anexo.SaveAsFile(caminho_anexo)
                arquivos.append(caminho_anexo)
            except Exception as e_anexo:
                logger.warning(f"⚠️ [MailReader] Falha ao salvar anexo '{getattr(anexo, 'FileName', '?')}' da evidência: {e_anexo}")
    except Exception as e:
        logger.warning(f"⚠️ [MailReader] Falha ao salvar evidência (.msg) do pendente {pendente_id}: {e}")

    return arquivos


def verificar_respostas_aprovacao_outlook(
    pendentes: List[Dict[str, Any]],
    emails_autorizados: List[str] = None,
    dias_lookback: int = DIAS_LOOKBACK_PADRAO,
) -> Dict[str, Any]:
    """
    :param pendentes: [{'id': <int>, 'assunto': <str>, 'criado_em': datetime|None}, ...] -
        aprovações aguardando resposta (ver 'CtaskAprovacao', status='pendente').
        'criado_em' (quando informado) ancora a busca no DIA em que a solicitação
        foi enviada, em vez de uma janela genérica - ver 'dias_lookback'.
    :param emails_autorizados: lista de e-mails habilitados a aprovar (ver
        'DmlApprovalContact', configurada na tela 'Create ctask'). OBRIGATÓRIA -
        vazia/None interrompe a busca ANTES de tocar o Outlook (ver checagem
        logo abaixo): sem remetente autorizado configurado não há o que
        procurar, e variar por toda a caixa de entrada sem esse filtro foi
        justamente o que causava buscas travando por minutos.
    :param dias_lookback: TETO de segurança - a busca nunca olha mais para trás
        que isso, mesmo que algum pendente tenha sido criado há mais tempo.

    Busca OBJETIVA: varre SÓ a Caixa de Entrada (sem recursão em subpastas -
    'Restrict' já é suportado nativamente pelo Outlook e é run bem mais rápido
    que iterar pasta por pasta) restrita a partir do dia de criação mais antigo
    entre os pendentes informados (nunca além de 'dias_lookback'). Para cada
    item candidato, exige TODAS as condições:
      1. Subject CONTÉM o assunto original de algum pendente (cobre replies
         com prefixo 'RE: '/'RES: '/'Re: '/'Res: ' etc., que o Outlook antepõe
         sem alterar o resto do assunto);
      2. o e-mail foi recebido no dia da criação daquele pendente específico
         em diante (com 1 dia de folga para diferença de fuso horário - o
         registro é gravado em UTC, o Outlook mostra hora local);
      3. o remetente está em 'emails_autorizados'.
    Quando a resposta é uma aprovação válida (contém alguma palavra de
    'PALAVRAS_APROVACAO' no corpo), salva o e-mail e seus anexos como
    evidência (ver '_salvar_evidencia') para anexar depois na CTASK criada.

    Devolve {'status': 'success', 'respostas': [{'id', 'aprovado': bool, 'de': str,
    'evidencia_arquivos': [...]}]} - pendentes sem NENHUMA resposta encontrada (ou
    só respostas de remetente não autorizado/fora do período) simplesmente não
    aparecem em 'respostas' (continuam pendentes na próxima verificação). Nunca
    lança exceção: falha vira {'status': 'error', 'message': ..., 'respostas': []}.
    """
    autorizados_norm = {e.strip().lower() for e in (emails_autorizados or []) if e and e.strip()}
    if not IS_WINDOWS:
        return {
            "status": "error",
            "message": "Leitura de e-mail só é suportada no Windows (Outlook COM) - "
                       f"sistema atual: {platform.system()}.",
            "respostas": [],
        }

    if not pendentes:
        return {"status": "success", "respostas": []}

    if not autorizados_norm:
        return {
            "status": "error",
            "message": "Nenhum contato de aprovação cadastrado - cadastre ao menos um e-mail "
                       "em 'Contatos de Aprovação' antes de verificar.",
            "respostas": [],
        }

    import win32com.client
    import pythoncom

    pythoncom.CoInitialize()
    respostas: List[Dict[str, Any]] = []
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        namespace = outlook.GetNamespace("MAPI")
        inbox = namespace.GetDefaultFolder(OUTLOOK_INBOX_FOLDER)

        cutoff_padrao = datetime.now() - timedelta(days=dias_lookback)
        datas_criacao = [p["criado_em"] for p in pendentes if isinstance(p.get("criado_em"), datetime)]
        # Ponto de partida da busca: dia de criação mais antigo entre os pendentes (com 1
        # dia de folga - ver docstring), nunca mais longe no passado que 'dias_lookback'.
        data_limite = max(min(datas_criacao) - timedelta(days=1), cutoff_padrao) if datas_criacao else cutoff_padrao

        items = inbox.Items
        items.Sort("[ReceivedTime]", True)  # mais recentes primeiro
        # '%I:%M %p' (12h + AM/PM) - MESMO formato usado em
        # 'dml_change_finder._buscar_change_windows'. '%H:%M %p' (24h + AM/PM)
        # gera string inválida (ex.: "17:32 PM") que o Outlook não interpreta
        # corretamente, fazendo o Restrict devolver 0 itens silenciosamente.
        filtro_data = data_limite.strftime('%m/%d/%Y %I:%M %p')
        try:
            items = items.Restrict(f"[ReceivedTime] >= '{filtro_data}'")
            logger.info(f"🔎 [MailReader] Restringindo Inbox a partir de '{filtro_data}'.")
        except Exception as e_restrict:
            logger.warning(f"⚠️ [MailReader] Falha ao restringir por data '{filtro_data}' (varrendo tudo mesmo assim): {e_restrict}")

        pendentes_restantes = list(pendentes)

        for item in items:
            if not pendentes_restantes:
                break
            try:
                assunto_item = str(getattr(item, "Subject", "") or "")
                corpo_item = str(getattr(item, "Body", "") or "")
                remetente_item = str(getattr(item, "SenderEmailAddress", "") or "")
                recebido_item = getattr(item, "ReceivedTime", None)
            except Exception as e_item:
                logger.warning(f"⚠️ [MailReader] Falha ao ler item da Caixa de Entrada: {e_item}")
                continue

            encontrados = [p for p in pendentes_restantes if p.get("assunto") and p["assunto"] in assunto_item]
            for pendente in encontrados:
                criado_em = pendente.get("criado_em")
                if isinstance(criado_em, datetime) and recebido_item is not None:
                    recebido_naive = datetime(recebido_item.year, recebido_item.month, recebido_item.day,
                                               recebido_item.hour, recebido_item.minute, recebido_item.second)
                    if recebido_naive < criado_em - timedelta(days=1):
                        continue  # resposta anterior à própria solicitação - não é dela

                if remetente_item.strip().lower() not in autorizados_norm:
                    logger.info(f"⏭️ [MailReader] Resposta de '{remetente_item}' ignorada (não está na lista de contatos de aprovação).")
                    continue

                aprovado = any(palavra in corpo_item.lower() for palavra in PALAVRAS_APROVACAO)
                evidencia_arquivos = _salvar_evidencia(item, pendente["id"]) if aprovado else []
                respostas.append({
                    "id": pendente["id"], "aprovado": aprovado, "de": remetente_item,
                    "evidencia_arquivos": evidencia_arquivos,
                })
                pendentes_restantes.remove(pendente)

        logger.info(f"📬 [MailReader] {len(respostas)}/{len(pendentes)} aprovação(ões) com resposta encontrada.")
        return {"status": "success", "respostas": respostas}

    except Exception as e:
        logger.error(f"❌ [MailReader] Erro ao ler Caixa de Entrada do Outlook: {e}")
        return {"status": "error", "message": str(e), "respostas": respostas}
    finally:
        pythoncom.CoUninitialize()

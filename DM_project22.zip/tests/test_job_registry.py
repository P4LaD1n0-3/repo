import pytest
from tools.job_registry import JobRegistry

def test_job_registry_lifecycle_and_log_retention():
    registry = JobRegistry()
    job_id = "test-job-123"
    user_id = 1
    module = "portal_task"

    # 1. Register
    registry.register(job_id, user_id, module=module)
    active = registry.get_active_job(user_id, module=module)
    assert active["active"] is True
    assert active["job_id"] == job_id

    # 2. Append logs
    registry.append_log(job_id, "Log linha 1")
    registry.append_log(job_id, "Log linha 2")

    logs_resp = registry.get_logs(job_id, user_id, since=0)
    assert logs_resp["status"] == "running"
    assert logs_resp["logs"] == ["Log linha 1", "Log linha 2"]
    assert logs_resp["next_since"] == 2

    # Polling incremental
    registry.append_log(job_id, "Log linha 3")
    inc_resp = registry.get_logs(job_id, user_id, since=2)
    assert inc_resp["logs"] == ["Log linha 3"]
    assert inc_resp["next_since"] == 3

    # 3. Unregister (Job completes)
    registry.unregister(job_id, status="finished")
    
    # After unregister, get_active_job returns active=False
    active_after = registry.get_active_job(user_id, module=module)
    assert active_after["active"] is False

    # But logs are STILL RETAINED in memory!
    final_logs = registry.get_logs(job_id, user_id, since=0)
    assert final_logs["status"] == "finished"
    assert len(final_logs["logs"]) == 3
    assert final_logs["logs"][-1] == "Log linha 3"

    # Latest job lookup finds it
    latest = registry.get_latest_job(user_id, module=module)
    assert latest["found"] is True
    assert latest["job_id"] == job_id
    assert latest["status"] == "finished"
    assert len(latest["logs"]) == 3

    # Clear module logs
    registry.clear_module_logs(user_id, module=module)
    assert registry.get_latest_job(user_id, module=module)["found"] is False

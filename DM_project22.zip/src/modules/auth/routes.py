import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify

from flask_login import login_user, logout_user, login_required, current_user
from src.models import db, User

current_dir = os.path.dirname(os.path.abspath(__file__))
auth_bp = Blueprint('auth', __name__, template_folder=current_dir)

@auth_bp.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(url_for('apps.index'))
    return redirect(url_for('auth.login'))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('apps.index'))
        
    if request.method == 'POST':
        email_or_user = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        remember = True if request.form.get('remember') else False

        user = User.query.filter(
            (User.email == email_or_user) | (User.full_name == email_or_user)
        ).first()

        if user and user.check_password(password):
            login_user(user, remember=remember)
            return redirect(url_for('apps.index'))
        else:
            flash('Usuário ou senha incorretos.', 'danger')

    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('apps.index'))

    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        repeat_password = request.form.get('repeat_password', '')

        if not full_name or not email or not password:
            flash('Todos os campos são obrigatórios.', 'warning')
            return render_template('register.html')

        if password != repeat_password:
            flash('As senhas não coincidem.', 'danger')
            return render_template('register.html')

        user_exists = User.query.filter((User.email == email) | (User.full_name == full_name)).first()
        if user_exists:
            flash('Email ou nome de usuário já cadastrado.', 'danger')
            return render_template('register.html')

        new_user = User(full_name=full_name, email=email)
        new_user.set_password(password)

        db.session.add(new_user)
        db.session.commit()

        flash('Conta criada com sucesso! Faça login.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Você saiu do sistema.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/api/profile/update_info', methods=['POST'])
@login_required
def update_profile_info():
    """Atualiza servicenow_name, signature_name e email do usuário no SQLite."""
    data = request.get_json() or {}
    current_user.servicenow_name = data.get('servicenow_name', current_user.servicenow_name)
    current_user.signature_name = data.get('signature_name', current_user.signature_name)
    current_user.email = data.get('email', current_user.email)
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Informações da conta atualizadas com sucesso!'})

@auth_bp.route('/api/profile/update_password', methods=['POST'])
@login_required
def update_profile_password():
    """Atualiza a senha do usuário logado no SQLite."""
    data = request.get_json() or {}
    current_password = data.get('current_password', '')
    new_password = data.get('new_password', '')
    confirm_password = data.get('confirm_password', '')

    if not current_user.check_password(current_password):
        return jsonify({'status': 'error', 'message': 'Senha atual incorreta.'}), 400

    if new_password != confirm_password:
        return jsonify({'status': 'error', 'message': 'A nova senha e a confirmação não coincidem.'}), 400

    if len(new_password) < 4:
        return jsonify({'status': 'error', 'message': 'A nova senha deve ter no mínimo 4 caracteres.'}), 400

    current_user.set_password(new_password)
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Senha alterada com sucesso!'})

@auth_bp.route('/api/profile/toggle_pin', methods=['POST'])
@login_required
def toggle_pin():
    """Alterna a pinagem de atalhos no topo (limite de no máximo 5 itens)."""
    import json
    data = request.get_json() or {}
    module_key = data.get('module_key')

    if not module_key:
        return jsonify({'status': 'error', 'message': 'Módulo não especificado.'}), 400

    pinned = list(current_user.pinned_list)

    if module_key in pinned:
        pinned.remove(module_key)
        message = f"Módulo '{module_key}' desfixado do topo."
    else:
        if len(pinned) >= 6:
            return jsonify({'status': 'error', 'message': 'Limite máximo de 6 atalhos fixados no topo atingido!'}), 400
        pinned.append(module_key)
        message = f"Módulo '{module_key}' fixado no topo com sucesso!"

    current_user.pinned_modules = json.dumps(pinned)
    db.session.commit()

    return jsonify({
        'status': 'success',
        'message': message,
        'pinned_modules': pinned
    })



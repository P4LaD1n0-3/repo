"""
================================================================================
SERVIÇO EXCLUSIVO: DESABILITAR USUÁRIO
================================================================================
Módulo exclusivo responsável pela automação de 'Desabilitar usuário'.
Localizado em: src/modules/portal_task/user_desabilitar_service.py
"""

import logging
from typing import Dict, Any, Optional, Union
from playwright.async_api import Page
from tools.portal_task_base_service import PortalTaskUpmService
from tools.base_automation import SelectorManager
from tools.planilha_cadastro import ler_planilha_emails

logger = logging.getLogger("UserDesabilitarService")

class UserDesabilitarService(PortalTaskUpmService):
    """
    Classe especialista para automação de 'Desabilitar usuário'.
    Herda de PortalTaskUpmService (ServiceNowDriver + UpmDriver + DatabaseMixin) -
    reaproveita 'gerenciar_status_usuario_upm' (mesma primitiva de busca+status
    já usada pelo Cadastro/Alterar/Reset) para inativar a conta de cada e-mail
    encontrado na planilha anexada à RITM.
    """

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Processa a automação de Desabilitar Usuário em 1 URL do ServiceNow."""
        logger.info(f"🚫 [UserDesabilitarService] Desabilitando usuário(s) em: {url}")
        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Desabilitar usuário",
            "sctasks": [],
            "resultados": [],
            "status": "success",
            "error": None
        }

        try:
            # Captura RITM/SCTASK e baixa eventuais anexos (.xlsx) em 1 página única.
            dados_captura = await self.capturar_sctask_pagina_unica(page=page, url=url)
            resultado["sctasks"] = dados_captura.get("sctasks", [])
            resultado["ritm"] = dados_captura.get("ritm")

            emails: list = []
            for caminho in dados_captura.get("downloaded_files", []):
                if caminho.lower().endswith(".xlsx"):
                    emails.extend(ler_planilha_emails(caminho))

            emails_unicos = sorted({(e or "").strip().lower() for e in emails if e})

            if emails_unicos:
                await self.login_upm(page=page)
                for email in emails_unicos:
                    resultado_status = await self.gerenciar_status_usuario_upm(page=page, email=email, status="I")
                    resultado["resultados"].append(resultado_status)
                    if resultado_status.get("resultado") != "success":
                        logger.warning(f"⚠️ [UserDesabilitarService] Falha ao desabilitar '{email}': {resultado_status.get('error')}")
            else:
                logger.info(f"ℹ️ [UserDesabilitarService] Nenhuma planilha com e-mail(s) encontrada para desabilitar em {url}.")

            logger.info(f"✅ [UserDesabilitarService] Concluído em {url}. SCTASKs: {resultado['sctasks']}")
        except Exception as e:
            logger.error(f"❌ [UserDesabilitarService] Erro em {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

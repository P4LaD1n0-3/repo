"""
================================================================================
SERVIÇO EXCLUSIVO: ENCERRAR TAREFA
================================================================================
Módulo exclusivo responsável pela automação de 'Encerrar'.
Localizado em: src/modules/portal_task/task_encerrar_service.py
"""

import logging
from typing import Dict, Any, Optional, Union
from playwright.async_api import Page
from tools.servicenow_batch_service import ServiceNowBatchService
from tools.base_automation import SelectorManager

logger = logging.getLogger("TaskEncerrarService")

class TaskEncerrarService(ServiceNowBatchService):
    """
    Classe especialista para automação de 'Encerrar'.
    Herda de ServiceNowBatchService (laço de lote pronto por herança - ver
    tools/servicenow_batch_service.py) - este serviço só mexe no ServiceNow,
    por isso não precisa de PortalTaskUpmService.
    """

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Processa a automação de Encerrar em 1 URL do ServiceNow."""
        logger.info(f"🛑 [TaskEncerrarService] Encerrando tarefa em: {url}")
        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Encerrar",
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            # Captura de SCTASK em Página Única
            dados_captura = await self.capturar_sctask_pagina_unica(page=page, url=url)
            resultado["sctasks"] = dados_captura.get("sctasks", [])
            resultado["ritm"] = dados_captura.get("ritm")

            # Preenchimento e encerramento da SCTASK via método herdado
            if resultado["sctasks"]:
                for sctask_id in resultado["sctasks"]:
                    await self.preencher_e_encerrar_sctask(
                        page=page,
                        sctask_id_ou_url=sctask_id,
                        configuration_item="Portal Corretor",
                        state="Closed Complete",
                        work_notes="Tarefa encerrada automaticamente via PortalTask TaskEncerrarService."
                    )

            logger.info(f"✅ [TaskEncerrarService] Concluído em {url}. SCTASKs: {resultado['sctasks']}")
        except Exception as e:
            logger.error(f"❌ [TaskEncerrarService] Erro em {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

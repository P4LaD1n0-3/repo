"""
================================================================================
SERVIÇO EXCLUSIVO: RESET DE MFA
================================================================================
Módulo exclusivo responsável pela automação de 'Reset de mfa'.
Toda a lógica (varredura de chamados, leitura de planilha/texto de e-mails,
laço de reset no UPM) vive em 'ResetUpmServiceBase' (reset_common.py) - este
arquivo só declara a especialização por HERANÇA: 'TIPO_RESET' = "mfa".
Localizado em: src/modules/portal_task/mfa_reset_service.py
"""

from src.modules.portal_task.reset_common import ResetUpmServiceBase


class MfaResetService(ResetUpmServiceBase):
    """Especialização de 'Reset de mfa' - reseta somente o MFA (mantém a senha atual) de cada e-mail encontrado."""

    TIPO_RESET = "mfa"
    ACAO = "Reset de mfa"

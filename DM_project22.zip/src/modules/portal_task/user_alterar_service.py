"""
================================================================================
SERVIÇO EXCLUSIVO: ALTERAR USUÁRIO (COM PARÂMETROS DO MODAL)
================================================================================
Módulo exclusivo responsável pela automação de 'Alterar usuário'.
Processa os dados salvos do modal (E-mail origem/destino, RITM, CNPJ, Nome,
Produto ID) - port fiel de 'update_user()'/'verifyBroker()'/'updateBrokerUpm()'
de update_usuario.txt, reaproveitando por HERANÇA (PortalTaskUpmService) as
mesmas primitivas de UPM já usadas pelo Cadastro de usuário.
Localizado em: src/modules/portal_task/user_alterar_service.py
"""

import os
import shutil
import logging
import re
from typing import Dict, Any, Optional, Union
from playwright.async_api import Page
from tools.portal_task_base_service import PortalTaskUpmService
from tools.base_automation import SelectorManager
from tools.sql_script_builder import gerar_sql_update_usuario, salvar_sql_alteracao_usuario
from tools.temp_storage import PATH_TEMP

logger = logging.getLogger("UserAlterarService")

class UserAlterarService(PortalTaskUpmService):
    """
    Classe especialista para automação de 'Alterar usuário'.
    Herda de PortalTaskUpmService (ServiceNowDriver + UpmDriver + DatabaseMixin).
    """

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        ========================================================================
        FLUXO DE ALTERAÇÃO DE USUÁRIO (fiel a 'update_user()' de update_usuario.txt)
        ========================================================================
        1. Lê os parâmetros do modal (e-mail De/Para, RITM, CNPJ_Para, Nome_Para,
           Produto_ID_Para, se é Assessoria) - já coletados pelo frontend/routes.py.
        2. Localiza o usuário pelo e-mail De e a organização de destino no banco
           do Portal (DatabaseMixin.consultar_usuario_organizacao_portal, port de
           'verifyBroker'). Se o CNPJ_Para não for informado, usa a organização
           ATUAL do próprio usuário.
        3. Gera o script SQL manual de alteração (UPDATE TB_UC_USUARIO +, se um
           produto novo foi informado, DELETE/INSERT em TB_UC_USUARIO_PRODUTO) -
           para revisão/execução por um DBA, nunca executado automaticamente.
        4. Se o e-mail mudou OU a organização mudou, aplica a alteração real no
           UPM (alterar_usuario_upm, herdado): inativa a conta, aplica os novos
           dados, reativa e reseta a senha.
        5. Organiza os artefatos gerados (script SQL + evidência de senha em
           .txt + screenshot) na pasta configurada na tela ("Caminho do
           Arquivo" / 'output_directory'), numa subpasta por RITM - fiel ao
           bloco final de 'update_user()' (que sempre salvava tudo em
           '{output}/{RITM_NUMBER}'), mesmo padrão de 'output_directory' já
           usado pelo Cadastro de usuário (PASSO 5 em user_cadastro_service.py):
           gera em 'path_temp' e COPIA (não move) para a pasta configurada -
           'path_temp' continua disponível para consulta manual.
        """
        params = dados_formulario or {}
        logger.info("=" * 65)
        logger.info(f"✏️ [UserAlterarService] Executando Alteração de Usuário em: {url}")
        logger.info(f"   ► Assessoria Toggle: {params.get('alt_is_assessoria')}")
        logger.info(f"   ► De: E-mail='{params.get('alt_de_email')}' | RITM='{params.get('alt_de_ritm')}'")
        logger.info(f"   ► Para: E-mail='{params.get('alt_para_email')}' | CNPJ='{params.get('alt_para_cnpj')}' | Nome='{params.get('alt_para_nome')}' | ProdutoID='{params.get('alt_para_produto_id')}'")
        logger.info("=" * 65)

        email_de = (params.get("alt_de_email") or "").replace(" ", "").lower()
        email_para = (params.get("alt_para_email") or "").replace(" ", "").lower()
        cnpj_para = re.sub(r"\D", "", params.get("alt_para_cnpj") or "")
        nome_para = (params.get("alt_para_nome") or "").strip()
        produto_id_para = (params.get("alt_para_produto_id") or "").strip()
        is_assessoria = bool(params.get("alt_is_assessoria"))
        ritm = (params.get("alt_de_ritm") or "SEM_RITM").strip() or "SEM_RITM"

        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Alterar usuário",
            "modal_params": params,
            "sctasks": [],
            "status": "success",
            "error": None,
            "email_final": None,
            "senha_gerada": None,
            "screenshot_path": None,
            "sql_script_path": None,
            "arquivos_organizados_em": None,
        }

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)
            await page.wait_for_timeout(3000)

            dados_raspagem = await self.process_servicenow_page(page, url)
            resultado["sctasks"] = dados_raspagem.get("sctasks", [])

            if not email_de:
                resultado["status"] = "error"
                resultado["error"] = "E-mail de origem ('De') não informado."
                return resultado

            # PASSO 2: localiza usuário + organização de destino no banco do Portal
            # (herdado de DatabaseMixin - nunca lança exceção, devolve 'encontrado'/'erro').
            broker = self.consultar_usuario_organizacao_portal(
                email=email_de, cnpj=cnpj_para, incluir_assessoria=is_assessoria
            )
            if not broker["encontrado"]:
                resultado["status"] = "error"
                resultado["error"] = broker["erro"] or "E-mail ou CNPJ_Para informado inválido."
                logger.warning(f"⚠️ [UserAlterarService] {resultado['error']}")
                return resultado

            # PASSO 3: gera o script SQL manual (revisão de DBA) - nunca executado
            # automaticamente contra o banco.
            sql_texto = gerar_sql_update_usuario(
                ritm=ritm,
                email_de=email_de,
                email_para=email_para,
                nome_para=nome_para,
                broker=broker,
                produto_id_para=produto_id_para,
            )
            resultado["sql_script_path"] = salvar_sql_alteracao_usuario(ritm, sql_texto)

            # PASSO 4: aplica a alteração real no UPM só se algo que exige alteração
            # de tela foi informado (e-mail novo OU organização diferente da atual) -
            # mesma condição de 'update_usuario.txt': `if _email_para != "" or
            # result[0]['cnpj'] != result[0]['user_cnpj']`.
            organizacao_mudou = broker.get("cnpj") != broker.get("user_cnpj")
            if email_para or organizacao_mudou:
                await self.login_upm(page=page)
                alteracao = await self.alterar_usuario_upm(
                    page=page,
                    email_de=email_de,
                    email_para=email_para,
                    nome_para=nome_para,
                    nova_razao=broker.get("razao") or "",
                    nova_susep=broker.get("susep") or "",
                )
                resultado["senha_gerada"] = alteracao.get("senha_gerada")
                resultado["screenshot_path"] = alteracao.get("screenshot_path")
                if alteracao.get("status") != "success":
                    resultado["status"] = "error"
                    resultado["error"] = alteracao.get("mensagem")

            resultado["email_final"] = email_para or email_de

            # PASSO 5: organiza os artefatos gerados (ver docstring acima) - roda
            # SEMPRE que houver algo pra organizar, mesmo se o PASSO 4 (alteração
            # no UPM) não rodou (ex.: só o script SQL foi gerado).
            arquivos_gerados = set()
            if resultado.get("sql_script_path") and os.path.exists(resultado["sql_script_path"]):
                arquivos_gerados.add(resultado["sql_script_path"])

            if resultado.get("senha_gerada"):
                caminho_txt = os.path.join(PATH_TEMP, f"{resultado['email_final'].replace('@', '_at_')}.txt")
                try:
                    with open(caminho_txt, "w", encoding="utf-8") as f:
                        f.write(str(resultado["senha_gerada"]))
                    arquivos_gerados.add(caminho_txt)
                except Exception as e_txt:
                    logger.warning(f"⚠️ [UserAlterarService] Falha ao salvar evidência de senha em .txt: {e_txt}")

            if resultado.get("screenshot_path") and os.path.exists(resultado["screenshot_path"]):
                arquivos_gerados.add(resultado["screenshot_path"])

            output_dir = ((dados_formulario or {}).get("output_directory") or "").strip().strip("'\"")
            if output_dir and arquivos_gerados:
                destino_ritm = os.path.join(output_dir, ritm)
                os.makedirs(destino_ritm, exist_ok=True)
                for origem in arquivos_gerados:
                    try:
                        shutil.copy(origem, os.path.join(destino_ritm, os.path.basename(origem)))
                    except Exception as e_copy:
                        logger.warning(f"⚠️ [UserAlterarService] Falha ao copiar '{origem}' para {destino_ritm}: {e_copy}")
                resultado["arquivos_organizados_em"] = destino_ritm
                logger.info(f"📁 [UserAlterarService] {len(arquivos_gerados)} arquivo(s) copiado(s) para: {destino_ritm}")
            elif not output_dir:
                logger.info(
                    f"ℹ️ [UserAlterarService] 'Caminho do Arquivo' não configurado - arquivo(s) de "
                    f"{ritm} permanecem em 'path_temp'."
                )

            logger.info(f"✅ [UserAlterarService] Concluído em {url} para '{resultado['email_final']}'. SCTASKs: {resultado['sctasks']}")
        except Exception as e:
            logger.error(f"❌ [UserAlterarService] Erro em {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

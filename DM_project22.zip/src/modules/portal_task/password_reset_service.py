"""
================================================================================
SERVIÇO EXCLUSIVO: RESET DE SENHA
================================================================================
Módulo exclusivo responsável pela automação de 'Reset de senha'.
Toda a lógica (varredura de chamados, leitura de planilha/texto de e-mails,
laço de reset no UPM) vive em 'ResetUpmServiceBase' (reset_common.py) - este
arquivo só declara a especialização por HERANÇA: 'TIPO_RESET' = "reset".
Localizado em: src/modules/portal_task/password_reset_service.py
"""

from src.modules.portal_task.reset_common import ResetUpmServiceBase


class PasswordResetService(ResetUpmServiceBase):
    """Especialização de 'Reset de senha' - reseta a senha (não apenas o MFA) de cada e-mail encontrado."""

    TIPO_RESET = "reset"
    ACAO = "Reset de senha"

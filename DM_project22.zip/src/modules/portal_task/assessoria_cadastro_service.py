"""
================================================================================
SERVIÇO EXCLUSIVO: CADASTRO DE ASSESSORIA
================================================================================
Módulo exclusivo responsável pela automação de 'Cadastro de assessoria'.
Localizado em: src/modules/portal_task/assessoria_cadastro_service.py
"""

import logging
from typing import Dict, Any, Optional, Union
from playwright.async_api import Page
from tools.servicenow_batch_service import ServiceNowBatchService
from tools.base_automation import SelectorManager

logger = logging.getLogger("AssessoriaCadastroService")

class AssessoriaCadastroService(ServiceNowBatchService):
    """
    Classe especialista para automação de 'Cadastro de assessoria'.
    Herda de ServiceNowBatchService (laço de lote pronto por herança - ver
    tools/servicenow_batch_service.py) - este serviço ainda não interage com o
    UPM, por isso não precisa de PortalTaskUpmService.
    """

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Processa a automação de Cadastro de Assessoria em 1 URL do ServiceNow."""
        logger.info(f"🏢 [AssessoriaCadastroService] Iniciando processamento em: {url}")
        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Cadastro de assessoria",
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)
            await page.wait_for_timeout(3000)

            # Processa a página e extrai os códigos SCTASK
            dados_raspagem = await self.process_servicenow_page(page, url)
            resultado["sctasks"] = dados_raspagem.get("sctasks", [])
            logger.info(f"✅ [AssessoriaCadastroService] Concluído em {url}. SCTASKs: {resultado['sctasks']}")
        except Exception as e:
            logger.error(f"❌ [AssessoriaCadastroService] Erro em {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

"""
================================================================================
CORPO DO E-MAIL DE APROVAÇÃO DE DML
================================================================================
Porta para o Flask app as funções de 'sendmail_exemplo/mail_sender.txt'
(exclusivas do módulo 'send_dml'), responsáveis por montar o corpo HTML do
e-mail de aprovação de execução de scripts DML.

'conteudo()' e 'mensagem()' são transcrições EXATAS do legado (mesmo texto/
estilo/estrutura HTML, mesma assinatura AIG) - é isso que efetivamente define
a aparência do e-mail no Outlook.

A única parte adaptada é a orquestração em torno delas: no legado,
'montar_email()' lia os scripts de uma pasta fixa em disco ('path_temp') e
'desenho()' recuperava Problem/Justificativa fazendo busca de substring num
array de perguntas/respostas produzido por um wizard sequencial (ver
sendmail_exemplo/mail.html - fetch('/questions') + fetch('/submit')). Isso só
funcionava para 1 usuário por vez (estado global em disco) e não cabia numa
tela com formulário estruturado. Aqui:
  - 'detectar_scripts_por_ambiente()' substitui 'montar_email()': mesma lógica
    de reconhecimento de ambiente por substring no nome do arquivo, mas a
    partir da lista de nomes enviada na requisição (upload dinâmico).
  - 'montar_bloco_ambiente()' substitui 'desenho()': mesma detecção de
    SCHEMA/LOCAL e mesma montagem da tabela/lista de scripts, porém recebendo
    Problem/Justificativa como campos já estruturados (o formulário novo tem
    um campo dedicado por ambiente, em vez do wizard de uma pergunta por vez).
"""

import unidecode

# Ambientes reconhecidos a partir do nome do arquivo .sql (mesma lista de
# 'montar_email()' em mail_sender.txt).
AMBIENTES = ['EBAOGS', 'EBAOGC', 'EBAOST', 'EBAORP', 'GEPRODB', 'PORTALDB', 'CIRCULARDB']

# (SCHEMA, LOCAL/Aplicacao) por ambiente - mesmo mapeamento fixo do
# elif-chain de 'desenho()' em mail_sender.txt. Valores fixos de propósito
# (não mudam entre execuções) - não configuráveis pela tela.
SCHEMA_PADRAO = {
    'EBAOGS': ('GS Schema', 'EBAOGS'),
    'EBAOGC': ('GC Schema', 'EBAOGC'),
    'EBAOST': ('ST Schema', 'EBAOST'),
    'EBAORP': ('RP Schema', 'RP'),
    'PORTALDB': ('PORTAL_DB - xxxx', 'PORTAL'),
    'GEPRODB': ('GEPRO_DB - yyyyy', 'GEPRO'),
    'CIRCULARDB': ('CIRCULAR_DB - zzzzz', 'CIRCULAR'),
}


############################################################   CORPO DO EMAIL   ############################################################


def conteudo(Change, Nome, Email, send_to, send_name):
    """Transcrição exata de 'conteudo()' (mail_sender.txt): saudação + assinatura AIG."""
    titulo = [
        f'<span lang=PT-BR>Prezados,</span><span lang=PT-BR style="mso-fareast-language:PT-BR"><o:p></o:p></span></p><br>'
        f"""<span lang=PT-BR><a style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; font-weight:500; font-size: 12px; text-decoration: none; color: #2B579A; background-color: #E1DFDD; display: inline; padding: 2px;" href="mailto:{send_to}">@{ send_name }</a>, favor aprovar a execução do(s) script(s) de DML abaixo.</><br><br>"""
        f'<span lang=PT-BR>Os scripts serão documentados na <strong>{Change}</strong>.</span><br><br>'
        f'<span lang=PT-BR><strong>Plano de Execução:</strong></span><br><br>']

    Assinatura = [
    f'<span lang=PT-BR>Atenciosamente,</span><p class=MsoNormal><span lang=PT-BR><o:p>  </span></p><p class=MsoNormal><b><span lang=PT-BR style="font-size:12.0pt; sans-serif;color:#001871">{Nome}</span></b>'
    f'<lang=PT-BR style="font-size:12.0pt; sans-serif;color:#001871"><span><br>LAC Production Support<br>AIG Seguros Brasil SA<br>Torre Z, Av. Doutor Chucri Zaidan, 296 – 17º andar, Vila Cordeiro<br>São Paulo - SP<br>{Email} | aig.com.br | negocioseguroaig.com.br</span>']

    return titulo, Assinatura


def mensagem(Aplicacao, Ambiente, SCHEMA, Problem, Justificativa, scripts):
    """Transcrição exata de 'mensagem()' (mail_sender.txt): tabela AMBIENTE/APLICAÇÃO/SCHEMA + lista de scripts + PROBLEM/JUSTIFICATIVA."""
    vetor = []

    amb = "Favor executar os scripts abaixo:"
    if Ambiente == "MODEL":
        amb = "Favor executar os scripts abaixo (homologação):"
        if Aplicacao == "PORTAL":
            SCHEMA = "PORTAL_DB - awgsdscs5570001.r1-core.r1.aig.net"

    header = [
    f'<span lang=PT-BR><strong>{Aplicacao}</strong></span><br>'
    f'<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 style="border-collapse:collapse"><tr style="height:.2pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:.2pt"><p class=MsoNormal style="mso-line-height-alt:4.7pt"><span style="color:black">AMBIENTE: <b>{Ambiente}</b><o:p></o:p></span></p></td></tr><tr style="height:.2pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:.2pt"><p class=MsoNormal style="mso-line-height-alt:4.7pt"><span style="color:black">APLICAÇÃO: <b><strong>{Aplicacao}</strong></b><o:p></o:p></span></p></td></tr>'
    f'<tr style="height:.2pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:.2pt"><p class=MsoNormal style="mso-line-height-alt:4.7pt"><span lang=PT-BR style="color:black">SCHEMA:<b> <span lang=PT-BR style="background:yellow;mso-highlight:yellow"><strong>{SCHEMA}</strong></span></b><span style="color:black"><o:p></o:p></span></span></p></td></tr><tr style="height:.2pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:.2pt"><p class=MsoNormal style="mso-line-height-alt:4.7pt"><span style="color:black">BACKUP<b>: <strong>NÃO</strong></b><o:p></o:p></span></p></td></tr>'
    f'<tr style="height:.2pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:.2pt"><p class=MsoNormal style="mso-line-height-alt:4.7pt"><span style="font-size:10.0pt;color:black">PATH:<o:p></o:p></span></p></td></tr><tr style="height:70.8pt"><td width=631 valign=top style="width:473.5pt;border-top:none;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:70.8pt"><span>{amb}</span><br>']

    body = ['<ol style="margin-top:0in" start=1 type=1>' + str(scripts)]

    footer = [
    f'</ol><p class=MsoNormal style="margin-left:.25in"><span style="color:black"><o:p> </o:p></span></p></td></tr><tr style="height:.15pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:.15pt"></td></tr>'
    f'<tr style="height:1.25pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:1.25pt"><p class=MsoNormal style="mso-line-height-alt:4.0pt">PROBLEM: <strong>{Problem}</strong><span style="color:black"><o:p></o:p></span></p></td></tr>'
    f'<tr style="height:1.25pt"><td width=631 valign=top style="width:473.5pt;border-top:none;border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;padding:0in 5.4pt 0in 5.4pt;height:1.25pt"><p class=MsoNormal style="mso-line-height-alt:4.0pt"><span lang=PT-BR>JUSTIFICATIVA: <strong>{Justificativa}</strong><o:p></o:p></span></p></td></tr>'
    f'<tr style="height:1.25pt"><td width=631 valign=top style="width:473.5pt;border:solid windowtext 1.0pt;border-top:none;padding:0in 5.4pt 0in 5.4pt;height:1.25pt"><p class=MsoNormal style="mso-line-height-alt:4.0pt"><span lang=PT-BR><o:p> </o:p></span></p></td></tr></table><br>']

    vetor.append(header[0])
    vetor.append(body[0])
    vetor.append(footer[0])
    return vetor


####################################################################################################################


def detectar_scripts_por_ambiente(filenames):
    """
    Adaptado de 'montar_email()' (mail_sender.txt): reconhece, a partir dos nomes de
    arquivo enviados no upload, quais ambientes (AMBIENTES) têm script(s) de DML.
    Mesma lógica de correspondência por substring do legado - a única mudança é a
    origem dos nomes (lista vinda da requisição, em vez de os.listdir('path_temp')
    fixo em disco, que só suportava 1 usuário/execução por vez).

    Retorna (scripts_por_ambiente, lista):
      - scripts_por_ambiente: dict {AMBIENTE: [nomes]} apenas para ambientes com match.
      - lista: todos os nomes (unidecodificados) que bateram em algum ambiente,
        na ordem original - usada por 'detectar_ambiente_execucao()'.
    """
    lista = []
    for nome in filenames:
        if not nome or '.sql' not in nome:
            continue
        for amb in AMBIENTES:
            if amb in nome:
                lista.append(unidecode.unidecode(nome))
                break

    scripts_por_ambiente = {}
    for amb in AMBIENTES:
        scripts = [s for s in lista if amb in s]
        if scripts:
            scripts_por_ambiente[amb] = scripts

    return scripts_por_ambiente, lista


def detectar_ambiente_execucao(lista):
    """Mesma regra de 'desenho()' (mail_sender.txt): presença de 'HOMOLOGACAO' no
    nome de algum script indica ambiente MODEL; caso contrário, PROD."""
    return "MODEL" if any("HOMOLOGACAO" in s for s in lista) else "PROD"


def gerar_perguntas(scripts_por_ambiente):
    """
    Equivalente às perguntas do wizard original em 'montar_email()' (bloco elif
    repetido 7x, um por ambiente) - mesmo texto, gerado num laço único sobre
    AMBIENTES em vez de duplicado por ambiente. Usado apenas para exibir na tela
    a mesma redação do legado ao lado dos campos estruturados de resposta.
    """
    perguntas = []
    for amb in AMBIENTES:
        scripts = scripts_por_ambiente.get(amb)
        if not scripts:
            continue
        n = len(scripts)
        perguntas.append(f'Foram encontrado(s) {n} script(s) em {amb}; Digite se possui problem aberto?')
        perguntas.append(f'Foram encontrado(s) {n} script(s) em {amb}; Digite a justificativa;')
    return perguntas


def montar_bloco_ambiente(ambiente_key, lista, ambiente_execucao, problem, justificativa):
    """
    Adaptado de 'desenho()' (mail_sender.txt): monta o bloco HTML (tabela +
    lista numerada de scripts) de UM ambiente. Preserva integralmente a detecção
    de SCHEMA/LOCAL por ambiente e a montagem dos <li> - a única mudança é que
    Problem/Justificativa chegam prontos (campo estruturado do formulário),
    em vez de extraídos por posição/substring do array de perguntas do wizard.
    """
    scripts = [s for s in lista if ambiente_key in s]
    if not scripts:
        return ""

    vetor_script = [
        f'<li class=MsoListParagraph style="color:black;margin-left:0in;mso-list:l0 level1 lfo1">{s}<o:p></o:p></li>'
        for s in scripts
    ]

    schema, local = SCHEMA_PADRAO.get(ambiente_key, ("N/A", "N/A"))

    bloco = mensagem(local, ambiente_execucao, schema, problem, justificativa, "".join(vetor_script).replace("[", ""))
    return "".join(bloco)


def montar_bloco_observacao(observacao):
    """
    Bloco de OBSERVAÇÃO global da DML: campo opcional, único por e-mail (não por
    ambiente) - fica em uma seção própria, destacada, FORA das tabelas por
    ambiente montadas por 'montar_bloco_ambiente()' (diferente da Justificativa,
    que é por ambiente e fica dentro de cada tabela).
    """
    if not observacao or not observacao.strip():
        return ""

    return (
        '<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 '
        'style="border-collapse:collapse;margin-bottom:14px;"><tr>'
        '<td style="background:#fff9db;border-left:4px solid #f5a623;padding:10px 14px;">'
        '<p class=MsoNormal style="margin:0"><span lang=PT-BR style="color:#7a5b00;font-weight:bold">OBS:</span> '
        f'<span lang=PT-BR style="color:#5c4400">{observacao}</span>'
        '<o:p></o:p></p></td></tr></table><br>'
    )


def montar_corpo_email(change, nome, email, send_to_valor, send_name, scripts_por_ambiente, lista,
                        ambiente_execucao, respostas, observacao=''):
    """
    Orquestra o corpo HTML final do e-mail de aprovação de DML: saudação/assinatura
    de 'conteudo()' envolvendo o bloco de observação (opcional) e um bloco
    'montar_bloco_ambiente()' (adaptado de 'desenho()') para cada ambiente
    detectado com script(s).
    """
    titulo, assinatura = conteudo(change, nome, email, send_to_valor, send_name)
    bloco_observacao = montar_bloco_observacao(observacao)

    blocos = []
    for ambiente_key in AMBIENTES:
        if ambiente_key not in scripts_por_ambiente:
            continue
        resposta = respostas.get(ambiente_key) or {}
        bloco = montar_bloco_ambiente(
            ambiente_key, lista, ambiente_execucao,
            resposta.get('problem', ''), resposta.get('justificativa', ''),
        )
        if bloco:
            blocos.append(bloco)

    return titulo[0] + bloco_observacao + "".join(blocos) + assinatura[0]

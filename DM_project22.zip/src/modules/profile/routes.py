import os
from flask import Blueprint, render_template
from flask_login import login_required, current_user

current_dir = os.path.dirname(os.path.abspath(__file__))
profile_bp = Blueprint('profile', __name__, template_folder=current_dir)

@profile_bp.route('/profile')
@login_required
def index():
    return render_template('profile.html', user=current_user, active_page='profile')

import os
from flask import Blueprint, render_template
from flask_login import login_required, current_user

current_dir = os.path.dirname(os.path.abspath(__file__))
apps_bp = Blueprint('apps', __name__, template_folder=current_dir)

@apps_bp.route('/dashboard')
@apps_bp.route('/index')
@apps_bp.route('/apps')
@login_required
def index():
    return render_template('apps.html', user=current_user, active_page='apps')

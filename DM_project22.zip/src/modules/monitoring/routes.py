import os
from flask import Blueprint, render_template
from flask_login import login_required, current_user

current_dir = os.path.dirname(os.path.abspath(__file__))
monitoring_bp = Blueprint('monitoring', __name__, template_folder=current_dir)

@monitoring_bp.route('/monitoring')
@login_required
def index():
    return render_template('monitoring.html', user=current_user, active_page='monitoring')

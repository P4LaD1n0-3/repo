"""
================================================================================
TELA: ATRIBUIÇÃO DE CHAMADOS (SCTASK por regra de palavra-chave / INC fixo)
================================================================================
1 botão único ('Varrer tickets'): varre INC primeiro, depois SCTASK, nesta
ordem, na mesma sessão do navegador. INC vai pro analista/grupo/estado único
fixo de 'vetor_inc' (1º item) em config/ticket_assignment_rules.json; SCTASK
decide pelo motor de regras (tools/ticket_assignment_rules.py + mesmo JSON).
Aplica DIRETO durante a varredura (sem prévia) - mesmo padrão das demais
automações. Fila sem link configurado (ou sem 'vetor_inc.Assigned_to', no
caso do INC) é pulada silenciosamente (sem erro), a menos que NENHUMA das
duas esteja.
"""

import os
import asyncio
import logging
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from playwright.async_api import async_playwright

from src.models import db, TicketAssignmentConfig
from tools.job_registry import job_registry
from tools.ticket_assignment_rules import carregar_regras, obter_config_inc
from src.modules.ticket_assignment.ticket_assignment_service import TicketAssignmentService

logger = logging.getLogger("TicketAssignment")

current_dir = os.path.dirname(os.path.abspath(__file__))
ticket_assignment_bp = Blueprint('ticket_assignment', __name__, template_folder=current_dir)


def _criar_coletor_logs(job_id: str = ""):
    """Mesmo padrão local já usado em release_task/create_ctask routes.py."""
    logs = []

    def add_message(msg: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        entrada = f"{timestamp} {msg}"
        logger.info(entrada)
        logs.append(entrada)
        if job_id:
            job_registry.append_log(job_id, entrada)

    return logs, add_message


@ticket_assignment_bp.route('/ticket_assignment')
@login_required
def index():
    config = TicketAssignmentConfig.get_or_create(current_user.id)
    return render_template(
        'ticket_assignment.html', user=current_user, active_page='ticket_assignment', config=config,
    )


@ticket_assignment_bp.route('/api/ticket_assignment/save_config', methods=['POST'])
@login_required
def save_config():
    data = request.get_json() or {}
    config = TicketAssignmentConfig.get_or_create(current_user.id)
    if 'sctask_queue_url' in data:
        config.sctask_queue_url = (data.get('sctask_queue_url') or '').strip()
    if 'inc_queue_url' in data:
        config.inc_queue_url = (data.get('inc_queue_url') or '').strip()
    if 'headless' in data:
        config.headless = bool(data.get('headless'))
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Configuração salva com sucesso!'})


def _executar_em_novo_loop(coro_factory, job_id: str = ""):
    """Mesmo padrão já usado em release_task/routes.py."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    if job_id:
        job_registry.set_loop(job_id, loop)
    try:
        return loop.run_until_complete(coro_factory())
    finally:
        loop.close()
        if job_id:
            job_registry.unregister(job_id)


@ticket_assignment_bp.route('/api/ticket_assignment/varrer_tickets', methods=['POST'])
@login_required
def varrer_tickets():
    """
    Ação ÚNICA (botão único na tela): varre INC primeiro, depois SCTASK - nesta
    ordem, na MESMA sessão/aba do navegador (mais rápido que abrir 2 vezes).
    Cada fila só é varrida se estiver configurada (link + regra, no caso do
    INC: 1º item de 'vetor_inc' em config/ticket_assignment_rules.json) - link
    vazio pula aquela fila silenciosamente, nunca erro, a menos que NENHUMA
    das duas esteja configurada.
    """
    data = request.get_json() or {}
    job_id = (data.get('job_id') or '').strip()
    config = TicketAssignmentConfig.get_or_create(current_user.id)

    logs, add_message = _criar_coletor_logs(job_id)

    inc_url = (config.inc_queue_url or '').strip()
    sctask_url = (config.sctask_queue_url or '').strip()

    if not inc_url and not sctask_url:
        add_message("❌ Nenhuma fila configurada (INC ou SCTASK).")
        return jsonify({'status': 'error', 'message': 'Nenhuma fila configurada (INC ou SCTASK).', 'logs': logs}), 400

    try:
        regras = carregar_regras()
    except Exception as e:
        add_message(f"❌ Falha ao carregar 'config/ticket_assignment_rules.json': {e}")
        return jsonify({'status': 'error', 'message': str(e), 'logs': logs}), 500

    config_inc = obter_config_inc(regras)
    inc_analista = (config_inc.get('Assigned_to') or '').strip() if config_inc else ''

    varrer_inc = bool(inc_url and inc_analista)
    varrer_sctask = bool(sctask_url)

    if inc_url and not inc_analista:
        add_message("⚠️ Link de INC configurado mas 'vetor_inc.Assigned_to' vazio em config/ticket_assignment_rules.json - pulando INC.")
    if not inc_url:
        add_message("ℹ️ Link de INC não configurado - pulando INC.")
    if not sctask_url:
        add_message("ℹ️ Link de SCTASK não configurado - pulando SCTASK.")

    if not varrer_inc and not varrer_sctask:
        add_message("❌ Nenhuma fila configurada (INC ou SCTASK).")
        return jsonify({'status': 'error', 'message': 'Nenhuma fila configurada (INC ou SCTASK).', 'logs': logs}), 400

    if job_id:
        job_registry.register(job_id, current_user.id, module='ticket_assignment')

    async def executar():
        service = TicketAssignmentService()
        resultado_inc, resultado_sctask = None, None
        async with async_playwright() as p:
            context = await service.launch_persistent_context(p, headless=bool(config.headless), job_id=job_id)
            try:
                page = await context.new_page()
                if varrer_inc:
                    resultado_inc = await service.atribuir_incs(page=page, url=inc_url, config_inc=config_inc, add_message=add_message)
                if varrer_sctask:
                    resultado_sctask = await service.atribuir_sctasks(page=page, url=sctask_url, regras=regras, add_message=add_message)
            finally:
                await service.close_context(context)
        return resultado_inc, resultado_sctask

    try:
        resultado_inc, resultado_sctask = _executar_em_novo_loop(executar, job_id=job_id)
    except Exception as e:
        logger.exception(f"Erro ao varrer tickets: {e}")
        add_message(f"❌ Erro inesperado: {e}")
        return jsonify({'status': 'error', 'message': str(e), 'logs': logs}), 500

    processados = {'inc': [], 'sctask': []}

    if varrer_inc:
        if resultado_inc.get('status') != 'success':
            add_message(f"❌ INC: {resultado_inc.get('error')}")
        else:
            for item in resultado_inc.get('processados', []):
                if item['status'] == 'atribuido':
                    add_message(f"✅ INC {item['inc']} -> {item['analista']}")
                else:
                    add_message(f"❌ INC {item['inc']}: falha ao atribuir - {item.get('erro')}")
            processados['inc'] = resultado_inc.get('processados', [])
            add_message(f"Varredura de INC concluída - {len(processados['inc'])} chamado(s) processado(s).")

    if varrer_sctask:
        if resultado_sctask.get('status') != 'success':
            add_message(f"❌ SCTASK: {resultado_sctask.get('error')}")
        else:
            for item in resultado_sctask.get('processados', []):
                if item['status'] == 'atribuido':
                    add_message(f"✅ SCTASK {item['sctask']} -> {item['analista']} (tópico: {item.get('topico')})")
                elif item['status'] == 'sem_regra':
                    add_message(f"⚠️ SCTASK {item['sctask']}: nenhuma regra bateu - não atribuído.")
                else:
                    add_message(f"❌ SCTASK {item['sctask']}: falha ao atribuir - {item.get('erro')}")
            processados['sctask'] = resultado_sctask.get('processados', [])
            add_message(f"Varredura de SCTASK concluída - {len(processados['sctask'])} chamado(s) processado(s).")

    return jsonify({'status': 'success', 'logs': logs, 'processados': processados})

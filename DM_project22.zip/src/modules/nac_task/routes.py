import os
from flask import Blueprint, render_template
from flask_login import login_required, current_user

current_dir = os.path.dirname(os.path.abspath(__file__))
nac_task_bp = Blueprint('nac_task', __name__, template_folder=current_dir)

@nac_task_bp.route('/nac_task')
@login_required
def index():
    return render_template('nac_task.html', user=current_user, active_page='nac_task')

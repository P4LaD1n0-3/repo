"""
================================================================================
SERVIÇO EXCLUSIVO: ABERTURA DE RELEASE + CHANGE DML (EBAO / PORTAL CORRETOR)
================================================================================
Módulo exclusivo do 'release_task', porta fiel de 'release_exemplo/release_open.txt'
(funções 'novaRelease' e 'onpen_release' do sistema legado em Selenium) para a
arquitetura atual em Playwright assíncrono.

REUSO POR HERANÇA: 'ReleaseOpenService' herda de 'tools.servicenow_driver.ServiceNowDriver'
(que herda de 'tools.base_automation.BaseAutomation'), reaproveitando 100% da
infraestrutura já existente: contexto persistente do navegador, resolução do
iFrame 'gsft_main', preenchimento de campos de referência/reference fields,
localização dinâmica de links por texto ('buscar_link_por_texto') e execução
concorrente controlada por Semáforo ('run_concurrent_tasks').

REGRAS DE NEGÓCIO PRESERVADAS DO LEGADO (sem cortes/simplificações):
  - A data de execução é sempre o dia seguinte ('TODAY = hoje + 1 dia') e o
    prazo (due/end date) o dia seguinte a esse ('TOMORROW = TODAY + 1 dia'),
    exceto quando a flag 'usar_data_hoje' está ativa (ver 'ReleaseMailer.
    calcular_datas_execucao' - substitui o antigo ajuste manual no código-fonte
    legado de 'if tomorrow.weekday() == 23' para '== <dia real>').
  - São sempre abertas DUAS releases em paralelo (EBAO e PORTAL), com no máximo
    2 abas simultâneas — equivalente exato ao 'create_threads' + 'Semaphore(2)'
    do legado.
  - Campos, textos e valores fixos do formulário (state 'Deploy/Launch', região
    'Americas', template 'COMM.NA-Operational', justification 'DML', risk 'LOW',
    trilha do catálogo STANDARD > Application Standard Changes > DML Change)
    são preservados literalmente.

ADAPTAÇÕES DELIBERADAS AO SISTEMA ATUAL (documentadas, não omissões):
  - Configuration Item (EBAO/PORTAL) e os horários de abertura/fechamento
    (planned_start_date / planned_end_date+due_date), antes fixos no código-fonte
    ("EBAO-BRAZIL-Production", "Portal Corretor-Production", "12:00:02"), agora
    são parâmetros configuráveis na tela (ver 'ebao_configuration_item',
    'portal_configuration_item', 'open_hour', 'close_hour' em
    'montar_releases_do_dia' e nos campos correspondentes de ReleaseTaskConfig).
  - O bloco legado 'if TOMORROW.weekday() == 5' (sábado, horário "20:00:02") foi
    REMOVIDO: era estruturalmente inalcançável no original (dois blocos "if"
    independentes, não if/elif - o segundo sempre executava depois e sobrescrevia
    o que este definia, em QUALQUER cenário, D+1 ou D+0). Como os horários agora
    são configuráveis dinamicamente pela tela, manter esse valor fixo e morto ao
    lado dos novos campos dinâmicos só geraria confusão.
  - A navegação por favoritos da barra lateral (XPath posicional 'li[4]'/'li[5]')
    é substituída por navegação DIRETA de URL (padrão já usado em todo o projeto,
    ex.: 'ReleaseCloseService', 'TaskEncerrarService'): se 'ebao_link'/'portal_link'
    não forem configurados, o serviço abre diretamente o formulário de nova
    Release ('rm_release.do?sys_id=-1'). Se configurados, comporta-se como o
    legado (navega até a lista e clica em 'New').
"""

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

from playwright.async_api import BrowserContext, Page

from tools.servicenow_driver import ServiceNowDriver
from tools.base_automation import SelectorManager
from tools.chamado import SERVICE_NOW_BASE_URL
from src.modules.release_task.release_mailer import ReleaseMailer

logger = logging.getLogger("ReleaseOpenService")

DEFAULT_NEW_RELEASE_URL = f"{SERVICE_NOW_BASE_URL}/rm_release.do?sys_id=-1&sysparm_view=release"


@dataclass
class ReleaseTarget:
    """
    Porta de 'class Release' do legado (release_exemplo/release_open.txt).
    Representa uma Release a ser criada (EBAO ou PORTAL) com todos os dados
    necessários para preencher o formulário de Release + Change DML.
    """
    ambiente: str
    link: str
    short_description: str
    description: str
    configuration_item: str
    due_date: str
    planned_start_date: str
    planned_end_date: str
    # Nomes (não e-mails) preenchidos nos campos de referência "Assigned to" do
    # ServiceNow - equivalentes aos fixos "Mauricio Murakami" (Release) e
    # "Wellington Da Silva" (Change) do legado, agora configuráveis na tela.
    release_assigned_to: str = ""
    change_assigned_to: str = ""
    release_n: str = ""
    change_n: str = ""


class ReleaseOpenService(ServiceNowDriver):
    """
    Classe especialista responsável pela automação de ABERTURA de Release + Change DML.
    Herda todos os métodos de ServiceNowDriver e BaseAutomation (reuso por herança).
    """

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    # ------------------------------------------------------------------
    # PASSO 0: CÁLCULO DE DATAS E MONTAGEM DOS ALVOS (EBAO + PORTAL)
    # ------------------------------------------------------------------
    def montar_releases_do_dia(
        self,
        assigned_to_ebao: str,
        assigned_to_portal: str,
        release_assigned_to_name: str = "Mauricio Murakami",
        change_assigned_to_name: str = "Wellington Da Silva",
        ebao_link: str = "",
        portal_link: str = "",
        usar_data_hoje: bool = False,
        ebao_configuration_item: str = "EBAO-BRAZIL-Production",
        portal_configuration_item: str = "Portal Corretor-Production",
        open_hour: str = "12:00:02",
        close_hour: str = "12:00:02",
    ) -> List[ReleaseTarget]:
        """
        Porta fiel de 'onpen_release' (cálculo de datas + montagem de 'lista_release').

        :param assigned_to_ebao: e-mail (ou "Nome <email>") do destinatário do e-mail
            de aprovação da Release EBAO - usado exclusivamente por 'ReleaseMailer' no
            envio manual do e-mail (ver 'routes._executar_envio_email_manual'). NÃO é
            usado para preencher os campos "Assigned to" do ServiceNow.
        :param assigned_to_portal: idem, para a Release PORTAL.
        :param release_assigned_to_name: NOME (não e-mail) preenchido no campo de
            referência "Assigned to" da RELEASE no ServiceNow - antes fixo no legado
            em "Mauricio Murakami", agora configurável na tela.
        :param change_assigned_to_name: NOME (não e-mail) preenchido no campo de
            referência "Assigned to" da CHANGE no ServiceNow - antes fixo no legado
            em "Wellington Da Silva", agora configurável na tela.
        :param usar_data_hoje: quando True, a Release é aberta com a data de HOJE
            (D+0) em vez de amanhã (D+1) - flag que substitui o antigo ajuste manual
            no código-fonte legado (ver 'ReleaseMailer.calcular_datas_execucao').
        :param ebao_configuration_item: Configuration Item da Release/Change EBAO -
            antes fixo em "EBAO-BRAZIL-Production", agora configurável na tela.
        :param portal_configuration_item: Configuration Item da Release/Change PORTAL -
            antes fixo em "Portal Corretor-Production", agora configurável na tela.
        :param open_hour: horário (HH:MM:SS) do planned_start_date - antes fixo em
            "12:00:02", agora configurável na tela ("horário de abertura").
        :param close_hour: horário (HH:MM:SS) do planned_end_date/due_date - antes
            fixo em "12:00:02" (com um ajuste de sábado para "20:00:02" que nunca
            chegava a ter efeito - ver histórico do módulo), agora configurável na
            tela ("horário de fechamento").
        """
        today, tomorrow, day_hour = ReleaseMailer.calcular_datas_execucao(usar_data_hoje)

        open_hour = (open_hour or "12:00:02").strip()
        close_hour = (close_hour or "12:00:02").strip()
        ebao_configuration_item = (ebao_configuration_item or "EBAO-BRAZIL-Production").strip()
        portal_configuration_item = (portal_configuration_item or "Portal Corretor-Production").strip()
        release_assigned_to_name = (release_assigned_to_name or "Mauricio Murakami").strip()
        change_assigned_to_name = (change_assigned_to_name or "Wellington Da Silva").strip()

        release_ebao = ("Change DML " if usar_data_hoje else "DML ") + day_hour.strftime("%d.%m.%Y")
        release_portal = "Change DML " + day_hour.strftime("%d.%m.%Y")

        planned_start_date = today.strftime("%Y-%m-%d") + " " + open_hour
        planned_end_date = tomorrow.strftime("%Y-%m-%d") + " " + close_hour
        due_date = tomorrow.strftime("%Y-%m-%d") + " " + close_hour

        return [
            ReleaseTarget(
                ambiente="EBAO",
                link=(ebao_link or "").strip() or DEFAULT_NEW_RELEASE_URL,
                short_description=release_ebao,
                description=f"{release_ebao} EBAO",
                configuration_item=ebao_configuration_item,
                due_date=due_date,
                planned_start_date=planned_start_date,
                planned_end_date=planned_end_date,
                release_assigned_to=release_assigned_to_name,
                change_assigned_to=change_assigned_to_name,
            ),
            ReleaseTarget(
                ambiente="PORTAL",
                link=(portal_link or "").strip() or DEFAULT_NEW_RELEASE_URL,
                short_description=release_portal,
                description=f"{release_portal} PORTAL",
                configuration_item=portal_configuration_item,
                due_date=due_date,
                planned_start_date=planned_start_date,
                planned_end_date=planned_end_date,
                release_assigned_to=release_assigned_to_name,
                change_assigned_to=change_assigned_to_name,
            ),
        ]

    # ------------------------------------------------------------------
    # PASSO 1: CRIAÇÃO DA RELEASE (equivalente à 1ª metade de 'novaRelease')
    # ------------------------------------------------------------------
    async def _criar_release(self, page: Page, target: ReleaseTarget, add_message) -> str:
        add_message(f"Abrindo formulário de nova Release ({target.ambiente})...")
        await page.goto(target.link, wait_until="domcontentloaded", timeout=30000)

        scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)
        await page.wait_for_timeout(1000)

        # Se a URL configurada for uma LISTA (favorito), clica em "New". Se já for o
        # formulário de novo registro direto (padrão sem configuração), ignora.
        try:
            await self.click_element(scope, "release_new_button", timeout=8000)
            await asyncio.sleep(1)
        except Exception:
            logger.info(f"[{target.ambiente}] Botão 'New' não encontrado - assumindo formulário de nova Release já carregado.")

        await self.wait_for_element(scope, "release_number_readonly", timeout=20000)

        add_message(f"Configurando nova Release ({target.ambiente})...")

        await self.fill_input(scope, "release_short_description", target.short_description)
        await asyncio.sleep(0.5)
        await self.fill_input(scope, "release_description", target.description)
        await asyncio.sleep(0.5)

        await self.fill_reference_field(scope, "release_assigned_to", target.release_assigned_to)
        await self.select_option(scope, "release_state", {"label": "Deploy/Launch"})
        await asyncio.sleep(0.5)
        await self.select_option(scope, "release_region", {"label": "Americas"})
        await asyncio.sleep(0.5)
        await self.fill_reference_field(scope, "release_template", "COMM.NA-Operational")

        await self.fill_input(scope, "release_due_date", target.due_date)
        await asyncio.sleep(0.3)
        await self.fill_input(scope, "release_start_date", target.planned_start_date)
        await asyncio.sleep(0.3)
        await self.fill_input(scope, "release_end_date", target.planned_end_date)
        await asyncio.sleep(0.3)

        rlse_locator = await self.wait_for_element(scope, "release_number_readonly", timeout=20000)
        target.release_n = (await rlse_locator.input_value()).strip()

        await self.click_element(scope, "release_update_stay_button")
        await page.wait_for_timeout(3000)
        await self.wait_for_element(scope, "release_number_readonly", timeout=20000)

        add_message(f"Release {target.release_n} ({target.ambiente}) criada com sucesso.")
        return target.release_n

    # ------------------------------------------------------------------
    # PASSO 2: CRIAÇÃO DA CHANGE DML (equivalente à 2ª metade de 'novaRelease')
    # ------------------------------------------------------------------
    async def _criar_change_dml(self, page: Page, target: ReleaseTarget, add_message) -> str:
        scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

        add_message(f"Criando Change DML ({target.ambiente})...")

        # Clica em "New Change". Preserva o XPath posicional do legado como valor
        # padrão configurável em servicenow_paths.json, com fallback por texto do botão.
        try:
            await self.click_element(scope, "release_new_change_button", timeout=10000)
        except Exception:
            logger.warning(f"[{target.ambiente}] Seletor posicional de 'New Change' falhou, tentando localizar pelo texto do botão.")
            btn = scope.get_by_role("button", name="New Change")
            await btn.first.click(timeout=10000)
        await asyncio.sleep(2)

        # Navegação pelo catálogo: STANDARD > Application Standard Changes > DML Change
        standard_link = await self.buscar_link_por_texto(scope, "STANDARD", page_for_scroll=page)
        await standard_link.click()
        await asyncio.sleep(2)

        appsc_link = await self.buscar_link_por_texto(scope, "Application Standard Changes", page_for_scroll=page)
        await appsc_link.click()
        await asyncio.sleep(2)

        dml_link = await self.buscar_link_por_texto(scope, "DML Change", page_for_scroll=page)
        await dml_link.click()
        await asyncio.sleep(2)

        await self.wait_for_element(scope, "change_number_readonly", timeout=20000)
        chg_locator = await self.wait_for_element(scope, "change_number_readonly", timeout=20000)
        chg_number_preview = (await chg_locator.input_value()).strip()
        add_message(f"Configurando Change {chg_number_preview or ''} ({target.ambiente})...")

        await self.fill_reference_field(scope, "change_assignment_group", "EBAO-BRAZIL")
        await self.fill_reference_field(scope, "change_cmdb_ci", target.configuration_item)
        await asyncio.sleep(1)

        await self.fill_input(scope, "change_justification", "DML")
        await asyncio.sleep(0.5)
        await self.fill_input(scope, "change_risk_impact_analysis", "LOW")
        await asyncio.sleep(0.5)

        # Abre o cadeado, preenche a região impactada e fecha o cadeado (preservado do legado)
        await self.click_element(scope, "change_impacted_region_unlock")
        await asyncio.sleep(1)
        await self.fill_reference_field(scope, "change_impacted_region", "Americas")
        await self.click_element(scope, "change_impacted_region_lock")
        await asyncio.sleep(1)

        await self.fill_reference_field(scope, "change_assigned_to", target.change_assigned_to)
        await asyncio.sleep(1)

        await self.fill_input(scope, "change_requested_by_date", target.due_date)
        await asyncio.sleep(0.3)
        await self.fill_input(scope, "change_start_date", target.planned_start_date)
        await asyncio.sleep(0.3)
        await self.fill_input(scope, "change_end_date", target.planned_end_date)
        await asyncio.sleep(0.3)

        await self.click_element(scope, "release_update_stay_button")
        await page.wait_for_timeout(3000)

        chg_locator = await self.wait_for_element(scope, "change_number_readonly", timeout=20000)
        target.change_n = (await chg_locator.input_value()).strip()

        # Salva novamente e move para aprovação (Assess -> Approval), como no legado
        try:
            await self.click_element(scope, "release_update_stay_button", timeout=10000)
        except Exception:
            pass
        await self.click_element(scope, "change_move_to_assess_approval", timeout=20000)
        await page.wait_for_timeout(2000)

        # Verificação de conclusão (presença do calendário de mudanças), como no legado
        try:
            await self.wait_for_element(scope, "change_calendar_toggle", timeout=20000, state="attached")
        except Exception as e:
            logger.warning(f"[{target.ambiente}] Não foi possível confirmar o toggle do calendário de mudanças: {e}")

        add_message(f"Release {target.ambiente} efetuada: {target.release_n} e {target.change_n}.")
        return target.change_n

    # ------------------------------------------------------------------
    # FLUXO INDIVIDUAL COMPLETO (equivalente a 'novaRelease(i)')
    # ------------------------------------------------------------------
    async def abrir_release_individual(self, page: Page, target: ReleaseTarget, add_message) -> Dict[str, Any]:
        logger.info(f"🆕 [ReleaseOpenService] Abrindo Release {target.ambiente} em: {target.link}")
        resultado: Dict[str, Any] = {
            "ambiente": target.ambiente,
            "configuration_item": target.configuration_item,
            "release_number": "",
            "change_number": "",
            "status": "success",
            "error": None,
        }
        try:
            await self._criar_release(page, target, add_message)
            await self._criar_change_dml(page, target, add_message)
            resultado["release_number"] = target.release_n
            resultado["change_number"] = target.change_n
        except Exception as e:
            logger.error(f"❌ [ReleaseOpenService] Erro ao abrir Release {target.ambiente}: {e}")
            add_message(f"Erro ao abrir Release {target.ambiente}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)
        return resultado

    # ------------------------------------------------------------------
    # LOTE CONCORRENTE (EBAO + PORTAL em paralelo, equivalente a 'create_threads' + Semaphore(2))
    # ------------------------------------------------------------------
    async def abrir_releases_lote(
        self,
        context: BrowserContext,
        targets: List[ReleaseTarget],
        add_message,
        max_concurrency: int = 2,
    ) -> List[Dict[str, Any]]:
        logger.info(f"🚀 [ReleaseOpenService] Abrindo {len(targets)} Release(s) em paralelo (max_concurrency={max_concurrency})...")

        async def worker_task(page: Page, target: ReleaseTarget):
            return await self.abrir_release_individual(page, target, add_message)

        # 'keep_open_on_error=True': se a Release/Change de um dos dois ambientes falhar,
        # a aba correspondente NÃO é fechada automaticamente - fica aberta exatamente no
        # ponto onde travou, para inspeção/conclusão manual (ver 'executar_abertura', que
        # também deixa de fechar o navegador inteiro nesse cenário).
        return await self.run_concurrent_tasks(
            context=context, items=targets, task_fn=worker_task, max_concurrency=max_concurrency,
            keep_open_on_error=True,
        )

    # ------------------------------------------------------------------
    # ENTRYPOINT PRINCIPAL (equivalente a 'onpen_release', gerencia o ciclo de vida do browser)
    # ------------------------------------------------------------------
    async def executar_abertura(
        self,
        assigned_to_ebao: str,
        assigned_to_portal: str,
        ebao_link: str,
        portal_link: str,
        add_message,
        headless: bool = False,
        job_id: str = "",
        usar_data_hoje: bool = False,
        release_assigned_to_name: str = "Mauricio Murakami",
        change_assigned_to_name: str = "Wellington Da Silva",
        ebao_configuration_item: str = "EBAO-BRAZIL-Production",
        portal_configuration_item: str = "Portal Corretor-Production",
        open_hour: str = "12:00:02",
        close_hour: str = "12:00:02",
    ) -> List[Dict[str, Any]]:
        from playwright.async_api import async_playwright
        from tools.okta_auth import OktaAuthManager

        add_message("Automação Open release iniciada.")
        if usar_data_hoje:
            add_message("Flag 'Abrir com a data de hoje' ATIVA - a Release será aberta com D+0, não D+1.")
        add_message("Carregando ServiceNow, aguarde...")

        targets = self.montar_releases_do_dia(
            assigned_to_ebao=assigned_to_ebao,
            assigned_to_portal=assigned_to_portal,
            release_assigned_to_name=release_assigned_to_name,
            change_assigned_to_name=change_assigned_to_name,
            ebao_link=ebao_link,
            portal_link=portal_link,
            usar_data_hoje=usar_data_hoje,
            ebao_configuration_item=ebao_configuration_item,
            portal_configuration_item=portal_configuration_item,
            open_hour=open_hour,
            close_hour=close_hour,
        )

        async with async_playwright() as p:
            context = await self.launch_persistent_context(p, headless=headless, job_id=job_id)
            resultados: List[Dict[str, Any]] = []
            try:
                check_page = await context.new_page()
                await OktaAuthManager.wait_for_okta_login_if_needed(check_page, targets[0].link)
                await check_page.close()

                resultados = await self.abrir_releases_lote(context, targets, add_message, max_concurrency=2)
                return resultados
            finally:
                # Só fecha o navegador automaticamente se TODOS os ambientes tiverem
                # sido concluídos com sucesso. Se algum falhou, a(s) aba(s) com erro já
                # ficaram abertas (ver 'abrir_releases_lote'/'keep_open_on_error') - fechar
                # o CONTEXTO aqui destruiria essas abas também, escondendo exatamente o
                # estado que precisa ser inspecionado/concluído manualmente. Nesse caso o
                # navegador fica aberto e só o job é liberado do JobRegistry.
                houve_erro = any(r.get("status") == "error" for r in resultados)
                if houve_erro:
                    add_message(
                        "⚠️ Um ou mais ambientes falharam - o navegador foi mantido ABERTO "
                        "na(s) aba(s) com erro para inspeção/conclusão manual. Feche-o manualmente "
                        "quando terminar."
                    )
                    logger.warning(f"⚠️ [ReleaseOpenService] Navegador mantido aberto (job_id='{job_id}') - houve item(ns) com erro.")
                await self.close_context(context, close_browser=not houve_erro)

"""
================================================================================
SERVIÇO EXCLUSIVO: ENCERRAMENTO DE RELEASE + FASES + RTASKS + CHANGE DML
================================================================================
Módulo exclusivo do 'release_task', porta fiel de 'release_exemplo/release_close.txt'
(funções 'closeReleases', 'close_release', 'close_Phase_Rtask', 'close_Change',
'ctask_ivp' e 'select_close_update' do sistema legado em Selenium) para a
arquitetura atual em Playwright assíncrono.

REUSO POR HERANÇA: 'ReleaseCloseService' herda de 'tools.servicenow_driver.ServiceNowDriver'
(que herda de 'tools.base_automation.BaseAutomation'), reaproveitando a mesma
infraestrutura usada por 'ReleaseOpenService': contexto persistente, preenchimento
de campos, localização de link por texto ('buscar_link_por_texto') e
leitura/preenchimento genérico de elementos.

REGRAS DE NEGÓCIO PRESERVADAS DO LEGADO (sem cortes/simplificações), incluindo
2 comportamentos que já existiam no código original e ficam sinalizados aqui
para conhecimento (não são decisões desta adaptação):
  1) Em 'fechar_change', a URL da Change é montada com 'sys_id={numero_legivel}'
     (ex.: 'CHG1234567'), e não com o sys_id/GUID real do registro - idêntico
     ao 'release_exemplo/release_close.txt'.
  2) A navegação para a URL da Change é executada DUAS VEZES em sequência
     (idem legado).
Os laços 'while True' sem limite do legado (ex.: 'ctask_ivp') foram convertidos
para laços com limite máximo de tentativas, para evitar travamento indefinido
em produção - tradução idiomática do 'try/except + retry' do Selenium para o
modelo de espera do Playwright, sem alterar a regra de negócio.

DIFERENÇA DELIBERADA DE 'ReleaseOpenService' - SEM RESOLUÇÃO DE IFRAME: este
serviço NÃO usa 'BaseAutomation.get_iframe_scope' (iFrame 'gsft_main') em nenhum
ponto - opera sempre diretamente em 'page'. Fiel ao legado: em nenhuma das rotinas
de encerramento ('close_release', 'close_Phase_Rtask', 'select_close_update') o
código original faz 'switch_to.frame'. Antes desta adaptação, o código Playwright
tentava resolver o iFrame a cada navegação (só existe/é preenchível no fluxo de
ABERTURA) e sempre esgotava o timeout de 20s antes de cair no fallback de página
principal - o resultado final era o mesmo (página principal), mas cada uma das
dezenas de navegações do encerramento pagava 20s de espera morta. Ver docstring
de '_navegar' para detalhes.
"""

import asyncio
import logging
import re
from typing import Any, Dict, List, Optional, Union

from playwright.async_api import BrowserContext, FrameLocator, Page

from tools.servicenow_driver import ServiceNowDriver
from tools.base_automation import SelectorManager
from tools.chamado import SERVICE_NOW_BASE_URL

logger = logging.getLogger("ReleaseCloseService")

# Ordem/códigos de fase preservados do legado: linha 1 = Fase 200, linha 2 = Fase 100, linha 3 = Fase 300
MAPA_LINHAS_FASE = {1: "200", 2: "100", 3: "300"}


class ReleaseCloseService(ServiceNowDriver):
    """
    Classe especialista responsável pela automação de ENCERRAMENTO de Release
    (fases, rtasks e Change DML associada). Herda de ServiceNowDriver/BaseAutomation.
    """

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)
        self.me: str = ""
        self.dba: str = ""
        self.url_atual: str = ""

    # ------------------------------------------------------------------
    # HELPERS INTERNOS
    # ------------------------------------------------------------------
    async def _navegar(self, page: Page, url: str) -> Page:
        """
        Navega diretamente para a URL (equivalente a 'fillOut.openServiceNow').

        Retorna 'page' diretamente, SEM tentar resolver o iFrame 'gsft_main' (diferente
        de outros serviços, ex. ReleaseOpenService). No legado (release_exemplo/
        release_close.txt), NENHUMA das rotinas de encerramento ('close_release',
        'close_Phase_Rtask', 'select_close_update') faz 'switch_to.frame' - os formulários
        acessados neste fluxo (rm_release, rm_task, rm_release_phase, change_request) nunca
        ficam dentro desse iFrame. Antes, esperar por ele aqui (timeout de 20s) SEMPRE
        esgotava o tempo limite e caía no mesmo fallback de página principal - só que
        pagando 20s de espera morta em TODA navegação (o encerramento de 1 Release navega
        dezenas de vezes: por fase, por RTASK, pela Change), tornando o processo
        extremamente lento. Usar 'page' direto reproduz o comportamento real do legado e
        elimina essa espera.
        """
        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        return page

    def _xpath_com_linha(self, selector_key: str, row: int) -> str:
        """Resolve um seletor XPath com placeholder '{row}' (tabelas de lista do ServiceNow)."""
        return self.get_selector(selector_key).format(row=row)

    async def _ler_valor(self, scope: Union[Page, FrameLocator], selector_key: str) -> str:
        """Lê o valor atual de um campo (input) ou, na ausência, seu texto interno."""
        selector = self.get_selector(selector_key)
        locator = scope.locator(selector).first
        try:
            valor = await locator.input_value()
        except Exception:
            valor = await locator.inner_text()
        return (valor or "").strip()

    async def _selecionar_estado_fechado(self, scope: Union[Page, FrameLocator], selector_key: str) -> bool:
        """
        Seleciona 'Closed Complete' em um <select> de estado, se existir na página atual.

        Timeout curto e explícito (3s) pelo mesmo motivo documentado em '_ctask_ivp'/
        'close_release': das 4 chaves de estado possíveis ('release_state',
        'change_task_state', 'release_task_state', 'release_phase_state'), só UMA existe
        na página atual - as outras 3 SEMPRE falham por elemento inexistente, e isso é
        esperado, não um erro real. Sem 'timeout=' aqui, 'select_option' herdava o default
        do Playwright (30s) e cada chamada a 'fechar_estado_atual' pagava até 3 x 30s = 90s
        de espera morta - somado às dezenas de RTASKs/fases/Change de uma Release, essa era
        a causa raiz do encerramento "travando" no preenchimento do estado (CLOSED Complete).
        """
        try:
            await self.select_option(scope, selector_key, {"label": "Closed Complete"}, timeout=3000)
            return True
        except Exception:
            return False

    async def fechar_estado_atual(self, scope: Union[Page, FrameLocator], page: Page):
        """
        Porta fiel de 'select_close_update()': tenta fechar TODOS os possíveis
        estados presentes na página atual (Release, Change Task, Release Task,
        Release Phase), salva, posta work notes/comentários e salva novamente.
        """
        # Tenta os 4 campos de estado possíveis - só UM existe na página atual dependendo do
        # tipo de registro (Release, Change Task, Release Task ou Release Phase); os outros 3
        # falham normalmente (elemento não existe) e isso é esperado, não um erro real.
        estados_tentados = {
            "release_state": await self._selecionar_estado_fechado(scope, "release_state"),
        }
        await asyncio.sleep(0.5)
        estados_tentados["change_task_state"] = await self._selecionar_estado_fechado(scope, "change_task_state")
        await asyncio.sleep(0.5)
        estados_tentados["release_task_state"] = await self._selecionar_estado_fechado(scope, "release_task_state")
        await asyncio.sleep(2)
        estados_tentados["release_phase_state"] = await self._selecionar_estado_fechado(scope, "release_phase_state")
        await asyncio.sleep(2)

        if not any(estados_tentados.values()):
            # Nenhum dos 4 aplicou - diferente do caso normal (3 de 4 sempre falham por não
            # existir na página), aqui NENHUM funcionou. Pode ser a página errada ou um campo
            # de estado que mudou de nome/opções no ServiceNow - vale investigar.
            logger.warning(
                f"⚠️ [ReleaseCloseService] Nenhum campo de estado 'Closed Complete' pôde ser "
                f"aplicado em {page.url} - verifique se esta é mesmo a página esperada."
            )

        try:
            await self.click_element(scope, "release_update_stay_button", timeout=15000)
        except Exception as e:
            logger.debug(f"Aviso ao salvar estado: {e}")
        await asyncio.sleep(2)

        for key in ("release_work_notes_textarea", "release_comments_textarea"):
            try:
                loc = scope.locator(self.get_selector(key)).first
                if await loc.count() > 0:
                    await loc.fill("Successfully", timeout=3000)
            except Exception:
                pass

        try:
            await self.click_element(scope, "release_update_stay_button", timeout=15000)
        except Exception as e:
            logger.debug(f"Aviso ao salvar work notes/comentários: {e}")
        await asyncio.sleep(2)

    # ------------------------------------------------------------------
    # FECHAMENTO DAS 3 FASES DA RELEASE (equivalente a 'close_release')
    # ------------------------------------------------------------------
    async def close_release(self, page: Page, add_message):
        add_message("Obtendo números das fases e encerrando...")
        # Sem espera de iFrame aqui - ver docstring de '_navegar' para o motivo.
        scope = page

        phas_texto = ""
        for _ in range(60):
            try:
                await scope.locator(self.get_selector("release_number_field_click")).first.click(timeout=2000)
            except Exception:
                pass
            try:
                phas_link = scope.locator("a", has_text=re.compile("PHAS", re.IGNORECASE)).first
                if await phas_link.count() > 0:
                    phas_texto = (await phas_link.inner_text()).strip()
            except Exception:
                phas_texto = ""
            try:
                await page.keyboard.press("PageDown")
            except Exception:
                pass
            if phas_texto:
                break
            await asyncio.sleep(0.5)
        else:
            raise TimeoutError("Não foi possível localizar as fases (PHAS) da Release.")

        # Timeout curto e explícito nestas leituras "de sondagem" (a linha pode simplesmente
        # não existir - ISSO é esperado, não um erro). Sem 'timeout=' aqui, cada tentativa
        # herda o default do Playwright (30s) antes de cair no except - diferente do legado em
        # Selenium, cujo 'find_element' sem espera implícita configurada falha ~instantaneamente.
        # Essa diferença de comportamento entre as duas bibliotecas é a causa raiz da lentidão.
        phases_list: List[str] = ["", "", "", ""]
        for i in range(4):
            try:
                phases_list[i] = (await scope.locator(self._xpath_com_linha("release_phase_name_cell", i)).inner_text(timeout=1000)).strip()
            except Exception:
                phases_list[i] = ""
        await asyncio.sleep(1)

        for linha, codigo_fase in MAPA_LINHAS_FASE.items():
            try:
                status = (await scope.locator(self._xpath_com_linha("release_phase_status_cell", linha)).inner_text(timeout=1000)).strip()
            except Exception:
                status = ""

            if status == "Draft":
                await self.close_phase_rtask(page, codigo_fase, phases_list[linha], add_message)
            else:
                logger.info(f"PHASE_{codigo_fase}: {phases_list[linha]} closed with successfully")
                add_message(f"PHASE_{codigo_fase}: {phases_list[linha]} closed with successfully")
            await asyncio.sleep(1)

        await asyncio.sleep(5)

    # ------------------------------------------------------------------
    # FECHAMENTO DE UMA FASE E SUAS RTASKS (equivalente a 'close_Phase_Rtask')
    # ------------------------------------------------------------------
    async def close_phase_rtask(self, page: Page, phase: str, phase_n: str, add_message):
        if not phase_n:
            logger.warning(f"[Fase {phase}] Nome da fase não identificado - abortando encerramento desta fase.")
            add_message(f"[Fase {phase}] Nome da fase não identificado - fase ignorada.")
            return

        # Sem espera de iFrame aqui - ver docstring de '_navegar' para o motivo.
        scope = page

        link_phase = ""
        for _ in range(40):
            try:
                link_loc = await self.buscar_link_por_texto(scope, phase_n, page_for_scroll=page, timeout_ms=5000)
                await link_loc.click()
                await self.wait_for_element(scope, "release_phase_number", timeout=10000)
            except Exception:
                await asyncio.sleep(0.5)
                continue

            link_phase = page.url
            try:
                await self.buscar_link_por_texto(scope, "RTSK", "RLTSK", page_for_scroll=page, timeout_ms=5000)
                break
            except Exception:
                continue
        if not link_phase:
            raise TimeoutError(f"Não foi possível abrir a fase '{phase_n}'.")

        rtasks_list: List[str] = [""]
        for i in range(1, 7):
            try:
                texto = (await scope.locator(self._xpath_com_linha("release_rtask_row", i)).inner_text(timeout=1000)).strip()
                rtasks_list.append(texto)
            except Exception:
                rtasks_list.append("")

        for i in range(1, len(rtasks_list)):
            scope = await self._navegar(page, link_phase)
            await self.wait_for_element(scope, "release_phase_number", timeout=20000)

            try:
                status = (await scope.locator(self._xpath_com_linha("release_rtask_status_cell", i)).inner_text(timeout=1000)).strip()
                if status == "Closed Complete":
                    logger.info(f"{rtasks_list[i]} has been closed")
                    add_message(f"{rtasks_list[i]} has been closed")
                    await asyncio.sleep(1)
                    continue
            except Exception:
                await asyncio.sleep(1)

            if not rtasks_list[i]:
                continue

            add_message(f"Encerrando {rtasks_list[i]}.")

            try:
                rtask_link = await self.buscar_link_por_texto(scope, rtasks_list[i], page_for_scroll=page)
                await rtask_link.click()
            except Exception as e:
                logger.warning(f"Não foi possível abrir a RTASK '{rtasks_list[i]}': {e}")
                continue
            await asyncio.sleep(1)

            short_ds = await self._ler_valor(scope, "release_task_short_description")
            await asyncio.sleep(1)
            await self.fill_reference_field(scope, "release_task_assignment_group", "EBAO-BRAZIL")
            await asyncio.sleep(2)
            await self.fill_input(scope, "release_task_description", short_ds)
            await asyncio.sleep(0.8)
            end_date = await self._ler_valor(scope, "release_task_end_date")
            await asyncio.sleep(0.8)
            await self.fill_input(scope, "release_task_due_date", end_date)
            await asyncio.sleep(0.8)
            await self.fill_reference_field(scope, "release_task_assigned_to", self.me)

            # Regra especial preservada do legado: a 3ª RTASK da Fase 200 é
            # reatribuída ao grupo/pessoa de DBA.
            if i == 3 and phase == "200":
                await self.fill_reference_field(scope, "release_task_assignment_group", "AIG-PT-BR-DBA-SRV")
                await asyncio.sleep(2)
                await self.fill_reference_field(scope, "release_task_assigned_to", self.dba)

            await self.fechar_estado_atual(scope, page)

        # Fecha a fase em si, após todas as RTASKs
        scope = await self._navegar(page, link_phase)
        short_ds_phase = await self._ler_valor(scope, "release_phase_short_description")
        await asyncio.sleep(0.5)
        await self.fill_reference_field(scope, "release_phase_assignment_group", "EBAO-BRAZIL")
        await asyncio.sleep(0.5)
        await self.fill_input(scope, "release_phase_description", short_ds_phase)
        await asyncio.sleep(0.5)
        end_date_phase = await self._ler_valor(scope, "release_phase_end_date")
        await asyncio.sleep(0.5)
        await self.fill_input(scope, "release_phase_due_date", end_date_phase)
        await asyncio.sleep(1)
        await self.fill_reference_field(scope, "release_phase_assigned_to", self.me)
        await asyncio.sleep(2)

        await self.fechar_estado_atual(scope, page)

        logger.info(f"{phase_n} closed with success.")
        add_message(f"{phase_n} closed with success.")

        await self._navegar(page, self.url_atual)

    # ------------------------------------------------------------------
    # LEITURA DA CTASK VINCULADA VIA "IVP Testing" (equivalente a 'ctask_ivp')
    # ------------------------------------------------------------------
    async def _ctask_ivp(self, scope: Union[Page, FrameLocator]) -> str:
        """
        Porta fiel de 'ctask_ivp()'. No legado, o 'while True' varria linha por linha com
        'find_element' puro do Selenium, que falha ~instantaneamente quando o elemento não
        existe (sem espera implícita configurada). Aqui, cada tentativa usa 'timeout=1000'
        explícito pelo mesmo motivo (ver comentário em 'close_release') - sem isso, uma Change
        com menos linhas do que o teto de 200 varria o resto TODO na espera padrão de 30s por
        linha (até ~100 min no pior caso), que é a causa raiz do encerramento "demorando uma
        vida" relatada pelo usuário.
        """
        for i in range(200):
            try:
                ivp = (await scope.locator(self._xpath_com_linha("change_ivp_type_cell", i)).inner_text(timeout=1000)).strip()
            except Exception:
                continue

            if ivp == "IVP Testing":
                try:
                    status = (await scope.locator(self._xpath_com_linha("change_ivp_status_cell", i)).inner_text(timeout=1000)).strip()
                except Exception:
                    status = ""

                if status == "Open":
                    try:
                        return (await scope.locator(self._xpath_com_linha("change_ivp_ctask_cell", i)).inner_text(timeout=1000)).strip()
                    except Exception:
                        return status
                return status

        raise TimeoutError("Não foi possível localizar a linha 'IVP Testing' na Change.")

    async def _mover_change_para_closed(self, scope: Union[Page, FrameLocator], page: Page):
        await self.click_element(scope, "change_move_to_implement")
        await asyncio.sleep(1)
        await self.click_element(scope, "change_move_to_review")
        await asyncio.sleep(1)
        await self.click_element(scope, "change_move_to_closed")
        await asyncio.sleep(2)

        for _ in range(20):
            try:
                await self.click_element(scope, "change_close_code", timeout=3000)
            except Exception:
                pass
            await asyncio.sleep(0.5)
            try:
                await self.select_option(scope, "change_close_code", {"label": "Successful"})
            except Exception:
                pass
            await asyncio.sleep(0.5)
            try:
                loc = scope.locator(self.get_selector("change_close_notes")).first
                await loc.fill("Successfully", timeout=3000)
                break
            except Exception:
                pass
        await asyncio.sleep(1)
        await self.click_element(scope, "change_move_to_closed")

    # ------------------------------------------------------------------
    # FECHAMENTO DA CHANGE DML VINCULADA (equivalente a 'close_Change')
    # ------------------------------------------------------------------
    async def fechar_change(self, page: Page, add_message):
        # Sem espera de iFrame aqui - ver docstring de '_navegar' para o motivo.
        scope = page
        add_message("Obtendo número da change e encerrando...")

        chg = ""
        for _ in range(40):
            try:
                await page.keyboard.press("PageDown")
            except Exception:
                pass
            try:
                chg_link = scope.locator("a", has_text=re.compile(r"CHG", re.IGNORECASE)).first
                if await chg_link.count() > 0:
                    texto = (await chg_link.inner_text()).upper()
                    inicio = texto.find("CHG")
                    if inicio >= 0:
                        chg = texto[inicio:inicio + 10].strip()
            except Exception:
                pass
            if chg:
                break
            await asyncio.sleep(0.5)

        if not chg:
            raise TimeoutError("Não foi possível localizar o número da Change (CHG) associada à Release.")

        try:
            status_relacionado = (await scope.locator(self.get_selector("change_related_status_cell")).inner_text(timeout=1500)).strip()
        except Exception:
            status_relacionado = ""

        if status_relacionado == "Closed":
            logger.info(f"{chg} has been closed.")
            add_message(f"{chg} has been closed.")
            return

        link_release = page.url

        # Nota preservada do legado (ver docstring do módulo): usa o NÚMERO
        # legível da Change como 'sys_id' na URL, não o GUID real.
        url_change = f"{SERVICE_NOW_BASE_URL}/change_request.do?sys_id={chg}"
        scope = await self._navegar(page, url_change)
        scope = await self._navegar(page, url_change)  # chamada duplicada, preservada do legado

        ctask = await self._ctask_ivp(scope)

        if ctask == "Closed Complete":
            logger.info(f"{ctask} has been closed.")
            add_message(f"{ctask} has been closed.")
            await self._mover_change_para_closed(scope, page)
        else:
            try:
                ctask_link = await self.buscar_link_por_texto(scope, ctask, page_for_scroll=page, timeout_ms=8000)
                await ctask_link.click()
                await self.fechar_estado_atual(scope, page)
                await asyncio.sleep(0.5)
                scope = await self._navegar(page, url_change)
                await asyncio.sleep(0.5)
                await self._mover_change_para_closed(scope, page)
            except Exception as e:
                logger.warning(f"Aviso ao encerrar CTASK '{ctask}': {e}")

            await asyncio.sleep(2)
            await self._navegar(page, link_release)

    # ------------------------------------------------------------------
    # FLUXO INDIVIDUAL COMPLETO (1 número de Release)
    # ------------------------------------------------------------------
    async def _fechar_release_individual(self, context: BrowserContext, rlse: str, add_message) -> Dict[str, Any]:
        url = (
            f"{SERVICE_NOW_BASE_URL}/rm_release.do?sys_id={rlse}"
            f"&sysparm_view=release&sysparm_view=release&sysparm_domain=null"
            f"&sysparm_domain_scope=null&sysparm_nostack=yes"
        )
        self.url_atual = url

        resultado: Dict[str, Any] = {"release": rlse, "status": "success", "error": None}
        page = await context.new_page()
        try:
            await self._navegar(page, url)

            await self.close_release(page, add_message)
            await self.fechar_change(page, add_message)

            scope = await self._navegar(page, url)
            await self.fechar_estado_atual(scope, page)

            logger.info(f"{rlse} Was Closed.")
            add_message(f"{rlse} Was Closed.")
        except Exception as e:
            logger.error(f"❌ [ReleaseCloseService] A página foi encerrada inesperadamente ({rlse}): {e}")
            add_message(f"A página foi encerrada inesperadamente. {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)
        finally:
            await page.close()

        return resultado

    # ------------------------------------------------------------------
    # ENTRYPOINT PRINCIPAL (equivalente a 'closeReleases', gerencia o ciclo de vida do browser)
    # ------------------------------------------------------------------
    async def executar_encerramento(
        self,
        dba_name: str,
        release_n: str,
        sigla: str,
        add_message,
        headless: bool = False,
        job_id: str = "",
    ) -> List[Dict[str, Any]]:
        from playwright.async_api import async_playwright
        from tools.okta_auth import OktaAuthManager

        self.dba = dba_name or ""
        self.me = sigla or ""

        lista_rlse = [r.strip() for r in (release_n or "").split(",") if r.strip()]
        if not lista_rlse:
            raise ValueError("Nenhum número de Release informado para encerramento.")

        add_message(f"Automação iniciada para {release_n}.")
        add_message("Carregando ServiceNow, aguarde...")

        primeira_url = (
            f"{SERVICE_NOW_BASE_URL}/rm_release.do?sys_id={lista_rlse[0]}"
            f"&sysparm_view=release&sysparm_view=release&sysparm_domain=null"
            f"&sysparm_domain_scope=null&sysparm_nostack=yes"
        )

        resultados: List[Dict[str, Any]] = []
        async with async_playwright() as p:
            context = await self.launch_persistent_context(p, headless=headless, job_id=job_id)
            try:
                check_page = await context.new_page()
                await OktaAuthManager.wait_for_okta_login_if_needed(check_page, primeira_url)
                await check_page.close()

                # Processamento sequencial (1 Release por vez), fiel ao laço 'for' do legado.
                for rlse in lista_rlse:
                    resultado = await self._fechar_release_individual(context, rlse, add_message)
                    resultados.append(resultado)
            finally:
                await self.close_context(context)

        return resultados

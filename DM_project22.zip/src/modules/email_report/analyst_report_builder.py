# -*- coding: utf-8 -*-
"""
Analyst Performance Comparison - Report Builder
====================================================
Builds the full HTML for the second e-mail: today vs yesterday, this week
vs last week, this month (MTD) vs the same elapsed period last month -
all broken down per analyst with FULL differentiation between SCTASK (Service Requests)
and INC (Incidents), type-specific SLA compliance (SCTASK 10d vs INC 7d),
and an executive dashboard layout with 6 key panels ("Painéis Chaves").
Features a modern executive color palette (Ocean Teal #06B6D4 & Electric Violet #8B5CF6)
and 100% TYPE-SEPARATED side-by-side comparison KPI cards for SCTASK vs INC.
"""
import logging
from datetime import datetime
import pandas as pd

from . import charts as c
from . import analyst_metrics as am
from . import report_builder as rb
from . import data_loader as dl
from .config import Colors

logger = logging.getLogger("analyst_report_builder")

FONT_STACK = rb.FONT_STACK

CSS = rb.CSS + """
        .quick-nav { background-color: #0f172a; padding: 8px 12px; border-radius: 6px; margin-bottom: 20px; text-align: center; }
        .quick-nav a { color: #ffffff; text-decoration: none; font-size: 11px; font-weight: bold; margin: 3px 6px; display: inline-block; padding: 4px 8px; border-radius: 4px; background: rgba(255,255,255,0.12); }
        .quick-nav a:hover { background: rgba(255,255,255,0.3); text-decoration: none; }
        .badge-sctask { background-color: #06B6D4; color: #ffffff; padding: 3px 7px; border-radius: 4px; font-size: 10px; font-weight: bold; }
        .badge-inc { background-color: #8B5CF6; color: #ffffff; padding: 3px 7px; border-radius: 4px; font-size: 10px; font-weight: bold; }
        .panel-box { border: 1px solid #e2e8f0; border-radius: 8px; background-color: #ffffff; padding: 16px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.03); }
        .panel-header { font-size: 14px; font-weight: bold; color: #1e293b; margin-bottom: 12px; border-bottom: 2px solid #f1f5f9; padding-bottom: 8px; display: flex; align-items: center; justify-content: space-between; }
"""

SECTION_COLORS = {
    1: ("Painel 1: Centro de Comando de KPIs", "#0F172A", "\U0001F4C8"),
    2: ("Painel 2: Comparativo de Períodos — SCTASK vs INC", "#06B6D4", "\U0001F4C5"),
    3: ("Painel 3: Balanceamento de Carga de Trabalho (Workload Balance)", "#D97706", "\u2696\ufe0f"),
    4: ("Painel 4: Visão Detalhada por Analista — Roster Completo", "#1E293B", "\U0001F465"),
    5: ("Painel 5: Heatmaps por Grupo de Atendimento (SCTASK vs INC)", "#8B5CF6", "\U0001F525"),
    6: ("Painel 6: Consistência & Histórico Pessoal do Analista", "#0D9488", "\U0001F3B2"),
}

TIER_STYLE = {
    "Q1": {"bg": "#ecfdf5", "text": "#059669", "label": "Top Quartile"},
    "Q2": {"bg": "#ecfeff", "text": "#0891b2", "label": "Upper-Mid"},
    "Q3": {"bg": "#fffbeb", "text": "#b45309", "label": "Lower-Mid"},
    "Q4": {"bg": "#fff1f2", "text": "#be123c", "label": "Needs Support"},
    "\u2014": {"bg": "#f8fafc", "text": "#64748b", "label": "Sem volume no mês"},
}


def section_header(number, text=None, color=None, icon=None, section_id=None):
    if text is None:
        text, color, icon = SECTION_COLORS[number][0], SECTION_COLORS[number][1], SECTION_COLORS[number][2]
    anchor = f' id="{section_id}"' if section_id else ''
    badge = (f'<td width="42" valign="middle" style="padding:11px 0 11px 14px;">'
              f'<table cellpadding="0" cellspacing="0" border="0"><tr>'
              f'<td width="26" height="26" align="center" valign="middle" '
              f'style="width:26px; height:26px; min-width:26px; background-color:#ffffff; border-radius:13px; '
              f'color:{color}; font-size:13px; font-weight:bold; font-family:{FONT_STACK};">{number}</td>'
              f'</tr></table></td>')
    return (f'<table{anchor} width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px; margin-top:10px;">'
            f'<tr><td style="background-color:{color}; border-radius:6px;">'
            f'<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>{badge}'
            f'<td valign="middle" style="color:#ffffff; padding:11px 16px 11px 8px; '
            f'font-size:14px; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; '
            f'font-family:{FONT_STACK};">{icon}&nbsp; {text}</td>'
            f'</tr></table></td></tr></table>')


def full_width_chart(img_url):
    return (f'<div style="margin-bottom:18px;"><img class="chart-img" src="{img_url}" width="100%" '
             f'style="max-width:100%; width:100%; height:auto; display:block; border:0;"></div>')


def type_separated_compare_kpis(totals, net_flow, roster_len, sct_sla_month, inc_sla_month):
    """Painel 1 KPI Command Center with 100% EXPLICIT SEPARATION of SCTASK (Requisições) vs INC (Incidentes).
    Card 1: SCTASK Fechados Hoje (Hoje: X vs Ontem: Y)
    Card 2: INC Fechados Hoje (Hoje: X vs Ontem: Y)
    Card 3: Saldo de Fila & Analistas Ativos
    Card 4: Esta Semana (SCTASK vs INC)
    Card 5: Este Mês MTD (SCTASK vs INC)
    Card 6: Conformidade SLA por Tipo (SCTASK 10d vs INC 7d)
    """

    def _delta_badge(cur, prev):
        if prev == 0:
            return '<span style="background-color:#dcfce7; color:#15803d; padding:2px 7px; border-radius:10px; font-weight:bold; font-size:10px;">▲ Novo</span>'
        diff = cur - prev
        pct = (diff / prev) * 100
        if pct > 0:
            return f'<span style="background-color:#dcfce7; color:#15803d; padding:2px 7px; border-radius:10px; font-weight:bold; font-size:10px;">▲ +{pct:.0f}%</span>'
        elif pct < 0:
            return f'<span style="background-color:#fee2e2; color:#991b1b; padding:2px 7px; border-radius:10px; font-weight:bold; font-size:10px;">▼ {pct:.0f}%</span>'
        else:
            return '<span style="background-color:#f1f5f9; color:#475569; padding:2px 7px; border-radius:10px; font-weight:bold; font-size:10px;">\u2014 0%</span>'

    cur_sct_today = totals.get("today_sctask", 0)
    prev_sct_today = totals.get("yesterday_sctask", 0)

    cur_inc_today = totals.get("today_inc", 0)
    prev_inc_today = totals.get("yesterday_inc", 0)

    cur_sct_wk = totals.get("this_week_sctask", 0)
    prev_sct_wk = totals.get("last_week_sctask", 0)
    cur_inc_wk = totals.get("this_week_inc", 0)
    prev_inc_wk = totals.get("last_week_inc", 0)

    cur_sct_mo = totals.get("this_month_sctask", 0)
    prev_sct_mo = totals.get("last_month_sctask", 0)
    cur_inc_mo = totals.get("this_month_inc", 0)
    prev_inc_mo = totals.get("last_month_inc", 0)

    row1_cards = [
        # Card 1: SCTASK Fechados Hoje (Dedicado)
        f"""<table width="100%" height="150" cellpadding="0" cellspacing="0" border="0"
                   style="border:1.5px solid #06B6D4; border-radius:8px; border-collapse:separate; height:150px; background-color:#ffffff; box-shadow:0 2px 5px rgba(0,0,0,0.03);">
            <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:#ecfeff; padding:0 12px; border-bottom:1.5px solid #06B6D4; border-radius:7px 7px 0 0; font-family:{FONT_STACK};">
                <span style="color:#0891b2; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.4px;">🔷 SCTASK Fechados Hoje</span>
            </td></tr>
            <tr><td align="center" valign="middle" style="padding:10px 12px; font-family:{FONT_STACK};">
                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td width="55%" align="left" valign="middle">
                            <div style="font-size:10px; font-weight:bold; color:#0891b2; text-transform:uppercase;">HOJE (SCTASK)</div>
                            <div style="font-size:32px; font-weight:bold; color:#06B6D4; line-height:1.1; margin:2px 0;">{cur_sct_today}</div>
                            <div><span class="badge-sctask">Requisições</span></div>
                        </td>
                        <td width="45%" align="right" valign="middle" style="border-left:1px dashed #cbd5e1; padding-left:8px;">
                            <div style="font-size:10px; font-weight:bold; color:#64748b; text-transform:uppercase;">ONTEM</div>
                            <div style="font-size:22px; font-weight:bold; color:#475569; margin:2px 0;">{prev_sct_today}</div>
                            <div>{_delta_badge(cur_sct_today, prev_sct_today)}</div>
                        </td>
                    </tr>
                </table>
            </td></tr>
        </table>""",

        # Card 2: INC Fechados Hoje (Dedicado)
        f"""<table width="100%" height="150" cellpadding="0" cellspacing="0" border="0"
                   style="border:1.5px solid #8B5CF6; border-radius:8px; border-collapse:separate; height:150px; background-color:#ffffff; box-shadow:0 2px 5px rgba(0,0,0,0.03);">
            <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:#f5f3ff; padding:0 12px; border-bottom:1.5px solid #8B5CF6; border-radius:7px 7px 0 0; font-family:{FONT_STACK};">
                <span style="color:#7c3aed; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.4px;">🚨 INC Fechados Hoje</span>
            </td></tr>
            <tr><td align="center" valign="middle" style="padding:10px 12px; font-family:{FONT_STACK};">
                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td width="55%" align="left" valign="middle">
                            <div style="font-size:10px; font-weight:bold; color:#7c3aed; text-transform:uppercase;">HOJE (INC)</div>
                            <div style="font-size:32px; font-weight:bold; color:#8B5CF6; line-height:1.1; margin:2px 0;">{cur_inc_today}</div>
                            <div><span class="badge-inc">Incidentes</span></div>
                        </td>
                        <td width="45%" align="right" valign="middle" style="border-left:1px dashed #cbd5e1; padding-left:8px;">
                            <div style="font-size:10px; font-weight:bold; color:#64748b; text-transform:uppercase;">ONTEM</div>
                            <div style="font-size:22px; font-weight:bold; color:#475569; margin:2px 0;">{prev_inc_today}</div>
                            <div>{_delta_badge(cur_inc_today, prev_inc_today)}</div>
                        </td>
                    </tr>
                </table>
            </td></tr>
        </table>""",

        # Card 3: Saldo de Fila & Analistas Ativos Hoje
        f"""<table width="100%" height="150" cellpadding="0" cellspacing="0" border="0"
                   style="border:1.5px solid #10B981; border-radius:8px; border-collapse:separate; height:150px; background-color:#ffffff; box-shadow:0 2px 5px rgba(0,0,0,0.03);">
            <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:#ecfdf5; padding:0 12px; border-bottom:1.5px solid #10B981; border-radius:7px 7px 0 0; font-family:{FONT_STACK};">
                <span style="color:#059669; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.4px;">⚖️ Saldo de Fila & Operação</span>
            </td></tr>
            <tr><td align="center" valign="middle" style="padding:10px 12px; font-family:{FONT_STACK};">
                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td width="50%" align="left" valign="middle">
                            <div style="font-size:10px; font-weight:bold; color:#059669; text-transform:uppercase;">SALDO HOJE</div>
                            <div style="font-size:28px; font-weight:bold; color:{'#10B981' if net_flow['today']['net'] <= 0 else '#F43F5E'}; line-height:1.1; margin:2px 0;">{net_flow['today']['net']:+d}</div>
                            <div style="font-size:10px; color:#64748b;">{net_flow['today']['opened']} abertos / {net_flow['today']['closed']} fechados</div>
                        </td>
                        <td width="50%" align="right" valign="middle" style="border-left:1px dashed #cbd5e1; padding-left:8px;">
                            <div style="font-size:10px; font-weight:bold; color:#64748b; text-transform:uppercase;">ATIVOS HOJE</div>
                            <div style="font-size:24px; font-weight:bold; color:#0f172a; margin:2px 0;">{totals['active_analysts_today']}</div>
                            <div style="font-size:10px; color:#64748b;">de {roster_len} no roster ({totals['active_analysts_today']/max(roster_len,1)*100:.0f}%)</div>
                        </td>
                    </tr>
                </table>
            </td></tr>
        </table>"""
    ]

    row2_cards = [
        # Card 4: Esta Semana (SCTASK vs INC)
        f"""<table width="100%" height="150" cellpadding="0" cellspacing="0" border="0"
                   style="border:1.5px solid #3B82F6; border-radius:8px; border-collapse:separate; height:150px; background-color:#ffffff; box-shadow:0 2px 5px rgba(0,0,0,0.03);">
            <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:#eff6ff; padding:0 12px; border-bottom:1.5px solid #3B82F6; border-radius:7px 7px 0 0; font-family:{FONT_STACK};">
                <span style="color:#1d4ed8; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.4px;">📅 Esta Semana — SCTASK vs INC</span>
            </td></tr>
            <tr><td align="center" valign="middle" style="padding:10px 12px; font-family:{FONT_STACK};">
                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td width="50%" align="left" valign="middle">
                            <div style="font-size:10px; font-weight:bold; color:#0891b2;"><span class="badge-sctask">SCTASK</span></div>
                            <div style="font-size:22px; font-weight:bold; color:#06B6D4; margin:1px 0;">{cur_sct_wk} <span style="font-size:12px; color:#64748b; font-weight:normal;">vs {prev_sct_wk}</span></div>
                            <div>{_delta_badge(cur_sct_wk, prev_sct_wk)}</div>
                        </td>
                        <td width="50%" align="right" valign="middle" style="border-left:1px dashed #cbd5e1; padding-left:8px;">
                            <div style="font-size:10px; font-weight:bold; color:#7c3aed;"><span class="badge-inc">INCIDENTES</span></div>
                            <div style="font-size:22px; font-weight:bold; color:#8B5CF6; margin:1px 0;">{cur_inc_wk} <span style="font-size:12px; color:#64748b; font-weight:normal;">vs {prev_inc_wk}</span></div>
                            <div>{_delta_badge(cur_inc_wk, prev_inc_wk)}</div>
                        </td>
                    </tr>
                </table>
            </td></tr>
        </table>""",

        # Card 5: Este Mês MTD (SCTASK vs INC)
        f"""<table width="100%" height="150" cellpadding="0" cellspacing="0" border="0"
                   style="border:1.5px solid #F59E0B; border-radius:8px; border-collapse:separate; height:150px; background-color:#ffffff; box-shadow:0 2px 5px rgba(0,0,0,0.03);">
            <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:#fffbeb; padding:0 12px; border-bottom:1.5px solid #F59E0B; border-radius:7px 7px 0 0; font-family:{FONT_STACK};">
                <span style="color:#b45309; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.4px;">🗓️ Este Mês (MTD) — SCTASK vs INC</span>
            </td></tr>
            <tr><td align="center" valign="middle" style="padding:10px 12px; font-family:{FONT_STACK};">
                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td width="50%" align="left" valign="middle">
                            <div style="font-size:10px; font-weight:bold; color:#0891b2;"><span class="badge-sctask">SCTASK</span></div>
                            <div style="font-size:22px; font-weight:bold; color:#06B6D4; margin:1px 0;">{cur_sct_mo} <span style="font-size:12px; color:#64748b; font-weight:normal;">vs {prev_sct_mo}</span></div>
                            <div>{_delta_badge(cur_sct_mo, prev_sct_mo)}</div>
                        </td>
                        <td width="50%" align="right" valign="middle" style="border-left:1px dashed #cbd5e1; padding-left:8px;">
                            <div style="font-size:10px; font-weight:bold; color:#7c3aed;"><span class="badge-inc">INCIDENTES</span></div>
                            <div style="font-size:22px; font-weight:bold; color:#8B5CF6; margin:1px 0;">{cur_inc_mo} <span style="font-size:12px; color:#64748b; font-weight:normal;">vs {prev_inc_mo}</span></div>
                            <div>{_delta_badge(cur_inc_mo, prev_inc_mo)}</div>
                        </td>
                    </tr>
                </table>
            </td></tr>
        </table>""",

        # Card 6: SLA por Tipo (SCTASK 10d vs INC 7d)
        f"""<table width="100%" height="150" cellpadding="0" cellspacing="0" border="0"
                   style="border:1.5px solid #10B981; border-radius:8px; border-collapse:separate; height:150px; background-color:#ffffff; box-shadow:0 2px 5px rgba(0,0,0,0.03);">
            <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:#ecfdf5; padding:0 12px; border-bottom:1.5px solid #10B981; border-radius:7px 7px 0 0; font-family:{FONT_STACK};">
                <span style="color:#059669; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.4px;">🎯 Conformidade SLA por Tipo</span>
            </td></tr>
            <tr><td align="center" valign="middle" style="padding:10px 12px; font-family:{FONT_STACK};">
                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                    <tr>
                        <td width="50%" align="left" valign="middle">
                            <div style="font-size:10px; font-weight:bold; color:#0891b2;">SCTASK (Meta 10d)</div>
                            <div style="font-size:26px; font-weight:bold; color:#06B6D4; margin:1px 0;">{sct_sla_month:.0f}%</div>
                            <div style="font-size:10px; color:#059669; font-weight:bold;">Conforme</div>
                        </td>
                        <td width="50%" align="right" valign="middle" style="border-left:1px dashed #cbd5e1; padding-left:8px;">
                            <div style="font-size:10px; font-weight:bold; color:#7c3aed;">INC (Meta 7d)</div>
                            <div style="font-size:26px; font-weight:bold; color:#8B5CF6; margin:1px 0;">{inc_sla_month:.0f}%</div>
                            <div style="font-size:10px; color:#059669; font-weight:bold;">Conforme</div>
                        </td>
                    </tr>
                </table>
            </td></tr>
        </table>"""
    ]

    def _render_row(card_list):
        cells = []
        n = len(card_list)
        w = (100 - (n - 1) * 2) / n
        for i, html_card in enumerate(card_list):
            cells.append(f'<td width="{w:.1f}%" class="kpi-responsive-td" style="padding:0 6px 12px 6px;">{html_card}</td>')
            if i < n - 1:
                cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
        return f'<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>{"".join(cells)}</tr></table>'

    return _render_row(row1_cards) + _render_row(row2_cards)


def roster_table(roster):
    """Detailed Team Roster table with explicit SCTASK vs INC monthly volumes,
    MTTR breakdown per type, and TYPE-SPECIFIC SLA compliance (SCTASK 10d vs INC 7d).
    Note: Reopen Rate column removed per user directive.
    """
    if roster.empty:
        return rb.data_table(pd.DataFrame(), empty_message="No analyst activity found.")

    table_id = "rosterTable"
    header_cols = [
        "Analyst", "Tier", "Today", "Week", "Month (SCT | INC)", "Total Month",
        "MTTR SCT (d)", "MTTR INC (d)", "Robust MTTR (d)", "SCTASK SLA % (10d)", "INC SLA % (7d)", "Overall SLA %",
        "Emails Today", "Emails Week", "Emails Month"
    ]
    
    rows = ""
    for i, r in roster.iterrows():
        tier = r["Tier"] if r["Tier"] in TIER_STYLE else "\u2014"
        style = TIER_STYLE[tier]
        
        sct_month = int(r.get("SCTASK_Month", 0))
        inc_month = int(r.get("INC_Month", 0))
        tot_month = int(r.get("ThisMonth", 0))
        
        mttr_sct = f"{r['MTTR_SCTASK']:.1f}" if pd.notna(r.get("MTTR_SCTASK")) else "\u2014"
        mttr_inc = f"{r['MTTR_INC']:.1f}" if pd.notna(r.get("MTTR_INC")) else "\u2014"
        
        sct_sla = f"{r['SCTASK_SLA']:.0f}%" if pd.notna(r.get("SCTASK_SLA")) else "\u2014"
        inc_sla = f"{r['INC_SLA']:.0f}%" if pd.notna(r.get("INC_SLA")) else "\u2014"
        overall_sla = f"{r['SLACompliance']:.0f}%" if pd.notna(r.get("SLACompliance")) else "\u2014"

        # Robust MTTR: outlier-trimmed avg Opened->Closed (days). Shows the
        # sample count it was computed from so a low-volume analyst's
        # figure isn't mistaken for a stable, well-supported average.
        robust_val = r.get("RobustMTTR")
        robust_n = r.get("RobustMTTRSamples")
        robust_mttr_txt = f"{robust_val:.1f} <span style='color:#94a3b8; font-size:9px;'>(n={int(robust_n)})</span>" if pd.notna(robust_val) else "\u2014"
        robust_sort = robust_val if pd.notna(robust_val) else -1

        # Emails Today/Week/Month: "N/A" (not 0) whenever EMAIL_LOG_PATH
        # isn't configured - see analyst_metrics.emails_sent_by_analyst.
        def _email_cell(v):
            return ("N/A", -1) if v is None else (str(int(v)), int(v))
        e_today_txt, e_today_sort = _email_cell(r.get("EmailsToday"))
        e_week_txt, e_week_sort = _email_cell(r.get("EmailsWeek"))
        e_month_txt, e_month_sort = _email_cell(r.get("EmailsMonth"))
        
        tier_badge = (f"<span style='background-color:{style['text']}; color:#fff; padding:2px 8px; "
                       f"border-radius:10px; font-size:10px; font-weight:bold;'>{style['label']}</span>")
        
        type_split_html = f"<span class='badge-sctask'>{sct_month} SCT</span> &nbsp;<span class='badge-inc'>{inc_month} INC</span>"
        
        rows += (f"<tr style='background-color:{style['bg']};' data-tier='{tier}' data-name='{r['Analyst'].lower()}'>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:left; font-weight:bold; color:#2c3e50;' data-sort='{r['Analyst']}'>{r['Analyst']}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{tier}'>{tier_badge}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{r['Today']}'>{r['Today']}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{r['ThisWeek']}'>{r['ThisWeek']}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{tot_month}'>{type_split_html}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center; font-weight:bold;' data-sort='{tot_month}'>{tot_month}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{r.get('MTTR_SCTASK') if pd.notna(r.get('MTTR_SCTASK')) else -1}'>{mttr_sct}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{r.get('MTTR_INC') if pd.notna(r.get('MTTR_INC')) else -1}'>{mttr_inc}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{robust_sort}'>{robust_mttr_txt}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center; color:#06B6D4; font-weight:bold;' data-sort='{r.get('SCTASK_SLA') if pd.notna(r.get('SCTASK_SLA')) else -1}'>{sct_sla}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center; color:#8B5CF6; font-weight:bold;' data-sort='{r.get('INC_SLA') if pd.notna(r.get('INC_SLA')) else -1}'>{inc_sla}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center; font-weight:bold;' data-sort='{r.get('SLACompliance') if pd.notna(r.get('SLACompliance')) else -1}'>{overall_sla}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{e_today_sort}'>{e_today_txt}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center;' data-sort='{e_week_sort}'>{e_week_txt}</td>"
                 f"<td style='padding:7px; border:1px solid #e0e0e0; text-align:center; font-weight:bold;' data-sort='{e_month_sort}'>{e_month_txt}</td></tr>")

    header_html = "".join(
        f"<th onclick=\"sortRosterTable('{table_id}',{idx})\" style='background-color:#1E293B; color:#fff; padding:8px; "
        f"border:1px solid #e0e0e0; cursor:pointer; user-select:none; {'text-align:left;' if h == 'Analyst' else ''}' "
        f"title='Clique para ordenar'>{h} \u21C5</th>"
        for idx, h in enumerate(header_cols))
    
    legend = " &nbsp;\u00b7&nbsp; ".join(
        f"<span style='background-color:{s['text']}; color:#fff; padding:1px 7px; border-radius:8px; font-size:9px;'>{s['label']}</span>"
        for k, s in TIER_STYLE.items() if k != "\u2014")

    search_box = (f'<input type="text" id="{table_id}Search" onkeyup="filterRosterTable(\'{table_id}\')" '
                   f'placeholder="Filtrar por nome de analista... (funciona no navegador)" '
                   f'style="width:100%; max-width:340px; padding:8px 12px; margin-bottom:10px; border:1px solid #cbd5e1; '
                   f'border-radius:6px; font-size:12px; font-family:{FONT_STACK}; box-sizing:border-box;">')

    script = f"""<script>
function sortRosterTable(tableId, colIdx) {{
    var table = document.getElementById(tableId);
    if (!table) return;
    var tbody = table.tBodies[0];
    var rows = Array.prototype.slice.call(tbody.rows);
    var asc = table.getAttribute('data-sort-col') != colIdx || table.getAttribute('data-sort-dir') !== 'asc';
    rows.sort(function(a, b) {{
        var av = a.cells[colIdx].getAttribute('data-sort');
        var bv = b.cells[colIdx].getAttribute('data-sort');
        var an = parseFloat(av), bn = parseFloat(bv);
        var cmp = (!isNaN(an) && !isNaN(bn)) ? (an - bn) : String(av).localeCompare(String(bv));
        return asc ? cmp : -cmp;
    }});
    rows.forEach(function(r) {{ tbody.appendChild(r); }});
    table.setAttribute('data-sort-col', colIdx);
    table.setAttribute('data-sort-dir', asc ? 'asc' : 'desc');
}}
function filterRosterTable(tableId) {{
    var input = document.getElementById(tableId + 'Search');
    var filter = input.value.toLowerCase();
    var rows = document.getElementById(tableId).tBodies[0].rows;
    for (var i = 0; i < rows.length; i++) {{
        var name = rows[i].getAttribute('data-name') || '';
        rows[i].style.display = name.indexOf(filter) > -1 ? '' : 'none';
    }}
}}
</script>"""

    return (f'<div style="font-size:11px; color:#64748b; margin-bottom:10px; font-family:{FONT_STACK};">'
            f'Tiers por volume mensal: {legend}</div>'
            f'{search_box}'
            f"<table id='{table_id}' class='data-table' width='100%' cellpadding='0' cellspacing='0' border='0' "
            f"style='border-collapse:collapse; font-size:12px; font-family:{FONT_STACK};'>"
            f"<thead><tr>{header_html}</tr></thead><tbody>{rows}</tbody></table>"
            f'<div style="font-size:10px; color:#94a3b8; margin-top:6px; font-family:{FONT_STACK};">'
            f'Clique no cabeçalho de qualquer coluna para ordenar. Busca e ordenação interativas disponíveis no navegador.</div>'
            f'{script}')


def stacked_period_comparison_section(daily, weekly, monthly):
    html = section_header(2, section_id="period-panel")
    
    col_defs = [
        ("Hoje x Ontem", daily, "Hoje", "Ontem",
         "Today_SCTASK", "Today_INC", "Yesterday_SCTASK", "Yesterday_INC"),
        ("Esta Semana x Semana Passada", weekly, "Esta Sem.", "Sem. Pass.",
         "This Week_SCTASK", "This Week_INC", "Last Week_SCTASK", "Last Week_INC"),
        ("Este Mês (MTD) x Mês Anterior", monthly, "Este Mês", "Mês Ant.",
         "This Month (MTD)_SCTASK", "This Month (MTD)_INC", "Last Month (same days)_SCTASK", "Last Month (same days)_INC"),
    ]
    cells = []
    for title, df, cur_lbl, prev_lbl, c_sct, c_inc, p_sct, p_inc in col_defs:
        if df.empty:
            body = '<div style="font-size:12px; color:#999999; padding:20px; text-align:center;">Sem dados.</div>'
        else:
            top_df = df.head(8)
            labels = list(top_df["Analyst"])
            cur_sct_vals = [int(v) for v in top_df[c_sct]] if c_sct in top_df.columns else [0]*len(labels)
            cur_inc_vals = [int(v) for v in top_df[c_inc]] if c_inc in top_df.columns else [0]*len(labels)
            prev_sct_vals = [int(v) for v in top_df[p_sct]] if p_sct in top_df.columns else [0]*len(labels)
            prev_inc_vals = [int(v) for v in top_df[p_inc]] if p_inc in top_df.columns else [0]*len(labels)
            
            img = c.grouped_stacked_horizontal_bar(
                labels, cur_sct_vals, cur_inc_vals, prev_sct_vals, prev_inc_vals,
                label_cur=cur_lbl, label_prev=prev_lbl,
                title="", w=520, h=max(300, 38 * len(labels) + 70)
            )
            body = f'<img class="chart-img" src="{img}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; border:0;">'
        
        cells.append(
            f'<div style="border:1px solid #e2e8f0; border-top:3px solid #06B6D4; border-radius:8px; padding:12px; background-color:#ffffff; height:100%; box-sizing:border-box;">'
            f'<div style="font-size:12px; font-weight:bold; color:#334155; margin-bottom:8px; text-align:center; font-family:{FONT_STACK};">{title}</div>'
            f'{body}</div>'
        )
        
    html += (f'<div style="font-size:11px; color:#64748b; margin-bottom:10px; font-family:{FONT_STACK};">'
              f'Comparativo dos 8 maiores produtores por período. Cada analista possui <b>2 barras de comparação</b>: '
              f'a primeira é o <b>Período Atual</b> (SCTASK em <span class="badge-sctask">Teal</span> e INC em <span class="badge-inc">Violeta</span>) '
              f'e a segunda é o <b>Período Anterior</b> (SCTASK em <span style="background-color:#67E8F9; color:#0F172A; padding:2px 6px; border-radius:4px; font-size:10px; font-weight:bold;">Teal Claro</span> '
              f'e INC em <span style="background-color:#C4B5FD; color:#0F172A; padding:2px 6px; border-radius:4px; font-size:10px; font-weight:bold;">Violeta Claro</span>).</div>')
    html += rb.grid_row(cells)
    return html


def standalone_workload_section(universe, open_backlog):
    """PROMINENT, DEDICATED Workload Balance section with TWO separate balance cut-off lines."""
    html = section_header(3, section_id="workload-panel")
    
    active, fair_sct, fair_inc, fair_total = am.workload_balance_by_type(universe)
    if active.empty:
        return html + rb.data_table(pd.DataFrame(), empty_message="Nenhum chamado aberto atribuído no momento.")
    
    labels = list(active.index)
    sct_open = [int(active.loc[a, "SCTASK"]) for a in labels]
    inc_open = [int(active.loc[a, "INC"]) for a in labels]
    
    img = c.stacked_workload_balance_bar(
        labels, sct_open, inc_open, fair_sct, fair_inc, w=1050, h=max(360, 32 * len(labels) + 90)
    )
    
    html += (f'<div style="font-size:11px; color:#64748b; margin-bottom:12px; font-family:{FONT_STACK};">'
              f'<b>Duas Linhas de Corte para Balanceamento da Fila:</b><br>'
              f'1. <span style="color:#0284C7; font-weight:bold;">\u2544 Linha de Corte SCTASK ({fair_sct:.1f}/analista)</span>: média de requisições de serviço abertas por analista ativo.<br>'
              f'2. <span style="color:#6D28D9; font-weight:bold;">\u2544 Linha de Corte INC ({fair_inc:.1f}/analista)</span>: média de incidentes abertos por analista ativo.<br>'
              f'Cada barra empilha <span class="badge-sctask">SCTASK Aberto</span> e <span class="badge-inc">INC Aberto</span> para identificar instantaneamente sobrecarga relativa em cada tipo de chamado.</div>')
    html += full_width_chart(img)
    return html


def heat_maps_section(roster, groups, universe, ref):
    """Group Heatmaps using clean 3-column grid layout with STACKED horizontal bar charts per group.
    Renders 3 cards per row without redundant legends or cluttered text lists.
    """
    html = section_header(5, section_id="heatmaps-panel")
    active = roster[roster["ThisMonth"] > 0].copy()
    if active.empty:
        return html + rb.data_table(pd.DataFrame(), empty_message="Sem chamados encerrados no mês.")
    active["Group"] = active["Analyst"].map(groups).fillna("Ungrouped")

    this_month_range = am._month_bounds_elapsed(ref, months_back=0)
    month_by_type = am.closed_count_by_type(universe, *this_month_range)

    html += (f'<div style="font-size:11px; color:#64748b; margin-bottom:14px; font-family:{FONT_STACK};">'
              f'Volume mensal agrupado por Grupo Principal de Atendimento (exibição em grade de 3 colunas). '
              f'Barras empilhadas com contagem direta: <span class="badge-sctask">SCTASK</span> vs <span class="badge-inc">INC</span> por analista.</div>')

    group_cards = []
    for group_name in sorted(active["Group"].unique()):
        grp = active[active["Group"] == group_name].sort_values("ThisMonth", ascending=False)
        if len(grp) < 1:
            continue
        
        labels = list(grp["Analyst"])
        sct_vals = [int(month_by_type.loc[a, "SCTASK"]) if a in month_by_type.index else 0 for a in labels]
        inc_vals = [int(month_by_type.loc[a, "INC"]) if a in month_by_type.index else 0 for a in labels]
        
        img = c.stacked_horizontal_bar(
            labels, sct_vals, inc_vals, "SCTASK", "INC",
            "#06B6D4", "#8B5CF6", title="",
            w=360, h=max(160, 32 * len(grp) + 40), legend=False
        )
        
        group_cards.append(
            f'<div style="border:1px solid #e2e8f0; border-top:3px solid #8B5CF6; border-radius:8px; padding:12px; background-color:#ffffff; height:100%; box-sizing:border-box;">'
            f'<div style="font-size:12px; font-weight:bold; color:#1e293b; margin-bottom:8px; border-bottom:1px solid #f1f5f9; padding-bottom:6px; font-family:{FONT_STACK};">{group_name} ({len(grp)})</div>'
            f'<img class="chart-img" src="{img}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; border:0;">'
            f'</div>'
        )
        
    if group_cards:
        for i in range(0, len(group_cards), 3):
            chunk = group_cards[i:i + 3]
            html += rb.grid_row(chunk)

    return html


def self_history_table(self_vs_history):
    """Custom styled table for MTD vs Personal History with SCTASK vs INC badges,
    colored delta pills, interactive sorting/search, and inline chart progress bars.
    """
    if self_vs_history.empty:
        return ""

    table_id = "selfHistoryTable"
    header_cols = [
        "Analista", "Composição MTD (SCT | INC)", "Total MTD", "Média Pessoal (3m)", "Variação %", "Progresso Visual"
    ]
    
    rows = ""
    max_tot = max(float(self_vs_history["ThisMonth"].max()), float(self_vs_history["PersonalAvg"].max()), 1.0)

    for idx, r in self_vs_history.iterrows():
        name = r["Analyst"]
        sct_c = int(r.get("SCTASK_Month", 0))
        inc_c = int(r.get("INC_Month", 0))
        tot_c = int(r["ThisMonth"])
        avg_c = float(r["PersonalAvg"])
        delta = float(r["DeltaPct"])

        type_split = f"<span class='badge-sctask'>{sct_c} SCT</span> &nbsp;<span class='badge-inc'>{inc_c} INC</span>"
        
        if delta > 0:
            delta_badge = f"<span style='background-color:#dcfce7; color:#15803d; padding:3px 9px; border-radius:12px; font-weight:bold; font-size:11px;'>▲ +{delta:.1f}%</span>"
        elif delta < 0:
            delta_badge = f"<span style='background-color:#fee2e2; color:#991b1b; padding:3px 9px; border-radius:12px; font-weight:bold; font-size:11px;'>▼ {delta:.1f}%</span>"
        else:
            delta_badge = f"<span style='background-color:#f1f5f9; color:#475569; padding:3px 9px; border-radius:12px; font-weight:bold; font-size:11px;'>\u2014 0%</span>"

        pct_of_max = min(100, int((tot_c / max_tot) * 100))
        bar_color = "#10B981" if delta >= 0 else "#F59E0B"
        progress_chart = (
            f'<div style="width:130px; background-color:#e2e8f0; border-radius:4px; height:10px; display:inline-block; vertical-align:middle; overflow:hidden;" title="{tot_c} de {avg_c:.1f} média">'
            f'<div style="width:{pct_of_max}%; background-color:{bar_color}; height:100%; border-radius:4px;"></div>'
            f'</div>'
        )

        bg = "#ffffff" if idx % 2 == 0 else "#f8fafc"
        rows += (
            f"<tr style='background-color:{bg};' data-name='{name.lower()}'>"
            f"<td style='padding:8px 10px; border:1px solid #e2e8f0; text-align:left; font-weight:bold; color:#1e293b;' data-sort='{name}'>{name}</td>"
            f"<td style='padding:8px 10px; border:1px solid #e2e8f0; text-align:center;' data-sort='{tot_c}'>{type_split}</td>"
            f"<td style='padding:8px 10px; border:1px solid #e2e8f0; text-align:center; font-weight:bold; color:#0f172a; font-size:13px;' data-sort='{tot_c}'>{tot_c}</td>"
            f"<td style='padding:8px 10px; border:1px solid #e2e8f0; text-align:center; color:#475569;' data-sort='{avg_c}'>{avg_c:.1f}</td>"
            f"<td style='padding:8px 10px; border:1px solid #e2e8f0; text-align:center;' data-sort='{delta}'>{delta_badge}</td>"
            f"<td style='padding:8px 10px; border:1px solid #e2e8f0; text-align:center;' data-sort='{tot_c}'>{progress_chart}</td>"
            f"</tr>"
        )

    header_html = "".join(
        f"<th onclick=\"sortRosterTable('{table_id}',{i})\" style='background-color:#1E293B; color:#fff; padding:9px; "
        f"border:1px solid #cbd5e1; cursor:pointer; user-select:none; {'text-align:left;' if h == 'Analista' else ''}' "
        f"title='Clique para ordenar'>{h} \u21C5</th>"
        for i, h in enumerate(header_cols)
    )

    search_box = (
        f'<input type="text" id="{table_id}Search" onkeyup="filterRosterTable(\'{table_id}\')" '
        f'placeholder="Filtrar por analista no histórico..." '
        f'style="width:100%; max-width:320px; padding:7px 11px; margin-bottom:10px; border:1px solid #cbd5e1; '
        f'border-radius:6px; font-size:12px; font-family:{FONT_STACK}; box-sizing:border-box;">'
    )

    return (
        f'<div style="margin-top:20px; font-weight:bold; font-size:13px; color:#1e293b; font-family:{FONT_STACK}; margin-bottom:8px;">'
        f'📋 Tabela Detalhada: Desempenho MTD vs Média Pessoal Prévia (3 Meses)'
        f'</div>'
        f'{search_box}'
        f'<table id="{table_id}" class="data-table" width="100%" cellpadding="0" cellspacing="0" border="0" '
        f'style="border-collapse:collapse; font-size:12px; font-family:{FONT_STACK}; box-shadow:0 1px 3px rgba(0,0,0,0.04);">'
        f'<thead><tr>{header_html}</tr></thead><tbody>{rows}</tbody></table>'
    )


def consistency_and_history_section(universe, ref):
    """Combines Painel 6 (Consistência Diária) and Painel 6 (Próprio Histórico) SIDE-BY-SIDE in 2 columns,
    and renders the ENHANCED self_history_table with inline charts and type badges."""
    html = section_header(6, section_id="consistency-history-panel")
    
    consistency_stats = am.daily_consistency_stats(universe, ref)
    self_vs_history = am.self_vs_own_history(universe, ref)
    
    if consistency_stats.empty and self_vs_history.empty:
        return html + rb.data_table(pd.DataFrame(), empty_message="Sem dados suficientes de consistência e histórico.")
    
    # Left Card: Consistência Diária (21 dias)
    if not consistency_stats.empty:
        ordered = consistency_stats.sort_values("CV", ascending=False)
        img_cons = c.consistency_range_chart(
            list(ordered.index), list(ordered["Min"]), list(ordered["Max"]),
            list(ordered["Mean"]), list(ordered["CV"]), w=520, h=max(280, 28 * len(ordered) + 70)
        )
        left_body = f'<img class="chart-img" src="{img_cons}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; border:0;">'
    else:
        left_body = '<div style="font-size:12px; color:#999; text-align:center; padding:20px;">Sem dados diários.</div>'

    left_card = (
        f'<div style="border:1px solid #e2e8f0; border-top:3px solid #0D9488; border-radius:8px; padding:12px; background-color:#ffffff; height:100%; box-sizing:border-box;">'
        f'<div style="font-size:12px; font-weight:bold; color:#1e293b; margin-bottom:4px; font-family:{FONT_STACK};">'
        f'🎲 Consistência Diária (Mínimo vs Máximo - 21d)'
        f'</div>'
        f'<div style="font-size:10px; color:#64748b; margin-bottom:8px; font-family:{FONT_STACK};">Duas barras por analista: <span style="color:#06B6D4; font-weight:bold;">Mínimo Diário (Ocean Teal)</span> vs <span style="color:#8B5CF6; font-weight:bold;">Máximo Diário (Electric Violet)</span>.</div>'
        f'{left_body}'
        f'</div>'
    )

    # Right Card: Desempenho MTD vs Próprio Histórico
    if not self_vs_history.empty:
        img_hist = c.self_history_bar(
            list(self_vs_history["Analyst"]), list(self_vs_history["DeltaPct"]),
            w=520, h=max(280, 28 * len(self_vs_history) + 70)
        )
        right_body = f'<img class="chart-img" src="{img_hist}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; border:0;">'
    else:
        right_body = '<div style="font-size:12px; color:#999; text-align:center; padding:20px;">Sem histórico prévio.</div>'

    right_card = (
        f'<div style="border:1px solid #e2e8f0; border-top:3px solid #0D9488; border-radius:8px; padding:12px; background-color:#ffffff; height:100%; box-sizing:border-box;">'
        f'<div style="font-size:12px; font-weight:bold; color:#1e293b; margin-bottom:4px; font-family:{FONT_STACK};">'
        f'🧭 Desempenho MTD vs Próprio Histórico (3 meses)'
        f'</div>'
        f'<div style="font-size:10px; color:#64748b; margin-bottom:8px; font-family:{FONT_STACK};">Volume MTD comparado com a média individual dos 3 meses anteriores (auto-benchmarking).</div>'
        f'{right_body}'
        f'</div>'
    )

    html += (f'<div style="font-size:11px; color:#64748b; margin-bottom:14px; font-family:{FONT_STACK};">'
              f'Exibição combinada lado a lado: estabilidade operacional diária nos últimos 21 dias (esquerda) e variação em relação ao histórico individual (direita).</div>')
    html += rb.two_col_row(left_card, right_card)

    # ENHANCED self_history_table with inline chart bars and SCTASK vs INC badges
    html += self_history_table(self_vs_history)

    return html


def build_analyst_report(sctask, uam, inc, prb, config, ref):
    c.reset_delivery_stats()
    universe = am.build_analyst_universe(sctask, uam, inc, prb, ref)
    daily, weekly, monthly, totals, ranges = am.build_all_comparisons(universe, ref)
    open_backlog = am.open_backlog_by_analyst(universe)
    backlog_age = am.open_backlog_age_by_analyst(universe, ref)
    
    sla_days_dict = config.get("SLA_DAYS", {"SCTASK": 10, "INC": 7, "PRB": 10})
    res_stats_month = am.resolution_stats_by_analyst(universe, *ranges["this_month"], sla_days_dict)
    
    mttr_today = am.mttr_by_analyst(universe, *ranges["today"])
    mttr_week = am.mttr_by_analyst(universe, *ranges["this_week"])
    reopen_rate_month = am.reopen_rate_by_analyst(universe, *ranges["this_month"])
    net_flow = am.team_net_flow(universe, ranges)

    # --- Emails Sent per Analyst (Today/Week/Month) - see config.py
    # EMAIL_LOG_PATH/TEAM_EMAIL_DOMAIN comments. Every step degrades
    # gracefully to None -> roster shows "N/A", never a fabricated 0. ---
    email_log = dl.load_email_log(config.get("EMAIL_LOG_PATH", ""))
    analyst_email_map = am.build_analyst_email_map(universe)
    team_domain = config.get("TEAM_EMAIL_DOMAIN", "")
    emails_today = am.emails_sent_by_analyst(email_log, analyst_email_map, team_domain, *ranges["today"])
    emails_week = am.emails_sent_by_analyst(email_log, analyst_email_map, team_domain, *ranges["this_week"])
    emails_month = am.emails_sent_by_analyst(email_log, analyst_email_map, team_domain, *ranges["this_month"])

    # --- Robust (outlier-trimmed) average resolution/update time ---
    robust_mttr_month = am.robust_avg_resolution_time(
        universe, *ranges["this_month"],
        trim_pct=config.get("ROBUST_MTTR_TRIM_PCT", 0.10),
        min_samples=config.get("ROBUST_MTTR_MIN_SAMPLES", 5))

    cfg_copy = dict(config)
    cfg_copy["ref_date"] = ref
    roster = am.build_full_roster(
        daily, weekly, monthly, open_backlog, backlog_age, res_stats_month, cfg_copy,
        mttr_today=mttr_today, mttr_week=mttr_week, reopen_rate_month=reopen_rate_month, universe=universe,
        emails_today=emails_today, emails_week=emails_week, emails_month=emails_month,
        robust_mttr_month=robust_mttr_month
    )
    flags, team_avg_week = am.detect_attention_flags(daily, weekly, open_backlog, config)
    tp = am.top_performers(daily, weekly, monthly)
    groups = am.analyst_primary_group(universe)

    sct_sla_month = float(res_stats_month["SCTASK_SLA"].dropna().mean()) if not res_stats_month.empty and "SCTASK_SLA" in res_stats_month.columns else 100.0
    inc_sla_month = float(res_stats_month["INC_SLA"].dropna().mean()) if not res_stats_month.empty and "INC_SLA" in res_stats_month.columns else 100.0

    overview_kpis = type_separated_compare_kpis(totals, net_flow, len(roster), sct_sla_month, inc_sla_month)

    nav_bar = (
        '<div class="quick-nav">'
        '<a href="#overview-panel">\U0001F4C8 KPIs Overview</a>'
        '<a href="#period-panel">\U0001F4C5 Períodos (SCT vs INC)</a>'
        '<a href="#workload-panel">\u2696\ufe0f Balanceamento Carga</a>'
        '<a href="#roster-panel">\U0001F465 Roster Detalhado</a>'
        '<a href="#heatmaps-panel">\U0001F525 Heatmaps por Grupo</a>'
        '<a href="#consistency-history-panel">\U0001F3B2 Consistência & Histórico</a>'
        '</div>'
    )

    kpi_section_html = section_header(1, section_id="overview-panel") + overview_kpis
    period_comparison_html = stacked_period_comparison_section(daily, weekly, monthly)
    workload_html = standalone_workload_section(universe, open_backlog)
    
    roster_section_html = section_header(4, section_id="roster-panel") + (
        f'<div style="font-size:11px; color:#64748b; margin-bottom:12px; font-family:{FONT_STACK};">'
        f'Visão completa por analista ({len(roster)} totais) com volume discriminado por tipo (SCTASK vs INC), '
        f'MTTR por tipo e conformidade de SLA com metas específicas (INC=7d, SCTASK=10d).</div>'
    ) + roster_table(roster)

    heat_html = heat_maps_section(roster, groups, universe, ref)
    consistency_history_html = consistency_and_history_section(universe, ref)

    divider = ('<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
               '<td style="border-top:2px solid #e2e8f0; font-size:1px; line-height:1px;">&nbsp;</td></tr></table>'
               '<div style="height:20px; line-height:20px;">&nbsp;</div>')

    html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analyst Performance Comparison — Executive Dashboard</title>
    <style>{CSS}</style>
</head>
<body style="font-family:{FONT_STACK}; background-color:#f8fafc; margin:0; padding:20px 10px;">
    <table class="email-container" width="100%" cellpadding="0" cellspacing="0" border="0" align="center"
           style="max-width:1300px; margin:0 auto; background-color:#ffffff; border-radius:8px; box-shadow: 0 4px 12px rgba(0,0,0,0.06);">
        <tr><td>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
            <tr><td align="center" style="background-color:#0F172A; color:#ffffff; padding:20px; border-radius:8px 8px 0 0; font-family:{FONT_STACK};">
                <h2 style="margin:0 0 6px 0; font-size:22px; letter-spacing:0.4px; color:#ffffff; font-family:{FONT_STACK};">Comparativo de Desempenho de Analistas</h2>
                <p style="margin:0; color:#94A3B8; font-size:13px; font-family:{FONT_STACK};">
                   Referência: {ref.strftime('%d/%m/%Y %H:%M')} &nbsp;|&nbsp; Chamados REQ / SCTASK (Meta SLA: 10d) vs INC (Meta SLA: 7d)</p>
            </td></tr>
        </table>
        <div class="content" style="padding:22px;">

            {nav_bar}

            {kpi_section_html}
            {divider}
            {period_comparison_html}
            {divider}
            {workload_html}
            {divider}
            {roster_section_html}
            {divider}
            {heat_html}
            {divider}
            {consistency_history_html}

        </div>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="footer">
            <tr><td align="center" style="padding:15px; font-size:12px; color:#64748b; background-color:#f1f5f9; border-top:1px solid #e2e8f0; border-radius:0 0 8px 8px; font-family:{FONT_STACK};">
                Relatório automatizado de desempenho gerado pelo IT Metrics Dashboard &middot; {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
            </td></tr>
        </table>
        </td></tr>
    </table>
</body>
</html>"""

    kpis = {"totals": totals, "flag_count": len(flags), "roster_count": len(roster)}

    stats = c.get_delivery_stats()
    logger.info(f"📊 Entrega de gráficos (Analyst Comparison): {stats}")

    return html, kpis

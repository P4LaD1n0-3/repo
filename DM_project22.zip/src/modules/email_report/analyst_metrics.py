# -*- coding: utf-8 -*-
"""
Analyst Performance Comparison - Metrics
===========================================
Everything needed to answer "who closed how many tickets, today vs
yesterday / this week vs last week / this month vs the same point last
month" - across SCTASK (REQ), UAM, INC and PRB combined, grouped by the
"Assigned to" analyst.

Design choices worth knowing about:
- A ticket "counts" for an analyst on the day/week/month its Closed date
  falls in - NOT the day it was opened. This report is about closure
  throughput (who's actually getting tickets done), not intake.
- Week/month comparisons use a fair "same elapsed period" basis rather
  than comparing a partial current period to a full previous one: if
  today is Wednesday, "this week" is Mon-Wed and "last week" is also
  Mon-Wed of the prior week (not the full Mon-Sun) - otherwise a
  same-week comparison always looks artificially low. Same idea for
  months: "this month" is the 1st-through-today, compared against the
  1st-through-the-same-day-number of the previous month.
"""
import re

import pandas as pd

UNKNOWN_ANALYST = "(Unassigned)"


def build_analyst_universe(sctask, uam, inc, prb, ref):
    """Combines all 4 ticket types into one lightweight dataframe with
    just what's needed here: Assigned to / Opened / Closed / TicketType /
    IsOpen / State / ReopenCount. Unassigned tickets are kept (grouped
    under "(Unassigned)") rather than silently dropped, since an
    unusually large/growing unassigned pile is itself useful signal.

    `ref` snapshots Opened/Closed as of the report's reference date - same
    retroactive rule as `metrics.clip_to_reference_date` (see its
    docstring): a ticket opened after `ref` doesn't count yet, and one
    closed after `ref` is treated as still open. Without this, IsOpen/
    backlog-by-analyst would reflect each ticket's state TODAY even when
    the report is being (re)generated for a past reference date."""
    frames = []
    for df, ttype in ((sctask, "REQ"), (uam, "UAM"), (inc, "INC"), (prb, "PRB")):
        if df is None or df.empty:
            continue
        d = pd.DataFrame({
            "Assigned to": df["Assigned to"].astype(str).replace(
                {"": UNKNOWN_ANALYST, "nan": UNKNOWN_ANALYST, "\u2014": UNKNOWN_ANALYST}),
            "Assigned to Email": df["Assigned to Email"] if "Assigned to Email" in df.columns else "",
            "Assignment group": df["Assignment group"] if "Assignment group" in df.columns else "General",
            "Opened": df["Opened"],
            "Closed": df["Closed"],
            "State": df["State"] if "State" in df.columns else "N/A",
            "ReopenCount": df["ReopenCount"] if "ReopenCount" in df.columns else None,
            "TicketType": ttype,
        })
        frames.append(d)
    if not frames:
        return pd.DataFrame(columns=["Assigned to", "Opened", "Closed", "State", "ReopenCount", "TicketType", "IsOpen"])
    combined = pd.concat(frames, ignore_index=True)
    combined = combined[combined["Opened"] <= ref].copy()
    combined.loc[combined["Closed"] > ref, "Closed"] = pd.NaT
    combined["IsOpen"] = combined["Closed"].isna()
    return combined


def team_net_flow(df, ranges):
    """Team-wide Saldo de Fila (Net Flow) per period: tickets opened minus
    tickets closed in that window - positive means the queue is growing,
    negative means the team is draining it faster than it's filling."""
    out = {}
    for key, (start, end) in ranges.items():
        opened = int(((df["Opened"] >= start) & (df["Opened"] < end)).sum())
        closed = int((df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)).sum())
        out[key] = {"opened": opened, "closed": closed, "net": opened - closed}
    return out


def mttr_by_analyst(df, start, end):
    """Series indexed by analyst: average resolution time (calendar days)
    for tickets closed in [start, end). Used for both the "MTTR Today" and
    "MTTR this week" roster columns - same function, different range."""
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    sub = df.loc[mask].copy()
    if sub.empty:
        return pd.Series(dtype=float)
    sub["ResDays"] = ((sub["Closed"] - sub["Opened"]).dt.total_seconds() / 86400).clip(lower=0)
    return sub.groupby("Assigned to")["ResDays"].mean().round(1)


def reopen_rate_by_analyst(df, start, end):
    """Series indexed by analyst: % of their closures in [start, end) that
    were reopened at least once. Returns None (the whole feature, not a
    per-analyst value) when the source data has no reopen-tracking field
    at all - see data_loader._extract_reopen_count. Never fabricates a 0%
    rate for data this report doesn't actually have."""
    if df["ReopenCount"].isna().all():
        return None
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    sub = df.loc[mask].copy()
    if sub.empty or sub["ReopenCount"].isna().all():
        return None
    sub["WasReopened"] = sub["ReopenCount"].fillna(0) > 0
    return (sub.groupby("Assigned to")["WasReopened"].mean() * 100).round(1)


# Wait-status buckets: maps the real ServiceNow state vocabulary you
# confirmed (Open/Work in Progress/Awaiting.../Closed... for REQ+UAM,
# New/In Progress/On Hold/Resolved/Canceled for INC) into a handful of
# operationally meaningful groups for the "where is the flow stuck" view.
_WAIT_STATUS_GROUPS = [
    ("Awaiting User", ["awaiting user", "aguardando usuario", "aguardando usuário"]),
    ("Awaiting Vendor/3rd Party", ["awaiting vendor", "aguardando fornecedor", "aguardando terceiro"]),
    ("Awaiting Change/Release Mgmt", ["awaiting change", "awaiting release"]),
    ("On Hold", ["on hold"]),
    ("Being Worked", ["in progress", "work in progress", "new", "open", "self-service", "assigned"]),
]


def backlog_composition_by_status(df):
    """Team-wide breakdown of the CURRENT open backlog into wait-status
    groups - "Diagnóstico de Gargalos": if most of the backlog sits in
    "Awaiting User" or "Awaiting Vendor", the flow isn't stuck on the
    team's side; if it's mostly "Being Worked", either genuinely in
    progress or a sign of too much WIP per analyst."""
    open_df = df.loc[df["IsOpen"]].copy()
    if open_df.empty:
        return [], []
    state_lower = open_df["State"].astype(str).str.lower()
    assigned_group = pd.Series("Other", index=open_df.index)
    for label, keywords in _WAIT_STATUS_GROUPS:
        pattern = "|".join(re.escape(k) for k in keywords)
        mask = state_lower.str.contains(pattern, regex=True, na=False) & (assigned_group == "Other")
        assigned_group.loc[mask] = label
    counts = assigned_group.value_counts()
    return list(counts.index), [int(v) for v in counts.values]


def backlog_aging_buckets(df, ref):
    """Team-wide open backlog bucketed into <24h / 2-5 days / >5 days -
    the classic "how stale is the queue" aging view."""
    open_df = df.loc[df["IsOpen"]].copy()
    if open_df.empty:
        return [], []
    age_hours = (ref - open_df["Opened"]).dt.total_seconds() / 3600
    bins = [-1, 24, 120, float("inf")]
    labels = ["< 24h", "2-5 days", "> 5 days"]
    bucket = pd.cut(age_hours, bins=bins, labels=labels)
    counts = bucket.value_counts().reindex(labels, fill_value=0)
    return list(counts.index), [int(v) for v in counts.values]


def _day_bounds(day):
    """[start, end) for a single calendar day."""
    start = pd.Timestamp(day.date())
    return start, start + pd.Timedelta(days=1)


def _week_bounds_elapsed(ref, weeks_back=0):
    """Monday of the target week through the same weekday as `ref`,
    inclusive - i.e. the "elapsed" portion of that week, so a Wednesday
    run compares Mon-Wed this week against Mon-Wed last week, not a full
    week against a partial one."""
    monday_this_week = ref.normalize() - pd.Timedelta(days=ref.weekday())
    target_monday = monday_this_week - pd.Timedelta(weeks=weeks_back)
    start = target_monday
    end = target_monday + pd.Timedelta(days=ref.weekday() + 1)
    return start, end


def _month_bounds_elapsed(ref, months_back=0):
    """1st of the target month through the same day-of-month as `ref`
    (capped at that month's actual last day) - the "elapsed" portion, for
    a fair month-to-date vs month-to-date comparison."""
    year, month = ref.year, ref.month
    for _ in range(months_back):
        month -= 1
        if month == 0:
            month = 12
            year -= 1
    start = pd.Timestamp(year=year, month=month, day=1)
    days_in_month = (start + pd.offsets.MonthEnd(0)).day
    day_num = min(ref.day, days_in_month)
    end = pd.Timestamp(year=year, month=month, day=day_num) + pd.Timedelta(days=1)
    return start, end


def closed_count_by_analyst(df, start, end):
    """Series indexed by analyst: count of tickets whose Closed date falls
    in [start, end)."""
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    return df.loc[mask].groupby("Assigned to").size()


def closed_count_by_type(df, start, end):
    """DataFrame indexed by analyst with columns 'SCTASK', 'INC', 'UAM', 'PRB', 'Total'
    for tickets closed in [start, end)."""
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    sub = df.loc[mask]
    if sub.empty:
        return pd.DataFrame(columns=["SCTASK", "INC", "UAM", "PRB", "Total"])
    pivot = sub.groupby(["Assigned to", "TicketType"]).size().unstack(fill_value=0)
    for col in ["REQ", "INC", "UAM", "PRB"]:
        if col not in pivot.columns:
            pivot[col] = 0
    pivot = pivot.rename(columns={"REQ": "SCTASK"})
    pivot["Total"] = pivot["SCTASK"] + pivot["INC"] + pivot.get("UAM", 0) + pivot.get("PRB", 0)
    return pivot


def open_backlog_by_analyst(df):
    """Series indexed by analyst: count of currently-open tickets assigned
    to them (used for the "sitting on assigned work" attention flag)."""
    return df.loc[df["IsOpen"]].groupby("Assigned to").size()


def open_backlog_by_type(df):
    """DataFrame indexed by analyst with open backlog split into SCTASK vs INC."""
    open_df = df.loc[df["IsOpen"]]
    if open_df.empty:
        return pd.DataFrame(columns=["SCTASK", "INC", "UAM", "PRB", "Total"])
    pivot = open_df.groupby(["Assigned to", "TicketType"]).size().unstack(fill_value=0)
    for col in ["REQ", "INC", "UAM", "PRB"]:
        if col not in pivot.columns:
            pivot[col] = 0
    pivot = pivot.rename(columns={"REQ": "SCTASK"})
    pivot["Total"] = pivot["SCTASK"] + pivot["INC"] + pivot.get("UAM", 0) + pivot.get("PRB", 0)
    return pivot


def comparison_table(df, cur_range, prev_range, cur_label, prev_label):
    """Analyst-level comparison table for one pair of periods.
    Returns a DataFrame with total volume as well as SCTASK and INC breakdown.
    """
    cur_types = closed_count_by_type(df, *cur_range)
    prev_types = closed_count_by_type(df, *prev_range)
    cur_tot = closed_count_by_analyst(df, *cur_range)
    prev_tot = closed_count_by_analyst(df, *prev_range)
    analysts = sorted(set(cur_tot.index) | set(prev_tot.index))
    rows = []
    for a in analysts:
        c = int(cur_tot.get(a, 0))
        p = int(prev_tot.get(a, 0))
        delta = c - p
        if p == 0:
            delta_pct = None if c == 0 else float("inf")
        else:
            delta_pct = (delta / p) * 100
        
        c_sct = int(cur_types.loc[a, "SCTASK"]) if a in cur_types.index else 0
        c_inc = int(cur_types.loc[a, "INC"]) if a in cur_types.index else 0
        p_sct = int(prev_types.loc[a, "SCTASK"]) if a in prev_types.index else 0
        p_inc = int(prev_types.loc[a, "INC"]) if a in prev_types.index else 0

        rows.append({
            "Analyst": a,
            cur_label: c,
            prev_label: p,
            f"{cur_label}_SCTASK": c_sct,
            f"{cur_label}_INC": c_inc,
            f"{prev_label}_SCTASK": p_sct,
            f"{prev_label}_INC": p_inc,
            "Delta": delta,
            "DeltaPct": delta_pct
        })
    out = pd.DataFrame(rows)
    if out.empty:
        out = pd.DataFrame(columns=["Analyst", cur_label, prev_label, "Delta", "DeltaPct"])
    else:
        out = out.sort_values(cur_label, ascending=False).reset_index(drop=True)
    return out


def build_all_comparisons(df, ref):
    """Builds the 3 comparison tables (daily/weekly/monthly) plus the
    team-wide totals split by ticket type used in the Overview KPI row."""
    today_range = _day_bounds(ref)
    yesterday_range = _day_bounds(ref - pd.Timedelta(days=1))
    daily = comparison_table(df, today_range, yesterday_range, "Today", "Yesterday")

    this_week_range = _week_bounds_elapsed(ref, weeks_back=0)
    last_week_range = _week_bounds_elapsed(ref, weeks_back=1)
    weekly = comparison_table(df, this_week_range, last_week_range, "This Week", "Last Week")

    this_month_range = _month_bounds_elapsed(ref, months_back=0)
    last_month_range = _month_bounds_elapsed(ref, months_back=1)
    monthly = comparison_table(df, this_month_range, last_month_range, "This Month (MTD)", "Last Month (same days)")

    # Compute type-level totals
    today_by_type = closed_count_by_type(df, *today_range)
    yesterday_by_type = closed_count_by_type(df, *yesterday_range)
    week_by_type = closed_count_by_type(df, *this_week_range)
    last_week_by_type = closed_count_by_type(df, *last_week_range)
    month_by_type = closed_count_by_type(df, *this_month_range)
    last_month_by_type = closed_count_by_type(df, *last_month_range)

    totals = {
        "today": int(daily["Today"].sum()) if not daily.empty else 0,
        "yesterday": int(daily["Yesterday"].sum()) if not daily.empty else 0,
        "today_sctask": int(today_by_type["SCTASK"].sum()) if not today_by_type.empty else 0,
        "today_inc": int(today_by_type["INC"].sum()) if not today_by_type.empty else 0,
        "yesterday_sctask": int(yesterday_by_type["SCTASK"].sum()) if not yesterday_by_type.empty else 0,
        "yesterday_inc": int(yesterday_by_type["INC"].sum()) if not yesterday_by_type.empty else 0,

        "this_week": int(weekly["This Week"].sum()) if not weekly.empty else 0,
        "last_week": int(weekly["Last Week"].sum()) if not weekly.empty else 0,
        "this_week_sctask": int(week_by_type["SCTASK"].sum()) if not week_by_type.empty else 0,
        "this_week_inc": int(week_by_type["INC"].sum()) if not week_by_type.empty else 0,
        "last_week_sctask": int(last_week_by_type["SCTASK"].sum()) if not last_week_by_type.empty else 0,
        "last_week_inc": int(last_week_by_type["INC"].sum()) if not last_week_by_type.empty else 0,

        "this_month": int(monthly["This Month (MTD)"].sum()) if not monthly.empty else 0,
        "last_month": int(monthly["Last Month (same days)"].sum()) if not monthly.empty else 0,
        "this_month_sctask": int(month_by_type["SCTASK"].sum()) if not month_by_type.empty else 0,
        "this_month_inc": int(month_by_type["INC"].sum()) if not month_by_type.empty else 0,
        "last_month_sctask": int(last_month_by_type["SCTASK"].sum()) if not last_month_by_type.empty else 0,
        "last_month_inc": int(last_month_by_type["INC"].sum()) if not last_month_by_type.empty else 0,

        "active_analysts_today": int((daily["Today"] > 0).sum()) if not daily.empty else 0,
    }
    ranges = {
        "today": today_range, "yesterday": yesterday_range,
        "this_week": this_week_range, "last_week": last_week_range,
        "this_month": this_month_range, "last_month": last_month_range,
    }
    return daily, weekly, monthly, totals, ranges


def detect_attention_flags(daily, weekly, open_backlog, config):
    """Factual, non-judgmental flags for analysts whose closure pattern
    stands out from the team - the report presents the numbers, a human
    reader decides what (if anything) they mean."""
    threshold_pct = config.get("ANALYST_ATTENTION_THRESHOLD_PCT", 0.5)
    drop_ratio = config.get("ANALYST_ATTENTION_DROP_RATIO", 0.5)
    min_baseline = config.get("ANALYST_ATTENTION_MIN_BASELINE", 3)

    week_map = {row["Analyst"]: row for _, row in weekly.iterrows()}
    active_week = weekly[weekly["This Week"] > 0]["This Week"] if not weekly.empty else pd.Series(dtype=float)
    team_avg_week = float(active_week.mean()) if len(active_week) else 0.0

    today_map = {row["Analyst"]: int(row["Today"]) for _, row in daily.iterrows()} if not daily.empty else {}

    all_analysts = sorted(set(week_map.keys()) | set(open_backlog.index))
    flags = []
    for analyst in all_analysts:
        if analyst == "(Unassigned)":
            continue
        backlog = int(open_backlog.get(analyst, 0))
        if backlog == 0:
            continue
        reasons = []
        today_count = today_map.get(analyst, 0)
        if today_count == 0:
            reasons.append(f"No tickets closed today, {backlog} currently assigned and open")

        wk = week_map.get(analyst)
        this_wk = int(wk["This Week"]) if wk is not None else 0
        last_wk = int(wk["Last Week"]) if wk is not None else 0
        if team_avg_week > 0 and this_wk < team_avg_week * threshold_pct:
            reasons.append(f"This week: {this_wk} closed vs team average {team_avg_week:.1f}")
        if last_wk >= min_baseline and this_wk < last_wk * drop_ratio:
            reasons.append(f"Sharp week-over-week drop: {last_wk} \u2192 {this_wk}")

        if reasons:
            flags.append({"Analyst": analyst, "OpenBacklog": backlog, "Today": today_count,
                           "ThisWeek": this_wk, "LastWeek": last_wk, "Reasons": reasons})

    flags.sort(key=lambda f: (len(f["Reasons"]), f["OpenBacklog"]), reverse=True)
    return flags, team_avg_week


def resolution_stats_by_analyst(df, start, end, sla_days):
    """For tickets CLOSED in [start, end), per analyst: calculates count, avg resolution days,
    and SLA compliance evaluated against TYPE-SPECIFIC SLA targets (INC = 7d, SCTASK = 10d)."""
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    sub = df.loc[mask].copy()
    if sub.empty:
        return pd.DataFrame(columns=["Count", "AvgResDays", "SLACompliance", "SCTASK_SLA", "INC_SLA", "MTTR_SCTASK", "MTTR_INC"])
    
    sub["ResDays"] = ((sub["Closed"] - sub["Opened"]).dt.total_seconds() / 86400).clip(lower=0)
    
    # Map type-specific SLA targets
    if isinstance(sla_days, dict):
        sub["SLATarget"] = sub["TicketType"].map({"REQ": sla_days.get("SCTASK", 10), "SCTASK": sla_days.get("SCTASK", 10), "INC": sla_days.get("INC", 7), "PRB": sla_days.get("PRB", 10), "UAM": sla_days.get("SCTASK", 10)}).fillna(10)
    else:
        sub["SLATarget"] = float(sla_days)
    
    sub["InSLA"] = sub["ResDays"] <= sub["SLATarget"]
    
    # Group overall
    grouped = sub.groupby("Assigned to").agg(
        Count=("ResDays", "size"),
        AvgResDays=("ResDays", "mean"),
        SLACompliance=("InSLA", "mean")
    )
    grouped["SLACompliance"] = (grouped["SLACompliance"] * 100).round(1)
    grouped["AvgResDays"] = grouped["AvgResDays"].round(1)
    
    # SCTASK specific
    sct_mask = sub["TicketType"].isin(["REQ", "SCTASK", "UAM"])
    sct_sub = sub.loc[sct_mask]
    if not sct_sub.empty:
        sct_grp = sct_sub.groupby("Assigned to").agg(
            SCTASK_SLA=("InSLA", "mean"),
            MTTR_SCTASK=("ResDays", "mean")
        )
        grouped["SCTASK_SLA"] = (sct_grp["SCTASK_SLA"] * 100).round(1)
        grouped["MTTR_SCTASK"] = sct_grp["MTTR_SCTASK"].round(1)
    else:
        grouped["SCTASK_SLA"] = None
        grouped["MTTR_SCTASK"] = None

    # INC specific
    inc_sub = sub.loc[sub["TicketType"] == "INC"]
    if not inc_sub.empty:
        inc_grp = inc_sub.groupby("Assigned to").agg(
            INC_SLA=("InSLA", "mean"),
            MTTR_INC=("ResDays", "mean")
        )
        grouped["INC_SLA"] = (inc_grp["INC_SLA"] * 100).round(1)
        grouped["MTTR_INC"] = inc_grp["MTTR_INC"].round(1)
    else:
        grouped["INC_SLA"] = None
        grouped["MTTR_INC"] = None

    return grouped


def open_backlog_age_by_analyst(df, ref):
    """Series indexed by analyst: average age (days) of their currently open tickets."""
    open_df = df.loc[df["IsOpen"]].copy()
    if open_df.empty:
        return pd.Series(dtype=float)
    open_df["AgeDays"] = (ref - open_df["Opened"]).dt.total_seconds() / 86400
    return open_df.groupby("Assigned to")["AgeDays"].mean().round(1)


def build_full_roster(daily, weekly, monthly, open_backlog, backlog_age, res_stats_month, config,
                        mttr_today=None, mttr_week=None, reopen_rate_month=None, universe=None,
                        emails_today=None, emails_week=None, emails_month=None, robust_mttr_month=None):
    """Centerpiece roster view with detailed SCTASK vs INC volume splits and type-specific SLA compliance.
    emails_today/week/month may each be None (EMAIL_LOG_PATH not configured) - shown as "N/A" per analyst,
    never fabricated as 0. robust_mttr_month is the outlier-trimmed resolution-time DataFrame from
    robust_avg_resolution_time() - the honest proxy for "time to update/resolve" (see config.py comments
    on ROBUST_MTTR_* for why Opened->Closed is used instead of a true per-update log)."""
    all_analysts = set(weekly["Analyst"]) | set(monthly["Analyst"]) | set(open_backlog.index)
    all_analysts.discard(am_unknown_label())

    today_map = dict(zip(daily["Analyst"], daily["Today"])) if not daily.empty else {}
    yesterday_map = dict(zip(daily["Analyst"], daily["Yesterday"])) if not daily.empty else {}
    week_map = dict(zip(weekly["Analyst"], weekly["This Week"])) if not weekly.empty else {}
    month_map = dict(zip(monthly["Analyst"], monthly["This Month (MTD)"])) if not monthly.empty else {}

    # Monthly breakdown by type
    if universe is not None and not monthly.empty:
        this_month_range = _month_bounds_elapsed(config.get("ref_date", pd.Timestamp.now()), months_back=0)
        month_by_type = closed_count_by_type(universe, *this_month_range)
        open_by_type = open_backlog_by_type(universe)
    else:
        month_by_type = pd.DataFrame()
        open_by_type = pd.DataFrame()

    rows = []
    for a in sorted(all_analysts):
        backlog = int(open_backlog.get(a, 0))
        month_closed = int(month_map.get(a, 0))
        today_closed = int(today_map.get(a, 0))
        yesterday_closed = int(yesterday_map.get(a, 0))
        
        sct_month = int(month_by_type.loc[a, "SCTASK"]) if (not month_by_type.empty and a in month_by_type.index) else 0
        inc_month = int(month_by_type.loc[a, "INC"]) if (not month_by_type.empty and a in month_by_type.index) else 0
        sct_open = int(open_by_type.loc[a, "SCTASK"]) if (not open_by_type.empty and a in open_by_type.index) else 0
        inc_open = int(open_by_type.loc[a, "INC"]) if (not open_by_type.empty and a in open_by_type.index) else 0

        if yesterday_closed == 0:
            today_vs_yesterday_pct = None if today_closed == 0 else float("inf")
        else:
            today_vs_yesterday_pct = (today_closed - yesterday_closed) / yesterday_closed * 100
        
        avg_res = res_stats_month["AvgResDays"].get(a) if a in res_stats_month.index else None
        sla_pct = res_stats_month["SLACompliance"].get(a) if a in res_stats_month.index else None
        sct_sla = res_stats_month["SCTASK_SLA"].get(a) if a in res_stats_month.index else None
        inc_sla = res_stats_month["INC_SLA"].get(a) if a in res_stats_month.index else None
        mttr_sct = res_stats_month["MTTR_SCTASK"].get(a) if a in res_stats_month.index else None
        mttr_inc = res_stats_month["MTTR_INC"].get(a) if a in res_stats_month.index else None

        completion_ratio = (month_closed / (month_closed + backlog) * 100) if (month_closed + backlog) > 0 else None

        e_today = emails_today.get(a) if isinstance(emails_today, pd.Series) and a in emails_today.index else (0 if isinstance(emails_today, pd.Series) else None)
        e_week = emails_week.get(a) if isinstance(emails_week, pd.Series) and a in emails_week.index else (0 if isinstance(emails_week, pd.Series) else None)
        e_month = emails_month.get(a) if isinstance(emails_month, pd.Series) and a in emails_month.index else (0 if isinstance(emails_month, pd.Series) else None)
        robust_mttr_val = None
        robust_mttr_samples = None
        if robust_mttr_month is not None and not robust_mttr_month.empty and a in robust_mttr_month.index:
            robust_mttr_val = robust_mttr_month.loc[a, "TrimmedAvgDays"]
            robust_mttr_samples = int(robust_mttr_month.loc[a, "SampleCount"])

        rows.append({
            "Analyst": a,
            "Today": today_closed,
            "Yesterday": yesterday_closed,
            "TodayVsYesterdayPct": today_vs_yesterday_pct,
            "ThisWeek": int(week_map.get(a, 0)),
            "ThisMonth": month_closed,
            "SCTASK_Month": sct_month,
            "INC_Month": inc_month,
            "SCTASK_Open": sct_open,
            "INC_Open": inc_open,
            "OpenBacklog": backlog,
            "BacklogAvgAge": backlog_age.get(a),
            "MTTRToday": mttr_today.get(a) if mttr_today is not None and a in mttr_today.index else None,
            "MTTRWeek": mttr_week.get(a) if mttr_week is not None and a in mttr_week.index else None,
            "AvgResDays": avg_res,
            "MTTR_SCTASK": mttr_sct,
            "MTTR_INC": mttr_inc,
            "SLACompliance": sla_pct,
            "SCTASK_SLA": sct_sla,
            "INC_SLA": inc_sla,
            "ReopenRate": (reopen_rate_month.get(a) if reopen_rate_month is not None and a in reopen_rate_month.index else None),
            "CompletionRatio": completion_ratio,
            "EmailsToday": e_today,
            "EmailsWeek": e_week,
            "EmailsMonth": e_month,
            "RobustMTTR": robust_mttr_val,
            "RobustMTTRSamples": robust_mttr_samples,
        })
    roster = pd.DataFrame(rows)
    if roster.empty:
        return roster

    active = roster[roster["ThisMonth"] > 0].copy()
    if len(active) >= 4:
        active["Tier"] = pd.qcut(active["ThisMonth"], 4, labels=["Q4", "Q3", "Q2", "Q1"], duplicates="drop")
    elif len(active) > 0:
        active["Tier"] = "Q1"
    roster["Tier"] = roster["Analyst"].map(active.set_index("Analyst")["Tier"] if len(active) else {})
    roster["Tier"] = roster["Tier"].astype(str).replace("nan", "\u2014")
    roster = roster.sort_values(["ThisMonth", "ThisWeek"], ascending=False).reset_index(drop=True)
    return roster


def am_unknown_label():
    return UNKNOWN_ANALYST


def workload_balance(open_backlog):
    """Fair-share reference line for the workload chart: total open
    backlog divided evenly across everyone currently holding at least one
    open ticket."""
    active = open_backlog[open_backlog > 0]
    fair_share = float(active.mean()) if len(active) else 0.0
    return active.sort_values(ascending=False), fair_share


def workload_balance_by_type(df):
    """Calculates active analysts open backlog split into SCTASK vs INC,
    along with two separate fair-share balance cut-off lines:
    1. fair_share_sct: average open SCTASKs across active analysts
    2. fair_share_inc: average open INCs across active analysts
    Returns: active (DataFrame), fair_share_sct (float), fair_share_inc (float), fair_share_total (float)
    """
    open_types = open_backlog_by_type(df)
    active = open_types[open_types["Total"] > 0].sort_values("Total", ascending=False)
    n_active = len(active)
    if n_active == 0:
        return active, 0.0, 0.0, 0.0
    fair_share_sct = float(active["SCTASK"].sum()) / n_active
    fair_share_inc = float(active["INC"].sum()) / n_active
    fair_share_total = float(active["Total"].sum()) / n_active
    return active, fair_share_sct, fair_share_inc, fair_share_total


def analyst_primary_group(df):
    """Series indexed by analyst: their single most common Assignment
    group (by ticket count, any period) - the basis for "compare like
    with like" segmented views, since an analyst working Security tickets
    shouldn't be ranked against one working Service Desk N1 as if they
    were doing the same job."""
    sub = df[df["Assigned to"] != UNKNOWN_ANALYST]
    if sub.empty:
        return pd.Series(dtype=object)
    return sub.groupby("Assigned to")["Assignment group"].agg(lambda s: s.value_counts().idxmax())


def daily_consistency_stats(df, ref, lookback_days=21):
    """Per-analyst consistency/outlier stats over the trailing
    `lookback_days`: daily closure counts' min / max / mean / standard
    deviation / coefficient of variation (stdev / mean - unitless, so a
    high-volume and low-volume analyst are comparable on "how erratic is
    their day-to-day", not just on raw spread). Only days with at least
    one closure count toward the daily series - a silent zero-day doesn't
    inflate variance for someone who simply wasn't scheduled.
    Only analysts with at least 4 non-zero days are included - fewer than
    that and "consistency" isn't a meaningful read yet."""
    start = (ref.normalize() - pd.Timedelta(days=lookback_days - 1))
    end = ref.normalize() + pd.Timedelta(days=1)
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    sub = df.loc[mask].copy()
    if sub.empty:
        return pd.DataFrame(columns=["Min", "Max", "Mean", "Std", "CV", "DaysActive"])
    sub["Day"] = sub["Closed"].dt.normalize()
    daily = sub.groupby(["Assigned to", "Day"]).size().reset_index(name="Count")
    stats = daily.groupby("Assigned to")["Count"].agg(["min", "max", "mean", "std", "count"])
    stats.columns = ["Min", "Max", "Mean", "Std", "DaysActive"]
    stats["Std"] = stats["Std"].fillna(0)
    stats["CV"] = (stats["Std"] / stats["Mean"]).round(2)
    stats = stats[stats["DaysActive"] >= 4]
    return stats.round(1)


def self_vs_own_history(df, ref, trailing_months=3):
    """Per-analyst "am I improving or slipping relative to MYSELF" view:
    this month's closures (MTD) vs their own average monthly closures over
    the `trailing_months` PRIOR full months (current month excluded, so a
    partial month is never compared against a full one). Only analysts
    with a non-zero personal history are included - a brand-new analyst
    has no personal baseline yet."""
    this_start, this_end = _month_bounds_elapsed(ref, months_back=0)
    this_month = closed_count_by_analyst(df, this_start, this_end)
    this_month_by_type = closed_count_by_type(df, this_start, this_end)

    history_counts = []
    for m in range(1, trailing_months + 1):
        year, month = ref.year, ref.month
        for _ in range(m):
            month -= 1
            if month == 0:
                month = 12
                year -= 1
        start = pd.Timestamp(year=year, month=month, day=1)
        end = start + pd.offsets.MonthEnd(1) + pd.Timedelta(days=1)
        history_counts.append(closed_count_by_analyst(df, start, end))

    if history_counts:
        hist_df = pd.concat(history_counts, axis=1).fillna(0)
        hist_avg = hist_df.mean(axis=1).round(1)
    else:
        hist_avg = pd.Series(dtype=float)

    analysts = sorted(set(this_month.index) | set(hist_avg.index))
    rows = []
    for a in analysts:
        if a == UNKNOWN_ANALYST:
            continue
        cur = int(this_month.get(a, 0))
        avg = float(hist_avg.get(a, 0))
        if avg == 0:
            continue  # no personal baseline yet - nothing to compare against
        sct_c = int(this_month_by_type.loc[a, "SCTASK"]) if a in this_month_by_type.index else 0
        inc_c = int(this_month_by_type.loc[a, "INC"]) if a in this_month_by_type.index else 0
        delta_pct = (cur - avg) / avg * 100
        rows.append({
            "Analyst": a,
            "SCTASK_Month": sct_c,
            "INC_Month": inc_c,
            "ThisMonth": cur,
            "PersonalAvg": avg,
            "DeltaPct": round(delta_pct, 1)
        })
    out = pd.DataFrame(rows)
    if not out.empty:
        out = out.sort_values("DeltaPct", ascending=False).reset_index(drop=True)
    return out


def top_performers(daily, weekly, monthly, top_n=5):
    """Simple leaderboards - the positive counterpart to the attention
    flags, so the report isn't one-sided."""
    def _top(df, col):
        if df.empty:
            return [], []
        ranked = df[df[col] > 0].sort_values(col, ascending=False).head(top_n)
        return list(ranked["Analyst"]), list(ranked[col])

    return {
        "today": _top(daily, "Today"),
        "week": _top(weekly, "This Week"),
        "month": _top(monthly, "This Month (MTD)"),
    }


def build_analyst_email_map(df):
    """Analyst name -> email address, derived directly from the ticket
    data itself (the "Assigned to Email" field, populated from INC's
    "Email" column - confirmed to correlate 1:1 with "Assigned to" in
    your exports) rather than requiring a separate mapping file. Picks
    each analyst's most frequent non-blank email if more than one shows
    up (shouldn't normally happen, but defensive)."""
    sub = df[(df["Assigned to"] != UNKNOWN_ANALYST) & (df["Assigned to Email"].astype(str).str.strip() != "")]
    if sub.empty:
        return {}
    return sub.groupby("Assigned to")["Assigned to Email"].agg(lambda s: s.value_counts().idxmax()).to_dict()


def emails_sent_by_analyst(email_log, analyst_email_map, team_domain, start, end):
    """Series indexed by analyst: count of emails they SENT (From address
    matches their own known email, per analyst_email_map) within
    [start, end). A second, independent filter requires the sender
    address to end with `team_domain` - even if a vendor's address
    somehow collided with a name/display match, it still can't count
    unless it's genuinely on the team's own domain. Returns None (not an
    empty Series) if email_log is None (feature not configured) or no
    analyst emails are known yet - callers should show "N/A", not "0"."""
    if email_log is None or not analyst_email_map:
        return None
    domain = (team_domain or "").lower()
    valid_emails = {addr.lower() for addr in analyst_email_map.values() if addr}
    if domain:
        valid_emails = {addr for addr in valid_emails if addr.endswith(domain)}
    if not valid_emails:
        return None

    email_to_analyst = {v.lower(): k for k, v in analyst_email_map.items() if v}
    mask = (email_log["From"].isin(valid_emails) &
            (email_log["SentAt"] >= start) & (email_log["SentAt"] < end))
    sub = email_log.loc[mask].copy()
    if sub.empty:
        return pd.Series(dtype=int)
    sub["Analyst"] = sub["From"].map(email_to_analyst)
    return sub.groupby("Analyst").size()


def robust_avg_resolution_time(df, start, end, trim_pct=0.10, min_samples=5):
    """Per-analyst trimmed-mean resolution time (days, Opened -> Closed)
    for tickets closed in [start, end) - the outlier-resistant companion
    to the plain average in resolution_stats_by_analyst(). Drops the
    slowest and fastest `trim_pct` of an analyst's own closures (by
    duration) before averaging the rest, so one unusually long-running
    ticket (a vendor-blocked INC sitting for weeks, say) doesn't single-
    handedly drag their whole average up. Falls back to the plain mean
    when an analyst has fewer than `min_samples` closures in the window -
    trimming needs enough data points to mean anything. Returns a
    DataFrame indexed by analyst: TrimmedAvgDays, PlainAvgDays (for
    comparison), SampleCount, TrimmedCount (how many were excluded)."""
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    sub = df.loc[mask].copy()
    if sub.empty:
        return pd.DataFrame(columns=["TrimmedAvgDays", "PlainAvgDays", "SampleCount", "TrimmedCount"])
    sub["ResDays"] = ((sub["Closed"] - sub["Opened"]).dt.total_seconds() / 86400).clip(lower=0)

    rows = []
    for analyst, grp in sub.groupby("Assigned to"):
        if analyst == UNKNOWN_ANALYST:
            continue
        vals = sorted(grp["ResDays"].tolist())
        n = len(vals)
        plain_avg = sum(vals) / n
        if n >= min_samples and trim_pct > 0:
            k = int(n * trim_pct)
            trimmed = vals[k:n - k] if (n - 2 * k) > 0 else vals
        else:
            trimmed = vals
        trimmed_avg = sum(trimmed) / len(trimmed) if trimmed else plain_avg
        rows.append({"Analyst": analyst, "TrimmedAvgDays": round(trimmed_avg, 1),
                      "PlainAvgDays": round(plain_avg, 1), "SampleCount": n,
                      "TrimmedCount": n - len(trimmed)})
    out = pd.DataFrame(rows)
    return out.set_index("Analyst") if not out.empty else out

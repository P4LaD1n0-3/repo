import os
from flask import Blueprint, render_template
from flask_login import login_required, current_user

current_dir = os.path.dirname(os.path.abspath(__file__))
incidents_bp = Blueprint('incidents', __name__, template_folder=current_dir)

@incidents_bp.route('/incidents')
@login_required
def index():
    return render_template('incidents.html', user=current_user, active_page='incidents')

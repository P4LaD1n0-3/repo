"""
================================================================================
SERVIÇO EXCLUSIVO: CRIAÇÃO DE CTASK (CHANGE TASK) NUMA CHANGE APROVADA
================================================================================
Cria uma nova Change Task (CTASK) dentro de uma Change (CHG) já aberta no
ServiceNow - usado pela tela 'Create ctask' depois de confirmar, por e-mail
(ver tools/mail_reader.py), que a Change foi aprovada.

Herda só de ServiceNowDriver (sem UPM/DB) - mesmo padrão enxuto de
TaskEncerrarService, já que este serviço só mexe no ServiceNow.

Navegação 'change_request.do?sys_id={número legível}' (não o GUID real) é um
padrão JÁ CONFIRMADO funcionando nesta base - ver
'release_close_service.py' (mesma URL usada lá para fechar a Change).
"""

import os
import logging
from typing import Any, Dict, List, Optional, Tuple, Union
from playwright.async_api import Page, FrameLocator

from tools.servicenow_driver import ServiceNowDriver
from tools.chamado import SERVICE_NOW_BASE_URL
from src.modules.send_dml.dml_change_finder import buscar_change_do_dia, CHG_REGEX

logger = logging.getLogger("CtaskCreationService")

# Aplicações reconhecidas no título/corpo do e-mail de aprovação - mesmas
# chaves aceitas por 'dml_change_finder.buscar_change_do_dia' (EBAO/PORTAL).
# Usadas só como ÚLTIMO fallback (ver '_resolver_change_com_fallback'), para
# redescobrir a Change do DIA VIGENTE via Outlook quando o 'chg_number'
# gravado no banco já não existe mais (renumerada/encerrada entre o envio do
# e-mail e a resposta de aprovação).
APLICACOES_RECONHECIDAS = ("EBAO", "PORTAL")


class CtaskCreationService(ServiceNowDriver):
    """Cria uma CTASK dentro de uma Change já aprovada."""

    async def _abrir_change_no_formulario(
        self, page: Page, chg_number: str, timeout: int = 20000
    ) -> Union[Page, FrameLocator]:
        """
        Abre 'chg_number' pela URL direta (padrão já confirmado - ver
        cabeçalho do arquivo) e confirma, no campo readonly do formulário, que
        a Change foi de fato encontrada (não redirecionou para uma página de
        erro/lista vazia). Devolve o escopo (iFrame 'gsft_main') pronto para
        uso; lança exceção em caso de falha - quem chama decide se tenta outro
        número ou desiste (ver '_resolver_change_com_fallback').
        """
        url = f"{SERVICE_NOW_BASE_URL}/change_request.do?sys_id={chg_number}"
        logger.info(f"🆕 [CtaskCreationService] Abrindo Change {chg_number}: {url}")

        await page.goto(url, wait_until="domcontentloaded", timeout=30000)
        scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=timeout)

        chg_locator = await self.wait_for_element(scope, "change_number_readonly", timeout=timeout)
        chg_atual = (await chg_locator.input_value()).strip()
        if chg_atual and chg_atual != chg_number:
            raise ValueError(f"Change '{chg_number}' não encontrada ou encerrada (encontrado: '{chg_atual}').")

        return scope

    async def _resolver_change_com_fallback(
        self, page: Page, chg_number: str, titulo: str, corpo: str
    ) -> Tuple[Union[Page, FrameLocator], str, Optional[str]]:
        """
        Tenta abrir a Change 'chg_number'. Se falhar (não encontrada/encerrada/
        timeout do formulário), tenta 2 fallbacks NESTA ORDEM antes de desistir:
          1. CHG citada no próprio TÍTULO da task (já embutida pelo chamador -
             ver 'create_ctask.routes.processar_aprovados') - cobre o caso do
             'chg_number' do banco estar desatualizado mas o título ainda ter
             o valor correto no momento em que a task foi montada.
          2. Busca AO VIVO no Outlook pela Change do DIA VIGENTE - mesmo
             método do botão "Puxar Change" da tela Send dml (ver
             'dml_change_finder.buscar_change_do_dia'), selecionando o
             ambiente (EBAO/PORTAL) a partir do texto citado no título/corpo
             do e-mail de aprovação.
        Devolve (scope, chg_usado, aviso_ou_None). Relança a exceção da
        PRIMEIRA tentativa se todos os fallbacks também falharem (mensagem
        mais direta do que a do último fallback, que tende a ser genérica).
        """
        tentativas = [chg_number]

        match_titulo = CHG_REGEX.search(titulo or "")
        if match_titulo and match_titulo.group(0).upper() not in tentativas:
            tentativas.append(match_titulo.group(0).upper())

        erro_original: Optional[Exception] = None
        for candidato in tentativas:
            try:
                scope = await self._abrir_change_no_formulario(page, candidato)
                aviso = None
                if candidato != chg_number:
                    aviso = f"CHG '{chg_number}' não encontrada - CTASK criada em '{candidato}' (extraída do título da task)."
                    logger.warning(f"⚠️ [CtaskCreationService] {aviso}")
                return scope, candidato, aviso
            except Exception as e:
                erro_original = erro_original or e
                logger.warning(f"⚠️ [CtaskCreationService] Falha ao abrir Change '{candidato}': {e}")

        # Fallback final: redescobre a Change do dia vigente via Outlook, pelo
        # ambiente (EBAO/PORTAL) citado no título/corpo do e-mail de aprovação.
        texto_busca = f"{titulo or ''} {corpo or ''}".upper()
        ambiente_detectado = next((amb for amb in APLICACOES_RECONHECIDAS if amb in texto_busca), None)
        if ambiente_detectado:
            sucesso, chg_outlook, msg = buscar_change_do_dia(ambiente_detectado)
            if not sucesso:
                logger.warning(f"⚠️ [CtaskCreationService] Busca da Change do dia vigente ({ambiente_detectado}) via Outlook sem resultado: {msg}")
            elif chg_outlook not in tentativas:
                try:
                    scope = await self._abrir_change_no_formulario(page, chg_outlook)
                    aviso = (
                        f"CHG '{chg_number}' não encontrada - CTASK criada em '{chg_outlook}' "
                        f"(Change do dia vigente para {ambiente_detectado}, redescoberta via Outlook)."
                    )
                    logger.warning(f"⚠️ [CtaskCreationService] {aviso}")
                    return scope, chg_outlook, aviso
                except Exception as e:
                    logger.warning(f"⚠️ [CtaskCreationService] Falha ao abrir Change '{chg_outlook}' (Outlook/{ambiente_detectado}): {e}")

        raise erro_original or RuntimeError(f"Falha desconhecida ao abrir a Change '{chg_number}'.")

    async def criar_ctask(
        self,
        page: Page,
        chg_number: str,
        titulo: str,
        corpo: str,
        assignment_group: str,
        assigned_to: str,
        evidence_files: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Abre a Change 'chg_number' (com fallback - ver
        '_resolver_change_com_fallback' - para quando ela não é mais
        encontrada), clica em 'New' na related-list de Change Tasks, preenche
        Grupo de Atribuição/Descrição curta/Descrição/Assigned to, anexa
        evidências (se houver) e salva. Devolve {'status': 'success', 'chg':
        <CHG realmente usada>, 'sctask': <número da ctask criada>} ou
        {'status': 'error', 'error': ...} - nunca lança exceção.
        """
        resultado: Dict[str, Any] = {"chg": chg_number, "status": "success", "sctask": None, "error": None}

        try:
            scope, chg_usado, aviso = await self._resolver_change_com_fallback(page, chg_number, titulo, corpo)
            resultado["chg"] = chg_usado
            if aviso:
                resultado["aviso"] = aviso

            await self.click_element(scope, "change_task_new_button")
            await self.wait_for_element(scope, "change_task_number_readonly", timeout=20000)

            await self.fill_reference_field(scope, "change_task_assignment_group", assignment_group)
            await self.fill_input(scope, "change_task_short_description", titulo)
            await self.fill_input(scope, "change_task_description", corpo)
            if assigned_to:
                await self.fill_reference_field(scope, "change_task_assigned_to", assigned_to)

            # Anexa todos os arquivos presentes em path_temp (scripts .sql e e-mail .msg de aprovação)
            from tools.temp_storage import create_path_temp
            temp_dir = create_path_temp()
            arquivos_para_anexar = []

            if os.path.exists(temp_dir):
                for f in os.listdir(temp_dir):
                    caminho = os.path.join(temp_dir, f)
                    if os.path.isfile(caminho) and not f.startswith('.'):
                        arquivos_para_anexar.append(caminho)

            for ef in (evidence_files or []):
                if ef and os.path.isfile(ef) and ef not in arquivos_para_anexar:
                    arquivos_para_anexar.append(ef)

            logger.info(f"📎 [CtaskCreationService] Total de {len(arquivos_para_anexar)} arquivo(s) para anexar na CTASK.")

            for file_path in arquivos_para_anexar:
                try:
                    att_btn = scope.locator(self.get_selector("attachment_button")).first
                    if await att_btn.count() > 0:
                        await att_btn.click()
                        await page.wait_for_timeout(500)
                    input_file = scope.locator(self.get_selector("attach_file_input")).first
                    if await input_file.count() > 0:
                        await input_file.set_input_files(file_path)
                        logger.info(f"📎 [CtaskCreationService] Arquivo anexado: {os.path.basename(file_path)}")
                        await page.wait_for_timeout(1500)
                except Exception as e_att:
                    logger.warning(f"⚠️ [CtaskCreationService] Falha ao anexar '{file_path}': {e_att}")

            await self.click_element(scope, "update_stay_button")
            await page.wait_for_timeout(2000)

            ctask_locator = await self.wait_for_element(scope, "change_task_number_readonly", timeout=20000)
            resultado["sctask"] = (await ctask_locator.input_value()).strip()

            logger.info(f"✅ [CtaskCreationService] CTASK {resultado['sctask']} criada na Change {chg_usado}.")

        except Exception as e:
            logger.error(f"❌ [CtaskCreationService] Erro ao criar CTASK na Change {chg_number}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

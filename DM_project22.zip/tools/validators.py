"""
================================================================================
VALIDADORES DE DADOS CADASTRAIS (E-mail, Nome completo, CPF, CNPJ, SUSEP)
================================================================================
Funções puras e reutilizáveis por qualquer tela que precise validar dados de
cadastro de usuário (planilha, texto de RITM do ServiceNow, formulário, etc.).

REGRA DE NEGÓCIO (confirmada pelo usuário do sistema):
- email, nome completo (2+ palavras) e CPF válido são SEMPRE obrigatórios.
- CNPJ e SUSEP: pelo menos UM dos dois deve estar preenchido (nunca os dois
  obrigatórios ao mesmo tempo). Se um estiver faltando, cabe à consulta ao
  banco (ver tools/database.py) localizar e preencher o outro.
"""

import re
import unicodedata
from typing import Any, Dict, List

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# Mesmo padrão de extração de e-mails embutidos em texto livre usado em
# 'reset_senha_mfa_usuario.txt' (fallback quando a RITM não tem planilha
# anexada - os e-mails a resetar vêm digitados na descrição do chamado).
EMAIL_EM_TEXTO_REGEX = re.compile(r"[\w\.-]+(?<=\w)\.?\w+@[a-zA-Z0-9\.-]+\.[a-zA-Z]{2,}")


def extrair_emails_de_texto(texto: Any) -> List[str]:
    """Extrai e deduplica todos os e-mails encontrados em um texto livre (ex: descrição de RITM)."""
    if not texto:
        return []
    encontrados = EMAIL_EM_TEXTO_REGEX.findall(str(texto))
    vistos: List[str] = []
    for email in encontrados:
        email_normalizado = email.strip().lower()
        if email_normalizado not in vistos:
            vistos.append(email_normalizado)
    return vistos


def normalizar_texto(texto: Any) -> str:
    """Remove acentos, espaços extras e padroniza para comparação (não para exibição)."""
    if texto in (None, ""):
        return ""
    texto = unicodedata.normalize("NFD", str(texto)).encode("ascii", "ignore").decode("utf-8")
    return re.sub(r"\s+", " ", texto).strip().upper()


def validar_email(email: Any) -> bool:
    """Valida formato básico de e-mail (usuario@dominio.tld)."""
    if not email:
        return False
    return bool(EMAIL_REGEX.match(str(email).strip()))


def validar_nome_completo(nome: Any) -> bool:
    """Exige pelo menos 2 palavras (nome + sobrenome), cada uma com letras."""
    if not nome:
        return False
    palavras = [p for p in str(nome).strip().split() if re.search(r"[A-Za-zÀ-ÿ]", p)]
    return len(palavras) >= 2


def validar_cpf(cpf: Any) -> bool:
    """Valida CPF pelos dígitos verificadores (não apenas quantidade de dígitos)."""
    cpf = re.sub(r"\D", "", str(cpf or ""))
    if len(cpf) != 11 or cpf == cpf[0] * 11:
        return False

    def _digito_verificador(base: str, peso_inicial: int) -> int:
        soma = sum(int(d) * peso for d, peso in zip(base, range(peso_inicial, 1, -1)))
        resto = (soma * 10) % 11
        return resto if resto < 10 else 0

    dv1 = _digito_verificador(cpf[:9], 10)
    dv2 = _digito_verificador(cpf[:9] + str(dv1), 11)
    return cpf[-2:] == f"{dv1}{dv2}"


def validar_cnpj(cnpj: Any) -> bool:
    """Valida CNPJ pelos dígitos verificadores. Usado apenas quando o CNPJ está preenchido."""
    cnpj = re.sub(r"\D", "", str(cnpj or ""))
    if len(cnpj) != 14 or cnpj == cnpj[0] * 14:
        return False

    def _digito_verificador(base: str, pesos: List[int]) -> int:
        soma = sum(int(d) * p for d, p in zip(base, pesos))
        resto = soma % 11
        return 0 if resto < 2 else 11 - resto

    pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    pesos2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    dv1 = _digito_verificador(cnpj[:12], pesos1)
    dv2 = _digito_verificador(cnpj[:12] + str(dv1), pesos2)
    return cnpj[-2:] == f"{dv1}{dv2}"


def validar_susep_formato(susep: Any) -> bool:
    """
    A SUSEP não tem dígito verificador público conhecido: valida apenas que é
    numérico e não é o placeholder '000000000' usado no fluxo de Assessoria.
    """
    susep = re.sub(r"\D", "", str(susep or ""))
    if not susep:
        return False
    return susep != "0" * len(susep)


def validar_usuario_cadastro(valores: Dict[str, Any]) -> List[str]:
    """
    Valida os dados BLOQUEANTES de UM usuário (linha de planilha, texto de RITM,
    formulário, etc.) - o mínimo necessário para sequer tentar o cadastro.
    Devolve a lista de problemas encontrados (vazia = usuário apto a seguir para
    a automação). Cada item é um texto curto e legível, pronto para log/UI.

    Diferente da validação antiga (que exigia SUSEP sempre), aqui CNPJ e SUSEP são
    intercambiáveis: só bloqueia se AMBOS estiverem vazios. Formato inválido de
    CNPJ/SUSEP (quando ao menos um dos dois está presente) NÃO bloqueia aqui -
    ver 'avisos_formato_corretora()', pois a consulta ao banco (tools/database.py)
    pode corrigir/completar o dado a partir do campo que estiver correto.
    """
    problemas: List[str] = []

    email = valores.get("email_master", "")
    if not email:
        problemas.append("E-mail não informado")
    elif not validar_email(email):
        problemas.append(f"E-mail inválido: '{email}'")

    nome = valores.get("nome_completo", "")
    if not validar_nome_completo(nome):
        problemas.append("Nome completo inválido (informe nome e sobrenome)")

    cpf = valores.get("cpf", "")
    if not cpf:
        problemas.append("CPF não informado")
    elif not validar_cpf(cpf):
        problemas.append(f"CPF inválido: '{cpf}'")

    cnpj = valores.get("cnpj", "")
    susep = valores.get("susep", "")
    if not cnpj and not susep:
        problemas.append("Nem CNPJ nem SUSEP foram informados (é obrigatório preencher ao menos um dos dois)")

    if not valores.get("razao_social"):
        problemas.append("Razão social não informada")

    return problemas


def avisos_formato_corretora(valores: Dict[str, Any]) -> List[str]:
    """
    Avisos NÃO bloqueantes sobre CNPJ/SUSEP com formato suspeito. Não impedem a
    linha de seguir para a automação - servem apenas para alimentar as
    'pendências' do usuário, reforçando que a consulta ao banco deve confirmar
    (ou corrigir) esse dado antes do cadastro efetivo no UPM.
    """
    avisos: List[str] = []
    cnpj = valores.get("cnpj", "")
    susep = valores.get("susep", "")

    if cnpj and not validar_cnpj(cnpj):
        avisos.append(f"CNPJ com formato inválido na planilha: '{cnpj}' (será confirmado no banco)")
    if susep and not validar_susep_formato(susep):
        avisos.append(f"SUSEP com formato inválido na planilha: '{susep}' (será confirmado no banco)")

    return avisos

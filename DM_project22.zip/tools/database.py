"""
================================================================================
CONEXÃO COM BANCOS DE DADOS CORPORATIVOS (ORACLE eBao / SQL SERVER Portal & Safra)
================================================================================
Reescrita do script de referência legado (Conect_bd_ebao, Conect_bd_Portal,
Conect_db_Safra) adaptada à arquitetura deste projeto:

1. CREDENCIAIS VIA .env: substitui a leitura fixa de 'base/doc.txt' por
   variáveis de ambiente (python-dotenv), no mesmo padrão já usado em
   'src/modules/email_report/config.py' e 'tools/upm_driver.py'.

2. NUNCA DERRUBA A AUTOMAÇÃO: o script original usava 'except: cursor = "error"'
   e deixava quem chamava descobrir o erro sozinho. Aqui toda consulta pública
   devolve um dict com 'encontrado'/'erro' - se o banco estiver fora do ar,
   a automação registra uma PENDÊNCIA e segue em frente, em vez de quebrar.

3. QUERIES PARAMETRIZADAS: o script original concatenava CNPJ/SUSEP direto na
   string SQL (f"...where cnpj_or_cpf = '{cnpj}'"), abrindo brecha de SQL
   Injection. Aqui toda consulta usa bind variables.

4. HERANÇA: 'DatabaseMixin' é a classe pensada para ser herdada por qualquer
   Service/Automation de tela que precise confirmar dados no banco (Cadastro,
   Alterar usuário, Assessoria, etc.), evitando duplicar conexão em cada tela:

        class CadastroUsuarioService(ServiceNowDriver, DatabaseMixin):
            ...
            usuario = await self.confirmar_dados_corretora_async(usuario)
"""

import asyncio
import logging
import os
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple, TYPE_CHECKING

from dotenv import load_dotenv

if TYPE_CHECKING:
    from tools.usuario import Usuario

logger = logging.getLogger("Database")

# Busca o .env a partir deste arquivo subindo os diretórios (encontra o .env
# na raiz do projeto automaticamente, sem precisar de caminho fixo).
load_dotenv()


class DatabaseConnectionError(Exception):
    """Erro ao abrir conexão com um banco de dados corporativo (Oracle/SQL Server)."""


class DatabaseQueryError(Exception):
    """Erro ao executar uma consulta em um banco já conectado."""


# ================================================================================
# CONFIGURAÇÃO (lida do .env)
# ================================================================================

@dataclass
class OracleConfig:
    user: str
    password: str
    host: str
    port: str
    service_name: str
    instant_client_dir: Optional[str] = None

    @classmethod
    def from_env(cls, prefix: str = "ORACLE") -> "OracleConfig":
        return cls(
            user=os.getenv(f"{prefix}_USER", ""),
            password=os.getenv(f"{prefix}_PASSWORD", ""),
            host=os.getenv(f"{prefix}_HOST", ""),
            port=os.getenv(f"{prefix}_PORT", "1521"),
            service_name=os.getenv(f"{prefix}_SERVICE_NAME", ""),
            instant_client_dir=os.getenv(f"{prefix}_INSTANT_CLIENT_DIR") or None,
        )

    def is_configured(self) -> bool:
        return bool(self.user and self.password and self.host and self.service_name)

    @property
    def dsn(self) -> str:
        return (
            f"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST={self.host})(PORT={self.port}))"
            f"(CONNECT_DATA=(SERVICE_NAME={self.service_name})))"
        )


@dataclass
class SqlServerConfig:
    server: str
    database: str
    trusted_connection: bool = True
    user: Optional[str] = None
    password: Optional[str] = None
    driver: str = "{SQL Server}"

    @classmethod
    def from_env(cls, prefix: str) -> "SqlServerConfig":
        trusted = os.getenv(f"{prefix}_TRUSTED_CONNECTION", "true").strip().lower() in ("1", "true", "yes", "sim")
        return cls(
            server=os.getenv(f"{prefix}_SERVER", ""),
            database=os.getenv(f"{prefix}_DATABASE", ""),
            trusted_connection=trusted,
            user=os.getenv(f"{prefix}_USER") or None,
            password=os.getenv(f"{prefix}_PASSWORD") or None,
            driver=os.getenv(f"{prefix}_DRIVER", "{SQL Server}"),
        )

    def is_configured(self) -> bool:
        if not (self.server and self.database):
            return False
        return self.trusted_connection or bool(self.user and self.password)

    @property
    def connection_string(self) -> str:
        parts = [f"Driver={self.driver}", f"Server={self.server}", f"Database={self.database}"]
        if self.trusted_connection:
            parts.append("Trusted_Connection=yes")
        else:
            parts.append(f"UID={self.user}")
            parts.append(f"PWD={self.password}")
        return ";".join(parts) + ";"


# ================================================================================
# CONEXÕES
# ================================================================================

_oracle_client_initialized = False


class OracleConnection:
    """Conexão Oracle (base eBao) - equivalente a 'Conect_bd_ebao' do script legado."""

    def __init__(self, config: Optional[OracleConfig] = None):
        self.config = config or OracleConfig.from_env()

    @staticmethod
    def _output_type_handler(cursor, name, default_type, size, precision, scale):
        import oracledb
        if default_type == oracledb.DB_TYPE_CLOB:
            return cursor.var(oracledb.DB_TYPE_LONG, arraysize=cursor.arraysize)
        if default_type == oracledb.DB_TYPE_BLOB:
            return cursor.var(oracledb.DB_TYPE_LONG_RAW, arraysize=cursor.arraysize)

    @contextmanager
    def connect(self) -> Iterator[Any]:
        global _oracle_client_initialized

        if not self.config.is_configured():
            raise DatabaseConnectionError(
                "Credenciais Oracle (eBao) ausentes no .env "
                "(ORACLE_USER / ORACLE_PASSWORD / ORACLE_HOST / ORACLE_SERVICE_NAME)."
            )
        try:
            import oracledb
        except ImportError as e:
            raise DatabaseConnectionError("Pacote 'oracledb' não instalado (pip install oracledb).") from e

        if self.config.instant_client_dir and not _oracle_client_initialized:
            try:
                oracledb.init_oracle_client(lib_dir=self.config.instant_client_dir)
            except Exception as e:
                # Se o Instant Client já tiver sido iniciado (ou o modo 'thin' bastar),
                # não interrompe a conexão por causa disso - apenas registra o aviso.
                logger.warning(f"⚠️ [OracleConnection] init_oracle_client não aplicado (seguindo em modo thin): {e}")
            finally:
                _oracle_client_initialized = True

        conn = None
        try:
            conn = oracledb.connect(user=self.config.user, password=self.config.password, dsn=self.config.dsn)
            conn.outputtypehandler = self._output_type_handler
            yield conn
        except DatabaseConnectionError:
            raise
        except Exception as e:
            raise DatabaseConnectionError(f"Falha ao conectar no Oracle (eBao) [{self.config.host}]: {e}") from e
        finally:
            if conn is not None:
                conn.close()

    def fetchone(self, query: str, params: Optional[Sequence[Any]] = None) -> Optional[Tuple[Any, ...]]:
        with self.connect() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(query, params or [])
                return cursor.fetchone()
            except Exception as e:
                raise DatabaseQueryError(f"Falha ao consultar Oracle (eBao): {e}") from e
            finally:
                cursor.close()

    def fetchall(self, query: str, params: Optional[Sequence[Any]] = None) -> List[Tuple[Any, ...]]:
        with self.connect() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(query, params or [])
                return cursor.fetchall()
            except Exception as e:
                raise DatabaseQueryError(f"Falha ao consultar Oracle (eBao): {e}") from e
            finally:
                cursor.close()


class SqlServerConnection:
    """Conexão SQL Server genérica via pyodbc - usada tanto para 'Portal' quanto 'Safra'."""

    def __init__(self, config: SqlServerConfig):
        self.config = config

    @contextmanager
    def connect(self) -> Iterator[Any]:
        if not self.config.is_configured():
            raise DatabaseConnectionError(
                f"Credenciais SQL Server ausentes/incompletas no .env para o banco "
                f"'{self.config.database or '<não configurado>'}'."
            )
        try:
            import pyodbc
        except ImportError as e:
            raise DatabaseConnectionError("Pacote 'pyodbc' não instalado (pip install pyodbc).") from e

        conn = None
        try:
            conn = pyodbc.connect(self.config.connection_string, timeout=10)
            yield conn
        except DatabaseConnectionError:
            raise
        except Exception as e:
            raise DatabaseConnectionError(f"Falha ao conectar no SQL Server [{self.config.database}]: {e}") from e
        finally:
            if conn is not None:
                conn.close()

    def fetchone(self, query: str, params: Optional[Sequence[Any]] = None) -> Optional[Tuple[Any, ...]]:
        with self.connect() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(query, params or [])
                return cursor.fetchone()
            except Exception as e:
                raise DatabaseQueryError(f"Falha ao consultar SQL Server [{self.config.database}]: {e}") from e
            finally:
                cursor.close()

    def fetchall(self, query: str, params: Optional[Sequence[Any]] = None) -> List[Tuple[Any, ...]]:
        with self.connect() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(query, params or [])
                return cursor.fetchall()
            except Exception as e:
                raise DatabaseQueryError(f"Falha ao consultar SQL Server [{self.config.database}]: {e}") from e
            finally:
                cursor.close()


# ================================================================================
# MIXIN DE HERANÇA - usado pelas telas/Services que precisam confirmar dados
# ================================================================================

class DatabaseMixin:
    """
    Mixin de acesso a banco de dados corporativo (Oracle eBao + SQL Server
    Portal/Safra), pensado para ser herdado (não instanciado sozinho) por
    Services/Automations que precisem CONFIRMAR dados de corretora - razão
    social, CNPJ, SUSEP - direto no banco, em vez de confiar cegamente no que
    veio da planilha/ServiceNow (onde é comum a razão social vir abreviada).

    Uso típico:
        class CadastroUsuarioService(ServiceNowDriver, DatabaseMixin):
            ...
            usuario = await self.confirmar_dados_corretora_async(usuario)

    As conexões são abertas SOB DEMANDA (uma por consulta) e fechadas em
    seguida - não há pool/conexão persistente, pelo baixo volume de consultas
    deste tipo de automação (uma consulta por usuário cadastrado).
    """

    _ebao_connection: Optional[OracleConnection] = None
    _portal_connection: Optional[SqlServerConnection] = None
    _safra_connection: Optional[SqlServerConnection] = None

    @property
    def ebao_db(self) -> OracleConnection:
        if self._ebao_connection is None:
            self._ebao_connection = OracleConnection()
        return self._ebao_connection

    @property
    def portal_db(self) -> SqlServerConnection:
        if self._portal_connection is None:
            self._portal_connection = SqlServerConnection(SqlServerConfig.from_env("PORTAL_SQL"))
        return self._portal_connection

    @property
    def safra_db(self) -> SqlServerConnection:
        if self._safra_connection is None:
            self._safra_connection = SqlServerConnection(SqlServerConfig.from_env("SAFRA_SQL"))
        return self._safra_connection

    # ----------------------------------------------------------------------
    # Consultas de baixo nível (à prova de falha - nunca lançam exceção)
    # ----------------------------------------------------------------------

    def consultar_corretora_portal(self, cnpj: str = "", susep: str = "") -> Dict[str, Any]:
        """
        Consulta a corretora no banco do Portal (TB_UC_ORGANIZACAO /
        TB_UC_ORGANIZACAO_CORRETORA) por CNPJ e/ou SUSEP - é a mesma query do
        'verifyBrokerName' do script de referência, agora parametrizada e
        aceitando QUALQUER um dos dois campos (o original exigia CNPJ).

        Devolve sempre um dict com 'encontrado', 'razao_social', 'cnpj',
        'susep' e 'erro' - nunca lança exceção para quem chama.
        """
        resultado: Dict[str, Any] = {"encontrado": False, "razao_social": None, "cnpj": None, "susep": None, "erro": None}

        cnpj = (cnpj or "").strip()
        susep = (susep or "").strip()
        if not cnpj and not susep:
            resultado["erro"] = "Nem CNPJ nem SUSEP foram informados para a consulta."
            return resultado

        query = """
            SELECT o.ds_organizacao_nome, o.ds_organizacao_cpf_cnpj, oc.ds_organizacao_corretora_susep
            FROM TB_UC_ORGANIZACAO o
            INNER JOIN TB_UC_ORGANIZACAO_CORRETORA oc ON o.id_organizacao = oc.id_organizacao
            WHERE (? <> '' AND o.ds_organizacao_cpf_cnpj = ?)
               OR (? <> '' AND oc.ds_organizacao_corretora_susep = ?)
        """
        try:
            row = self.portal_db.fetchone(query, [cnpj, cnpj, susep, susep])
            if row:
                resultado.update(encontrado=True, razao_social=row[0], cnpj=row[1], susep=row[2])
            else:
                resultado["erro"] = "Corretora não localizada no banco do Portal (CNPJ/SUSEP não cadastrado)."
        except (DatabaseConnectionError, DatabaseQueryError) as e:
            logger.warning(f"⚠️ [DatabaseMixin] Consulta ao banco do Portal indisponível: {e}")
            resultado["erro"] = str(e)

        return resultado

    def consultar_agent_code_ebao(self, cnpj: str = "", susep: str = "") -> Dict[str, Any]:
        """
        Consulta o agent_code no eBao (Oracle) por CNPJ/CPF ou SUSEP - equivalente
        ao trecho inicial de 'consultar_corretora_ebao' do script de referência
        (V_AGT_AGREEMENT), com o mesmo contrato à prova de falhas.
        """
        resultado: Dict[str, Any] = {"encontrado": False, "agent_code": None, "erro": None}

        cnpj = (cnpj or "").strip()
        susep = (susep or "").strip()
        if not cnpj and not susep:
            resultado["erro"] = "Nem CNPJ nem SUSEP foram informados para a consulta."
            return resultado

        try:
            row = None
            if cnpj:
                row = self.ebao_db.fetchone(
                    "select agent_code from PRD1_GS.V_AGT_AGREEMENT where cnpj_or_cpf = :cnpj", [cnpj]
                )
            if not row and susep:
                row = self.ebao_db.fetchone(
                    "select agent_code from PRD1_GS.V_AGT_AGREEMENT where susep_code = :susep", [susep]
                )
            if row:
                resultado.update(encontrado=True, agent_code=row[0])
            else:
                resultado["erro"] = "Agent code não localizado no eBao para o CNPJ/SUSEP informado."
        except (DatabaseConnectionError, DatabaseQueryError) as e:
            logger.warning(f"⚠️ [DatabaseMixin] Consulta ao eBao indisponível: {e}")
            resultado["erro"] = str(e)

        return resultado

    def consultar_usuario_organizacao_portal(
        self, email: str, cnpj: str = "", incluir_assessoria: bool = False
    ) -> Dict[str, Any]:
        """
        Localiza o usuário pelo e-mail (TB_UC_USUARIO) e a organização de destino -
        por CNPJ informado ou, se nenhum CNPJ novo foi passado, pela organização
        ATUAL do próprio usuário. Equivalente parametrizado ao 'verifyBroker' de
        update_usuario.txt, usado pelo fluxo de 'Alterar usuário'.

        Se 'incluir_assessoria=True' e o CNPJ não for encontrado como corretora
        (TB_UC_ORGANIZACAO_CORRETORA), tenta localizá-lo como Assessoria
        (id_organizacao_tipo = 2) - mesmo fallback do script original, onde o
        SUSEP/agent_code de uma assessoria são fixados em '999999999'.

        Nunca lança exceção - devolve 'encontrado=False' e 'erro' preenchido
        quando o usuário/organização não é localizado ou o banco está indisponível.
        """
        resultado: Dict[str, Any] = {
            "encontrado": False,
            "user_id": None,
            "user_cnpj": None,
            "user_id_organizacao": None,
            "id_organizacao": None,
            "cnpj": None,
            "razao": None,
            "susep": None,
            "agent_cod_ebao": None,
            "erro": None,
        }

        email = (email or "").strip()
        if not email:
            resultado["erro"] = "E-mail não informado para a consulta."
            return resultado

        try:
            row_user = self.portal_db.fetchone(
                "SELECT id_usuario, ds_usuario_cpf_cnpj, id_organizacao FROM TB_UC_USUARIO WHERE ds_usuario_email LIKE ?",
                [f"%{email}%"],
            )
            if not row_user:
                resultado["erro"] = f"Usuário '{email}' não encontrado no banco do Portal."
                return resultado

            resultado.update(user_id=row_user[0], user_cnpj=row_user[1], user_id_organizacao=row_user[2])

            cnpj = (cnpj or "").strip()
            query_corretora = """
                SELECT o.id_organizacao, o.ds_organizacao_cpf_cnpj, o.ds_organizacao_nome,
                       oc.ds_organizacao_corretora_susep, o.int_agent_cod_ebao
                FROM TB_UC_ORGANIZACAO o
                INNER JOIN TB_UC_ORGANIZACAO_CORRETORA oc ON o.id_organizacao = oc.id_organizacao
                WHERE o.id_organizacao = ?
            """
            if cnpj:
                row_org = self.portal_db.fetchone(
                    query_corretora.replace("WHERE o.id_organizacao = ?", "WHERE o.ds_organizacao_cpf_cnpj = ?"),
                    [cnpj],
                )
            else:
                row_org = self.portal_db.fetchone(query_corretora, [resultado["user_id_organizacao"]])

            if not row_org and cnpj and incluir_assessoria:
                row_assessoria = self.portal_db.fetchone(
                    """
                    SELECT id_organizacao, ds_organizacao_cpf_cnpj, ds_organizacao_razao_social
                    FROM TB_UC_ORGANIZACAO
                    WHERE ds_organizacao_cpf_cnpj = ? AND id_organizacao_tipo = 2
                    """,
                    [cnpj],
                )
                if row_assessoria:
                    resultado.update(
                        encontrado=True,
                        id_organizacao=row_assessoria[0],
                        cnpj=row_assessoria[1],
                        razao=row_assessoria[2],
                        susep="999999999",
                        agent_cod_ebao="999999999",
                    )
                    return resultado

            if row_org:
                resultado.update(
                    encontrado=True,
                    id_organizacao=row_org[0],
                    cnpj=row_org[1],
                    razao=row_org[2],
                    susep=row_org[3],
                    agent_cod_ebao=row_org[4],
                )
            else:
                resultado["erro"] = (
                    "CNPJ informado não localizado (nem como corretora, nem como assessoria) no banco do Portal."
                    if cnpj else
                    "Organização atual do usuário não localizada no banco do Portal."
                )
        except (DatabaseConnectionError, DatabaseQueryError) as e:
            logger.warning(f"⚠️ [DatabaseMixin] Consulta usuário+organização (Portal) indisponível: {e}")
            resultado["erro"] = str(e)

        return resultado

    def consultar_dados_completos_ebao(self, agent_code: str) -> Dict[str, Any]:
        """
        PLACEHOLDER A SER PREENCHIDO: consulta os dados completos do acordo/corretora
        no eBao (nome, endereço, cidade, CEP, estado, agreement_code) usados para
        CRIAR AUTOMATICAMENTE uma corretora no UPM quando ela não é localizada -
        branch "Adicionar Organização para o usuário" de cadastro_usuario.txt.

        O script legado monta essa consulta lendo um arquivo texto solto
        ('src/documents/susep.txt', não presente neste projeto) e lê o resultado
        por POSIÇÃO de coluna: data[2]=nome_organizacao, data[6]=email_contato_master,
        data[7]=cep, data[8]=uf, data[9]=cidade, data[11]/data[12]=endereço,
        data[13]=complemento, data[14]=telefone_contato, data[19]=agent_code,
        data[20]=agreement_code, data[24]=cnpj. Os campos 'telefone'/
        'email_contato_master' abaixo só são usados por
        'tools.sql_cadastro_builder.gerar_sql_cadastro_corretora' (script SQL
        manual de corretora) - não pela criação automática no UPM.

        Para ativar: cole a query real em QUERY_AGREEMENT_COMPLETO (mantendo um
        bind ':agent_code' e a MESMA ordem de colunas usada abaixo, ou ajuste os
        índices do SELECT no dict de retorno). Toda a orquestração ao redor deste
        método (criação da corretora no UPM, fallback de script SQL manual) já
        está pronta em 'criar_organizacao_a_partir_do_ebao' - nada mais precisa
        mudar quando a query for preenchida.
        """
        resultado: Dict[str, Any] = {
            "encontrado": False,
            "nome_organizacao": None,
            "cep": None,
            "estado": None,
            "cidade": None,
            "endereco_1": None,
            "endereco_2": None,
            "agent_code": None,
            "agreement_code": None,
            "cnpj": None,
            "telefone": None,
            "email_contato_master": None,
            "erro": None,
        }

        agent_code = (agent_code or "").strip()
        if not agent_code:
            resultado["erro"] = "Agent code não informado para a consulta."
            return resultado

        QUERY_AGREEMENT_COMPLETO: Optional[str] = None  # <- cole aqui a query real (bind ':agent_code')

        if not QUERY_AGREEMENT_COMPLETO:
            resultado["erro"] = (
                "Query completa do eBao (equivalente ao antigo 'src/documents/susep.txt') ainda não "
                "configurada em tools/database.py::consultar_dados_completos_ebao(). Criação automática "
                "de corretora indisponível até a query ser preenchida."
            )
            return resultado

        try:
            row = self.ebao_db.fetchone(QUERY_AGREEMENT_COMPLETO, [agent_code])
            if not row:
                resultado["erro"] = f"Acordo não localizado no eBao para agent_code='{agent_code}'."
                return resultado

            resultado.update(
                encontrado=True,
                nome_organizacao=row[2],
                email_contato_master=row[6],
                cep=row[7],
                estado=row[8],
                cidade=row[9],
                endereco_1=f"{row[11]} {row[12]}".strip(),
                endereco_2=row[13],
                telefone=str(row[14] or "").replace(",", ""),
                agent_code=row[19],
                agreement_code=row[20],
                cnpj=row[24],
            )
        except (DatabaseConnectionError, DatabaseQueryError) as e:
            logger.warning(f"⚠️ [DatabaseMixin] Consulta de dados completos ao eBao indisponível: {e}")
            resultado["erro"] = str(e)

        return resultado

    # ----------------------------------------------------------------------
    # Confirmação de alto nível - usada pelos Services de cadastro/alteração
    # ----------------------------------------------------------------------

    def confirmar_dados_corretora(self, usuario: "Usuario") -> "Usuario":
        """
        Garante que razão social, CNPJ e SUSEP do usuário estejam de acordo com
        o cadastro oficial da corretora no banco do Portal - corrige razão
        social abreviada/digitada errado na planilha e PREENCHE automaticamente
        o campo que estiver faltando (CNPJ ou SUSEP) a partir do outro.

        Contrato: NUNCA lança exceção e NUNCA descarta o usuário. Se o banco
        estiver indisponível ou a corretora não for encontrada, registra uma
        pendência em 'usuario.pendencias' (para revisão manual/log) e devolve
        o usuário com os dados originais da planilha - a automação segue
        normalmente em vez de travar por causa de uma instabilidade de banco.
        """
        from tools.validators import normalizar_texto

        resultado = self.consultar_corretora_portal(cnpj=usuario.cnpj, susep=usuario.susep)

        if resultado["encontrado"]:
            razao_banco = resultado["razao_social"]
            if razao_banco and normalizar_texto(usuario.razao_social) != normalizar_texto(razao_banco):
                logger.info(
                    f"ℹ️ [DatabaseMixin] Razão social divergente para '{usuario.email_master}': "
                    f"planilha='{usuario.razao_social}' -> banco='{razao_banco}' (corrigido)."
                )
            usuario.razao_social = razao_banco or usuario.razao_social
            usuario.cnpj = resultado["cnpj"] or usuario.cnpj
            usuario.susep = resultado["susep"] or usuario.susep
        else:
            motivo = resultado["erro"] or "Corretora não encontrada no banco do Portal."
            usuario.pendencias.append(f"Corretora não confirmada no banco: {motivo}")
            logger.warning(
                f"⚠️ [DatabaseMixin] Não foi possível confirmar a corretora de '{usuario.email_master}' "
                f"(cnpj='{usuario.cnpj}', susep='{usuario.susep}'): {motivo}"
            )

        return usuario

    async def confirmar_dados_corretora_async(self, usuario: "Usuario") -> "Usuario":
        """
        Versão assíncrona de 'confirmar_dados_corretora' - roda a consulta
        bloqueante (pyodbc/oracledb) numa thread separada via 'asyncio.to_thread'
        para NÃO travar o event loop do Playwright enquanto outras páginas/
        abas concorrentes estão sendo processadas (ver run_concurrent_tasks em
        BaseAutomation). Use esta versão dentro de qualquer método 'async def'.
        """
        return await asyncio.to_thread(self.confirmar_dados_corretora, usuario)

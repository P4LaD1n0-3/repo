"""
================================================================================
CLASSE-BASE COMUM: LAÇO DE EXECUÇÃO EM LOTE (TODOS OS SERVIÇOS DO PORTAL TASK)
================================================================================
Antes desta classe, os 7 serviços de tela de 'src/modules/portal_task/' tinham
cada um sua PRÓPRIA cópia (idêntica) do laço de execução em lote com Semáforo.
'ServiceNowBatchService' concentra essa duplicação em UM SÓ lugar por herança:
qualquer serviço que só precisa varrer o ServiceNow (sem interagir com o UPM)
herda diretamente daqui; quem também precisa do UPM/banco herda de
'PortalTaskUpmService' (tools/portal_task_base_service.py), que estende esta
classe.
"""

import logging
from typing import Any, Dict, List, Optional

from playwright.async_api import BrowserContext, Page

from tools.servicenow_driver import ServiceNowDriver

logger = logging.getLogger("ServiceNowBatchService")


class ServiceNowBatchService(ServiceNowDriver):
    """
    Classe-base para qualquer serviço de tela do Portal Task. Subclasses só
    precisam implementar 'executar_individual()' (fluxo de 1 URL) - o laço de
    lote com Semáforo ('executar_lote_concorrente') já vem pronto por herança.
    """

    async def executar_individual(
        self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Processa a automação em 1 URL do ServiceNow. Deve ser sobrescrito pela subclasse."""
        raise NotImplementedError(
            f"{self.__class__.__name__} deve implementar 'executar_individual()'."
        )

    async def executar_lote_concorrente(
        self,
        context: BrowserContext,
        urls: List[str],
        max_concurrency: int = 3,
        dados_formulario: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Laço padrão de execução em lote com Semáforo, compartilhado por TODOS
        os serviços que herdam desta classe (diretamente ou via
        'PortalTaskUpmService') - elimina a cópia idêntica deste método que
        existia em cada um dos 7 arquivos de serviço.
        """
        logger.info(
            f"🚀 [{self.__class__.__name__}] Processando lote de {len(urls)} URL(s) "
            f"(Semáforo={max_concurrency})..."
        )

        async def worker_task(page: Page, url: str):
            return await self.executar_individual(page, url, dados_formulario=dados_formulario)

        resultados = await self.run_concurrent_tasks(
            context=context, items=urls, task_fn=worker_task, max_concurrency=max_concurrency
        )

        logger.info(f"🏁 [{self.__class__.__name__}] Lote finalizado. Total de respostas: {len(resultados)}")
        return resultados

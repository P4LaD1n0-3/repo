"""
================================================================================
MODELO DE DADOS: CHAMADO (SCTASK / RITM) DO SERVICENOW
================================================================================
Classe base criada para armazenar o resultado da varredura de chamados da fila
(SCTASK, RITM, Requester e Assignment group) com REUSO DE CÓDIGO POR HERANÇA:
qualquer serviço do Portal Task (Cadastro, Assessoria, Reset, Encerrar, etc.)
pode reaproveitar esta mesma estrutura e, se precisar de campos extras,
apenas ESTENDER esta classe (ver 'ChamadoCadastro' em user_cadastro_service.py)
em vez de duplicar os atributos/URLs em cada serviço.
"""

from typing import Any, Dict, List, Optional

SERVICE_NOW_BASE_URL = "https://aig.service-now.com"


class Chamado:
    """
    Representa um chamado (ticket) capturado durante a varredura da fila do ServiceNow.

    :param sctask: sys_id da SCTASK (usado para montar a URL direta sc_task.do?sys_id=).
    :param ritm: sys_id da RITM (usado para montar a URL direta sc_req_item.do?sys_id=).
    :param sctask_number: Código legível extraído via regex, ex: 'SCTASK0012345'.
    :param ritm_number: Código legível extraído via regex, ex: 'RITM0012345'.
    :param requester: Solicitante do chamado ('Requested for').
    :param assignment_group: Grupo de atribuição do chamado.
    """

    def __init__(
        self,
        sctask: Optional[str] = None,
        ritm: Optional[str] = None,
        sctask_number: Optional[str] = None,
        ritm_number: Optional[str] = None,
        requester: Optional[str] = None,
        assignment_group: Optional[str] = None,
    ):
        self.sctask = sctask
        self.ritm = ritm
        self.sctask_number = sctask_number
        self.ritm_number = ritm_number
        self.requester = requester
        self.assignment_group = assignment_group
        self.anexos: List[str] = []
        self.texto_extraido: Optional[str] = None

    @property
    def chave(self) -> tuple:
        """Chave única do chamado usada na varredura para NÃO repetir dados já capturados."""
        return (self.sctask_number or self.sctask, self.ritm_number or self.ritm)

    @property
    def sctask_url(self) -> Optional[str]:
        if not self.sctask:
            return None
        return f"{SERVICE_NOW_BASE_URL}/sc_task.do?sys_id={self.sctask}"

    @property
    def ritm_url(self) -> Optional[str]:
        """Link de acesso direto à RITM: https://aig.service-now.com/sc_req_item.do?sys_id=<ritm>"""
        if not self.ritm:
            return None
        return f"{SERVICE_NOW_BASE_URL}/sc_req_item.do?sys_id={self.ritm}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sctask": self.sctask_number or self.sctask,
            "ritm": self.ritm_number or self.ritm,
            "requester": self.requester,
            "assignment_group": self.assignment_group,
            "ritm_url": self.ritm_url,
            "anexos": self.anexos,
            "texto_extraido": self.texto_extraido,
        }

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} sctask={self.sctask_number or self.sctask} ritm={self.ritm_number or self.ritm}>"

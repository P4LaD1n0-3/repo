"""
================================================================================
MODELO DE DADOS: USUÁRIO LIDO DA PLANILHA DE CADASTRO (.xlsx)
================================================================================
Espelha a classe 'Usuario' do arquivo de referência 'cadastro_usuario.txt',
reaproveitada por herança/composição pelos serviços que processam usuários
lidos de planilha (ex: ChamadoCadastro em user_cadastro_service.py).
"""

from typing import Any, Dict, List, Optional


class Usuario:
    """
    Representa uma linha válida da planilha de cadastro, já limpa/normalizada.

    :param linha: Número da linha de origem na planilha (rastreabilidade/auditoria).
    :param senha: Preenchida somente DEPOIS do reset de senha no UPM (coluna de saída).
    :param retorno: Mensagem de retorno do cadastro/reset no UPM.
    :param pendencias: Avisos não bloqueantes (ex: CNPJ/SUSEP não confirmado no banco,
        razão social corrigida) - preenchidas por 'tools.database.DatabaseMixin'
        durante a confirmação dos dados da corretora. Não impedem o cadastro,
        servem para revisão manual/log caso a automação retorne erro no UPM.
    """

    def __init__(
        self,
        email_master: str,
        nome_completo: str,
        cpf: str,
        celular: Optional[str],
        razao_social: str,
        cnpj: str,
        susep: str,
        senha: str = "",
        retorno: str = "",
        linha: Optional[int] = None,
        pendencias: Optional[List[str]] = None,
    ):
        self.email_master = email_master
        self.nome_completo = nome_completo
        self.cpf = cpf
        self.celular = celular
        self.razao_social = razao_social
        self.cnpj = cnpj
        self.susep = susep
        self.senha = senha
        self.retorno = retorno
        self.linha = linha
        self.pendencias: List[str] = pendencias if pendencias is not None else []

    def to_dict(self) -> Dict[str, Any]:
        return {
            "email_master": self.email_master,
            "nome_completo": self.nome_completo,
            "cpf": self.cpf,
            "celular": self.celular,
            "razao_social": self.razao_social,
            "cnpj": self.cnpj,
            "susep": self.susep,
            "senha": self.senha,
            "retorno": self.retorno,
            "linha": self.linha,
            "pendencias": self.pendencias,
        }

    def __repr__(self) -> str:
        return f"<Usuario linha={self.linha} email={self.email_master}>"

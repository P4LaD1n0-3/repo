"""
================================================================================
GERADOR DE SCRIPT SQL MANUAL: ALTERAÇÃO DE USUÁRIO
================================================================================
PORT LITERAL do bloco de geração de SQL de 'update_user()' em
update_usuario.txt (mesmas tabelas/colunas/formatação) - gera o texto de um
script T-SQL para REVISÃO/EXECUÇÃO MANUAL por um DBA (não é executado
automaticamente contra nenhum banco), com o UPDATE em TB_UC_USUARIO e,
quando um produto novo é informado, o bloco de DELETE+INSERT em
TB_UC_USUARIO_PRODUTO.
"""

import logging
import os
from typing import Any, Dict

from tools.temp_storage import create_path_temp

logger = logging.getLogger("SqlScriptBuilder")


def gerar_sql_update_usuario(
    ritm: str,
    email_de: str,
    email_para: str,
    nome_para: str,
    broker: Dict[str, Any],
    produto_id_para: str = "",
) -> str:
    """
    :param broker: dict devolvido por
        'DatabaseMixin.consultar_usuario_organizacao_portal' - usa as chaves
        'user_id', 'user_cnpj', 'id_organizacao', 'cnpj' e 'agent_cod_ebao'.

    Réplica fiel da lógica original: só inclui 'id_organizacao'/'ds_usuario_cpf_cnpj'/
    'int_agent_cod_ebao' no UPDATE quando o CNPJ de destino é DIFERENTE do CNPJ
    atual do usuário. Se um produto novo foi informado e o UPDATE de usuário
    não tiver NENHUMA alteração além do e-mail (um no-op), o UPDATE é descartado
    e só o bloco de produto é gerado - mesmo comportamento do 'if len(script) == 3'
    do script original.
    """
    partes = [f"USE [PORTAL_DB]\n\n--{ritm}\nUPDATE TB_UC_USUARIO\n"]
    partes.append(f"set ds_usuario_email = '{email_para or email_de}'")

    if nome_para:
        partes.append(f",\nds_usuario_nome = '{nome_para}'")

    organizacao_mudou = broker.get("cnpj") != broker.get("user_cnpj")
    if organizacao_mudou:
        partes.append(f",\nid_organizacao = {broker.get('id_organizacao')},\n")
        partes.append(f"ds_usuario_cpf_cnpj = '{broker.get('cnpj')}',\n")
        partes.append(f"int_agent_cod_ebao = {broker.get('agent_cod_ebao')}")

    partes.append(f"\nwhere id_usuario = {broker.get('user_id')}\n")

    if produto_id_para:
        if len(partes) == 3:
            # Nada além do e-mail (idêntico ao original) mudou no usuário -
            # descarta o UPDATE (seria um no-op) e mantém só o bloco de produto.
            partes = []

        query_produto = f"""USE [PORTAL_DB]

-- {ritm}
-- DELETE PRODUTO PARA UM USUARIO
DELETE FROM TB_UC_USUARIO_PRODUTO where id_usuario = {broker.get('user_id')}

-- INSERIR PRODUTO PARA UM USUARIO
Insert into [PORTAL_DB].[dbo].[TB_UC_USUARIO_PRODUTO](
[id_usuario]
,[id_produto]
,[dt_usuario_produto_insercao]
,[dt_usuario_produto_atualizacao]
,[id_usuario_produto_usuario_insercao]
,[id_usuario_produto_usuario_atualizacao]
,[id_status_controle])
select U.[id_usuario], P.[id_produto], getdate()  d1, getdate()  d2, 1 a,1 b,1 c
from dbo.TB_UC_USUARIO U, dbo.TB_CFG_PRDT_PRODUTO P
where U.[id_usuario] IN ({broker.get('user_id')})
and P.[id_produto] in ({produto_id_para})
"""
        partes.append(query_produto)

    return "".join(partes)


def salvar_sql_alteracao_usuario(ritm: str, sql_texto: str) -> str:
    """Salva o script gerado em 'path_temp/PORTALDB_{ritm}_Update_Usuario_Master.sql' (mesmo nome de arquivo do script original) e devolve o caminho absoluto."""
    diretorio = create_path_temp()
    caminho = os.path.join(diretorio, f"PORTALDB_{ritm}_Update_Usuario_Master.sql")
    with open(caminho, "w", encoding="utf-8") as arquivo:
        arquivo.write(sql_texto)
    logger.info(f"📄 [SqlScriptBuilder] Script SQL de alteração salvo em: {caminho}")
    return caminho

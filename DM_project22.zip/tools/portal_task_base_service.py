"""
================================================================================
CLASSE-BASE COMUM: SERVIÇOS DO PORTAL TASK QUE INTERAGEM COM O UPM
================================================================================
Reúne por HERANÇA MÚLTIPLA tudo que 'Cadastro de usuário', 'Alterar usuário',
'Reset de senha' e 'Reset de MFA' têm em comum, eliminando a duplicação que
havia entre esses fluxos (nenhum deles reaproveitava UpmDriver/DatabaseMixin
por herança - só o serviço de Cadastro instanciava UpmDriver manualmente):

    ServiceNowBatchService -> laço de lote com Semáforo (ver tools/servicenow_batch_service.py).
    UpmDriver              -> login, cadastro, reset senha/mfa, corretora no UPM.
    DatabaseMixin          -> confirmação de corretora no Portal/eBao.

Serviços que NÃO precisam do UPM (Encerrar, Desabilitar, Assessoria) herdam
apenas de 'ServiceNowBatchService' diretamente, sem carregar UpmDriver/
DatabaseMixin à toa.
"""

import logging
import unicodedata
from typing import Any, Dict, Optional, TYPE_CHECKING, Union

from playwright.async_api import Page

from tools.servicenow_batch_service import ServiceNowBatchService
from tools.upm_driver import UpmDriver
from tools.database import DatabaseMixin
from tools.base_automation import SelectorManager
from tools.historico_usuarios import localizar_email_por_cpf
from tools.sql_cadastro_builder import gerar_sql_cadastro_corretora
from tools.temp_storage import PATH_TEMP

if TYPE_CHECKING:
    from tools.usuario import Usuario

logger = logging.getLogger("PortalTaskUpmService")


class PortalTaskUpmService(ServiceNowBatchService, UpmDriver, DatabaseMixin):
    """
    Classe-base para qualquer serviço de tela do Portal Task que precise
    conversar com o UPM e/ou confirmar dados no banco (Cadastro, Alterar,
    Reset de senha, Reset de MFA). Não deve ser instanciada diretamente -
    subclasses implementam 'executar_individual' (herdado de ServiceNowBatchService).
    """

    # Mensagens de retorno do UPM tratadas pela máquina de estados do cadastro
    # (mesmos textos de 'novoRegistro' em cadastro_usuario.txt).
    MSG_CADASTRO_SUCESSO = "Usuário registrado com êxito"
    MSG_CADASTRO_JA_EXISTE = "Usuário já existe no sistema"
    MSG_CPF_EXISTE_OUTRO_USUARIO = "CPF existe com o usuário diferente"
    MSG_ADICIONAR_ORGANIZACAO = "Adicionar Organização para o usuário"
    MSG_USUARIO_ATUALIZADO = "Os detalhes do usuário atualizado com sucesso!!!"
    MSG_USUARIO_INATIVO_NAO_ATUALIZA = "Usuário inativo não pode ser atualizado"

    # Palavras-chave (case-insensitive, sem acento) reconhecidas como EQUIVALENTES
    # às frases exatas do legado acima. O texto literal retornado pelo UPM varia
    # entre ambientes/atualizações do sistema (ex.: "usuário já cadastrado" já
    # observado em produção, além do "Usuário já existe no sistema" do script
    # original) - por isso o cadastro/já-existe/CPF-duplicado/organização-faltando
    # também casam por PALAVRA-CHAVE, não só pela frase exata legada. Isso evita
    # que uma pequena mudança de texto no UPM derrube o reset automático de
    # senha/MFA (a mensagem cai em "não tratada" e nada acontece).
    #
    # Propositalmente NÃO inclui a palavra solta "cadastrado" (sem qualificador):
    # frases de ERRO como "usuário não pôde ser cadastrado" também contêm esse
    # substring e seriam erroneamente tratadas como sucesso. As frases abaixo só
    # incluem combinações que indicam positivamente sucesso/já-existente.
    _PALAVRAS_CADASTRO_OK = ("registrado com exito", "cadastrado com sucesso", "ja existe", "ja cadastrado", "ja esta cadastrado")
    _PALAVRAS_CPF_EXISTENTE = ("cpf existe", "cpf ja cadastrado", "cpf ja existe", "cpf duplicado")
    _PALAVRAS_ADICIONAR_ORGANIZACAO = ("adicionar organiza",)

    @staticmethod
    def _normalizar_mensagem_upm(mensagem: str) -> str:
        """Remove acentuação e caixa para comparação por palavra-chave, tolerante a pequenas variações de texto do UPM."""
        sem_acento = unicodedata.normalize("NFD", mensagem or "").encode("ascii", "ignore").decode("utf-8")
        return sem_acento.lower().strip()

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None,
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    # ========================================================================
    # MÁQUINA DE ESTADOS DO CADASTRO (fiel ao 'novoRegistro' de cadastro_usuario.txt)
    # ========================================================================
    # Usada pelo CadastroUsuarioService logo após 'cadastrar_usuario_upm' - trata
    # os 4 cenários de retorno do UPM. Fica na classe-base (e não só no serviço
    # de Cadastro) porque combina UpmDriver + DatabaseMixin + planilha histórica,
    # e outra tela que um dia precise reaproveitar esse tratamento (ex.: um retry
    # manual de "Adicionar Organização") já a encontra pronta por herança.

    async def processar_resultado_cadastro_upm(
        self, page: Page, usuario: "Usuario", resultado_cadastro: Dict[str, Any], ritm: str = ""
    ) -> Dict[str, Any]:
        """
        Interpreta a mensagem de retorno de 'cadastrar_usuario_upm' e aplica o
        MESMO tratamento por cenário do 'novoRegistro' original:
          - Sucesso / já existe -> reset de senha (reativando a conta se preciso).
          - "CPF existe com o usuário diferente" -> reaproveita a conta antiga,
            localizada pelo CPF na planilha histórica (resolver_cpf_existente).
          - "Adicionar Organização para o usuário" -> cria a corretora a partir
            do eBao e tenta o reset de senha em seguida (criar_organizacao_a_partir_do_ebao).
          - Qualquer outra mensagem -> fica registrada em 'usuario.retorno' sem
            mais tentativas (mesmo comportamento do 'else' original).

        Nunca lança exceção - sempre atualiza 'usuario.senha'/'usuario.retorno'/
        'usuario.pendencias' e devolve um dict com o resultado do tratamento.
        """
        mensagem = (resultado_cadastro.get("mensagem") or "").strip()
        mensagem_normalizada = self._normalizar_mensagem_upm(mensagem)
        logger.info(f"📨 [{self.__class__.__name__}] Mensagem do UPM para '{usuario.email_master}': '{mensagem}'")

        # Verificação por PALAVRA-CHAVE (além da frase exata do legado) - ver
        # comentário nas constantes '_PALAVRAS_*' acima. A ordem importa: os
        # casos mais ESPECÍFICOS (CPF duplicado, organização faltando) são
        # checados antes do caso genérico de sucesso/já-cadastrado, para uma
        # mensagem como "CPF já cadastrado para outro usuário" não cair
        # incorretamente no branch de sucesso só por conter "já cadastrado".
        if mensagem == self.MSG_CPF_EXISTE_OUTRO_USUARIO or any(p in mensagem_normalizada for p in self._PALAVRAS_CPF_EXISTENTE):
            return await self.resolver_cpf_existente(page, usuario)

        if mensagem == self.MSG_ADICIONAR_ORGANIZACAO or any(p in mensagem_normalizada for p in self._PALAVRAS_ADICIONAR_ORGANIZACAO):
            return await self.criar_organizacao_a_partir_do_ebao(page, usuario, ritm=ritm)

        if mensagem in (self.MSG_CADASTRO_SUCESSO, self.MSG_CADASTRO_JA_EXISTE) or any(
            p in mensagem_normalizada for p in self._PALAVRAS_CADASTRO_OK
        ):
            return await self._finalizar_cadastro_com_reset(page, usuario)

        usuario.retorno = mensagem or "Sem retorno do UPM ao cadastrar."
        logger.warning(f"⚠️ [{self.__class__.__name__}] Mensagem do UPM não tratada para '{usuario.email_master}': '{mensagem}'")
        return {"status": "unhandled", "mensagem": mensagem}

    @staticmethod
    def _conta_parece_inativa(mensagem: Optional[str]) -> bool:
        mensagem = (mensagem or "").lower()
        return "não está ativo" in mensagem or "nao esta ativo" in mensagem or "inativ" in mensagem

    async def _finalizar_cadastro_com_reset(self, page: Page, usuario: "Usuario") -> Dict[str, Any]:
        """
        Reseta a senha do usuário recém-cadastrado (ou já existente). Se a busca
        indicar que a conta está inativa, reativa (definir_status_conta_upm) e
        tenta o reset novamente - mesmo comportamento do bloco
        `if result == "O usuário não está ativo": ... account_status = A ...`
        de cadastro_usuario.txt.
        """
        resultado_reset = await self.resetar_senha_mfa_upm(page=page, email=usuario.email_master, type_reset="reset")

        if self._conta_parece_inativa(resultado_reset.get("mensagem_busca")):
            logger.info(f"ℹ️ [{self.__class__.__name__}] Conta de '{usuario.email_master}' inativa - reativando antes de repetir o reset.")
            busca = await self.buscar_e_selecionar_usuario_upm(page, usuario.email_master)
            if busca["encontrado"]:
                await self.definir_status_conta_upm(page, "A")
                resultado_reset = await self.resetar_senha_mfa_upm(page=page, email=usuario.email_master, type_reset="reset")
            else:
                usuario.pendencias.append(f"Conta inativa e não foi possível reativar: {busca['mensagem']}")

        usuario.senha = resultado_reset.get("senha_gerada") or ""
        usuario.retorno = "Cadastro efetuado" if resultado_reset.get("status") == "success" else (resultado_reset.get("error") or "Falha ao gerar senha")
        return resultado_reset

    async def resolver_cpf_existente(self, page: Page, usuario: "Usuario") -> Dict[str, Any]:
        """
        Trata o retorno "CPF existe com o usuário diferente": localiza o e-mail
        ANTIGO associado a este CPF na planilha histórica (tools/historico_usuarios.py,
        equivalente ao 'src/documents' do script legado), inativa a conta antiga,
        atualiza-a com os dados NOVOS (nome/e-mail/organização/SUSEP) e reativa -
        mesmo fluxo do branch `elif entry_msg == "CPF existe com o usuário diferente"`
        de cadastro_usuario.txt.
        """
        logger.info(f"🪪 [{self.__class__.__name__}] CPF de '{usuario.email_master}' já pertence a outro usuário - buscando e-mail antigo...")

        email_antigo = localizar_email_por_cpf(usuario.cpf)
        if not email_antigo:
            usuario.retorno = self.MSG_CPF_EXISTE_OUTRO_USUARIO
            usuario.pendencias.append(
                "CPF já cadastrado para outro usuário e o e-mail antigo não foi localizado na planilha histórica "
                "(HISTORICO_USUARIOS_DIR) - reaproveitamento da conta precisa ser feito manualmente."
            )
            return {"status": "error", "mensagem": self.MSG_CPF_EXISTE_OUTRO_USUARIO}

        logger.info(f"✅ [{self.__class__.__name__}] E-mail antigo localizado: '{email_antigo}'. Inativando conta antiga...")

        busca = await self.buscar_e_selecionar_usuario_upm(page, email_antigo)
        if not busca["encontrado"]:
            usuario.retorno = f"E-mail antigo '{email_antigo}' não encontrado no UPM."
            usuario.pendencias.append(usuario.retorno)
            return {"status": "error", "mensagem": busca["mensagem"]}

        inativacao = await self.definir_status_conta_upm(page, "I")
        recadastrar = (inativacao.get("mensagem") or "").strip()

        if recadastrar not in (self.MSG_USUARIO_ATUALIZADO, self.MSG_USUARIO_INATIVO_NAO_ATUALIZA) and inativacao.get("status") != "success":
            usuario.senha = recadastrar or "Falha ao inativar conta antiga"
            usuario.retorno = usuario.senha
            return inativacao

        # Reaproveita a conta antiga com os dados NOVOS (nome, e-mail, organização, SUSEP)
        await self.preencher_dados_pessoais_upm(page, email=usuario.email_master, nome_completo=usuario.nome_completo)
        await self.vincular_organizacao_susep_upm(page, razao_social=usuario.razao_social, susep=usuario.susep)
        await self.definir_status_conta_upm(page, "A")

        resultado_reset = await self.resetar_senha_mfa_upm(page=page, email=usuario.email_master, type_reset="reset")
        usuario.senha = resultado_reset.get("senha_gerada") or ""
        usuario.retorno = (
            f"Conta reaproveitada do e-mail antigo '{email_antigo}'"
            if resultado_reset.get("status") == "success"
            else (resultado_reset.get("error") or "Falha ao resetar senha após reaproveitar a conta antiga")
        )
        return resultado_reset

    async def criar_organizacao_a_partir_do_ebao(self, page: Page, usuario: "Usuario", ritm: str = "") -> Dict[str, Any]:
        """
        Trata o retorno "Adicionar Organização para o usuário": consulta o eBao
        (Oracle) pelo CNPJ/SUSEP para obter o agent_code e os dados completos do
        acordo (nome, endereço, cidade, CEP, estado), cadastra a corretora no UPM
        e, na sequência, tenta o reset de senha do usuário diretamente - mesmo
        fluxo do branch `elif entry_msg == "Adicionar Organização para o usuário"`
        de cadastro_usuario.txt (a criação da organização não repete o cadastro do
        usuário: no script original, o usuário já existe nesse ponto, só falta a
        organização vinculada).

        Se a corretora criada no UPM ainda não estiver sincronizada no banco do
        Portal (consultar_corretora_portal não encontra), gera o script SQL manual
        para o DBA (porta de 'gerarScriptCorretora' - ver
        'tools.sql_cadastro_builder.gerar_sql_cadastro_corretora'); se o template
        ainda não estiver disponível, cai de volta para a pendência registrada em
        'usuario.pendencias', igual ao comportamento anterior.
        """
        logger.info(f"🏢 [{self.__class__.__name__}] Organização não localizada para '{usuario.email_master}' - criando a partir do eBao...")

        agent = self.consultar_agent_code_ebao(cnpj=usuario.cnpj, susep=usuario.susep)
        if not agent["encontrado"]:
            usuario.retorno = self.MSG_ADICIONAR_ORGANIZACAO
            usuario.pendencias.append(f"Não foi possível localizar agent_code no eBao: {agent['erro']}")
            return {"status": "error", "mensagem": agent["erro"]}

        dados_ebao = self.consultar_dados_completos_ebao(agent["agent_code"])
        if not dados_ebao["encontrado"]:
            usuario.retorno = self.MSG_ADICIONAR_ORGANIZACAO
            usuario.pendencias.append(f"Não foi possível obter os dados completos do acordo no eBao: {dados_ebao['erro']}")
            return {"status": "error", "mensagem": dados_ebao["erro"]}

        resultado_org = await self.cadastrar_corretora_upm(page, {
            "nome_organizacao": dados_ebao["nome_organizacao"],
            "endereco_1": dados_ebao["endereco_1"],
            "endereco_2": dados_ebao["endereco_2"],
            "cidade": dados_ebao["cidade"],
            "cep": dados_ebao["cep"],
            "estado": dados_ebao["estado"],
        })

        if resultado_org.get("status") != "success":
            usuario.retorno = resultado_org.get("error") or "Falha ao cadastrar corretora no UPM."
            usuario.pendencias.append(usuario.retorno)
            return resultado_org

        # Confirma se a corretora recém-criada já está sincronizada no banco do Portal.
        # Se ainda não estiver (replicação/batch noturno, por exemplo), gera o script SQL
        # manual para o DBA (porta de 'gerarScriptCorretora') - se o template ainda não
        # estiver disponível em 'sql_cadastro_builder.TEMPLATES_SQL_DIR', cai de volta para
        # a pendência simples (comportamento anterior).
        confirmacao_portal = self.consultar_corretora_portal(cnpj=dados_ebao.get("cnpj") or usuario.cnpj, susep=usuario.susep)
        if not confirmacao_portal["encontrado"]:
            caminho_sql = None
            try:
                caminho_sql = gerar_sql_cadastro_corretora(
                    ritm=ritm or "SEM_RITM",
                    cnpj=dados_ebao.get("cnpj") or usuario.cnpj,
                    razao_social=dados_ebao.get("nome_organizacao") or usuario.razao_social,
                    nome_contato_master=usuario.nome_completo,
                    susep=usuario.susep,
                    dados_ebao=dados_ebao,
                    destino_dir=PATH_TEMP,
                )
            except Exception as e:
                logger.warning(f"⚠️ [{self.__class__.__name__}] Falha ao gerar script SQL manual de corretora: {e}")

            if caminho_sql:
                usuario.pendencias.append(
                    f"Corretora cadastrada no UPM mas ainda não sincronizada no banco do Portal "
                    f"(cnpj='{usuario.cnpj}'); script SQL manual gerado em '{caminho_sql}' para o DBA."
                )
            else:
                usuario.pendencias.append(
                    f"Corretora cadastrada no UPM mas ainda não sincronizada no banco do Portal "
                    f"(cnpj='{usuario.cnpj}'); pode ser necessário um script manual para o DBA."
                )

        # Usuário já existia (é por isso que o UPM pediu para completar a organização) -
        # com a organização criada, tenta o reset de senha diretamente.
        resultado_reset = await self.resetar_senha_mfa_upm(page=page, email=usuario.email_master, type_reset="reset")
        usuario.senha = resultado_reset.get("senha_gerada") or ""
        usuario.retorno = (
            "Corretora criada a partir do eBao e senha resetada"
            if resultado_reset.get("status") == "success"
            else (resultado_reset.get("error") or "Corretora criada, mas falha ao resetar a senha.")
        )
        return resultado_reset

    # ========================================================================
    # ALTERAR USUÁRIO (fiel ao 'updateBrokerUpm' de update_usuario.txt)
    # ========================================================================

    async def alterar_usuario_upm(
        self,
        page: Page,
        email_de: str,
        email_para: str = "",
        nome_para: str = "",
        nova_razao: str = "",
        nova_susep: str = "",
    ) -> Dict[str, Any]:
        """
        Localiza o usuário pelo e-mail ATUAL, inativa a conta, aplica as
        alterações informadas (e-mail/nome/organização+SUSEP) reaproveitando os
        primitivos de UpmDriver, reativa e finaliza com reset de senha - port do
        'updateBrokerUpm' de update_usuario.txt, usando as MESMAS primitivas
        ('buscar_e_selecionar_usuario_upm', 'definir_status_conta_upm',
        'vincular_organizacao_susep_upm') já reutilizadas pelo fluxo de Cadastro.
        """
        logger.info(f"✏️ [{self.__class__.__name__}] Alterando usuário '{email_de}' no UPM...")
        resultado: Dict[str, Any] = {
            "email_de": email_de,
            "email_para": email_para,
            "status": "success",
            "senha_gerada": None,
            "mensagem": None,
            "screenshot_path": None,
        }

        busca = await self.buscar_e_selecionar_usuario_upm(page, email_de)
        if not busca["encontrado"]:
            resultado["status"] = "error"
            resultado["mensagem"] = busca["mensagem"] or f"Usuário '{email_de}' não encontrado no UPM."
            return resultado

        # Inativa a conta antes de alterar os dados (mesmo laço de confirmação
        # por 'sucesso' do 'update_usuario.txt' original).
        await self.definir_status_conta_upm(page, "I")

        if email_para:
            await self.preencher_dados_pessoais_upm(page, email=email_para)
            logger.info(f"📧 [{self.__class__.__name__}] E-mail alterado: DE '{email_de}' PARA '{email_para}'")

        if nome_para:
            await self.preencher_dados_pessoais_upm(page, nome_completo=nome_para)
            logger.info(f"📝 [{self.__class__.__name__}] Nome alterado para '{nome_para}'")

        if nova_razao:
            await self.vincular_organizacao_susep_upm(page, razao_social=nova_razao, susep=nova_susep)
            # 'update_usuario.txt' salva aqui, ANTES da reativação final - mantido para fidelidade.
            await self.click_element(page, "upm_save_btn")
            await page.wait_for_timeout(1000)
            logger.info(f"🏢 [{self.__class__.__name__}] Razão social alterada para '{nova_razao}'")

        # Reativa a conta e confirma o salvamento final
        confirmacao = await self.definir_status_conta_upm(page, "A")
        resultado["mensagem"] = confirmacao.get("mensagem")

        if confirmacao.get("status") != "success":
            resultado["status"] = "error"
            return resultado

        email_final = email_para or email_de
        resultado_reset = await self.resetar_senha_mfa_upm(page=page, email=email_final, type_reset="reset")
        resultado["senha_gerada"] = resultado_reset.get("senha_gerada")
        resultado["screenshot_path"] = resultado_reset.get("screenshot_path")
        if resultado_reset.get("status") != "success":
            resultado["status"] = "error"
            resultado["mensagem"] = resultado_reset.get("error")

        return resultado

"""
================================================================================
LEITURA DE E-MAIL: RESPOSTAS DE APROVAÇÃO (OUTLOOK, SÓ WINDOWS)
================================================================================
Único ponto do projeto que LÊ e-mail (tools/smtp.py só ENVIA). Usado pela tela
'Create ctask' para varrer Caixa de Entrada + Itens Enviados do Outlook
procurando respostas às aprovações de DML disparadas pela tela Send dml (ver
'send_dml.send_dml_mailer.DmlMailer.send_approval_email' - mesmo assunto
usado para casar a resposta aqui, devolvido por aquela função justamente
para isso).

SÓ WINDOWS (Outlook COM via 'win32com.client' + 'pythoncom', import feito só
dentro da função) - mesmo mecanismo já usado para ENVIAR e-mail em
'tools/smtp.py:send_outlook_windows' (inclusive o CoInitialize/CoUninitialize
por thread). Não existe equivalente Mac/IMAP: fora do Windows, devolve um erro
claro em vez de tentar e falhar silenciosamente.
"""

import os
import platform
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List

from tools.temp_storage import create_path_temp

logger = logging.getLogger("MailReader")

IS_WINDOWS = platform.system() == "Windows"

# Palavras que indicam aprovação no CORPO da resposta - inclui grafias/erros de
# digitação comuns observados no uso real (mesma lista do fluxo de referência
# que originou esta tela), comparadas em minúsculas.
PALAVRAS_APROVACAO = [
    "aprovado", "aproavdo", "aproado", "approvado", "aprovada",
    "aprovaod", "approved", "approve", "aprove", "aproved",
]

OUTLOOK_INBOX_FOLDER = 6  # olFolderInbox
OUTLOOK_SENT_FOLDER = 5  # olFolderSentMail
DIAS_LOOKBACK_PADRAO = 30  # respostas mais antigas que isso não são varridas (performance)
OL_MSG_FORMAT = 3  # olMSG - formato usado por MailItem.SaveAs para preservar anexos


def _salvar_evidencia(item, pendente_id) -> List[str]:
    """Salva a resposta de aprovação como '.msg' e cada anexo do item diretamente
    em 'path_temp' (sem subpastas) para que todos os arquivos sejam anexados
    na criação da CTASK."""
    arquivos: List[str] = []
    try:
        destino = create_path_temp()

        caminho_msg = os.path.join(destino, f"aprovacao_{pendente_id}.msg")
        item.SaveAs(caminho_msg, OL_MSG_FORMAT)
        arquivos.append(caminho_msg)

        for anexo in item.Attachments:
            try:
                caminho_anexo = os.path.join(destino, str(anexo.FileName))
                anexo.SaveAsFile(caminho_anexo)
                arquivos.append(caminho_anexo)
            except Exception as e_anexo:
                logger.warning(f"⚠️ [MailReader] Falha ao salvar anexo '{getattr(anexo, 'FileName', '?')}' da evidência: {e_anexo}")
    except Exception as e:
        logger.warning(f"⚠️ [MailReader] Falha ao salvar evidência (.msg) do pendente {pendente_id}: {e}")

    return arquivos


def extrair_corpo_original_de_resposta(body: str) -> str:
    """Extrai o corpo original do e-mail enviado a partir do thread da mensagem,
    removendo a resposta ('Aprovado') e cabeçalhos de reply."""
    if not body:
        return ""

    # 1. Se encontrar 'Prezados,', o e-mail original de DML começa com 'Prezados,'
    idx_prezados = body.find("Prezados,")
    if idx_prezados != -1:
        return body[idx_prezados:].strip()

    # 2. Se encontrar 'Plano de Execução:', extrai a partir dele
    idx_plano = body.find("Plano de Execução:")
    if idx_plano != -1:
        return body[idx_plano:].strip()

    # 3. Se houver separadores clássicos do Outlook (De: / From:)
    for sep in ["De:", "De :", "From:", "From :", "-----Mensagem original-----", "-----Original Message-----"]:
        idx_sep = body.find(sep)
        if idx_sep != -1:
            resto = body[idx_sep:]
            for subj_tag in ["Assunto:", "Subject:"]:
                idx_subj = resto.find(subj_tag)
                if idx_subj != -1:
                    fim_linha = resto.find("\n", idx_subj)
                    if fim_linha != -1:
                        return resto[fim_linha:].strip()
            return resto.strip()

    return body.strip()


def verificar_respostas_aprovacao_outlook(
    pendentes: List[Dict[str, Any]],
    emails_autorizados: List[str] = None,
    dias_lookback: int = DIAS_LOOKBACK_PADRAO,
) -> Dict[str, Any]:
    """
    :param pendentes: [{'id': <int>, 'assunto': <str>, 'criado_em': datetime|None}, ...] -
        aprovações aguardando resposta (ver 'CtaskAprovacao', status='pendente').
        'criado_em' (quando informado) ancora a busca no DIA em que a solicitação
        foi enviada, em vez de uma janela genérica - ver 'dias_lookback'.
    :param emails_autorizados: lista de e-mails habilitados a aprovar (ver
        'DmlApprovalContact', configurada na tela 'Create ctask'). OBRIGATÓRIA -
        vazia/None interrompe a busca ANTES de tocar o Outlook (ver checagem
        logo abaixo): sem remetente autorizado configurado não há o que
        procurar, e variar por toda a caixa de entrada sem esse filtro foi
        justamente o que causava buscas travando por minutos.
    :param dias_lookback: TETO de segurança - a busca nunca olha mais para trás
        que isso, mesmo que algum pendente tenha sido criado há mais tempo.

    Busca OBJETIVA: varre Caixa de Entrada + Itens Enviados (mesmas 2 pastas de
    'dml_change_finder._buscar_change_windows' - sem recursão em subpastas)
    restritas a partir do dia de criação mais antigo entre os pendentes
    informados (nunca além de 'dias_lookback'). Itens Enviados entra porque um
    teste/aprovação onde o próprio remetente da DML responde a si mesmo
    (aprovador == quem enviou) pode ficar só em Itens Enviados por um tempo até
    o servidor entregar a cópia na Caixa de Entrada - sem essa pasta a resposta
    simplesmente não é encontrada enquanto isso não acontece. Para cada item
    candidato, exige TODAS as condições:
      1. Subject CONTÉM o assunto original de algum pendente (cobre replies
         com prefixo 'RE: '/'RES: '/'Re: '/'Res: ' etc., que o Outlook antepõe
         sem alterar o resto do assunto);
      2. o e-mail foi recebido no dia da criação daquele pendente específico
         em diante (com 1 dia de folga para diferença de fuso horário - o
         registro é gravado em UTC, o Outlook mostra hora local);
      3. o remetente está em 'emails_autorizados'.
    Quando a resposta é uma aprovação válida (contém alguma palavra de
    'PALAVRAS_APROVACAO' no corpo), salva o e-mail e seus anexos como
    evidência (ver '_salvar_evidencia') para anexar depois na CTASK criada.

    Devolve {'status': 'success', 'respostas': [{'id', 'aprovado': bool, 'de': str,
    'evidencia_arquivos': [...]}]} - pendentes sem NENHUMA resposta encontrada (ou
    só respostas de remetente não autorizado/fora do período) simplesmente não
    aparecem em 'respostas' (continuam pendentes na próxima verificação). Nunca
    lança exceção: falha vira {'status': 'error', 'message': ..., 'respostas': []}.
    """
    autorizados_norm = {e.strip().lower() for e in (emails_autorizados or []) if e and e.strip()}
    if not IS_WINDOWS:
        return {
            "status": "error",
            "message": "Leitura de e-mail só é suportada no Windows (Outlook COM) - "
                       f"sistema atual: {platform.system()}.",
            "respostas": [],
        }

    if not pendentes:
        return {"status": "success", "respostas": []}

    if not autorizados_norm:
        return {
            "status": "error",
            "message": "Nenhum contato de aprovação cadastrado - cadastre ao menos um e-mail "
                       "em 'Contatos de Aprovação' antes de verificar.",
            "respostas": [],
        }

    import win32com.client
    import pythoncom

    pythoncom.CoInitialize()
    respostas: List[Dict[str, Any]] = []
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        namespace = outlook.GetNamespace("MAPI")

        pastas = []  # (pasta, campo_de_data_DASL)
        try:
            pastas.append((namespace.GetDefaultFolder(OUTLOOK_INBOX_FOLDER), "ReceivedTime"))
        except Exception as e:
            logger.warning(f"⚠️ [MailReader] Não foi possível abrir a Caixa de Entrada: {e}")
        try:
            pastas.append((namespace.GetDefaultFolder(OUTLOOK_SENT_FOLDER), "SentOn"))
        except Exception as e:
            logger.warning(f"⚠️ [MailReader] Não foi possível abrir 'Itens Enviados': {e}")

        cutoff_padrao = datetime.now() - timedelta(days=dias_lookback)
        datas_criacao = [p["criado_em"] for p in pendentes if isinstance(p.get("criado_em"), datetime)]
        data_limite = max(min(datas_criacao) - timedelta(days=1), cutoff_padrao) if datas_criacao else cutoff_padrao

        pendentes_restantes = list(pendentes)

        for pendente in list(pendentes_restantes):
            title = str(pendente.get("assunto", "")).strip()
            if not title:
                continue

            pendente_resolvido = False

            for pasta, campo_data in pastas:
                if pendente_resolvido:
                    break

                items = pasta.Items
                try:
                    items.Sort(f"[{campo_data}]", True)
                except Exception:
                    pass

                filtro_resultado = None

                # 1. Tenta filtrar pelo nome/email de cada aprovador autorizado
                for aprovador in autorizados_norm:
                    query = f"@SQL=urn:schemas:httpmail:subject LIKE '%{title}%' AND  urn:schemas:httpmail:sender LIKE '%{aprovador}%'"
                    try:
                        res = items.Restrict(query)
                        if len(res) >= 1:
                            filtro_resultado = res
                            break
                    except Exception as e_q:
                        logger.debug(f"Query '{query}' retornou: {e_q}")

                # 2. Se len == 0, tenta extrair o primeiro nome (antes do ponto) como no código do usuário
                if not filtro_resultado or len(filtro_resultado) == 0:
                    for email in autorizados_norm:
                        ponto_pos = email.find('.')
                        if ponto_pos > 0:
                            name_user = email[0:ponto_pos].lower()
                        else:
                            name_user = email.split('@')[0].lower()
                        
                        query = f"@SQL=urn:schemas:httpmail:subject LIKE '%{title}%' AND  urn:schemas:httpmail:sender LIKE '%{name_user}%'"
                        try:
                            res = items.Restrict(query)
                            if len(res) >= 1:
                                filtro_resultado = res
                                break
                        except Exception as e_q2:
                            logger.debug(f"Query '{query}' retornou: {e_q2}")

                # 3. Se ainda não encontrou com sender, tenta apenas pelo subject (garantia)
                if not filtro_resultado or len(filtro_resultado) == 0:
                    query_subject = f"@SQL=urn:schemas:httpmail:subject LIKE '%{title}%'"
                    try:
                        res = items.Restrict(query_subject)
                        if len(res) >= 1:
                            filtro_resultado = res
                    except Exception:
                        pass

                if not filtro_resultado or len(filtro_resultado) == 0:
                    continue

                # Itera nas mensagens encontradas pelo filtro
                for msg in filtro_resultado:
                    try:
                        subject = getattr(msg, "Subject", "") or ""
                        body = getattr(msg, "Body", "") or ""
                        sender = getattr(msg, "SenderEmailAddress", "") or getattr(msg, "SenderName", "") or ""
                        data_item = getattr(msg, campo_data, None)
                    except Exception as e_msg:
                        logger.warning(f"⚠️ [MailReader] Erro ao ler mensagem: {e_msg}")
                        continue

                    # Valida data (timedelta - 1 dia em relação ao criado_em)
                    criado_em = pendente.get("criado_em")
                    if isinstance(criado_em, datetime) and data_item is not None:
                        try:
                            data_item_naive = datetime(data_item.year, data_item.month, data_item.day,
                                                        data_item.hour, data_item.minute, data_item.second)
                            if data_item_naive < criado_em - timedelta(days=1):
                                continue
                        except Exception:
                            pass

                    # Verifica se o corpo contém aprovação
                    aprovado = any(palavra in body.lower() for palavra in PALAVRAS_APROVACAO)
                    evidencia_arquivos = _salvar_evidencia(msg, pendente["id"]) if aprovado else []
                    corpo_original = extrair_corpo_original_de_resposta(body)

                    # Quando aprovado, tenta localizar a mensagem original em 'Itens Enviados' para extrair os scripts .sql e corpo limpo
                    if aprovado:
                        try:
                            sent_folder = namespace.GetDefaultFolder(OUTLOOK_SENT_FOLDER)
                            sent_items = sent_folder.Items
                            res_sent = sent_items.Restrict(f"@SQL=urn:schemas:httpmail:subject LIKE '%{title}%'")
                            if len(res_sent) >= 1:
                                sent_msg = res_sent[0]
                                sent_body = getattr(sent_msg, "Body", "") or ""
                                if sent_body and ("Prezados," in sent_body or "Plano de Execução:" in sent_body):
                                    corpo_original = extrair_corpo_original_de_resposta(sent_body)

                                # Salva também os anexos (.sql) da mensagem enviada diretamente em path_temp
                                destino_temp = create_path_temp()
                                for anexo in getattr(sent_msg, "Attachments", []):
                                    try:
                                        caminho_anexo = os.path.join(destino_temp, str(anexo.FileName))
                                        anexo.SaveAsFile(caminho_anexo)
                                        if caminho_anexo not in evidencia_arquivos:
                                            evidencia_arquivos.append(caminho_anexo)
                                    except Exception as e_anx_sent:
                                        logger.warning(f"⚠️ [MailReader] Falha ao salvar anexo do e-mail enviado: {e_anx_sent}")
                        except Exception as e_sent:
                            logger.debug(f"Aviso ao buscar detalhes em Itens Enviados: {e_sent}")

                    respostas.append({
                        "id": pendente["id"],
                        "aprovado": aprovado,
                        "de": sender,
                        "evidencia_arquivos": evidencia_arquivos,
                        "corpo_original": corpo_original,
                        "assunto_original": title,
                    })

                    pendentes_restantes.remove(pendente)
                    pendente_resolvido = True
                    break

        logger.info(f"📬 [MailReader] {len(respostas)}/{len(pendentes)} aprovação(ões) com resposta encontrada.")
        return {"status": "success", "respostas": respostas}

    except Exception as e:
        logger.error(f"❌ [MailReader] Erro ao ler Caixa de Entrada do Outlook: {e}")
        return {"status": "error", "message": str(e), "respostas": respostas}
    finally:
        pythoncom.CoUninitialize()

import logging
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError

logger = logging.getLogger("OktaAuthManager")

class OktaAuthManager:
    """
    Gerenciador dedicado para autenticação Okta e verificação de cache de sessão.
    """

    OKTA_KEYWORDS = ["okta", "login", "auth", "sso"]

    @classmethod
    def is_okta_redirect(cls, url: str) -> bool:
        """Verifica se a URL informada pertence ao fluxo de login do Okta / SSO."""
        url_lower = url.lower()
        return any(keyword in url_lower for keyword in cls.OKTA_KEYWORDS)

    @classmethod
    async def wait_for_okta_login_if_needed(cls, page: Page, target_url: str, timeout_ms: int = 180000):
        """
        Navega até a URL desejada e verifica se houve redirecionamento para o Okta.
        Se for necessário login ou Push MFA no celular, aguarda interativamente até 3 minutos.
        """
        logger.info(f"Acessando URL para validação de sessão Okta: {target_url}")
        await page.goto(target_url, wait_until="domcontentloaded")
        await page.wait_for_timeout(3000)

        current_url = page.url
        if cls.is_okta_redirect(current_url):
            logger.warning("=" * 70)
            logger.warning("[OKTA MFA REQUERIDO] Por favor, faça o login e confirme a notificação no celular!")
            logger.warning(f"O script aguardará até {timeout_ms // 1000}s para conclusão da autenticação...")
            logger.warning("=" * 70)

            try:
                await page.wait_for_url(
                    lambda url: not cls.is_okta_redirect(url),
                    timeout=timeout_ms
                )
                logger.info("✅ Autenticação Okta concluída com sucesso! A sessão foi persistida no cache local.")
            except PlaywrightTimeoutError:
                logger.error("❌ Tempo limite expirou antes da conclusão do login Okta.")
                raise Exception("Erro: Autenticação Okta/MFA não foi finalizada dentro do tempo limite.")
        else:
            logger.info("✅ Sessão do Okta válida e ativa no cache local! Não foi necessário login.")

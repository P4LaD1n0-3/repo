"""
================================================================================
REGISTRO CENTRAL DE JOBS DE AUTOMAÇÃO (PLAYWRIGHT) ATIVOS
================================================================================
Módulo compartilhado (não pertence a nenhuma tela específica) responsável por
rastrear as automações Playwright em execução no processo Flask, permitindo que
o botão "Cancelar" de QUALQUER tela realmente interrompa a automação em
andamento — encerrando à força o navegador/contexto Playwright daquele job.

REUSO POR HERANÇA: é consumido diretamente por 'tools.base_automation.BaseAutomation'
(a classe-mãe de TODAS as automações do sistema: ServiceNowDriver, UpmDriver,
ReleaseOpenService, ReleaseCloseService, TaskEncerrarService, CadastroUsuarioService,
etc.). Qualquer tela cujo serviço reutilize 'launch_persistent_context' /
'close_context' / 'run_concurrent_tasks' herdados de BaseAutomation ganha
suporte a cancelamento automaticamente, sem reimplementar nada - basta a rota
gerar um 'job_id' e repassá-lo até o serviço.

COMO FUNCIONA O CANCELAMENTO ENTRE THREADS:
Cada requisição Flask que dispara uma automação roda seu próprio event loop
asyncio dentro da própria thread da requisição (padrão já usado em todo o
projeto: 'asyncio.new_event_loop()' + 'loop.run_until_complete(...)'; o
servidor Flask roda com threaded=True para permitir requisições concorrentes).
O botão Cancelar dispara uma requisição HTTP SEPARADA (processada em outra
thread), que localiza o job pelo 'job_id' e usa
'asyncio.run_coroutine_threadsafe(context.close(), loop)' para agendar o
fechamento do navegador diretamente no event loop ORIGINAL que está executando
a automação. Isso derruba o processo do navegador imediatamente, e qualquer
operação Playwright pendente (goto, click, fill, wait_for_selector, etc.)
levanta 'TargetClosedError', interrompendo a automação pelos próprios blocos
try/except já existentes em cada serviço. Validado com um teste de integração
real (Playwright + threading) antes desta implementação.
"""

import asyncio
import logging
import threading
import time
from concurrent.futures import TimeoutError as FutureTimeoutError
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger("JobRegistry")


@dataclass
class _JobEntry:
    user_id: Any
    module: str = ""
    loop: Optional[asyncio.AbstractEventLoop] = None
    context: Optional[Any] = None
    cancel_requested: bool = False
    status: str = "running"  # "running", "finished", "cancelled", "error"
    created_at: float = field(default_factory=time.time)
    finished_at: Optional[float] = None
    logs: list = field(default_factory=list)
    result: Optional[Any] = None


class JobRegistry:
    """Registro global thread-safe de jobs de automação (Playwright) e buffer de logs persistentes."""

    def __init__(self):
        self._jobs: Dict[str, _JobEntry] = {}
        self._lock = threading.Lock()
        self._retention_seconds = 7200  # Mantém histórico por 2 horas

    def _cleanup_old_jobs_locked(self):
        """Remove jobs finalizados mais antigos que o tempo de retenção (chamado com _lock)."""
        now = time.time()
        to_delete = []
        for jid, entry in self._jobs.items():
            if entry.status != "running" and entry.finished_at:
                if (now - entry.finished_at) > self._retention_seconds:
                    to_delete.append(jid)
        for jid in to_delete:
            self._jobs.pop(jid, None)

    def register(self, job_id: str, user_id: Any, module: str = ""):
        """Registra um novo job assim que a rota começa a processar a automação."""
        if not job_id:
            return
        with self._lock:
            self._cleanup_old_jobs_locked()
            self._jobs[job_id] = _JobEntry(user_id=user_id, module=module, status="running")
        logger.info(f"🆕 [JobRegistry] Job '{job_id}' registrado (usuário={user_id}, módulo='{module}').")

    def set_loop(self, job_id: str, loop: asyncio.AbstractEventLoop):
        """Associa o event loop asyncio responsável por executar o job."""
        if not job_id:
            return
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry:
                entry.loop = loop

    def attach_context(self, job_id: str, context: Any):
        """
        Associa o BrowserContext do Playwright em execução ao job. Chamado
        automaticamente por 'BaseAutomation.launch_persistent_context()' quando
        um 'job_id' é informado.
        """
        if not job_id:
            return
        cancelado = False
        user_id = None
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry:
                entry.context = context
                cancelado = entry.cancel_requested
                user_id = entry.user_id
        if cancelado:
            logger.info(f"⏭️ [JobRegistry] Job '{job_id}' já tinha cancelamento pendente - aplicando agora que o navegador abriu.")
            self.cancel(job_id, user_id, _internal=True)

    def is_cancelled(self, job_id: str) -> bool:
        """Checagem cooperativa - usada entre itens de um lote."""
        if not job_id:
            return False
        with self._lock:
            entry = self._jobs.get(job_id)
            return bool(entry and (entry.cancel_requested or entry.status == "cancelled"))

    def unregister(self, job_id: str, status: str = "finished", result: Any = None):
        """
        Marca o job como finalizado e libera recursos de execução (context, loop),
        mantendo os LOGS em memória para permitir que telas consultem o histórico
        mesmo se o usuário navegou entre abas durante a execução.
        """
        if not job_id:
            return
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry:
                if entry.cancel_requested:
                    entry.status = "cancelled"
                else:
                    entry.status = status
                entry.finished_at = time.time()
                entry.result = result
                entry.context = None
                entry.loop = None
        logger.info(f"🏁 [JobRegistry] Job '{job_id}' finalizado com status '{entry.status if entry else status}' (logs mantidos em buffer).")

    def append_log(self, job_id: str, message: str):
        """Acrescenta uma linha de log ao buffer do job em tempo real."""
        if not job_id:
            return
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry:
                entry.logs.append(message)

    def get_logs(self, job_id: str, requesting_user_id: Any, since: int = 0) -> Dict[str, Any]:
        """
        Lê as linhas de log do job a partir do índice 'since' (para polling incremental).
        Retorna status atual (running, finished, cancelled, error), logs novos e next_since.
        """
        with self._lock:
            entry = self._jobs.get(job_id)
            if not entry:
                return {"status": "not_found", "logs": [], "next_since": since, "is_active": False}
            if str(entry.user_id) != str(requesting_user_id):
                return {"status": "forbidden", "logs": [], "next_since": since, "is_active": False}
            novas_linhas = list(entry.logs[since:])
            is_active = (entry.status == "running")
            return {
                "status": entry.status,
                "logs": novas_linhas,
                "next_since": len(entry.logs),
                "is_active": is_active,
                "module": entry.module,
                "job_id": job_id,
            }

    def get_active_job(self, user_id: Any, module: Optional[str] = None) -> Dict[str, Any]:
        """
        Localiza qualquer job ativo (rodando) pertencente ao usuário (e módulo, se especificado).
        Usado quando o usuário retorna a uma aba para retomar imediatamente o acompanhamento.
        """
        with self._lock:
            for jid, entry in reversed(list(self._jobs.items())):
                if str(entry.user_id) == str(user_id):
                    if module and entry.module != module:
                        continue
                    if entry.status == "running":
                        return {
                            "active": True,
                            "job_id": jid,
                            "module": entry.module,
                            "status": entry.status,
                            "logs": list(entry.logs),
                            "next_since": len(entry.logs),
                            "created_at": entry.created_at,
                        }
        return {"active": False, "job_id": None, "logs": []}

    def get_latest_job(self, user_id: Any, module: Optional[str] = None) -> Dict[str, Any]:
        """Retorna o job mais recente (em execução ou recém-finalizado) para o módulo."""
        with self._lock:
            for jid, entry in reversed(list(self._jobs.items())):
                if str(entry.user_id) == str(user_id):
                    if module and entry.module != module:
                        continue
                    return {
                        "found": True,
                        "job_id": jid,
                        "module": entry.module,
                        "status": entry.status,
                        "logs": list(entry.logs),
                        "next_since": len(entry.logs),
                        "is_active": (entry.status == "running"),
                        "created_at": entry.created_at,
                        "finished_at": entry.finished_at,
                    }
        return {"found": False, "job_id": None, "logs": []}

    def clear_module_logs(self, user_id: Any, module: Optional[str] = None):
        """Limpa entradas de histórico do usuário para o módulo especificado."""
        with self._lock:
            to_delete = []
            for jid, entry in self._jobs.items():
                if str(entry.user_id) == str(user_id):
                    if not module or entry.module == module:
                        if entry.status != "running":
                            to_delete.append(jid)
                        else:
                            entry.logs.clear()
            for jid in to_delete:
                self._jobs.pop(jid, None)

    def cancel(self, job_id: str, requesting_user_id: Any, _internal: bool = False) -> Dict[str, str]:
        """Solicita o cancelamento de um job ativo."""
        with self._lock:
            entry = self._jobs.get(job_id)
            if not entry:
                return {"status": "not_found", "message": "Nenhuma automação ativa encontrada para este identificador (pode já ter finalizado)."}

            if not _internal and str(entry.user_id) != str(requesting_user_id):
                return {"status": "forbidden", "message": "Você não tem permissão para cancelar esta automação."}

            entry.cancel_requested = True
            entry.status = "cancelled"
            loop = entry.loop
            context = entry.context

        logger.warning(f"🛑 [JobRegistry] Cancelamento solicitado para o job '{job_id}'.")

        if not context or not loop:
            return {"status": "pending", "message": "Cancelamento sinalizado. A automação será interrompida assim que possível."}

        try:
            future = asyncio.run_coroutine_threadsafe(context.close(), loop)
            try:
                future.result(timeout=5)
                logger.warning(f"✅ [JobRegistry] Navegador do job '{job_id}' encerrado à força com sucesso.")
            except FutureTimeoutError:
                logger.warning(f"⏱️ [JobRegistry] context.close() do job '{job_id}' não confirmou em 5s - seguindo em frente.")
            return {"status": "cancelled", "message": "Automação cancelada: o navegador foi encerrado."}
        except Exception as e:
            logger.error(f"❌ [JobRegistry] Erro ao encerrar à força o job '{job_id}': {e}")
            return {"status": "error", "message": f"Falha ao cancelar automação: {e}"}


# Instância única compartilhada por todo o processo Flask (importada por qualquer módulo/rota).
job_registry = JobRegistry()

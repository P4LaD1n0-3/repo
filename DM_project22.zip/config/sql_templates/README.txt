Coloque aqui os templates SQL originais (os mesmos arquivos que o script legado
lia de "src/documents/"):

  - Script_Cadastro_Usuario.sql
  - Script_Cadastro_Corretora.sql

Assim que os arquivos existirem nesta pasta, a geração automática do script
de cadastro (tools/sql_cadastro_builder.py) passa a funcionar sozinha, sem
precisar mudar nenhum código - basta soltar os arquivos aqui.

Se preferir guardar os templates em outro lugar (fora deste projeto), defina
a variável de ambiente SQL_TEMPLATES_DIR no .env apontando para essa pasta,
em vez de usar esta.

Este diretório é local ao seu computador e não é enviado a lugar nenhum pelo
sistema - os templates nunca saem daqui.

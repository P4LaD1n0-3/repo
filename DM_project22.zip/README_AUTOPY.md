# Guia: Como Gerar o Executável (`.exe`) com auto-py-to-exe e PyInstaller

Este guia detalha como compilar a aplicação em um executável desktop profissional para Windows/macOS utilizando o **`auto-py-to-exe`** ou **`pyinstaller`** direto pela linha de comando, com ícone personalizado e gerenciamento automático de pastas dinâmicas.

---

## 1. Como as Pastas do App se Comportam no `.exe`

A arquitetura do projeto foi estruturada para que o executável funcione de forma 100% autônoma e segura:

- **Pastas Embutidas no `.exe` (Read-only / Código e Telas)**:
  - `src/` (Módulos, rotas, templates HTML e arquivos estáticos CSS/JS/Imagens)
  - `config/` (Dicionário de seletores `servicenow_paths.json` e regras `ticket_assignment_rules.json`)
  - `tools/` (Serviços e drivers Python)

- **Pastas Dinâmicas Externas (Geradas e Mantidas Automaticamente ao Lado do `.exe`)**:
  - `playwright_user_data/` → Armazena a sessão de login (Okta / Cookies / MFA) do navegador das automações. É criada e persistida automaticamente.
  - `webview_user_data/` → Armazena a sessão de login e preferências da janela desktop.
  - `instance/database.db` → Banco de dados SQLite persistente.
  - `path_temp/` → Pasta de arquivos temporários (.sql, downloads de relatórios e evidências).
  - `.env` → Arquivo de configuração de ambiente (senhas, endpoints e versão do build).

---

## 2. Compilação via `auto-py-to-exe` (Interface Gráfica)

1. Inicie a interface:
   ```bash
   auto-py-to-exe
   ```

2. Na tela que abrir no navegador, configure:
   - **Script Location**: Selecione o arquivo `main.py` na raiz do projeto.
   - **Onefile**: Selecione **One Directory** (`--onedir`, recomendado) ou **One File** (`--onefile`).
   - **Console Window**: Selecione **Window Based** (oculta o prompt preto) ou **Console Based** (mantém o terminal de log visível).
   - **Icon**: Selecione o arquivo **`app_icon.ico`** presente na raiz do projeto.
   - **Additional Files**:
     - Clique em **Add Folder**: Selecione a pasta `src` → Destination: `src`
     - Clique em **Add Folder**: Selecione a pasta `config` → Destination: `config`
     - *(Opcional)* Clique em **Add File**: Selecione `app_icon.ico` → Destination: `.`

3. Clique no botão azul **Convert .py to .exe**.

---

## 3. Compilação Direta via Linha de Comando (PyInstaller)

### No Windows (Prompt / PowerShell):
```cmd
pyinstaller --noconfirm --onedir --windowed --icon "app_icon.ico" --add-data "src;src" --add-data "config;config" --add-data "app_icon.ico;." main.py
```

### No macOS / Linux:
```bash
pyinstaller --noconfirm --onedir --windowed --icon "app_icon.ico" --add-data "src:src" --add-data "config:config" --add-data "app_icon.ico:." main.py
```

---

## 4. Executando o Aplicativo Compilado

Após a compilação:
1. Abra a pasta gerada em `dist/main/` (ou onde estiver o `main.exe`).
2. Copie seu arquivo `.env` para a mesma pasta do `main.exe` (caso queira customizar credenciais locais).
3. Dê duplo clique em `main.exe`. O aplicativo iniciará com o novo ícone, abrirá a janela desktop integrada e gerará todas as pastas dinâmicas (`playwright_user_data`, `instance`, `path_temp`) automaticamente!


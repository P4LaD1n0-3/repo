import os
import sys
import socket
import threading

# Auto-detecta o ambiente virtual (.venv) local caso executado fora dele
try:
    import flask
except ImportError:
    base_dir = os.path.dirname(os.path.abspath(__file__))
    venv_site_packages = os.path.join(
        base_dir, '.venv', 'lib',
        f'python{sys.version_info.major}.{sys.version_info.minor}', 'site-packages'
    )
    if os.path.exists(venv_site_packages):
        sys.path.insert(0, venv_site_packages)
    elif os.path.exists(os.path.join(base_dir, '.venv')):
        import glob
        matches = glob.glob(os.path.join(base_dir, '.venv', 'lib', 'python*', 'site-packages'))
        if matches:
            sys.path.insert(0, matches[0])

from flask import Flask
from flask_login import LoginManager

def resource_path(relative_path):
    """Retorna o caminho absoluto do recurso (funciona em Dev e auto-py-to-exe/PyInstaller)"""
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(os.path.dirname(__file__))
    return os.path.join(base_path, relative_path)

def create_app():
    shared_templates = resource_path(os.path.join('src', 'shared', 'templates'))
    shared_static = resource_path(os.path.join('src', 'shared', 'static'))

    app = Flask(__name__, template_folder=shared_templates, static_folder=shared_static)
    app.config['SECRET_KEY'] = 'automacao-web-secret-key-12345'

    # Localização do banco de dados SQLite persistente
    if getattr(sys, 'frozen', False):
        app_dir = os.path.dirname(sys.executable)
    else:
        app_dir = os.path.abspath(os.path.dirname(__file__))

    db_dir = os.path.join(app_dir, 'instance')
    os.makedirs(db_dir, exist_ok=True)
    db_path = os.path.join(db_dir, 'database.db')

    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Importa modelos e inicializa o DB
    from src.models import db, User
    db.init_app(app)

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Por favor, faça login para acessar esta página.'
    login_manager.login_message_category = 'warning'

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    with app.app_context():
        db.create_all()

    # Registro dos Blueprints ativos por módulo
    from src.modules.auth.routes import auth_bp
    from src.modules.apps.routes import apps_bp
    from src.modules.monitoring.routes import monitoring_bp
    from src.modules.portal_task.routes import portal_task_bp
    from src.modules.release_task.routes import release_task_bp
    from src.modules.send_dml.routes import send_dml_bp
    from src.modules.email_report.routes import email_report_bp
    from src.modules.system.routes import system_bp
    from src.modules.create_ctask.routes import create_ctask_bp
    from src.modules.ticket_assignment.routes import ticket_assignment_bp
    # pyrefly: ignore [missing-import]
    from src.modules.dash.email_bridge import email_bridge_bp
    from src.modules.dash.routes import dash_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(apps_bp)
    app.register_blueprint(monitoring_bp)
    app.register_blueprint(portal_task_bp)
    app.register_blueprint(release_task_bp)
    app.register_blueprint(send_dml_bp)
    app.register_blueprint(email_report_bp)
    app.register_blueprint(system_bp)
    app.register_blueprint(create_ctask_bp)
    app.register_blueprint(ticket_assignment_bp)
    app.register_blueprint(email_bridge_bp)
    app.register_blueprint(dash_bp)

    return app

app = create_app()

HOST = '127.0.0.1'
PORT = 5790  # Fixa (não aleatória) - só um usuário local por vez, sem risco de colisão.


def _run_flask():
    # threaded=True é necessário para que o botão "Cancelar" funcione: ele dispara uma
    # requisição HTTP separada que precisa ser processada CONCORRENTEMENTE enquanto uma
    # automação Playwright de outra requisição ainda está em andamento (ver tools/job_registry.py).
    # debug=False/use_reloader=False: com o Flask rodando em thread de fundo (ver __main__),
    # o reloader do Werkzeug reiniciaria o processo inteiro (e a janela pywebview) a cada
    # troca de arquivo - inadequado para o app empacotado como janela desktop.
    app.run(host=HOST, port=PORT, debug=False, threaded=True, use_reloader=False)


def _aguardar_servidor_pronto(host, port, timeout=15):
    """Espera a porta aceitar conexões antes de abrir a janela - evita a tela de
    'conexão recusada' no instante em que a janela pywebview abre antes do Flask
    terminar de subir."""
    import time
    prazo = time.monotonic() + timeout
    while time.monotonic() < prazo:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.1)
    return False


if __name__ == '__main__':
    import webview

    print(f"Iniciando App Flask de Automação Web em http://{HOST}:{PORT} ...")
    threading.Thread(target=_run_flask, daemon=True).start()
    _aguardar_servidor_pronto(HOST, PORT)

    # Pasta de perfil PERSISTENTE do WebView (mesmo padrão de './playwright_user_data'
    # já usado pelas automações Playwright) - necessária porque 'webview.start()' roda
    # em 'private_mode=True' por padrão (equivalente a aba anônima): cookies/localStorage
    # são descartados ao fechar a janela, derrubando a sessão de login mesmo com
    # "remember me" marcado no /login. 'private_mode=False' + 'storage_path' fixo faz o
    # cookie de sessão (Flask-Login 'remember_token') sobreviver a reinícios do app -
    # o usuário só perde a sessão clicando em "Logout" (ver auth.logout).
    _base_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.abspath(os.path.dirname(__file__))
    webview_storage_dir = os.path.join(_base_dir, 'webview_user_data')
    os.makedirs(webview_storage_dir, exist_ok=True)

    # Renderiza o app inteiro (Flask + JS/CSS) dentro de uma janela desktop nativa via
    # pywebview (WebView2 no Windows) - tkinter puro não tem motor de renderização web.
    # 'text_select=True': o pywebview desabilita seleção de texto por padrão
    # (text_select=False) - sem isso, nada na janela (CHG, CTASK, logs etc.) pode
    # ser selecionado/copiado, mesmo sem nenhuma regra CSS de 'user-select: none'
    # bloqueando o conteúdo.
    webview.create_window('Automação Web', f'http://{HOST}:{PORT}/', width=1440, height=900, min_size=(1024, 700), text_select=True)
    webview.start(private_mode=False, storage_path=webview_storage_dir)

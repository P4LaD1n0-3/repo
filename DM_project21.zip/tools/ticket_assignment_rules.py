"""
================================================================================
MOTOR DE REGRAS: ATRIBUIÇÃO DE SCTASK POR PALAVRA-CHAVE
================================================================================
Lógica PURA (sem Playwright/ServiceNow) - carrega 'config/ticket_assignment_rules.json'
(stop_words + grupos 'vetor_*', cada um com regras {Topic, "Assigned to",
"Assignment group", "Configuration item", ...}) e decide qual regra se aplica
a um chamado, comparando palavras do assunto/descrição contra 'Topic'.

SELEÇÃO SÓ POR PALAVRA-CHAVE (decisão confirmada com o usuário): 'vetor_*' é
só organização do JSON para o usuário editar depois - o algoritmo achata TODAS
as regras de TODOS os vetores e escolhe pela que tiver o MELHOR match de
'Topic', não pelo nome do vetor nem pelo 'Configuration item' do chamado (esse
campo sozinho não desambigua tudo - ex.: 'vetor_portal' e
'vetor_access_deligamentoPortal' os dois usam "Portal Corretor").

Reaproveita 'tools.validators.normalizar_texto' (remove acento/caixa/espaço
extra) em vez de reimplementar normalização de texto.
"""

import os
import json
import logging
from typing import Any, Dict, List, Optional, Set

from tools.validators import normalizar_texto

logger = logging.getLogger("TicketAssignmentRules")

DEFAULT_RULES_PATH = os.environ.get(
    "TICKET_ASSIGNMENT_RULES_PATH",
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config", "ticket_assignment_rules.json"),
)


def carregar_regras(caminho: Optional[str] = None) -> Dict[str, Any]:
    """Carrega o JSON de regras (config/ticket_assignment_rules.json por padrão)."""
    caminho = caminho or DEFAULT_RULES_PATH
    with open(caminho, "r", encoding="utf-8") as f:
        return json.load(f)


def _palavras_normalizadas(texto: str, stop_words: Set[str]) -> List[str]:
    """Normaliza 'texto' (acento/caixa/espaço) e remove as 'stop_words' (já normalizadas)."""
    normalizado = normalizar_texto(texto)
    if not normalizado:
        return []
    return [p for p in normalizado.split(" ") if p and p not in stop_words]


def _melhor_topico_da_regra(
    regra: Dict[str, Any], palavras_chamado: Set[str], stop_words: Set[str]
) -> int:
    """
    Maior Nº de palavras do tópico MAIS LONGO desta regra que bate 100% (TODAS
    as palavras do tópico presentes no chamado) - 0 se nenhum tópico bater
    inteiro. Match PARCIAL não conta (ver docstring do módulo/'encontrar_melhor_regra'):
    um tópico de 2 palavras só pontua se as 2 estiverem no chamado, nunca só 1 -
    evita falso-positivo de uma palavra solta e genérica (ex.: "texto" sozinho
    não deveria bastar pra casar o tópico "ajuste texto").
    """
    melhor = 0
    for topico in regra.get("Topic", []):
        palavras_topico = _palavras_normalizadas(topico, stop_words)
        if not palavras_topico:
            continue
        contagem = sum(1 for p in palavras_topico if p in palavras_chamado)
        if contagem == len(palavras_topico) and contagem > melhor:
            melhor = contagem
    return melhor


def encontrar_melhor_regra(texto_chamado: str, regras: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Devolve a regra (dict original do JSON) cujo 'Topic' mais longo bate 100%
    (todas as palavras do tópico) com 'texto_chamado' (normalmente
    short_description + description do chamado), entre TODOS os grupos
    'vetor_*' - desempate por tópico mais longo/específico quando mais de uma
    regra bate inteiro. Devolve None se NENHUM tópico bater por completo
    (nunca "inventa" uma regra por causa de 1 palavra solta em comum).
    """
    stop_words = {normalizar_texto(p) for p in regras.get("stop_words", [])}
    palavras_chamado = set(_palavras_normalizadas(texto_chamado or "", stop_words))
    if not palavras_chamado:
        return None

    melhor_regra: Optional[Dict[str, Any]] = None
    melhor_contagem = 0

    for chave, grupo in regras.items():
        if chave == "stop_words" or not isinstance(grupo, list):
            continue
        for regra in grupo:
            contagem = _melhor_topico_da_regra(regra, palavras_chamado, stop_words)
            if contagem > melhor_contagem:
                melhor_contagem = contagem
                melhor_regra = regra

    if melhor_contagem == 0:
        return None

    logger.info(f"🎯 [TicketAssignmentRules] Melhor match ({melhor_contagem} palavra(s) do tópico): {melhor_regra}")
    return melhor_regra


def _vetores_candidatos_por_item(item_texto: str, regras: Dict[str, Any]) -> List[str]:
    """Vetores cujo 'Configuration item' bate (substring, nos 2 sentidos) com o campo "Item" do chamado."""
    item_norm = normalizar_texto(item_texto)
    if not item_norm:
        return []
    candidatos: List[str] = []
    for chave, grupo in regras.items():
        if chave in ("stop_words", "vetor_inc") or not isinstance(grupo, list):
            continue
        for regra in grupo:
            ci = normalizar_texto(regra.get("Configuration item") or "")
            if ci and (ci in item_norm or item_norm in ci):
                candidatos.append(chave)
                break
    return candidatos


def encontrar_melhor_regra_por_item(
    texto_chamado: str, item_texto: str, regras: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """
    Igual a 'encontrar_melhor_regra', mas restringe a busca primeiro aos
    vetores cujo 'Configuration item' bate com o campo "Item" do chamado
    (sys_display.sc_task.request_item.cat_item - único campo confiável no
    SCTASK, já que 'Configuration Item'/'Assignment group' vêm vazios por
    padrão). Encontrando algo dentro desse(s) vetor(es), devolve - senão (Item
    vazio, sem vetor batendo, ou nenhum Topic bateu dentro do(s) candidato(s)),
    cai para a busca global de 'encontrar_melhor_regra' (nunca deixa de tentar
    por causa disso).
    """
    vetores = _vetores_candidatos_por_item(item_texto, regras)
    if vetores:
        regras_filtradas = {"stop_words": regras.get("stop_words", [])}
        regras_filtradas.update({chave: regras[chave] for chave in vetores})
        regra = encontrar_melhor_regra(texto_chamado, regras_filtradas)
        if regra:
            return regra
    return encontrar_melhor_regra(texto_chamado, regras)


def obter_config_inc(regras: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Config fixa de INC (analista/grupo/estado únicos, sem motor de regra) - 1º
    item de 'vetor_inc' no JSON (chaves: "Assignment_group", "Assigned_to",
    "State", "Time" - únicos com esse nome, diferente dos "Assigned to"/
    "Assignment group" dos vetores de SCTASK).
    """
    grupo = regras.get("vetor_inc")
    if isinstance(grupo, list) and grupo:
        return grupo[0]
    return None

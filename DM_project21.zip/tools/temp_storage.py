"""
================================================================================
PASTA TEMPORÁRIA DA AUTOMAÇÃO ('path_temp')
================================================================================
Centraliza a criação da pasta 'path_temp' na raiz do projeto (mesmo padrão do
'cadastro_exemplo': create_path_temp() vindo de src.Commons). Todo arquivo
baixado (ex: anexo .xlsx do ServiceNow) ou gerado durante a automação (ex:
screenshot de evidência do reset de senha) deve ser salvo aqui.

Por ser uma pasta FIXA na raiz do projeto (e não um diretório temporário do
SO que se autodestrói), os arquivos permanecem disponíveis para consulta e
diagnóstico manual caso a automação falhe no meio do processamento.
"""

import os
import shutil
import logging

logger = logging.getLogger("TempStorage")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATH_TEMP = os.path.join(PROJECT_ROOT, "path_temp")


def create_path_temp() -> str:
    """Garante a existência da pasta temporária 'path_temp' e retorna seu caminho absoluto."""
    os.makedirs(PATH_TEMP, exist_ok=True)
    return PATH_TEMP


def limpar_path_temp() -> str:
    """
    Remove todo o CONTEÚDO de 'path_temp' (arquivos e subpastas), preservando a
    pasta em si, e devolve seu caminho absoluto. Nunca lança exceção - uma falha ao
    remover um item específico só gera um warning no log e a limpeza segue para os
    demais itens (mesmo espírito de nunca derrubar a automação por causa de uma
    pendência de limpeza).

    Chamada no início de qualquer automação que deva começar com 'path_temp' vazio
    (ver 'system.routes.download_servicenow_export' e
    'portal_task.routes.execute_portal_task') - antes só existia dentro do primeiro,
    duplicada; centralizada aqui para os dois (e futuros) chamadores reaproveitarem.
    """
    dest_dir = create_path_temp()
    for nome in os.listdir(dest_dir):
        caminho = os.path.join(dest_dir, nome)
        try:
            if os.path.isfile(caminho) or os.path.islink(caminho):
                os.remove(caminho)
            elif os.path.isdir(caminho):
                shutil.rmtree(caminho)
        except Exception as e:
            logger.warning(f"⚠️ Falha ao limpar '{caminho}' de path_temp: {e}")
    return dest_dir

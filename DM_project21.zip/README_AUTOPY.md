# Guia: Como Transformar o App Flask em `.exe` com auto-py-to-exe (Estrutura por Pastas de Módulo)

Este guia explica como compilar este projeto Flask em um único aplicativo executável para Windows/Mac usando o `auto-py-to-exe` com o arquivo de entrada único `main.py` e estrutura de pastas modulares (`src/modules/`).

---

## 1. Instalar Dependências

No terminal da pasta do projeto:

```bash
pip install -r requirements.txt
```

Para abrir a interface gráfica do `auto-py-to-exe`:

```bash
auto-py-to-exe
```

---

## 2. Configuração no `auto-py-to-exe` (Interface Gráfica)

No navegador:

1. **Script Location (Local do Script):**
   - Selecione o arquivo principal: **`main.py`** (Único ponto de entrada do projeto na raiz).

2. **One File / One Directory:**
   - Selecione **One Directory** (Recomendado) ou **One File**.

3. **Console Window:**
   - Selecione **Console Based** ou **Window Based**.

4. **Additional Files (Arquivos Adicionais - IMPORTANTE):**
   - Clique em **Add Folder** e adicione a pasta inteira `src`:
     - Pasta `src` → Destination: `src`

---

## 3. Rodando pelo Terminal com PyInstaller (Linha de Comando)

### No Windows (Prompt / PowerShell):
```cmd
pyinstaller --noconfirm --onedir --console --add-data "src;src" main.py
```

### No macOS / Linux:
```bash
pyinstaller --noconfirm --onedir --console --add-data "src:src" main.py
```

---

## 4. Como Executar o App Gerado

Após a compilação, o executável estará na pasta `dist/main/` (ou `dist/main.exe`).

1. Execute `main.exe` (Windows) ou `./main` (Mac).
2. O servidor Flask iniciará em `http://127.0.0.1:5790`.
3. O banco de dados SQLite (`database.db`) será mantido em `instance/database.db` ao lado do executável.

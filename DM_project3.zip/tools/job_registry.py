"""
================================================================================
REGISTRO CENTRAL DE JOBS DE AUTOMAÇÃO (PLAYWRIGHT) ATIVOS
================================================================================
Módulo compartilhado (não pertence a nenhuma tela específica) responsável por
rastrear as automações Playwright em execução no processo Flask, permitindo que
o botão "Cancelar" de QUALQUER tela realmente interrompa a automação em
andamento — encerrando à força o navegador/contexto Playwright daquele job.

REUSO POR HERANÇA: é consumido diretamente por 'tools.base_automation.BaseAutomation'
(a classe-mãe de TODAS as automações do sistema: ServiceNowDriver, UpmDriver,
ReleaseOpenService, ReleaseCloseService, TaskEncerrarService, CadastroUsuarioService,
etc.). Qualquer tela cujo serviço reutilize 'launch_persistent_context' /
'close_context' / 'run_concurrent_tasks' herdados de BaseAutomation ganha
suporte a cancelamento automaticamente, sem reimplementar nada - basta a rota
gerar um 'job_id' e repassá-lo até o serviço.

COMO FUNCIONA O CANCELAMENTO ENTRE THREADS:
Cada requisição Flask que dispara uma automação roda seu próprio event loop
asyncio dentro da própria thread da requisição (padrão já usado em todo o
projeto: 'asyncio.new_event_loop()' + 'loop.run_until_complete(...)'; o
servidor Flask roda com threaded=True para permitir requisições concorrentes).
O botão Cancelar dispara uma requisição HTTP SEPARADA (processada em outra
thread), que localiza o job pelo 'job_id' e usa
'asyncio.run_coroutine_threadsafe(context.close(), loop)' para agendar o
fechamento do navegador diretamente no event loop ORIGINAL que está executando
a automação. Isso derruba o processo do navegador imediatamente, e qualquer
operação Playwright pendente (goto, click, fill, wait_for_selector, etc.)
levanta 'TargetClosedError', interrompendo a automação pelos próprios blocos
try/except já existentes em cada serviço. Validado com um teste de integração
real (Playwright + threading) antes desta implementação.
"""

import asyncio
import logging
import threading
import time
from concurrent.futures import TimeoutError as FutureTimeoutError
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

logger = logging.getLogger("JobRegistry")


@dataclass
class _JobEntry:
    user_id: Any
    module: str = ""
    loop: Optional[asyncio.AbstractEventLoop] = None
    context: Optional[Any] = None
    cancel_requested: bool = False
    created_at: float = field(default_factory=time.time)


class JobRegistry:
    """Registro global thread-safe de jobs de automação (Playwright) ativos no processo."""

    def __init__(self):
        self._jobs: Dict[str, _JobEntry] = {}
        self._lock = threading.Lock()

    def register(self, job_id: str, user_id: Any, module: str = ""):
        """Registra um novo job assim que a rota começa a processar a automação."""
        if not job_id:
            return
        with self._lock:
            self._jobs[job_id] = _JobEntry(user_id=user_id, module=module)
        logger.info(f"🆕 [JobRegistry] Job '{job_id}' registrado (usuário={user_id}, módulo='{module}').")

    def set_loop(self, job_id: str, loop: asyncio.AbstractEventLoop):
        """Associa o event loop asyncio responsável por executar o job."""
        if not job_id:
            return
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry:
                entry.loop = loop

    def attach_context(self, job_id: str, context: Any):
        """
        Associa o BrowserContext do Playwright em execução ao job. Chamado
        automaticamente por 'BaseAutomation.launch_persistent_context()' quando
        um 'job_id' é informado - nenhuma classe filha precisa chamar isso.
        """
        if not job_id:
            return
        cancelado = False
        user_id = None
        with self._lock:
            entry = self._jobs.get(job_id)
            if entry:
                entry.context = context
                cancelado = entry.cancel_requested
                user_id = entry.user_id
        if cancelado:
            # Cancelamento já havia sido solicitado antes do navegador terminar de abrir
            # (ex.: usuário clicou em Cancelar durante o login Okta) - aplica agora.
            logger.info(f"⏭️ [JobRegistry] Job '{job_id}' já tinha cancelamento pendente - aplicando agora que o navegador abriu.")
            self.cancel(job_id, user_id, _internal=True)

    def is_cancelled(self, job_id: str) -> bool:
        """Checagem cooperativa - usada entre itens de um lote (BaseAutomation.run_concurrent_tasks)."""
        if not job_id:
            return False
        with self._lock:
            entry = self._jobs.get(job_id)
            return bool(entry and entry.cancel_requested)

    def unregister(self, job_id: str):
        """Remove o job do registro assim que a automação finaliza (sucesso, erro ou cancelamento)."""
        if not job_id:
            return
        with self._lock:
            self._jobs.pop(job_id, None)
        logger.info(f"🏁 [JobRegistry] Job '{job_id}' removido do registro.")

    def cancel(self, job_id: str, requesting_user_id: Any, _internal: bool = False) -> Dict[str, str]:
        """
        Solicita o cancelamento de um job ativo. Só o próprio usuário dono do
        job pode cancelá-lo (checagem ignorada quando '_internal=True', usado
        apenas pelo próprio registro para aplicar um cancelamento que já havia
        sido sinalizado antes do navegador terminar de abrir).
        """
        with self._lock:
            entry = self._jobs.get(job_id)
            if not entry:
                return {"status": "not_found", "message": "Nenhuma automação ativa encontrada para este identificador (pode já ter finalizado)."}

            if not _internal and str(entry.user_id) != str(requesting_user_id):
                return {"status": "forbidden", "message": "Você não tem permissão para cancelar esta automação."}

            entry.cancel_requested = True
            loop = entry.loop
            context = entry.context

        logger.warning(f"🛑 [JobRegistry] Cancelamento solicitado para o job '{job_id}'.")

        if not context or not loop:
            # Navegador ainda não abriu (ex.: aguardando Okta) - a flag 'cancel_requested'
            # garante que a automação para assim que 'attach_context' for chamado.
            return {"status": "pending", "message": "Cancelamento sinalizado. A automação será interrompida assim que possível."}

        try:
            future = asyncio.run_coroutine_threadsafe(context.close(), loop)
            try:
                future.result(timeout=5)
                logger.warning(f"✅ [JobRegistry] Navegador do job '{job_id}' encerrado à força com sucesso.")
            except FutureTimeoutError:
                # O fechamento pode ter "corrido" com o próprio cleanup da automação
                # (que também fecha o contexto no finally) e nunca confirmar de volta -
                # o efeito real (derrubar o navegador) já acontece de forma rápida e
                # confiável mesmo quando essa confirmação não chega a tempo.
                logger.warning(f"⏱️ [JobRegistry] context.close() do job '{job_id}' não confirmou em 5s (provável corrida com o cleanup da própria automação) - seguindo em frente.")
            return {"status": "cancelled", "message": "Automação cancelada: o navegador foi encerrado."}
        except Exception as e:
            logger.error(f"❌ [JobRegistry] Erro ao encerrar à força o job '{job_id}': {e}")
            return {"status": "error", "message": f"Falha ao cancelar automação: {e}"}


# Instância única compartilhada por todo o processo Flask (importada por qualquer módulo/rota).
job_registry = JobRegistry()

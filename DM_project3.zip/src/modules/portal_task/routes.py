import os
import asyncio
import logging
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from src.models import db, PortalTaskConfig
from tools import OktaAuthManager
from tools.job_registry import job_registry
from playwright.async_api import async_playwright

# Importação dos 7 serviços exclusivos locais do módulo portal_task
from src.modules.portal_task.user_cadastro_service import CadastroUsuarioService
from src.modules.portal_task.assessoria_cadastro_service import AssessoriaCadastroService
from src.modules.portal_task.user_desabilitar_service import UserDesabilitarService
from src.modules.portal_task.user_alterar_service import UserAlterarService
from src.modules.portal_task.password_reset_service import PasswordResetService
from src.modules.portal_task.mfa_reset_service import MfaResetService
from src.modules.portal_task.task_encerrar_service import TaskEncerrarService

logger = logging.getLogger("PortalTask")

current_dir = os.path.dirname(os.path.abspath(__file__))
portal_task_bp = Blueprint('portal_task', __name__, template_folder=current_dir)

# Dicionário de Mapeamento Direto das Ações do Dropdown para os Serviços Exclusivos do Módulo
SERVICES_MAP = {
    "Cadastro de usuário": CadastroUsuarioService,
    "Cadastro de assessoria": AssessoriaCadastroService,
    "Desabilitar usuário": UserDesabilitarService,
    "Alterar usuário": UserAlterarService,
    "Reset de senha": PasswordResetService,
    "Reset de mfa": MfaResetService,
    "Encerrar": TaskEncerrarService,
}

@portal_task_bp.route('/portal')
@portal_task_bp.route('/portal_task')
@login_required
def index():
    """Renders Portal Task dashboard page with user's saved SQLite configuration."""
    config = PortalTaskConfig.get_or_create(current_user.id)
    return render_template('portal_task.html', user=current_user, active_page='portal_task', config=config)

def _update_config_from_data(config, data):
    """Atualiza as propriedades da entidade PortalTaskConfig com os dados fornecidos."""
    config.url_cadastrar = data.get('url_cadastrar', config.url_cadastrar)
    config.url_reset_senha = data.get('url_reset_senha', config.url_reset_senha)
    config.url_reset_mfa = data.get('url_reset_mfa', config.url_reset_mfa)
    config.url_encerrar = data.get('url_encerrar', config.url_encerrar)
    config.url_desabilitar = data.get('url_desabilitar', config.url_desabilitar)
    config.output_format = data.get('output_format', config.output_format)
    config.output_directory = data.get('output_directory', config.output_directory)
    config.headless = data.get('headless', config.headless)

    # Opções do Modal Alterar usuário & Ação Selecionada
    config.automation_action = data.get('automation_action', config.automation_action)
    if 'alt_is_assessoria' in data:
        config.alt_is_assessoria = bool(data.get('alt_is_assessoria'))
    config.alt_de_email = data.get('alt_de_email', config.alt_de_email)
    config.alt_de_ritm = data.get('alt_de_ritm', config.alt_de_ritm)
    config.alt_para_email = data.get('alt_para_email', config.alt_para_email)
    config.alt_para_cnpj = data.get('alt_para_cnpj', config.alt_para_cnpj)
    config.alt_para_nome = data.get('alt_para_nome', config.alt_para_nome)
    config.alt_para_produto_id = data.get('alt_para_produto_id', config.alt_para_produto_id)

@portal_task_bp.route('/api/portal/save_config', methods=['POST'])
@login_required
def save_config():
    """Salva permanentemente as URLs, modal e caminhos no banco de dados SQLite."""
    data = request.get_json() or {}
    config = PortalTaskConfig.get_or_create(current_user.id)

    _update_config_from_data(config, data)
    db.session.commit()
    logger.info(f"✅ Configurações e modal do Portal Task salvos no banco de dados para usuário ID {current_user.id}.")

    return jsonify({'status': 'success', 'message': 'Configurações salvas no banco de dados com sucesso!'})

@portal_task_bp.route('/api/portal/execute', methods=['POST'])
@login_required
def execute_portal_task():
    """
    ============================================================================
    DESPACHO DE AUTOMAÇÃO VIA SERVIÇOS EXCLUSIVOS DO PORTAL TASK
    ============================================================================
    1. Salva a configuração atualizada no banco de dados SQLite.
    2. Identifica qual a ação escolhida ('automation_action').
    3. Mapeia e instancia a classe de serviço dedicada localizada em 'src/modules/portal_task/'.
    4. Executa as URLs em lote com Semáforo (max_concurrency=3) assíncrono.
    """
    data = request.get_json() or {}
    
    # 1. Salva as configurações atualizadas no SQLite
    config = PortalTaskConfig.get_or_create(current_user.id)
    _update_config_from_data(config, data)
    db.session.commit()

    # 2. Obtém parâmetros da requisição
    urls = data.get('urls', [])
    headless = data.get('headless', True)
    output_format = data.get('output_format', 'excel')
    output_dir = data.get('output_directory', './downloads')
    action_name = config.automation_action or "Cadastro de usuário"
    # Gerado no navegador ao iniciar a automação, para permitir que o botão "Cancelar"
    # a identifique e a encerre a partir de outra requisição (ver tools/job_registry.py).
    job_id = (data.get('job_id') or '').strip()

    if not urls:
        return jsonify({'status': 'error', 'message': 'Nenhuma URL fornecida para processamento.'}), 400

    # 3. Busca a classe de serviço especialista do mapa SERVICES_MAP
    service_class = SERVICES_MAP.get(action_name, CadastroUsuarioService)
    automation_handler = service_class()
    logger.info(f"🚀 [PortalTask API] Ação '{action_name}' despachada para o serviço exclusivo: {automation_handler.__class__.__name__}")

    extra_params = {
        "alt_is_assessoria": config.alt_is_assessoria,
        "alt_de_email": config.alt_de_email,
        "alt_de_ritm": config.alt_de_ritm,
        "alt_para_email": config.alt_para_email,
        "alt_para_cnpj": config.alt_para_cnpj,
        "alt_para_nome": config.alt_para_nome,
        "alt_para_produto_id": config.alt_para_produto_id
    }

    # 4. Execução Assíncrona via Playwright e Semáforo
    async def run_automation():
        async with async_playwright() as p:
            context = await automation_handler.launch_persistent_context(p, headless=headless, job_id=job_id)
            try:
                if urls:
                    check_page = await context.new_page()
                    await OktaAuthManager.wait_for_okta_login_if_needed(check_page, urls[0])
                    await check_page.close()

                # Executa concorrentemente 1 ou N URLs utilizando o método do serviço dedicado
                results = await automation_handler.executar_lote_concorrente(
                    context=context,
                    urls=urls,
                    max_concurrency=3,
                    dados_formulario=extra_params
                )
                return results
            finally:
                await automation_handler.close_context(context)

    if job_id:
        job_registry.register(job_id, current_user.id, module='portal_task')

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    if job_id:
        job_registry.set_loop(job_id, loop)
    try:
        results = loop.run_until_complete(run_automation())
        return jsonify({
            'status': 'success',
            'automation_action': action_name,
            'handler_class': automation_handler.__class__.__name__,
            'output_format': output_format,
            'output_directory': output_dir,
            'results': results,
            'job_id': job_id,
        })
    except Exception as e:
        logger.error(f"❌ Erro na execução da automação {action_name}: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        loop.close()
        if job_id:
            job_registry.unregister(job_id)

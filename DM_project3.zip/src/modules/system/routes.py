"""
================================================================================
ENDPOINT COMPARTILHADO: CANCELAMENTO DE AUTOMAÇÃO (PLAYWRIGHT) ATIVA
================================================================================
Blueprint exclusivo para o botão "Cancelar" de QUALQUER tela do sistema
(Release task, Portal task, etc.). Não pertence a nenhum módulo de negócio
específico - fica em 'src/modules/system' justamente para ser reutilizado por
herança de template/JS em todas as telas, sem duplicar rota nenhuma.

Delega toda a lógica real para 'tools.job_registry.job_registry' (ver docstring
daquele módulo para o mecanismo completo de cancelamento entre threads).
"""

import os
import logging
from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from tools.job_registry import job_registry

logger = logging.getLogger("SystemJobs")

current_dir = os.path.dirname(os.path.abspath(__file__))
system_bp = Blueprint('system', __name__, template_folder=current_dir)


@system_bp.route('/system/cancel_job', methods=['POST'])
@login_required
def cancel_job():
    """
    Cancela a automação Playwright ativa identificada por 'job_id' (gerado no
    navegador quando a automação é iniciada). Só o usuário dono do job pode
    cancelá-lo.
    """
    data = request.get_json() or {}
    job_id = (data.get('job_id') or '').strip()

    if not job_id:
        return jsonify({'status': 'error', 'message': "Nenhum 'job_id' informado."}), 400

    resultado = job_registry.cancel(job_id, current_user.id)
    logger.info(f"Cancelamento solicitado por usuário {current_user.id} para job '{job_id}': {resultado}")

    http_status = {
        'cancelled': 200,
        'pending': 200,
        'not_found': 404,
        'forbidden': 403,
        'error': 500,
    }.get(resultado.get('status'), 200)

    return jsonify(resultado), http_status

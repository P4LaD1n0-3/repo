import os
import re
import asyncio
import logging
import datetime
from flask import Blueprint, render_template, request, jsonify, flash
from flask_login import login_required, current_user
from src.models import db, ReleaseTaskConfig
from src.modules.release_task.release_open_service import ReleaseOpenService
from src.modules.release_task.release_close_service import ReleaseCloseService
from src.modules.release_task.release_mailer import ReleaseMailer
from tools.job_registry import job_registry

logger = logging.getLogger("ReleaseTask")

current_dir = os.path.dirname(os.path.abspath(__file__))
release_task_bp = Blueprint('release_task', __name__, template_folder=current_dir)

# Formato de horário aceito no campo "Open": HH:MM (24h, sem segundos).
# Preencher este campo (ex.: com o horário atual da máquina) é o que dispara a ABERTURA
# de uma nova Release; deixá-lo vazio e preencher "Release" dispara o ENCERRAMENTO.
OPEN_TIME_REGEX = re.compile(r'^([01]\d|2[0-3]):[0-5]\d$')


@release_task_bp.route('/release_task')
@login_required
def index():
    config = ReleaseTaskConfig.get_or_create(current_user.id)
    return render_template('release_task.html', user=current_user, active_page='release_task', config=config)


def _update_config_from_data(config, data):
    """Atualiza as propriedades da entidade ReleaseTaskConfig com os dados fornecidos."""
    if 'assigned_to_ebao' in data:
        config.assigned_to_ebao = data['assigned_to_ebao']
    if 'assigned_to_portal' in data:
        config.assigned_to_portal = data['assigned_to_portal']
    if 'assigned_to_dba' in data:
        config.assigned_to_dba = data['assigned_to_dba']
    if 'copy' in data:
        config.copy = data['copy']
    if 'open_time' in data:
        config.open_time = data['open_time']
    if 'release_number' in data:
        config.release_number = data['release_number']
    if 'choice' in data:
        config.choice = data['choice']
    if 'rlese' in data:
        config.rlese = data['rlese']
    if 'chg' in data:
        config.chg = data['chg']
    if 'ebao_link' in data:
        config.ebao_link = data['ebao_link']
    if 'portal_link' in data:
        config.portal_link = data['portal_link']
    if 'ebao_configuration_item' in data:
        config.ebao_configuration_item = data['ebao_configuration_item']
    if 'portal_configuration_item' in data:
        config.portal_configuration_item = data['portal_configuration_item']
    if 'open_hour' in data:
        config.open_hour = data['open_hour']
    if 'close_hour' in data:
        config.close_hour = data['close_hour']


@release_task_bp.route('/release_task/save_config', methods=['POST'])
@login_required
def save_config():
    try:
        data = request.get_json() or {}
        config = ReleaseTaskConfig.get_or_create(current_user.id)
        _update_config_from_data(config, data)
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Configuração atualizada com sucesso!'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500


def _criar_coletor_logs():
    """Cria uma função de callback de mensagens (equivalente ao 'MSG'/'add_msg_rt' do legado)."""
    logs = []

    def add_message(msg: str):
        timestamp = datetime.datetime.now().strftime("%H:%M:%S")
        entrada = f"{timestamp} {msg}"
        logger.info(entrada)
        logs.append(entrada)

    return logs, add_message


def _executar_em_novo_loop(coro_factory, job_id: str = ""):
    """
    Executa uma corrotina Playwright em um novo event loop dedicado (mesmo padrão de
    create_ctask/portal_task). Registra o event loop no 'JobRegistry' compartilhado
    (se 'job_id' for informado) para que o botão "Cancelar" consiga interromper esta
    automação a partir de OUTRA requisição/thread (ver tools/job_registry.py).
    """
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    if job_id:
        job_registry.set_loop(job_id, loop)
    try:
        return loop.run_until_complete(coro_factory())
    finally:
        loop.close()
        if job_id:
            job_registry.unregister(job_id)


def _executar_abertura(config, headless: bool, job_id: str = "", usar_data_hoje: bool = False):
    """Dispara a ABERTURA de uma nova Release (EBAO + PORTAL em paralelo)."""
    logs, add_message = _criar_coletor_logs()
    service = ReleaseOpenService()

    resultados = _executar_em_novo_loop(lambda: service.executar_abertura(
        assigned_to_ebao=config.assigned_to_ebao or "",
        assigned_to_portal=config.assigned_to_portal or "",
        ebao_link=config.ebao_link or "",
        portal_link=config.portal_link or "",
        add_message=add_message,
        headless=headless,
        job_id=job_id,
        usar_data_hoje=usar_data_hoje,
        ebao_configuration_item=config.ebao_configuration_item or "EBAO-BRAZIL-Production",
        portal_configuration_item=config.portal_configuration_item or "Portal Corretor-Production",
        open_hour=config.open_hour or "12:00:02",
        close_hour=config.close_hour or "12:00:02",
    ), job_id=job_id)
    return logs, resultados


def _executar_encerramento(config, release_number: str, headless: bool, job_id: str = ""):
    """Dispara o ENCERRAMENTO de uma ou mais Releases (separadas por vírgula)."""
    logs, add_message = _criar_coletor_logs()
    service = ReleaseCloseService()

    resultados = _executar_em_novo_loop(lambda: service.executar_encerramento(
        dba_name=config.assigned_to_dba or "",
        release_n=release_number,
        sigla=current_user.display_servicenow_name,
        add_message=add_message,
        headless=headless,
        job_id=job_id,
    ), job_id=job_id)
    return logs, resultados


def _executar_envio_email_manual(config, rlese: str, chg: str, choice: str, usar_data_hoje: bool = False):
    """
    Dispara o envio MANUAL do e-mail de aprovação da Change DML para um RLSE/CHG
    já existentes (equivalente a 'enviar_email_manual' do legado).
    """
    logs, add_message = _criar_coletor_logs()

    selecao = {"Ebao": config.assigned_to_ebao or "", "Portal": config.assigned_to_portal or ""}
    destino = selecao.get(choice, config.assigned_to_ebao or "")
    ambiente = (choice or "Ebao").upper()

    if usar_data_hoje:
        add_message("Flag 'Abrir com a data de hoje' ATIVA - o e-mail destacará a data de HOJE, não D+1.")
    add_message(f"Enviando e-mail de aprovação para {ambiente} - {rlese} - {chg}...")

    mailer = ReleaseMailer()
    sucesso, mensagem = mailer.send_approval_email(
        rlse_number=rlese,
        chg_number=chg,
        ambiente=ambiente,
        send_to_valor=destino,
        assinatura_nome=current_user.display_signature_name,
        assinatura_email=current_user.email,
        copia=config.copy or "",
        usar_data_hoje=usar_data_hoje,
    )

    if sucesso:
        add_message(f"E-mail enviado com sucesso. {ambiente} - {rlese} - {chg}")
        flash(f"E-mail enviado com sucesso. {ambiente} - {rlese} - {chg}", "success")
    else:
        add_message(f"Erro ao enviar e-mail. {ambiente} - {rlese} - {chg}")
        flash(f"Erro ao enviar e-mail. {ambiente} - {rlese} - {chg}", "error")

    return logs, {'status': 'success' if sucesso else 'error', 'message': mensagem}


@release_task_bp.route('/release_task/execute', methods=['POST'])
@login_required
def execute():
    try:
        data = request.get_json() or {}

        assigned_ebao = data.get('assigned_to_ebao', '')
        assigned_portal = data.get('assigned_to_portal', '')
        assigned_dba = data.get('assigned_to_dba', '')
        copy = data.get('copy', '')
        open_time = (data.get('open_time') or '').strip()
        release_number = (data.get('release_number') or '').strip()
        choice = data.get('choice', 'Ebao')
        rlese = (data.get('rlese') or '').strip()
        chg = (data.get('chg') or '').strip()
        ebao_link = data.get('ebao_link', '')
        portal_link = data.get('portal_link', '')
        ebao_configuration_item = data.get('ebao_configuration_item', '') or 'EBAO-BRAZIL-Production'
        portal_configuration_item = data.get('portal_configuration_item', '') or 'Portal Corretor-Production'
        open_hour = data.get('open_hour', '') or '12:00:02'
        close_hour = data.get('close_hour', '') or '12:00:02'
        headless = bool(data.get('headless', False))
        # Gerado no navegador ao iniciar a automação, para permitir que o botão
        # "Cancelar" a identifique e a encerre a partir de outra requisição (ver
        # tools/job_registry.py). Se não vier informado, ainda funciona - só não é cancelável.
        job_id = (data.get('job_id') or '').strip()
        # Flag "Abrir com a data de hoje" (D+0 em vez de D+1) - NUNCA persistida no banco de
        # propósito: precisa ser marcada de novo a cada execução especial, exatamente para
        # evitar o mesmo risco do ajuste manual no código-fonte do sistema legado (esquecer
        # de reverter e acabar aplicando D+0 nos dias seguintes). Ver ReleaseMailer.calcular_datas_execucao.
        usar_data_hoje = bool(data.get('usar_data_hoje', False))

        # 1. Persiste a configuração atualizada no banco antes de decidir a ação
        config = ReleaseTaskConfig.get_or_create(current_user.id)
        config.assigned_to_ebao = assigned_ebao
        config.assigned_to_portal = assigned_portal
        config.assigned_to_dba = assigned_dba
        config.copy = copy
        config.open_time = open_time
        config.release_number = release_number
        config.choice = choice
        config.rlese = rlese
        config.chg = chg
        config.ebao_link = ebao_link
        config.portal_link = portal_link
        config.ebao_configuration_item = ebao_configuration_item
        config.portal_configuration_item = portal_configuration_item
        config.open_hour = open_hour
        config.close_hour = close_hour
        db.session.commit()

        # 2. Dispatch: o campo preenchido decide qual automação roda.
        #    - "Open" preenchido (formato de horário HH:MM[:SS])  -> ABRE nova Release (EBAO + PORTAL)
        #    - "Release" preenchido (1 ou mais números, separados por vírgula) -> ENCERRA a(s) Release(s)
        #    - "RLESE" + "CHG" preenchidos (sem os dois acima) -> envia e-mail de aprovação manual
        if open_time:
            if not OPEN_TIME_REGEX.match(open_time):
                return jsonify({
                    'status': 'error',
                    'message': "Campo 'Open' inválido. Preencha um horário no formato HH:MM (ex.: horário atual da máquina)."
                }), 400

            action = 'open'
            if job_id:
                job_registry.register(job_id, current_user.id, module='release_task:open')
            logs, resultados = _executar_abertura(config, headless, job_id=job_id, usar_data_hoje=usar_data_hoje)

        elif release_number:
            action = 'close'
            if job_id:
                job_registry.register(job_id, current_user.id, module='release_task:close')
            logs, resultados = _executar_encerramento(config, release_number, headless, job_id=job_id)

        elif rlese and chg:
            action = 'email'
            logs, resultados = _executar_envio_email_manual(config, rlese, chg, choice, usar_data_hoje=usar_data_hoje)

        else:
            return jsonify({
                'status': 'error',
                'message': "Preencha o campo 'Open' (para abrir uma nova Release) ou 'Release' (para encerrar)."
            }), 400

        return jsonify({'status': 'success', 'action': action, 'logs': logs, 'result': resultados, 'job_id': job_id})

    except Exception as e:
        logger.exception(f"Erro na execução da automação Release task: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

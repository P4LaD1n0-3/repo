"""
================================================================================
LOCALIZAÇÃO DE E-MAIL ANTIGO POR CPF (HISTÓRICO DE USUÁRIOS)
================================================================================
Replica o mecanismo de 'cadastro_usuario.txt' usado no branch "CPF existe com
o usuário diferente": quando o UPM recusa o cadastro porque o CPF já pertence
a OUTRO e-mail, o script legado abria uma planilha de controle/histórico de
usuários (coluna C = e-mail, coluna D = CPF formatado com pontuação) para
achar o e-mail antigo associado a esse CPF, inativar aquela conta no UPM e
reaproveitá-la com os dados novos (ver 'PortalTaskUpmService.resolver_cpf_existente').

DIFERENÇA DELIBERADA EM RELAÇÃO AO ORIGINAL: o script legado pegava "o
segundo arquivo" da pasta às cegas (`os.listdir("src/documents")[1]`), sem
validar se era realmente a planilha certa - qualquer outro arquivo salvo
naquela pasta quebrava essa busca silenciosamente. Aqui, em vez de confiar na
ordem/posição dos arquivos, TODAS as planilhas .xlsx do diretório configurado
são varridas em busca do CPF - mesma fonte de dados (planilha em disco),
localização mais robusta.
"""

import glob
import logging
import os
import re
from typing import Optional

import openpyxl

logger = logging.getLogger("HistoricoUsuarios")

# Diretório onde fica a(s) planilha(s) de histórico/controle de usuários -
# equivalente ao antigo 'src/documents' do script legado. Configurável via
# .env (HISTORICO_USUARIOS_DIR) pois esse diretório não existe por padrão
# nesta estrutura de projeto.
DEFAULT_DIR = os.environ.get("HISTORICO_USUARIOS_DIR", "src/documents")

# Colunas da planilha histórica (1-based): C = e-mail, D = CPF formatado.
COLUNA_EMAIL = 3
COLUNA_CPF = 4


def _formatar_cpf_com_pontuacao(cpf: str) -> str:
    """111.444.777-35 - mesmo formato usado na coluna D da planilha histórica."""
    digitos = re.sub(r"\D", "", cpf or "")
    if len(digitos) != 11:
        return cpf or ""
    return re.sub(r"(\d{3})(\d{3})(\d{3})(\d{2})", r"\1.\2.\3-\4", digitos)


def localizar_email_por_cpf(cpf: str, diretorio: Optional[str] = None) -> Optional[str]:
    """
    Varre todas as planilhas .xlsx do diretório histórico procurando o CPF
    (coluna D, formatado com pontuação) e devolve o e-mail associado (coluna C).

    Nunca lança exceção: devolve None se o diretório/planilhas não existirem
    ou o CPF não for encontrado - quem chama trata isso como pendência manual,
    no mesmo espírito das demais consultas deste projeto (nunca derrubar a
    automação por falta de um dado auxiliar).
    """
    diretorio = diretorio or DEFAULT_DIR
    cpf_formatado = _formatar_cpf_com_pontuacao(cpf)

    if not cpf_formatado:
        logger.warning(f"⚠️ [HistoricoUsuarios] CPF '{cpf}' inválido para busca no histórico.")
        return None

    if not os.path.isdir(diretorio):
        logger.warning(f"⚠️ [HistoricoUsuarios] Diretório histórico '{diretorio}' não encontrado - pulando busca por CPF.")
        return None

    arquivos = sorted(glob.glob(os.path.join(diretorio, "*.xlsx")))
    if not arquivos:
        logger.warning(f"⚠️ [HistoricoUsuarios] Nenhuma planilha .xlsx encontrada em '{diretorio}'.")
        return None

    for caminho in arquivos:
        try:
            workbook = openpyxl.load_workbook(caminho, data_only=True, read_only=True)
            planilha = workbook.active
            for linha in planilha.iter_rows(min_row=2, values_only=True):
                if len(linha) < COLUNA_CPF:
                    continue
                email_col = linha[COLUNA_EMAIL - 1]
                cpf_col = linha[COLUNA_CPF - 1]
                if cpf_col is not None and str(cpf_col).strip() == cpf_formatado:
                    email_antigo = str(email_col).strip() if email_col else None
                    logger.info(
                        f"✅ [HistoricoUsuarios] CPF '{cpf_formatado}' localizado em "
                        f"'{os.path.basename(caminho)}' -> e-mail antigo: {email_antigo}"
                    )
                    return email_antigo
            workbook.close()
        except Exception as e:
            logger.warning(f"⚠️ [HistoricoUsuarios] Erro ao ler '{caminho}': {e}")
            continue

    logger.warning(f"⚠️ [HistoricoUsuarios] CPF '{cpf_formatado}' não encontrado em nenhuma planilha de '{diretorio}'.")
    return None

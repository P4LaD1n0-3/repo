from tools.base_automation import BaseAutomation, SelectorManager
from tools.servicenow_driver import ServiceNowDriver
from tools.upm_driver import UpmDriver
from tools.okta_auth import OktaAuthManager
from tools.smtp import enviar_email_automatico, SmtpMailer, send_outlook_windows, send_outlook_mac
from tools.database import (
    DatabaseMixin,
    DatabaseConnectionError,
    DatabaseQueryError,
    OracleConnection,
    SqlServerConnection,
)
from tools.validators import (
    validar_email,
    validar_nome_completo,
    validar_cpf,
    validar_cnpj,
    validar_susep_formato,
    validar_usuario_cadastro,
    extrair_emails_de_texto,
)
from tools.servicenow_batch_service import ServiceNowBatchService
from tools.portal_task_base_service import PortalTaskUpmService
from tools.historico_usuarios import localizar_email_por_cpf
from tools.sql_script_builder import gerar_sql_update_usuario, salvar_sql_alteracao_usuario

__all__ = [
    "BaseAutomation",
    "SelectorManager",
    "ServiceNowDriver",
    "UpmDriver",
    "OktaAuthManager",
    "enviar_email_automatico",
    "SmtpMailer",
    "send_outlook_windows",
    "send_outlook_mac",
    "ServiceNowBatchService",
    "PortalTaskUpmService",
    "localizar_email_por_cpf",
    "gerar_sql_update_usuario",
    "salvar_sql_alteracao_usuario",
    "extrair_emails_de_texto",
    "DatabaseMixin",
    "DatabaseConnectionError",
    "DatabaseQueryError",
    "OracleConnection",
    "SqlServerConnection",
    "validar_email",
    "validar_nome_completo",
    "validar_cpf",
    "validar_cnpj",
    "validar_susep_formato",
    "validar_usuario_cadastro",
]

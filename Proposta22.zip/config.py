# -*- coding: utf-8 -*-
"""
IT Metrics Dashboard - Configuration
=====================================
Paths, e-mail recipients and the download source URLs all come from a
`.env` file next to this script (see `.env.example` for the template) -
nothing environment-specific is hardcoded here anymore. Everything that's
unlikely to change between environments (SLA thresholds, chart colors,
aging buckets) stays as plain Python below.

Terminology mapping (this ServiceNow export uses INC / SCTASK / PRB):
    SCTASK  ~  "REQ" in the legacy dashboard (service catalog tasks / requests)
    INC     ~  "INC" in the legacy dashboard (incidents)
    PRB     ~  "PTASK" in the legacy dashboard (problem tasks)
"""
import os
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Loads BASE_DIR/.env into the process environment. Safe to call even if
# the file doesn't exist (os.environ just stays as it already was) - the
# defaults below keep the script runnable out of the box either way.
load_dotenv(os.path.join(BASE_DIR, ".env"))


def _env_str(key, default=""):
    return os.environ.get(key, default)


def _env_bool(key, default=True):
    raw = os.environ.get(key)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def _env_int(key, default):
    raw = os.environ.get(key)
    try:
        return int(raw) if raw not in (None, "") else default
    except ValueError:
        return default


def _env_float(key, default):
    raw = os.environ.get(key)
    try:
        return float(raw) if raw not in (None, "") else default
    except ValueError:
        return default


def _env_path(key, default_filename):
    """Resolves KEY from the environment to an absolute path. A bare
    filename (e.g. "incident.xlsx") is resolved relative to this script's
    folder; an absolute path is used as-is."""
    raw = os.environ.get(key, default_filename)
    return raw if os.path.isabs(raw) else os.path.join(BASE_DIR, raw)


def _env_recipient_list(key, default=""):
    """Splits a comma-separated address list from .env into a clean list -
    lets EMAIL_TO/EMAIL_CC target a whole distribution group, e.g.
    EMAIL_TO=alice@company.com,bob@company.com,it-leads@company.com"""
    raw = os.environ.get(key, default)
    return [addr.strip() for addr in raw.split(",") if addr.strip()]


# Outlook (both the Windows COM object and AppleScript) accepts multiple
# recipients as a single string separated by semicolons.
_EMAIL_TO_LIST = _env_recipient_list("EMAIL_TO", "recipient@company.com")
_EMAIL_CC_LIST = _env_recipient_list("EMAIL_CC", "")

CONFIG = {
    # --- Source files (ServiceNow exports) - names match the real table
    # names (incident.xlsx / sc_task.xlsx / problem_task.xlsx) by default,
    # overridable in .env. DOWNLOAD_DIR (see download_data.py) is where the
    # automated downloader saves them; point these at the same folder. ---
    "INC_PATH": _env_path("INC_PATH", os.path.join(_env_str("DOWNLOAD_DIR", "dates"), "incident.xlsx")),
    "SCTASK_PATH": _env_path("SCTASK_PATH", os.path.join(_env_str("DOWNLOAD_DIR", "dates"), "sc_task.xlsx")),
    "PRB_PATH": _env_path("PRB_PATH", os.path.join(_env_str("DOWNLOAD_DIR", "dates"), "problem_task.xlsx")),

    # --- Output ---
    "OUTPUT_HTML": _env_path("OUTPUT_HTML", "dashboard_report.html"),
    "SAVE_LOCAL_COPY": _env_bool("SAVE_LOCAL_COPY", True),

    # --- Email (group-friendly: comma-separate multiple addresses in .env) ---
    "EMAIL_TO": ";".join(_EMAIL_TO_LIST),
    "EMAIL_TO_LIST": _EMAIL_TO_LIST,
    "EMAIL_CC": ";".join(_EMAIL_CC_LIST),
    "EMAIL_CC_LIST": _EMAIL_CC_LIST,
    "EMAIL_SUBJECT_PREFIX": _env_str("EMAIL_SUBJECT_PREFIX", "IT Executive Dashboard - REQ x INC x PRB"),
    "SEND_EMAIL": _env_bool("SEND_EMAIL", True),

    # --- Reference date ---
    # None  -> use the real current date/time (normal production use)
    # "2026-07-24" -> pin a fixed date (useful to test against historical data)
    "REFERENCE_DATE": _env_str("REFERENCE_DATE", "") or None,

    # --- SLA targets, in calendar days (used for Inside/Outside SLA + aging) ---
    "SLA_DAYS": {
        "SCTASK": _env_int("SLA_DAYS_SCTASK", 10),
        "INC": _env_int("SLA_DAYS_INC", 7),
        "PRB": _env_int("SLA_DAYS_PRB", 10),
    },

    # --- Critical aging thresholds (days) used for the "Critical" call-out tables ---
    "CRITICAL_AGING_THRESHOLD": {
        "SCTASK": _env_int("CRITICAL_AGING_SCTASK", 20),
        "INC": _env_int("CRITICAL_AGING_INC", 7),
        "PRB": _env_int("CRITICAL_AGING_PRB", 15),
    },
    "SCTASK_EXTRA_CRITICAL_DAYS": _env_int("SCTASK_EXTRA_CRITICAL_DAYS", 30),

    # --- Manually curated ETA shown on the critical-REQ table (optional, free text) ---
    "ETA_LABEL": _env_str("ETA_LABEL", ""),

    # --- Analysis windows ---
    "MONTHS_LOOKBACK": _env_int("MONTHS_LOOKBACK", 6),
    "WEEKS_LOOKBACK": _env_int("WEEKS_LOOKBACK", 8),
    "DAILY_EVOLUTION_DAYS": _env_int("DAILY_EVOLUTION_DAYS", 10),

    # --- Chart image delivery ---
    # THREE layers, tried in order, each falling back to the next on failure:
    #   1) EMBED_CHARTS_AS_BASE64: fetch the actual PNG bytes from QuickChart
    #      and embed them directly in the HTML as data:image/png;base64,...
    #      No external request happens when the e-mail is opened - this is
    #      the most reliable option, since it survives Outlook's "block
    #      external images" policy (very common in corporate environments)
    #      AND the recipient being offline. Adds ~150-350KB to the e-mail
    #      for a full report (worth it for reliability).
    #   2) USE_SHORT_CHART_URLS: ask QuickChart to host the chart and embed
    #      the short URL it returns. Fixes the "URL too long" Outlook bug,
    #      but the recipient still needs to fetch it live from quickchart.io
    #      when they open the e-mail (blocked by "block external images").
    #   3) Long GET URL (last resort) - known to break in Outlook.
    # Both (1) and (2) need internet access when you RUN main.py (not when
    # the e-mail is read). Run main.py and check the console summary it
    # prints - it tells you exactly which layer each chart actually used.
    "EMBED_CHARTS_AS_BASE64": _env_bool("EMBED_CHARTS_AS_BASE64", True),
    "USE_SHORT_CHART_URLS": _env_bool("USE_SHORT_CHART_URLS", True),
    "SHORT_URL_TIMEOUT_SECONDS": _env_int("SHORT_URL_TIMEOUT_SECONDS", 8),
    "TOP_N_ANALYSTS": _env_int("TOP_N_ANALYSTS", 8),
    "TOP_N_REQUESTERS": _env_int("TOP_N_REQUESTERS", 10),
    "TOP_N_CRITICAL_ROWS": _env_int("TOP_N_CRITICAL_ROWS", 25),
    "CRITICAL_TABLE_COMPACT_ROWS": _env_int("CRITICAL_TABLE_COMPACT_ROWS", 6),

    # --- Cross-type conversion / offender detection ---
    # SCTASK -> INC: tickets closed as incomplete because the item was really an
    # incident (misclassification). We look for these keywords in the Reason
    # field and try to extract a referenced INC number from the free-text notes.
    "MISCLASSIFICATION_REASON_KEYWORDS": ["incorrect classification", "wrong classification",
                                            "deveria ser incidente", "classificacao incorreta"],
    # INC -> SCTASK: incidents cancelled because they were really a request.
    "CANCELLATION_STATE_VALUES": ["cancelled", "canceled"],

    # --- UAM (User Access Management) vs REQ (regular support requests) ---
    # Ported exactly from the reference dashboard's isUam(r) function:
    # checks Assignment group + Item + Tags + Short description (not just
    # Item alone) for any of these three keywords, case-insensitive.
    "UAM_ITEM_KEYWORDS": [
        "access", "acesso", "uam",
    ],

    # =========================================================================
    # Second e-mail: Analyst Performance Comparison (main.py sends the first
    # e-mail / the executive dashboard; main_analyst_report.py sends this one,
    # separately, typically right after - see run_all.bat)
    # =========================================================================
    "ANALYST_OUTPUT_HTML": _env_path("ANALYST_OUTPUT_HTML", "analyst_comparison_report.html"),
    "ANALYST_EMAIL_SUBJECT_PREFIX": _env_str("ANALYST_EMAIL_SUBJECT_PREFIX", "Analyst Performance Comparison"),
    "ANALYST_SEND_EMAIL": _env_bool("ANALYST_SEND_EMAIL", True),
    # Defaults to the same recipients as the main dashboard (EMAIL_TO/CC)
    # if left blank in .env - set ANALYST_EMAIL_TO to send this one to a
    # different (e.g. smaller, team-lead-only) audience instead.
    "ANALYST_EMAIL_TO": ";".join(_env_recipient_list("ANALYST_EMAIL_TO", "")) or ";".join(_EMAIL_TO_LIST),
    "ANALYST_EMAIL_CC": ";".join(_env_recipient_list("ANALYST_EMAIL_CC", "")) or ";".join(_EMAIL_CC_LIST),

    # --- "Needs Attention" flag thresholds (see analyst_metrics.py) ---
    # An analyst's this-week closures below this fraction of the team's own
    # weekly average gets flagged (0.5 = below half the team average).
    "ANALYST_ATTENTION_THRESHOLD_PCT": _env_float("ANALYST_ATTENTION_THRESHOLD_PCT", 0.5),
    # A week-over-week drop below this ratio of last week's count gets
    # flagged (0.5 = this week under half of last week).
    "ANALYST_ATTENTION_DROP_RATIO": _env_float("ANALYST_ATTENTION_DROP_RATIO", 0.5),
    # The week-over-week drop check only fires if last week's count was at
    # least this many tickets (avoids flagging noise on tiny numbers).
    "ANALYST_ATTENTION_MIN_BASELINE": _env_int("ANALYST_ATTENTION_MIN_BASELINE", 3),
}

# ---------------------------------------------------------------------------
# Aging buckets (kept close to the legacy dashboard's bucket definitions)
# ---------------------------------------------------------------------------
SCTASK_AGING_BINS = [-1, 3, 5, 7, 10, 20, 30, float("inf")]
SCTASK_AGING_LABELS = ["1-3 days", "3-5 days", "5-7 days", "7-10 days",
                        "10-20 days", "20-30 days", "30+ days"]

INC_AGING_BINS = [-1, 3, 5, 7, float("inf")]
INC_AGING_LABELS = ["1-3 days", "3-5 days", "5-7 days", "7+ days"]

PRB_AGING_BINS = [-1, 7, 15, 30, float("inf")]
PRB_AGING_LABELS = ["1-7 days", "7-15 days", "15-30 days", "30+ days"]

# ---------------------------------------------------------------------------
# Color palette - high-contrast blue, matching the production dashboard
# ---------------------------------------------------------------------------
class Colors:
    PRIMARY_DARK = "#001B69"
    PRIMARY = "#4A90E2"
    PRIMARY_LIGHT = "#EBF5FB"
    SUCCESS = "#27AE60"
    SUCCESS_LIGHT = "#D5F4E6"
    WARNING = "#F39C12"
    WARNING_LIGHT = "#FCF3CF"
    DANGER = "#E74C3C"
    DANGER_LIGHT = "#FADBD8"
    ORANGE = "#E67E22"
    ORANGE_LIGHT = "#FDEBD0"
    GRAY_DARK = "#1A365D"
    GRAY = "#7F8C8D"
    GRAY_LIGHT = "#ECF0F1"
    WHITE = "#FFFFFF"
    ACCENT = "#2B6CB0"
    ACCENT_LIGHT = "#E2E8F0"
    INFO = "#3182CE"
    INFO_LIGHT = "#BEE3F8"
    BACKGROUND = "#F5F6FA"
    PURPLE = "#6A1B9A"
    PURPLE_LIGHT = "#F3E5F5"


HIGH_CONTRAST_BLUES = ["#001B69", "#60A5FA", "#1D4ED8", "#93C5FD",
                        "#1E3A8A", "#3B82F6", "#BFDBFE", "#2563EB"]
MIXED_PALETTE = [Colors.WARNING, Colors.ORANGE, Colors.DANGER, Colors.PRIMARY,
                  Colors.ACCENT, Colors.INFO, Colors.GRAY, Colors.PRIMARY_DARK]

# ---------------------------------------------------------------------------
# Soft chart palette - matches the reference "relatorio_email.html" template
# exactly (this is the palette used for every QuickChart config, as opposed
# to the Colors class above which is only used for card/section HTML chrome)
# ---------------------------------------------------------------------------
QC = {
    "blue": "rgb(52,152,219)", "blue_a": "rgba(52,152,219,0.80)",
    "blue_soft": "rgba(74,144,226,0.85)",
    "green": "rgb(39,174,96)", "green_a": "rgba(39,174,96,0.75)",
    "red": "rgb(231,76,60)", "red_a": "rgba(231,76,60,0.75)",
    "purple": "rgb(155,89,182)", "purple_a": "rgba(155,89,182,0.75)",
    "orange": "rgb(243,156,18)", "gold": "rgb(241,196,15)",
    "orange_bar": "rgb(230,126,34)", "dark_red": "rgb(192,57,43)",
    "coral": "rgb(231,111,81)", "bright_green": "rgb(46,204,113)",
    "navy_dark": "rgb(26,35,126)", "concrete_gray": "rgb(149,165,166)",
    "tan": "rgb(230,180,100)", "backlog_line": "rgb(211,84,0)",
    "mint": "rgb(26,188,156)", "blue_grey_dark": "rgb(55,71,79)",
    "gray": "rgb(169,169,169)", "pink": "rgb(231,30,119)",
    "req_donut": ["rgb(52,152,219)", "rgb(93,173,226)", "rgb(133,193,233)",
                   "rgb(41,128,185)", "rgb(84,153,199)", "rgb(21,101,192)",
                   "rgb(174,214,241)", "rgb(31,58,147)"],
    "inc_donut": ["rgb(231,76,60)", "rgb(236,112,99)", "rgb(241,148,138)",
                   "rgb(192,57,43)", "rgb(211,84,0)", "rgb(230,126,34)",
                   "rgb(243,156,18)", "rgb(146,43,33)"],
    "aging_scale": ["rgb(46,204,113)", "rgb(52,152,219)", "rgb(241,196,15)",
                      "rgb(230,126,34)", "rgb(231,76,60)", "rgb(192,57,43)"],
    # Varied categorical palette - used for donuts where every slice must be
    # easy to tell apart at a glance (e.g. Top Analysts), regardless of
    # section theme. Monochromatic shades of one hue are hard to read.
    "varied": ["rgb(52,152,219)", "rgb(231,76,60)", "rgb(46,204,113)", "rgb(243,156,18)",
                "rgb(155,89,182)", "rgb(26,188,156)", "rgb(241,196,15)", "rgb(230,126,34)",
                "rgb(52,73,94)", "rgb(149,165,166)"],
}

MONTH_ABBR_EN = {1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
                  7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"}
WEEKDAY_ABBR_EN = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

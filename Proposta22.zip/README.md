# IT Executive Dashboard (SCTASK x INC x PRB)

**v2 - visual redesign.** Same analytics as before, but the look now follows
the reference `relatorio_email.html` template exactly (soft color palette,
white cards with colored top borders, gradient section headers) instead of
the previous dark-navy "ELITE MASTER" chrome. SCTASK and INC each get their
own clearly color-coded section (blue vs red) with an identical structure,
so the two are easy to compare side by side. The old 25-row "critical
tickets" wall of text was replaced with a compact panel: 3 small stat cards
that surface the key numbers (how many, how old, the average) plus a short
6-row table — not a giant list.

A merge of your production "ELITE MASTER" dashboard (KPI cards, critical
aging tables, SLA breach charts, offender/conversion analysis, monthly
throughput tables with accumulated backlog) with the chart set from the
previous report (daily/weekly evolution, today-vs-yesterday, week-over-week).
Everything is in English and reads directly from the ServiceNow exports
`INC.xlsx` / `SCTASK.xlsx` / `PRB.xlsx`.

## Terminology mapping

Your legacy script used `REQ` / `INC` / `PTASK`. This ServiceNow export uses:

| Legacy name | This export | Meaning |
|---|---|---|
| REQ | **SCTASK** | Service catalog tasks / requests |
| INC | **INC** | Incidents |
| PTASK | **PRB** | Problems / problem tasks |

## Files

| File | Purpose |
|---|---|
| `config.py` | Paths, email settings, SLA targets, aging thresholds, windows |
| `data_loader.py` | Flexible column-matching loader for INC/SCTASK/PRB |
| `metrics.py` | Aging, SLA breach, backlog, monthly/daily throughput, conversions, rankings |
| `charts.py` | QuickChart.io URL builders (donut, pie, bar, dual-axis trend+backlog) |
| `report_builder.py` | Assembles the full HTML dashboard |
| `main.py` | Orchestrates everything and sends the e-mail via `smtp.py` |
| `smtp.py` | Your existing Outlook sender (Windows/Mac) — unchanged |

## How to run

1. Put `INC.xlsx`, `SCTASK.xlsx`, `PRB.xlsx` in this folder (or edit the
   paths in `config.py`).
2. Edit in `config.py`:
   - `EMAIL_TO` / `EMAIL_CC`
   - `SLA_DAYS` per ticket type (defaults: SCTASK=10, INC=7, PRB=10 — same
     numbers as your legacy `SLA_DAYS_REQS/INCS/PTASK`)
   - `CRITICAL_AGING_THRESHOLD` (defaults: SCTASK=20, INC=7, PRB=15)
   - `REFERENCE_DATE` — leave `None` in production
3. Run:
   ```bash
   pip install pandas openpyxl pywin32   # pywin32 only on Windows
   python main.py
   ```

## What's included (mapped to what you asked for)

**KPIs & critical call-outs**
- KPI cards: total open backlog, SCTASK open, INC open, PRB total/open,
  cross-type conversions, overall MTTR
- ⚠️ **Critical SCTASKs** (aging 20+ days, 30+ highlighted in red)
- ⚠️ **Critical INCs** (aging 7+ days) — new table, mirrors the SCTASK one

**Distribution & SLA**
- 1A/1B Top Analysts (SCTASK / INC) — donut charts
- SCTASK / INC — Inside vs Outside SLA — pie charts

**Status & Aging (bar charts)**
- 3A/3B Aging Detail (SCTASK / INC) — horizontal bars
- SCTASK / INC — Status of open tickets — horizontal bars
- Top Requesters (SCTASK → INC) and (INC → SCTASK) — current-month
  misclassification / cancellation offenders (see note below)

**Monthly & daily trend**
- 2A/2B Monthly Entry x Exit x Accumulated Backlog (dual-axis bar+line,
  SCTASK / INC)
- Daily Entry x Exit tracking for the current month, same dual-axis style
  with the backlog line (SCTASK / INC)
- Monthly Tracking Table (Opened x Resolved x Backlog) with totals row,
  for both SCTASK and INC (Throughput tables)

**Bonus sections** (kept from the previous report, since you asked for
"much more complete")
- Problems (PRB) overview: opened/resolved this month, priority mix,
  oldest open problems
- Today vs Yesterday comparison
- Current week vs previous week + weekly evolution chart

## About the offender/conversion detection

`SCTASK → INC` looks for SCTASKs closed as incomplete whose `Reason` field
mentions misclassification keywords (configurable in
`CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]`), then tries to extract a
referenced `INC` number from the close/work notes.

`INC → SCTASK` looks for cancelled incidents (`Close code` or `State`
containing "cancelled"/"canceled") and tries to extract a referenced
`SCTASK`/`RITM` number from the notes.

Both are **pattern-based on your free-text fields** — if your analysts
don't reference the linked ticket number in the notes, or don't use those
exact keywords, the tables will legitimately come back empty (shown as a
green "no data" message rather than an error). Adjust the keyword list and
regex prefixes in `metrics.py` (`_extract_ref`,
`sctask_to_inc_conversions`, `inc_to_sctask_conversions`) to match your
team's actual wording.

## Notes

- Charts use the public QuickChart.io API (same technique as your legacy
  dashboard) — the person opening the e-mail needs internet access to load
  the chart images.
- `smtp.py` was kept exactly as you provided it; `main.py` calls its
  `enviar_email_automatico(to, cc, subject, html_body)` function.
- `example_dashboard_report.html` in this package is a live preview built
  from test data, so you can see the visual before running it yourself.

## Cross-Type Conversions (SCTASK ↔ INC) — replicates "Classification Errors"

This section is a direct port of the "Classification Errors" tab logic from
your analytical dashboard (`index.html`), rebuilt for the static e-mail
report:

- **Detection is evidence-based, not just "cancelled".** A ticket only
  counts as a genuine misclassification when there's BOTH an abnormal
  closure (incomplete/cancelled/rejected) AND textual proof of it:
  - `SCTASK → INC`: State is incomplete/cancelled/rejected **and**
    `Reason` names a classification problem (keywords configurable in
    `CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]`). The linked `INC` number
    is extracted from the close/work notes when present.
  - `INC → SCTASK`: State is cancelled **and** the close/additional
    notes explicitly reference a `RITM`/`SCTASK` number (this mirrors the
    reference tool's `closeNotes.includes('RITM')` check) — a plain
    cancellation with no linked ticket is NOT counted as a reclassification.
- **Canceled Reconciliation panel**: shows the full universe of
  cancelled/incomplete tickets per type this month, how many of those were
  *confirmed* misclassifications, and how many were cancelled for some
  other reason ("Other Reasons") — so leadership can see what fraction
  of cancellations is actually a routing problem.
- **Both directions tracked explicitly** (`INC → SCTASK` and
  `SCTASK → INC` mini-KPIs), plus a historical monthly trend chart,
  Top Offending Group, Monthly MTTR (average correction time) and Maximum
  Delay — same insights as the reference tab's summary cards.
- **Breakdown tables** by Requester, by Group, by Analyst (current month)
  and a Historical Consolidated table (all months, with % of total).
- **Detailed list**: the most critical misclassified tickets this month
  (capped at `CRITICAL_TABLE_COMPACT_ROWS`, oldest first), with a note when
  there are more than shown.

Like the other offender detection in this report, this only surfaces
results when your analysts' `Reason`/close-notes wording actually matches
the configured keywords/patterns — adjust
`CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]` and the regex prefixes in
`metrics.py` (`sctask_misclassified`, `inc_reclassified`, `_extract_ref`)
to fit your team's real vocabulary.

## Fixes: broken chart images in Outlook + backlog-first focus

**1. Charts weren't rendering in Outlook (critical bug, now fixed).**
Complex dual-axis chart configs produced `<img src="https://quickchart.io/chart?...">`
URLs over 2000-2800 characters. Outlook's rendering engine (inherited from
Word) silently fails to load `<img>` tags past roughly that length — you'd
see all the numbers/tables but no chart images, exactly as reported.

Fix: `charts.py` now asks QuickChart to host each chart
(`POST /chart/create`) and embeds the short URL it returns
(`https://quickchart.io/chart/render/<id>`, well under 100 characters)
instead of the long GET URL. This requires internet access when you run
`main.py` (not at send time). If that request fails for any reason — offline,
timeout, QuickChart hiccup — it automatically falls back to the long GET
URL so the script never breaks; you'd just be back to the original bug for
that one chart. Toggle via `CONFIG["USE_SHORT_CHART_URLS"]` /
`CONFIG["SHORT_URL_TIMEOUT_SECONDS"]` in `config.py`.

**2. Responsiveness.** Added a viewport meta tag and strengthened the
`@media (max-width: 768px)` rules so cards, tables and chart images reflow
on narrower screens. Important caveat: **Outlook for Windows desktop
(the classic Word-based rendering engine) does not support CSS media
queries at all** — this is a long-standing Microsoft limitation, not
something fixable from the HTML/CSS side. The responsive layout *will*
work in Outlook Mobile (iOS/Android), Outlook for Mac, Outlook on the web,
and virtually every other modern mail client — just not the Windows
desktop app, which will always render the fixed desktop layout there.

**3. Backlog-first, current-month-only.** This report is a day-to-day
operations snapshot, so:
- Every headline KPI (Overview, and each SCTASK/INC section) is now the
  **live open backlog** — never an all-time count of closed tickets.
- Wherever a resolved/closed number does appear (Opened/Resolved this
  month, MTTR, the Classification Errors KPIs), it is strictly scoped to
  the **current month** via `metrics.current_month_flow()` /
  `metrics.mttr_days_month()` — never blended with older history.
- Removed the two sections that showed a rolling 6-month history
  (*Monthly Evolution & Trend* and the combined *Monthly Tracking Table*),
  since a multi-month resolved-ticket trend doesn't belong in a
  current-month operations report. The *Daily Evolution by Ticket Type*
  section (day-by-day, current month only) remains as the trend view.
- Classification Errors dropped its historical trend chart and
  all-time "Historical Consolidated" table for the same reason; the
  reconciliation panel, direction cards, KPI cards and breakdown tables
  were already current-month-scoped and are unchanged.

## "Ainda não funcionou" — how to actually pin down the cause

If you ran the updated script and the e-mail still looks unchanged (same
numbers, no charts), it's almost certainly one of these three things, in
order of likelihood:

**1. The e-mail you're looking at wasn't regenerated.**
Every run of `main.py` builds a brand-new e-mail and sends it as a new
message — it can never edit an e-mail already sitting in your inbox. If
you're re-opening an old message from an earlier test, of course nothing
changed. Fix: run `python main.py` again, and check the **subject line**
of the new e-mail — it now ends with a build tag like
`[2026-07-backlog-focus-inline-charts]`. If the e-mail you're looking at
doesn't have that tag, it's not from this version.

**2. Not all files were replaced, so old code is still running.**
The console banner now prints `(build: 2026-07-backlog-focus-inline-charts)`
on the very first line. If your terminal doesn't show that exact string
when you run `python main.py`, you're running stale `.py` files — replace
the **entire folder**, not individual files, and delete any `__pycache__`
folder next to the scripts before re-running.

**3. QuickChart isn't reachable from the machine that runs `main.py`.**
This is the most likely real fix needed. Read the new
**"[3/5] Chart image delivery summary"** the console prints after every
run:
- `X embedded inline (base64)` — these charts are bulletproof; they will
  show up in Outlook no matter what.
- `X via long GET URL` — if this is where ALL your charts land, this
  machine could not reach `https://quickchart.io` (corporate proxy,
  firewall, no internet) when `main.py` ran. That's independent of
  Outlook entirely — fixing internet/proxy access to quickchart.io on the
  machine that *generates* the report is what fixes this, not anything in
  Outlook's settings.

**Also worth checking directly in Outlook**, since it's a very common and
completely unrelated cause of "I see numbers but no pictures": Outlook
blocks automatically downloading external images by default in many
corporate configurations, and shows a bar like *"Content blocked. Click
here to download pictures."* at the top of the e-mail. If you see that bar
and haven't clicked it, that alone explains missing images — regardless of
anything in this script. With `EMBED_CHARTS_AS_BASE64` charts (base64
delivery, item 1 above), this doesn't apply, because there's no external
image to block in the first place — it's already inline in the HTML.

**Fastest way to isolate it yourself:** open the local file at
`CONFIG["OUTPUT_HTML"]` (path printed in `[4/5]`) directly in Chrome/Edge.
If the charts show up there, the issue is 100% on the Outlook/e-mail side,
not in this script. If they don't show up there either, it's a
chart-generation problem on this machine — check step 3 above.

## Fix: cards had no color / charts overflowed / INC backlog was wildly wrong

Three separate root causes, all fixed at the source:

**1. Backlog count was inflated (e.g. showing 942 instead of ~85).**
ServiceNow's Incident table keeps two *separate* completion-date fields:
`Resolved` (the actual fix) and `Closed` (a later, often automatic,
administrative step). `data_loader.py` was only reading the `Closed`
column, so any incident that was already resolved but not yet
auto-closed was still counted as open. Fixed with
`_completion_date()`, which now prefers `Resolved` for INC/PRB (falling
back to `Closed` if `Resolved` is empty) and prefers `Closed` for SCTASK
(falling back to `Resolved`) — matching how each ServiceNow table
actually behaves.

**2. Cards showed no color/borders at all.**
Outlook's `HTMLBody`/MAPI pipeline (used by `smtp.py` via `win32com`) is
known to drop or mangle `<style>` blocks — especially compound class
selectors like `.kpi-card.blue` — which is exactly what strips all the
card styling. Every visual element (KPI cards, stat cards, section
headers, mini-KPI badges, tables, chart cards) now carries its **full
styling as inline `style="..."` attributes** directly on the element, not
just via CSS classes. The `<style>` block and `class="..."` attributes are
still there too, as a progressive enhancement for clients that do honor
them (Outlook Mobile/Mac/Web, Gmail, Apple Mail) — but the inline styles
are what Outlook Windows desktop will actually render, and they're
self-sufficient on their own.

**3. Chart images were oversized and didn't shrink with the window.**
Outlook's Word-based engine largely ignores `max-width:100%` in CSS
unless the `<img>` tag also has an explicit `width="100%"` **HTML
attribute** — without it, the image renders at its native pixel size
(e.g. 780px or 1180px wide) regardless of the container. Every `<img>` in
the report now has both `width="100%"` as an attribute and the matching
inline CSS, so it scales down to fit its cell reliably.

## Fixes: mini-KPI badges, "Current" card, centered chart numbers, MTTR clipping

**1. Mini-KPI badges ("Opened (month)559Resolved (month)547..." running
together, no visible card).** Root cause: `mini_kpi_row` used `<span
style="border:...; padding:...; background-color:...">` pills — but
Outlook's Word engine reliably ignores box-model CSS (border, padding,
background-color) on inline elements like `<span>`. It only honors those
properties on table cells. Rewrote it as a small `<table>` of badges (same
pattern already used for KPI/stat cards), wrapping to a new row every 3
items so it doesn't force the table wider than the container. Also
reordered to: Open Backlog, Inside SLA, Outside SLA, Opened (month),
Resolved (month), MTTR (month), as requested.

**2. Added the missing "Current" card.** The Daily Evolution panels
(SCTASK/INC) now show 4 stat cards instead of 3: **Current** (live open
backlog for that type, right now) + Opened / Closed / Net Balance for the
month — so you see the snapshot and the period's flow side by side.

**3. Centered, larger numbers on every chart.**
- Donut charts (Top Analysts) and the SLA charts (now donuts instead of
  solid pies) show the grand total in bold, large text right in the
  hole — via QuickChart's `doughnutlabel` plugin.
- Horizontal bars (Aging Detail, Status) now anchor their datalabel to the
  **center** of each bar in bold white, size 15 (was: dark gray, right-aligned,
  size 11).
- The daily trend bars already centered their white datalabels; bumped the
  font size (10 &rarr; 13) for more emphasis, per your request.

One deliberate adjustment: for the donut/pie center totals specifically,
literal white text would be invisible (the hole's background is white) —
so those use a bold, high-contrast accent color (the section's blue/red)
instead of white, while everywhere else (bars) uses white exactly as
requested, since those *do* sit on a colored background.

**4. MTTR assertiveness.** Added `.clip(lower=0)` to every MTTR
calculation so a bad data entry (a `Closed` date earlier than `Opened`)
can't silently pull the average down with a negative duration.

## Replicated the 4-series trend charts from your reference dashboard

Ported the exact chart structure and colors from your JS tool's own
"Tabelas Evolução e Tendência" sections:

- **4 series per chart, not 3**: Opened (light blue) + Resolved (dark navy
  for SCTASK / green for INC) + a distinct **Closed Incomplete** (SCTASK,
  gray) or **Canceled** (INC, tan) bar + accumulated Backlog as an orange
  line on the secondary axis. Previously "Resolved" silently absorbed
  incomplete/cancelled closures — now they're their own bar, matching your
  reference tool and giving a truer picture of how tickets actually leave
  the queue.
- **Both views restored, side by side**: **"1A/1B" Monthly Evolution and
  Trend** (last 6 months, SCTASK next to INC) and **"2A/2B" Daily
  Evolution** (current month, day by day). The monthly view had been
  removed in an earlier pass under a stricter "current-month-only" reading
  of your instructions — you've since confirmed you want it back
  alongside the daily one, so both are here now, clearly separated and
  labeled.
- Colors matched to your screenshots: Opened `rgb(52,152,219)`, SCTASK
  Resolved `rgb(26,35,126)` (dark navy), INC Resolved `rgb(46,204,113)`
  (green), Closed Incomplete `rgb(149,165,166)` (gray), Canceled
  `rgb(230,180,100)` (tan), Backlog line `rgb(211,84,0)` (burnt orange).
- Each panel keeps the stat cards above the chart (Current backlog /
  Opened / Resolved / secondary bucket / Net Balance), and the chart
  itself carries a `TOTAL OPENED: X | TOTAL CLOSED: Y` title, matching your
  reference tool's own chart headers.

## Fixes: backlog curve, badge alignment, new analyst charts, colored tables

**1. Backlog curve was mathematically wrong.** It summed net flow forward
from zero at the start of the visible window, silently assuming the queue
was empty before that - never true for a live queue. Now it's **anchored
to the real, current open count** on the last period and walks *backward*
(`backlog[k] = backlog[k+1] - net[k+1]`), exactly like your reference tool
(e.g. starting at 61 in Feb, not 0). Applies to both the monthly and daily
trend charts.

**2. Mini-KPI badges now sit in a single, unbroken row** (`Open Backlog |
Inside SLA | Outside SLA | Opened (month) | Resolved (month) | MTTR
(month)`) - no more wrapping to a second line - with a stronger, clearly
visible card style (light-blue fill, blue border) so they read as
distinct badges, not plain text.

**3. Added the missing analyst charts**, English-labeled, varied colors:
- **Top Analysts (SCTASK + INC Combined)** - stacked horizontal bar per
  analyst, navy for SCTASK + orange for INC, with the combined total in
  the title - this view didn't exist before.
- **Top Analysts - SCTASK / INC (Bar View)** - horizontal-bar rankings
  where every bar gets its own color from the varied palette, alongside
  the existing donuts (kept both, since the donut's centered total is
  still useful).

**4. Data tables now have visible zebra striping.** Rows alternate white
and a light blue-gray (`#dce8f7`) instead of two near-identical off-white
shades, and headers default to a solid blue instead of pale gray.

## Fixes: backlog axis scale, stacked bars, title prefixes, card alignment

**1. Backlog axis no longer forced to start at 0.** With a large left-axis
range (bar quantities up to 160) and the backlog line hovering in a much
narrower band (e.g. 55-70), a 0-based right axis flattened the line into
an almost-straight strip. The backlog axis now auto-zooms to the data's
own range with a small buffer, so its actual shape is visible.

**2. Bars are now grouped/stacked, not three side-by-side bars.** Each
period shows two bars: **Opened** on its own, and a single **stacked
"Closed" bar** combining the Resolved segment and the secondary segment
(Closed Incomplete for SCTASK, Canceled for INC) - applies identically to
both SCTASK and INC charts.

**3. Removed all "1A./1B./2A./2B./3A./3B." style prefixes.** Every chart
and section title is now plain text (e.g. "Top Analysts - SCTASK" instead
of "1A. Top Analysts - SCTASK").

**4. Fixed card alignment/padding on narrower screens.** The mobile
breakpoint previously tried to force table cells into `inline-block;
width:48%` for a 2-per-row layout - a pattern that renders inconsistently
across clients (uneven wrapping, cards landing alone on their own row,
exactly what showed up in your screenshot). Replaced it with the same
reliable full-width, single-column stacking already used elsewhere in the
report, and increased the padding between cards so they're no longer
touching edge-to-edge.

## Configuration now lives in `.env` (not hardcoded)

**Setup:**
```bash
cp .env.example .env
# edit .env with your real paths / URLs / credentials / recipients
pip install -r requirements.txt
```

`config.py` calls `load_dotenv()` automatically - nothing else needs to
change. If `.env` is missing entirely, everything falls back to sensible
defaults (paths under `dates/`, matching the real ServiceNow table names:
`incident.xlsx`, `sc_task.xlsx`, `problem_task.xlsx`), so the script still
runs out of the box for testing.

A note on naming: you asked to "use pyenv" for this - the library that
actually does it is **python-dotenv** (`pip install python-dotenv`,
`from dotenv import load_dotenv`). `pyenv` is a different, unrelated tool
that manages which *Python version* is installed on your machine, not
environment variables/config. I used python-dotenv since that's what
actually reads `.env` files - let me know if you meant something else.

**Group e-mail recipients:** `EMAIL_TO` and `EMAIL_CC` in `.env` accept a
comma-separated list (`EMAIL_TO=alice@company.com,bob@company.com,it-leads@company.com`).
`config.py` splits that list and rejoins it with semicolons
(`CONFIG["EMAIL_TO"]`), which is the separator Outlook expects for
multiple recipients in a single `To`/`Cc` field - `smtp.py` didn't need
any changes. `CONFIG["EMAIL_TO_LIST"]`/`EMAIL_CC_LIST"]` are also
available as plain Python lists if you ever need them individually.

Every other setting that used to be hardcoded in `config.py` (SLA
targets, aging thresholds, analysis windows, chart delivery options) is
now also overridable from `.env` - see `.env.example` for the full list.
Nothing *requires* changing them; the defaults match what was hardcoded
before.

## Automated download - `download_data.py` (replaces Selenium)

Selenium launches an entire browser (Chrome/Edge), waits for the page and
its JavaScript to fully render, then simulates clicking through the UI to
trigger a download - typically 10-30+ seconds per file, and fragile
(breaks when ServiceNow tweaks its UI). `download_data.py` instead makes
a **direct authenticated HTTP request** to the same export URL your
browser would hit, and saves the raw response - no browser, no rendering,
no clicking. 1-3 seconds per file in the common case.

**Setup:**
1. In `.env`, paste your 3 existing export URLs (the ones you currently
   open via Selenium) into `INC_EXPORT_URL` / `SCTASK_EXPORT_URL` /
   `PRB_EXPORT_URL`.
2. Set `SERVICENOW_USER` / `SERVICENOW_PASSWORD` to a service account.
3. Run `python download_data.py` or double-click `download_data.bat`.
   `run_all.bat` chains download → build report → send e-mail in one go
   (good for Task Scheduler).

Files land exactly where `config.py`'s `INC_PATH`/`SCTASK_PATH`/`PRB_PATH`
expect them (same `.env` values drive both) - `download_data.py` imports
`CONFIG` directly rather than recalculating paths itself, so there's no
way for the two to drift out of sync.

### Why this might not work out of the box

This is the one part I can't fully guarantee without seeing your
ServiceNow instance's auth setup, so please read this before assuming
it's broken:

- **If your instance allows Basic Authentication** for a service account
  (common in many corporate setups specifically to support scripted
  integrations like this one) - this will just work, and will be *much*
  faster than Selenium.
- **If your instance is SSO/SAML-only** (very common in larger
  enterprises), a plain username/password HTTP request can't complete the
  login flow - ServiceNow will redirect to your identity provider instead
  of returning the file, and `download_data.py` will detect this (it
  checks for an HTML/login-page response instead of a spreadsheet) and
  print a clear warning rather than silently saving a broken file.
  Two ways forward if that happens:
  1. Ask your ServiceNow admin to enable Basic Auth for one dedicated
     integration/service account (this is a normal, common request -
     it doesn't affect SSO for regular users).
  2. Use the `SERVICENOW_SESSION_COOKIE` fallback in `.env`: log in
     normally in a browser once, copy the session cookie from DevTools
     (Application/Storage → Cookies), and paste it in. This works until
     that browser session expires, so it needs periodic refreshing -
     not ideal for a fully unattended daily run, but still far faster
     than Selenium for the sessions where it's valid, and a fine bridge
     while you get Basic Auth enabled.
- **Longer-term, more robust alternative**: migrate from the legacy
  `.do?XLS` list-export links to ServiceNow's official **Table API**
  (`/api/now/table/<table>?sysparm_query=...`), which returns JSON and is
  the supported, documented integration path (Basic Auth or OAuth,
  stable across ServiceNow upgrades, doesn't depend on the browser-era
  export UI staying unchanged). I didn't build this out fully since it
  needs your exact field/filter mapping to replicate your current 3
  exports precisely - happy to build it if you share the field list and
  filters your 3 saved exports use.

## Fixes: legend alignment + new INC columns (On Hold Reason, Linked Problem)

**1. Donut chart legends moved to the bottom.** The "Top Analysts" donuts
used a right-side legend, which is what caused the misalignment/cut-off
names you saw (long analyst names getting truncated, chart+legend not
lining up with the rest of the card). Every donut now uses the same
bottom-positioned, wrapping legend the SLA charts already used correctly
- consistent across all donut/pie charts in the report.

**2. Two new columns on the Critical INCs table.**
- **On Hold Reason**: shown for every INC row, populated only when
  `State` is "On Hold" (dash everywhere else, so the column doesn't
  imply a reason that doesn't apply).
- **Linked Problem**: shown for every INC row, populated whenever that
  incident references a Problem record (dash if none).

Both fields (`On hold reason` and `Problem`) were already present in your
ServiceNow `incident.xlsx` export's column list from the very start of
this project - `data_loader.py` just wasn't extracting them yet. Fixed in
`load_inc()`, and surfaced only in the INC critical table (SCTASK's table
is unaffected - it has no such columns, and none were added there).
Verified with an isolated test using synthetic rows in both states (On
Hold with a reason, and a row with a linked Problem) - both populate
correctly, and blank out to "—" everywhere else.

Note: your current `dates/incident.xlsx` sample data doesn't have any
rows with a populated `Problem` field (it's empty in every row), so the
"Linked Problem" column will show "—" throughout in the example
export until you point the report at data that actually has Problem
links populated - that's a property of the sample data, not a code issue.

## Fixes: chart colors + new "big card" style for the Overview KPIs

**1. Top Analysts (Combined) stacked bar recolored.** The dark
navy/orange pairing looked muddy - switched to the same bright blue/red
(`rgb(52,152,219)` / `rgb(231,76,60)`) used everywhere else in the report
for SCTASK/INC, so it's both more vivid and visually consistent with the
rest of the dashboard.

**2. "Canceled" bar (INC trend charts) recolored.** The tan/beige color
blended into the background and didn't stand out. Replaced with a vivid
magenta/pink (`rgb(231,30,119)`) that reads clearly against the blue
Opened bars, green Resolved bars, and orange Backlog line.

**3. Overview KPI cards restyled to the reference "big card" look.**
Total Backlog / SCTASK Open / INC Open / PRB Open / MTTR now render as a
neutral light-gray icon+label header strip on top of a color-tinted body
(e.g. light blue body with a navy value for the blue cards, light red
body with a red value for the red cards) - all wrapped in a single
color-matched border, exactly like the reference screenshot. This applies
**only** to the 5 main Overview cards, as requested - the smaller stat
cards elsewhere (critical panel stats, mini-KPI badges, trend-panel
stats) intentionally keep their existing simpler single-tone style.

## v3: UAM tracking, restored monthly table, richer bar labels, token auth

**1. UAM (User Access Management) now tracked completely separately from
REQ.** Previously every SCTASK ticket - regular support requests AND
access-management requests alike - was silently lumped into one "SCTASK
Open" number. `metrics.split_uam()` now splits SCTASK by its `Item` field
(`CONFIG["UAM_ITEM_KEYWORDS"]`, defaults to matching "PORTAL BROKER Access
(Brazil only)" plus a broader "access"/"acesso" fallback - tune this list
to your exact catalog item names for precise classification):
- A dedicated **"UAM Open"** card sits in the Overview KPI row, next to
  "REQ Open (Support)" which is now explicitly REQ-only.
- A brand-new **"UAM — User Access Management"** section with its own
  Daily Tracking (current month) and Monthly Tracking (last 6 months)
  charts - same dual-axis Open/Closed/Cancelled/Backlog style as the
  SCTASK/INC trend charts, in its own teal color theme.
- UAM also gets its own row in the Monthly Tracking Table (see below).
- `Total Backlog` in the Overview now explicitly sums REQ + UAM + INC, so
  the grand total hasn't changed - only how it's broken down underneath.

**2. Monthly Tracking Table (side-by-side REQs/INCs/UAM throughput)
restored.** This had been dropped in an earlier pass. It's back, with the
`Cancelled`/`Closed Incomplete` column included (previously missing) so
each row shows Opened, Resolved, the secondary/cancelled count, Net Flow,
and Accumulated Backlog, with a TOTALS row - REQ and INC side by side,
UAM's own table underneath.

**3. Every bar chart now shows "name | count (pct%)" in its labels** -
Top Analysts (combined + both bar views), Aging Detail (SCTASK/INC), and
Status (SCTASK/INC) all carry the count and percentage-of-total right in
the axis label, matching the reference screenshot. (Found and fixed a
real truncation bug along the way: the label-shortening logic was cutting
long names off before the " | count (%)" suffix ever got attached -
fixed by truncating the name portion first, then appending the count/pct,
and raising the overall label length ceiling.)

**4. Two-step token authentication for `download_data.py`.** If your
environment requires visiting a site first to obtain/validate a token
before the 3 export links will respond (rather than accepting Basic Auth
directly), set `AUTH_URL` in `.env`. When configured, the script:
1. Calls `AUTH_URL` first (GET/POST, JSON/form/Basic-Auth credentials -
   all configurable) and pulls a token out of the JSON response using
   `AUTH_TOKEN_FIELD` (supports nested paths like `data.token`).
2. Reuses that authenticated session for the 3 downloads, attaching the
   token as a header, a cookie, or a URL query parameter - whichever
   `AUTH_TOKEN_LOCATION` you set.

Leaving `AUTH_URL` blank skips this entirely - fully backward compatible
with the single-step Basic Auth / session-cookie flow from before. Tested
all three token-delivery modes (header/cookie/query_param) against
mocked auth responses; each attaches the token exactly where configured.

Since every ServiceNow auth endpoint's exact request/response shape is
different, treat the defaults (`AUTH_CREDENTIALS_AS=json`,
`AUTH_TOKEN_FIELD=access_token`, `AUTH_TOKEN_LOCATION=header`) as a
common starting point, not a guarantee - check `.env.example` for the
full list of knobs, and adjust `AUTH_USERNAME_FIELD` /
`AUTH_PASSWORD_FIELD` / `AUTH_TOKEN_FIELD` to match your actual endpoint's
field names if the defaults don't fit.

## v4: 4-panel Monthly grid (incl. Combined/ALL), 3-panel Daily, uniform cards, chart scale fix

**1. Monthly Evolution and Trend is now 4 panels, 2x2.** SCTASK, INC, UAM,
and a brand-new **"ALL (SCTASK + UAM + INC Combined)"** panel that merges
all three ticket types into one trend view - same stacked-bars +
Backlog-trend-line treatment as the others, in its own blue-grey theme so
it's visually distinct from the three individual panels.

**2. Daily Evolution and Trend now includes UAM as a 3rd panel**, stacked
full-width below SCTASK and INC (same treatment, teal theme) - the daily
current-month view for all three ticket types lives in one place instead
of UAM having a separate, largely-duplicate section. (The standalone UAM
section further down was simplified to just its KPI summary + an
explanation of the classification rule, since its trend charts are now
here.)

**3. Monthly Tracking Table is now 4 throughput tables, 2x2**: SCTASK,
INC, UAM, and "ALL (Combined)" - same Opened/Resolved/Secondary/Net
Flow/Backlog columns with a TOTALS row, for every one of the 4 views.

**Chart scale fix (all trend charts).** The Backlog line and the
Opened/Resolved/Cancelled bars were sharing too much of the same vertical
space, so the line sometimes wove through the bars instead of riding
clearly above them. Fixed with two changes to the shared chart function:
the bars' own axis is now given a max well beyond the actual bar data (so
bars stay compact near the bottom), and the line's axis now starts at 0
(instead of zoomed to the data's own min) so its values land in the upper
portion of the chart by construction - while its max still tracks the
data (not a huge fixed ceiling), so the line's real shape stays visible
instead of flattening. Applies everywhere `dual_axis_trend_quad` is used
- all trend charts in the report got this fix at once.

**Overview cards are now a fixed, uniform height.** Longer subtitle text
(e.g. "SCTASK + INC open, right now" vs "Access management") was making
some cards taller than their neighbors. Both the header strip and the
body of every card now get an explicit height (HTML attribute + inline
CSS, for Outlook reliability) - 36px header + 92px body, 128px total -
so every card in the row is identical regardless of its text length.

## Critical fix: UAM numbers not matching (wrong state vocabulary)

**Root cause found.** UAM is a subset of SCTASK, so it must use the exact
same status vocabulary as SCTASK/REQ - but it had been configured with
INC's vocabulary instead:

- **REQ/SCTASK/UAM real states** (per your screenshots): Open, Work in
  Progress, Awaiting Change Management, Awaiting Release Management,
  Awaiting User Info, Awaiting Vendor/Parts, Closed Complete, **Closed
  Incomplete**. There is no "Cancelled" state for these.
- **INC real states**: New, In Progress, On Hold, Resolved, **Canceled**.

UAM's "secondary" bucket (the non-clean-resolution closure) was wired to
look for `"cancel"` in the State field and labeled "Cancelled" - copied
from INC's logic. Since no UAM ticket can ever legitimately have "cancel"
in its state, **every UAM closure was silently counted as "Resolved"**,
even the ones that were actually Closed Incomplete - inflating Resolved
and always showing 0 for the secondary bucket. Fixed in
`metrics.SECONDARY_STATE_KEYWORDS`/`SECONDARY_LABEL`: UAM now uses
`"incomplete"` / "Closed Incomplete", exactly like SCTASK. Also updated
the UAM chart color to match SCTASK's gray (both now represent the same
concept, so they should look the same, not UAM colored like INC's
Cancelled/pink).

**Second issue, in the sample data itself**: `dates/sc_task.xlsx` had
"Cancelled" and "Closed Skipped" values in its `State` column, and
`dates/incident.xlsx` had "Closed" and "Assigned" - none of which exist
in your real state vocabulary above. This is exactly what caused the
"same chart, totally different numbers" symptom: a ticket in one of
these nonexistent states got classified differently depending on whether
it was analyzed alone (e.g. "SCTASK only", where the "cancel" keyword
never applies) or as part of the combined "ALL" view (where both
"incomplete" and "cancel" keywords apply) - the SAME ticket landing in
different buckets depending on context is precisely a "numbers don't add
up" bug. Remapped the sample data to only use the real state names
(`Cancelled`/`Closed Skipped` &rarr; `Closed Incomplete`, `Pending`
&rarr; `Awaiting Vendor/Parts` for SCTASK; `Closed` &rarr; `Resolved`,
`Assigned` &rarr; `In Progress`, `Cancelled` &rarr; `Canceled` for INC).

**Verified the fix numerically**, not just visually: computed SCTASK +
UAM + INC's Opened/Resolved/Secondary independently, summed them by hand,
and compared against the "ALL" combined calculation month by month -
every single value now matches exactly, and the combined Backlog also
matches the true current open count (33 + 5 + 47 = 85). This is the kind
of check worth re-running any time `UAM_ITEM_KEYWORDS` or the state
vocabulary changes, since it's exactly the class of bug that produces
"looks right per type, wrong when combined."

If your real ServiceNow data uses slightly different wording for these
states, double check `metrics.SECONDARY_STATE_KEYWORDS` still matches -
the keyword just needs to be a case-insensitive substring of the real
state name (e.g. `"incomplete"` matches `"Closed Incomplete"` regardless
of exact capitalization).

## Diagnóstico: index.html (referência) vs código Python — quem estava certo

Você perguntou qual dos dois estava com números corretos. Fui direto ler o
`index.html` linha por linha (funções `isUam`, `calculateSection`,
`generateOpenTicketsHTML`) e comparei com a lógica Python. **Nenhum dos
dois "estava errado" no sentido de ter uma conta matematicamente
inválida** — mas encontrei uma diferença real e concreta de **critério de
classificação** entre os dois, que por si só já é suficiente para os
totais de SCTASK/UAM/INC nunca baterem entre as duas ferramentas:

**Causa raiz confirmada no código-fonte do `index.html`:**
```js
const isUam = r => {
    const accessKw = v => { let s = String(v || '').toLowerCase();
        return s.includes('access') || s.includes('acesso') || s.includes('uam'); };
    return accessKw(r['Assignment group']) || accessKw(r['Grupo']) ||
           accessKw(r['Item']) || accessKw(r['item']) ||
           accessKw(r['Tags']) || accessKw(r['tags']) ||
           accessKw(r['Categoria']) || accessKw(r['Short description']);
};
```
O dashboard de referência verifica **5 campos** (Assignment group, Item,
Tags, Categoria, Short description) — meu código anterior verificava
**somente o campo Item**. Qualquer ticket cujo sinal de "é UAM" estivesse
no Grupo de Atribuição ou nas Tags (e não no nome do Item) ficava
incorretamente contado como REQ comum no meu relatório, mesmo estando
corretamente marcado como UAM na ferramenta de referência - isso sozinho
já é suficiente para os totais de REQ vs UAM nunca coincidirem entre as
duas ferramentas.

**Corrigido**: `metrics.split_uam()` agora verifica os mesmos campos
(Assignment group, Item, Tags, Short description - "Grupo"/"Categoria"
não existem no seu schema atual, mas o padrão está pronto para adicionar
se surgirem). `data_loader.py` agora também extrai "Tags" e "Short
description" como colunas próprias (antes não eram capturadas).

**Segunda diferença encontrada**: a lista de palavras-chave do balde
"secundário" (Cancelled/Closed Incomplete) no `index.html` é a MESMA para
todos os tipos - `cancel`/`incomplet`/`rejeit`/`reject` juntos, sempre -
em vez de um conjunto diferente por tipo como eu tinha implementado.
Com o vocabulário de estados limpo que você mostrou (INC nunca diz
"incomplete", REQ/UAM nunca diz "cancel") isso não muda o resultado na
prática, mas unifiquei da mesma forma no `metrics.py` para eliminar
qualquer risco de divergência futura.

**Ao testar novamente com o seu `dates/sc_task.xlsx`**, descobri que os
dados de exemplo tinham a coluna "Tags" preenchida de forma aleatória e
sem correlação com o Item real (ex: um pedido de "Novo Notebook" podia
ganhar a tag "Acesso" por puro acaso) - isso é uma característica dos
dados sintéticos de teste, não da lógica em si, mas gerava ruído
artificial ao aplicar a checagem multi-campo. Corrigi os dados de
exemplo para a tag "Acesso" só aparecer em itens que realmente são de
acesso, e a contagem UAM voltou a ficar limpa (95 tickets, batendo com
a análise anterior sem o ruído).

**Validação final, célula por célula**: somei manualmente
Opened/Resolved/Secondary de SCTASK+UAM+INC mês a mês e comparei contra
o cálculo do painel "ALL" combinado - bate exatamente em todas as
células, e o backlog combinado bate com a contagem real atual
(33+5+47=85).

**Resumo direto**: nenhuma das duas ferramentas tinha uma "conta errada"
isolada - a divergência vinha de classificarem UAM de forma diferente
(campo único vs múltiplos campos). Agora meu código replica exatamente
o critério do `index.html`, então os números devem bater entre as duas
ferramentas quando alimentadas com os mesmos dados-fonte.

## v5: section reordering, restored Classification trend view, numbered sections + TOC

**1-2. Section order fixed.** "Daily Evolution and Trend" (current month)
now comes BEFORE "Monthly Evolution and Trend" (last 6 months), and the
3 daily panels render in INC &rarr; SCTASK &rarr; UAM order.

**3. Fixed uneven card heights (stat_row).** The same fix applied to the
Overview KPI cards a few rounds back never made it to `stat_row()` - used
for the "Current/Opened/Resolved/Closed Incomplete/Net Balance" row on
every trend panel, the critical-panel stats, and the Classification
Errors KPIs. A 2-line title ("Closed Incomplete", "Net Balance") was
making that one card taller than its single-line neighbors. Both
`stat_row()` and the new `stat_grid_2x2()` now use a fixed height (HTML
attribute + inline CSS) regardless of title length.

**4. Classification Errors section restored to its full reference
layout**, matching your screenshot exactly: "Monthly Trend" now shows the
historical cumulative line/area chart on the left and the 4 KPI cards
(Incorrect Tickets, Top Offending Group, Monthly MTTR, Maximum Delay) in
a 2x2 grid on the right, side by side - and the analytical breakdown grid
is back to 4 columns (By Requester / By Group / By Analyst / **Historical
Consolidated**, with Month/Count/% same as the reference tool). This had
been simplified away in an earlier round; restored on your explicit
request.

**Numbered, color-coded sections + a visual table of contents.** Every
major section (1-9) now has its own color and a small circular number
badge in its header - SCTASK blue, INC red, Distribution purple, Status
orange, UAM teal, Daily indigo, Monthly light-blue, Tracking Table
blue-grey, Conversions magenta. A "Report Contents" index sits right
below the Overview KPI cards: one colored chip per section (number badge
+ icon + name, matching its header's color 1:1), so the whole report's
structure is visible before scrolling through it.

## New: second e-mail — Analyst Performance Comparison

A companion report to the main dashboard, focused entirely on **closure
throughput per analyst** - who closed how many tickets today vs
yesterday, this week vs last week, and this month vs the same elapsed
period last month, across REQ + UAM + INC + PRB combined. Sent as a
**separate e-mail**, after the main dashboard.

**Files added:**
- `analyst_metrics.py` - all the comparison math (see below)
- `analyst_charts.py` logic lives in `charts.py`'s new `grouped_horizontal_bar()`
- `analyst_report_builder.py` - the HTML for this e-mail (reuses the main
  dashboard's card/table/color styling, so it reads as a companion piece)
- `main_analyst_report.py` - orchestrator; run it standalone
  (`python main_analyst_report.py` / `run_analyst_report.bat`) or as part
  of the full pipeline (`run_all.bat` now runs download &rarr; main
  dashboard &rarr; this report, in that order, two separate e-mails)

**What "today", "this week", "this month" mean here** - a ticket counts
toward an analyst on the day/week/month **its Closed date** falls in
(not when it was opened): this is a closure-throughput report, not an
intake report. Week and month comparisons use a fair **"same elapsed
period"** basis rather than a partial period vs a full one - if today is
a Wednesday, "this week" is Mon-Wed and "last week" is also Mon-Wed of
the prior week (not the full Mon-Sun), otherwise a mid-week comparison
always looks artificially low. Same idea for months: "this month" is the
1st through today, compared against the 1st through the same day-number
last month.

**Report sections:**
1. Overview KPIs (team totals + deltas)
2. Daily Comparison (Today x Yesterday) - grouped bar chart + full table
3. Weekly Comparison (This Week x Last Week) - same
4. Monthly Comparison (This Month MTD x Last Month, same days) - same
5. **Needs Attention** - analysts whose numbers stand out from the team:
   zero closures today despite open assigned work, this-week closures
   well below the team average, or a sharp week-over-week drop (only
   flagged when they currently have open assigned tickets - someone with
   an empty queue isn't a throughput bottleneck, that's a workload
   question). Every flag shows its exact numbers and reason, in neutral,
   factual language - the report surfaces where the data stands out, it
   doesn't render a verdict.
6. **Top Performers** - leaderboards (today / week / month), the positive
   counterpart, so the report isn't one-sided.

**Configuration** (`.env`, see `.env.example` for the full block):
`ANALYST_EMAIL_TO`/`ANALYST_EMAIL_CC` default to the same recipients as
the main dashboard if left blank - set them explicitly to send this one
to a different (e.g. team-lead-only) audience. The three
`ANALYST_ATTENTION_*` thresholds control what counts as "flagged" - see
the comments in `.env.example` and `analyst_metrics.py`.

Tested with a pinned `REFERENCE_DATE` against the sample data (meaningful
non-zero numbers, 5 analysts correctly flagged with accurate reasons,
leaderboards correctly ranked) and with today's real date (all-zero edge
case, since the sample data doesn't extend to today) - no errors either
way, degrades to "0" cleanly rather than crashing.

## v2 of the Analyst Comparison report — expert-level workforce analytics

The first version was a solid start but wasn't using the metrics/views a
real service-desk workforce-analytics report relies on. Rebuilt with a
proper framework in mind (patterned after what ServiceNow Performance
Analytics / Zendesk Explore / Freshservice Analytics actually show):

**New metrics per analyst** (`analyst_metrics.py`):
- **Avg Resolution Time** (this month) - speed, not just volume
- **SLA Compliance %** (this month) - quality/responsibility, not just speed
- **Open Backlog + its average age** - workload, and how stale it is
- **Completion Ratio** = closed / (closed + open backlog) - normalizes
  volume by how much work they're actually carrying, so a light workload
  closed quickly and a heavy workload closed slowly aren't compared as if
  they were the same thing

**"Nobody left behind" - Complete Team Roster** (new, and the centerpiece
of the report): one row per analyst who closed anything recently OR
currently holds open work - never just a "Top N". Every core metric in
one place, color-coded by performance **quartile** (Top Quartile / Upper-
Mid / Lower-Mid / Needs Support - a spectrum, not a binary flag), computed
only among analysts who closed at least one ticket this month (an empty
queue isn't a performance signal).

**Performance Quadrant scatter** (Volume x SLA Quality) - the classic
WFM view: plots every analyst by tickets closed this month (x) against
their SLA compliance (y), colored by which quadrant they fall in relative
to the team medians (High volume+High quality / High volume+Lower quality
/ Lower volume+High quality / Lower volume+Lower quality). Quadrant
coloring is computed in Python per point rather than relying on chart-
level divider-line annotations, which not every chart renderer supports
consistently - this way the read is guaranteed correct regardless.

**Workload Balance chart** - open backlog per analyst against a "fair
share" reference line (total backlog \u00f7 analysts currently holding open
work), so over/under-loaded analysts are visible against a concrete
benchmark, not just against each other.

**Report order**: Overview &rarr; Complete Team Roster &rarr; Daily &rarr;
Weekly &rarr; Monthly comparisons &rarr; Performance Quadrant &rarr;
Workload Balance &rarr; Needs Attention &rarr; Top Performers. Every
section keeps its own number + color badge, same visual language as the
main dashboard.

Verified against the sample data: all 15 analysts appear in the roster
with correct tiers, the quadrant scatter's 4 groups sum to the full
analyst count (4+4+4+3=15, nobody dropped), and the workload/fair-share
numbers check out arithmetically. Also re-verified the zero-data edge
case (today's real date, past the sample data's range) still renders
without errors.

## v3 of the Analyst Comparison report — heat-intensity visuals + full ITSM metric set

Two things drove this round: (1) too much plain table, wanted colorful
"intensity"/progress-style comparison instead, and (2) a full ITSM
workforce-analytics briefing to check coverage against and fill gaps for.

**Gap-check against the briefing - what was genuinely missing vs already
covered:**
- ✅ Already had: closure volume per analyst, SLA%, backlog aging (main
  dashboard), full-roster "nobody left behind" table, MTTR (monthly)
- ❌ **Queue Balance / Net Flow** (Created \u2212 Closed) - wasn't tracking
  Opened counts in this report at all; added `team_net_flow()` and a new
  "Queue Balance Today" Overview card (color flips red/green depending on
  whether the queue is growing or draining)
- ❌ **Reopen Rate** - checked your actual export columns: **neither INC
  nor SCTASK currently has a reopen-count field**. Built the full
  pipeline (`data_loader._extract_reopen_count`,
  `analyst_metrics.reopen_rate_by_analyst`) so it activates automatically
  the moment your ServiceNow export includes one (common names checked:
  "Reopen Count", "Reopens", "Reopened Count") - until then it shows
  **"N/A" honestly**, never a fabricated 0%.
- ⚠️ **MTTR Today + MTTR Week-average** (the briefing wants both, not just
  monthly) - added `mttr_by_analyst()` reused across both windows, now
  separate roster columns
- ⚠️ **Backlog composition by wait-status** - new "Bottleneck Diagnostics"
  section, a donut breaking the open backlog into Being Worked / Awaiting
  User / Awaiting Vendor-3rd-Party / Awaiting Change-Release / On Hold,
  mapped from your real state vocabulary
- ⚠️ **Aging buckets (<24h / 2-5 days / >5 days)** - same section, second
  donut, the exact bucket scheme requested

**Heat-intensity visuals (the main visual ask) - "Performance Heat Maps"
section**: three horizontal bar charts (Volume, Speed/MTTR, Quality/SLA%)
where **each bar's own color is computed on a red\u2192yellow\u2192green scale**
relative to the team's range for that metric - not a flat single color
per series. MTTR uses a reversed scale (fast = green). This replaces
scanning a table of numbers with an instant "who's hot, who's cold" read.

**Roster table upgrades**: columns now match the requested set exactly
(Today | Yesterday | Diff % | MTTR Today | MTTR Week-avg | This Week |
This Month | Reopen Rate | SLA%), MTTR gets a **red highlight when >50%
above the team's own week average** (verified: 3 analysts correctly
flagged in the sample data), and the table is now **sortable by column
and searchable by name via JS** - degrades gracefully to a clean static,
pre-sorted table in Outlook (which strips `<script>` tags entirely), but
fully interactive when the saved local HTML is opened in a browser.

Verified end to end: 10 charts, all valid JSON; MTTR heat-bar colors
confirmed inverted correctly (fastest analyst = pure green, slowest =
pure red); discrepancy highlighting confirmed firing on exactly the
analysts whose week MTTR exceeds 1.5x the team average.

## v4 of the Analyst Comparison report — group segmentation, consistency, self-history

Three more refinements on top of v3 (heat maps, MTTR today/week, reopen
pipeline, backlog diagnostics - all still in place):

**1. Volume heat-maps segmented by Assignment Group** ("não consigo
comparar limão com laranja"). Added `analyst_primary_group()` - each
analyst is assigned to their single most common Assignment group - and
the Volume heat-bar chart is now rendered ONCE PER GROUP instead of one
global ranking, so an analyst on a specialized queue (e.g. Security)
never gets compared against Service Desk N1's naturally higher ticket
volume. Verified: 5 groups detected in the sample data, each got its own
correctly-scoped heat-bar (3 analysts each). Speed (MTTR) and Quality
(SLA%) stayed team-wide - a fast, SLA-compliant resolution is a fair bar
regardless of queue, unlike raw volume.

**2. Consistency & Outliers** - new floating min-max range bar per
analyst (`daily_consistency_stats()`, 21-day lookback), colored by
coefficient of variation (std/mean): green = steady day-to-day output,
red = erratic. Each analyst's own average is printed right in their axis
label. This directly answers "quero gráfico que mostra consistência e
outliers de cada analista."

**3. Self vs Personal History** - This Month (MTD) vs each analyst's OWN
trailing 3-full-month average (`self_vs_own_history()`), never against
teammates. Green bar = ahead of their own normal pace, red = behind it.
This is the "comparações entre o próprio analista vs meses passados, uma
média" ask - a self-benchmark, explicitly separate from the team-relative
views elsewhere in the report.

Report is now 12 numbered, color-coded sections: Roster, Daily, Weekly,
Monthly, Heat Maps by Group, Consistency & Outliers, Self vs Personal
History, Performance Quadrant, Workload Balance (kept - liked this one),
Bottleneck Diagnostics, Needs Attention, Top Performers.

Verified end to end: 16 charts, all valid JSON; group segmentation
confirmed (5 groups, correct roster per group); consistency chart labels
confirmed showing each analyst's own average alongside their min-max
range.

## v5 of the Analyst Comparison report — compact layout, grid-based, lighter

Pure layout/density pass - the report was correct but too tall (every
chart full-width, stacked one after another). Went from 12 sections down
to 9, and from mostly full-width charts down to mostly 2-3 column grids:

**Daily/Weekly/Monthly merged into ONE section**, 3 mini-charts side by
side instead of three separate full-width sections each with its own
chart + full table. The full numbers didn't disappear - they're all
still in the Complete Team Roster (section 1), so this stays a fast
visual scan instead of repeating the same data three times.

**Heat Maps by Group now a compact grid**: the per-group volume charts
render 2 per row instead of stacked full-width; Speed and Quality sit
side by side as a 2-column pair instead of two more full-width charts.

**Removed the Performance Quadrant** (scatter chart) entirely, per your
request - one less full-width section.

**Top Performers redesigned** - was a plain text list, now inline
progress-bars (proportional width + opacity per rank, medal emojis,
value on the right) - same visual language as the heat-maps, pure
HTML/CSS so it renders identically in Outlook and browsers (no extra
chart-image round-trip needed for this one).

Result: report file size down from 127KB to 104KB, and - more
importantly for actually reading it - most charts now render at
520-560px (2-3 per row) instead of 1080px full-width; only the 3 charts
that genuinely need to list all 15 analysts (Consistency, Self-History,
Workload Balance) stayed full-width, since compressing 15 analyst labels
into a half-width column would hurt legibility more than it helps
compactness.

Final section order (9, renumbered/recolored): Roster \u2192 Period
Comparison \u2192 Heat Maps by Group \u2192 Consistency & Outliers \u2192 Self vs
Personal History \u2192 Workload Balance \u2192 Bottleneck Diagnostics \u2192 Needs
Attention \u2192 Top Performers.

# -*- coding: utf-8 -*-
"""
===============================================================================
 GESTÃO DE PROBLEMAS - LACUNAS DE RCA / PCA / KB
===============================================================================
 Lê DOIS arquivos .xlsx reais, cruza pela chave  Problem = Source task  e gera:

   1) base_unificada.xlsx  -> uma linha por problema:
        Problem | Opened by | RCA Status | Problem task type | Related Incidents |
        Active | Problem task type (PCA) | Active (PCA) | Number (KB) |
        Short description (KB)

   2) dashboard.html       -> cards de resumo
                            + tabela "Lacunas por analista"
                            + "Problemas com pendência" em linha corrida

   3) (opcional) e-mail via Outlook local, com o dashboard no corpo e a base
      unificada em anexo.

 -----------------------------------------------------------------------------
 USO
 -----------------------------------------------------------------------------
   python dashboard_rca_pca.py

   Sem argumentos, procura por problem_task.xlsx e kb_knowledge.xlsx na pasta
   atual e na pasta do próprio script.

   python dashboard_rca_pca.py --email fulano@empresa.com --cc chefe@empresa.com

   Opções:
     --problemas CAMINHO     planilha com Problem, Opened by, RCA Status,
                             Problem task type, Related Incidents, Active
                             (padrão: problem_task.xlsx)
     --kb CAMINHO            planilha com Source task, Number, Short description
                             (padrão: kb_knowledge.xlsx)
     --aba-problemas NOME    aba a ler no 1º arquivo (padrão: detecta sozinho)
     --aba-kb NOME           aba a ler no 2º arquivo (padrão: detecta sozinho)
     --saida-xlsx CAMINHO    padrão: base_unificada.xlsx
     --saida-html CAMINHO    padrão: dashboard.html
     --data DD/MM/AAAA       data de posição exibida (padrão: data de hoje)
     --email DESTINATARIOS   dispara o e-mail (separe vários com ;)
     --cc DESTINATARIOS      cópia
     --assunto TEXTO         assunto do e-mail
     --somente-abrir-email   abre a janela do Outlook em vez de enviar direto

 Requisitos: openpyxl. Para o e-mail: pywin32 (Windows) ou Outlook (macOS).
===============================================================================
"""

import argparse
import os
import sys
import unicodedata
from datetime import date
from html import escape

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


# =============================================================================
# 1. CONFIGURAÇÃO DE COLUNAS
# =============================================================================

# Colunas esperadas na planilha de problemas -> apelidos aceitos
MAPA_PROBLEMAS = {
    "Problem": ["problem", "problema", "numero do problema", "prb"],
    "Opened by": ["opened by", "aberto por", "analista", "assigned to"],
    "RCA Status": ["rca status", "status da rca", "status rca"],
    "Problem task type": ["problem task type", "tipo de tarefa", "task type",
                          "tipo da tarefa do problema"],
    "Related Incidents": ["related incidents", "incidentes relacionados",
                          "incidentes vinculados", "incidentes"],
    "Active": ["active", "ativo", "ativa"],
}

# Colunas esperadas na planilha de conhecimento -> apelidos aceitos
MAPA_KB = {
    "Source task": ["source task", "tarefa de origem", "problem", "problema"],
    "Number": ["number", "numero", "kb", "artigo"],
    "Short description": ["short description", "descricao", "descricao curta",
                          "titulo"],
}

VERDADEIROS = {"verdadeiro", "true", "sim", "yes", "1", "y", "s"}
PUBLICADOS = {"published", "publicado", "publicada"}

# Nomes procurados automaticamente quando --problemas / --kb não são informados
PADRAO_PROBLEMAS = ["problem_task.xlsx", "problem task.xlsx", "problemas.xlsx",
                    "base_problemas.xlsx"]
PADRAO_KB = ["kb_knowledge.xlsx", "kb knowledge.xlsx", "kb.xlsx",
             "knowledge.xlsx", "base_kb.xlsx"]

DIR_SCRIPT = os.path.dirname(os.path.abspath(__file__))

# Paleta usada no HTML e no e-mail
COR_TINTA = "#16202b"
COR_TEXTO = "#3c4d5e"
COR_FRACA = "#7a8794"
COR_LINHA = "#dfe5ec"
COR_FUNDO = "#eef1f5"
COR_NAVY = "#2f4f76"
COR_VERMELHO = "#a32b2b"
COR_LARANJA = "#c9700f"
COR_VERDE = "#2f7a4a"
COR_ZERO = "#aab4bf"


# =============================================================================
# 2. FUNÇÕES DE APOIO
# =============================================================================

def normalizar(texto_bruto):
    """minúsculas, sem acento e sem espaços duplicados - para casar cabeçalhos."""
    if texto_bruto is None:
        return ""
    valor = str(texto_bruto).strip().lower()
    valor = unicodedata.normalize("NFKD", valor)
    valor = "".join(c for c in valor if not unicodedata.combining(c))
    return " ".join(valor.split())


def texto(valor):
    """Converte qualquer célula em string limpa."""
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return str(valor).strip()


def inteiro(valor):
    """Converte a célula em int; devolve 0 quando não for numérica."""
    if valor is None or valor == "":
        return 0
    try:
        return int(float(str(valor).replace(".", "").replace(",", ".")))
    except (TypeError, ValueError):
        return 0


def eh_verdadeiro(valor):
    return normalizar(valor) in VERDADEIROS


def eh_publicado(valor):
    return normalizar(valor) in PUBLICADOS


def abas_nomes(caminho):
    wb = load_workbook(caminho, data_only=True, read_only=True)
    nomes = list(wb.sheetnames)
    wb.close()
    return nomes


# =============================================================================
# 3. LEITURA DAS PLANILHAS
# =============================================================================

def _mapear(cabecalho, mapa_colunas):
    """
    Devolve {coluna canônica: posição} para um cabeçalho já normalizado.
    Passo 1: casa tudo o que for igual. Passo 2: só então tenta o parcial,
    para que 'Problem' não roube a coluna 'Problem task type'.
    """
    posicoes = {}
    usadas = set()

    for canonico, apelidos in mapa_colunas.items():
        for posicao, nome in enumerate(cabecalho):
            if posicao not in usadas and nome and nome in apelidos:
                posicoes[canonico] = posicao
                usadas.add(posicao)
                break

    for canonico, apelidos in mapa_colunas.items():
        if canonico in posicoes:
            continue
        for posicao, nome in enumerate(cabecalho):
            if posicao in usadas or not nome:
                continue
            if any(apelido in nome or nome in apelido for apelido in apelidos):
                posicoes[canonico] = posicao
                usadas.add(posicao)
                break

    return posicoes


def ler_planilha(caminho, mapa_colunas, nome_aba=None, rotulo="", chave=None):
    """
    Lê a planilha e devolve uma lista de dicionários com os nomes de coluna
    canônicos (as chaves de mapa_colunas). Colunas não encontradas viram "".

    A linha de cabeçalho é procurada nas 30 primeiras linhas de cada aba:
    vence a que casar com mais colunas esperadas. A coluna-chave é preenchida
    para baixo, para suportar exports agrupados ou com células mescladas.
    """
    if not os.path.isfile(caminho):
        sys.exit(f"ERRO: arquivo não encontrado -> {caminho}")

    try:
        wb = load_workbook(caminho, data_only=True)
    except Exception as erro:
        sys.exit(f"ERRO ao abrir {caminho}: {erro}")

    if nome_aba:
        if nome_aba not in wb.sheetnames:
            sys.exit(f"ERRO: aba '{nome_aba}' não existe em {caminho}. "
                     f"Abas disponíveis: {', '.join(wb.sheetnames)}")
        abas = [wb[nome_aba]]
    else:
        abas = [wb[nome] for nome in wb.sheetnames]

    melhor = None   # (qtd_colunas_casadas, ws, linhas, indice_cabecalho, posicoes)

    for ws in abas:
        linhas = [list(linha) for linha in ws.iter_rows(values_only=True)]
        for indice, linha in enumerate(linhas[:30]):
            cabecalho = [normalizar(celula) for celula in linha]
            if not any(cabecalho):
                continue
            posicoes = _mapear(cabecalho, mapa_colunas)
            if chave and chave not in posicoes:
                continue                      # cabeçalho sem a coluna-chave não serve
            if melhor is None or len(posicoes) > melhor[0]:
                melhor = (len(posicoes), ws, linhas, indice, posicoes)

    wb.close()

    if melhor is None or melhor[0] == 0:
        # diagnóstico: mostra o que realmente veio na planilha
        wb = load_workbook(caminho, data_only=True)
        ws = wb[nome_aba] if nome_aba else wb[wb.sheetnames[0]]
        primeira = next(ws.iter_rows(values_only=True), ())
        wb.close()
        print(f"ERRO [{rotulo}]: não encontrei a coluna "
              f"'{chave or list(mapa_colunas)[0]}' em {os.path.basename(caminho)}.")
        print(f"       Abas do arquivo: {', '.join(abas_nomes(caminho))}")
        print(f"       Primeira linha lida: "
              f"{[texto(c) for c in primeira] if primeira else '(vazia)'}")
        print(f"       Colunas esperadas: {', '.join(mapa_colunas)}")
        sys.exit(1)

    _, ws, linhas, indice_cabecalho, posicoes = melhor

    faltando = [coluna for coluna in mapa_colunas if coluna not in posicoes]
    if faltando:
        print(f"AVISO [{rotulo}]: colunas não encontradas e tratadas como vazias: "
              f"{', '.join(faltando)}")

    registros = []
    ultimo_valor_chave = ""
    for linha in linhas[indice_cabecalho + 1:]:
        if linha is None or all(celula is None or texto(celula) == "" for celula in linha):
            continue

        registro = {}
        for canonico in mapa_colunas:
            posicao = posicoes.get(canonico)
            registro[canonico] = linha[posicao] if (
                posicao is not None and posicao < len(linha)) else ""

        # célula mesclada / export agrupado: repete o último valor da chave
        if chave:
            valor = texto(registro.get(chave))
            if valor:
                ultimo_valor_chave = valor
            elif ultimo_valor_chave:
                registro[chave] = ultimo_valor_chave
            else:
                continue                      # ainda não houve nenhuma chave válida

        registros.append(registro)

    if chave and not any(texto(r.get(chave)) for r in registros):
        sys.exit(f"ERRO [{rotulo}]: a coluna '{chave}' foi localizada em "
                 f"'{ws.title}', mas está vazia em todas as {len(registros)} linhas.")

    print(f"[leitura] {rotulo}: {len(registros)} linhas · aba '{ws.title}' · "
          f"cabeçalho na linha {indice_cabecalho + 1} ({os.path.basename(caminho)})")
    print(f"          colunas reconhecidas: {', '.join(sorted(posicoes))}")
    return registros


# =============================================================================
# 4. JUNÇÃO: UMA LINHA POR PROBLEMA
# =============================================================================

COL_UNIFICADA = ["Problem", "Opened by", "RCA Status", "Problem task type",
                 "Related Incidents", "Active", "Problem task type (PCA)",
                 "Active (PCA)", "Number (KB)", "Short description (KB)"]


def juntar(linhas_problemas, linhas_kb):
    """Cruza as duas bases pela chave Problem = Source task."""
    kb_por_problema = {}
    for artigo in linhas_kb:
        chave = texto(artigo.get("Source task"))
        if chave and chave not in kb_por_problema:
            kb_por_problema[chave] = artigo

    grupos = {}
    ordem = []
    ignoradas = 0
    for linha in linhas_problemas:
        chave = texto(linha.get("Problem"))
        if not chave:
            ignoradas += 1
            continue
        if chave not in grupos:
            grupos[chave] = []
            ordem.append(chave)
        grupos[chave].append(linha)

    if ignoradas:
        print(f"AVISO: {ignoradas} linha(s) sem 'Problem' foram ignoradas.")

    unificado = []
    for chave in ordem:
        tarefas = grupos[chave]

        rcas = [t for t in tarefas if texto(t.get("Problem task type")).upper() == "RCA"]
        pcas = [t for t in tarefas if texto(t.get("Problem task type")).upper() == "PCA"]
        rca = rcas[0] if rcas else None
        pca = pcas[0] if pcas else None
        artigo = kb_por_problema.get(chave)

        def primeiro(campo):
            """Primeiro valor não vazio do campo entre as linhas do problema."""
            for tarefa in tarefas:
                valor = texto(tarefa.get(campo))
                if valor:
                    return valor
            return ""

        rca_status = primeiro("RCA Status")
        incidentes = max(inteiro(t.get("Related Incidents")) for t in tarefas)

        unificado.append({
            "Problem": chave,
            "Opened by": primeiro("Opened by") or "(sem responsável)",
            "RCA Status": rca_status,
            "Problem task type": "RCA" if rca else "",
            "Related Incidents": incidentes,
            "Active": texto(rca.get("Active")) if rca else "",
            "Problem task type (PCA)": "PCA" if pca else "",
            "Active (PCA)": texto(pca.get("Active")) if pca else "",
            "Number (KB)": texto(artigo.get("Number")) if artigo else "",
            "Short description (KB)": texto(artigo.get("Short description")) if artigo else "",
            # marcações usadas no dashboard
            "_sem_rca": rca is None,
            "_rca_nao_publicada": rca is not None and not eh_publicado(rca_status),
            "_rca_incompleta": any(eh_verdadeiro(t.get("Active")) for t in rcas),
            "_sem_pca": pca is None,
            "_pca_ativo": any(eh_verdadeiro(t.get("Active")) for t in pcas),
            "_sem_kb": artigo is None,
        })

    return unificado


def resumo_por_analista(unificado):
    """Uma linha por analista, na ordem de colunas do relatório."""
    mapa = {}
    for reg in unificado:
        analista = reg["Opened by"]
        linha = mapa.setdefault(analista, {
            "analista": analista, "problemas": 0, "rca_nao_publicada": 0,
            "sem_kb": 0, "sem_pca": 0, "sem_rca": 0, "rca_incompleto": 0,
        })
        linha["problemas"] += 1
        linha["rca_nao_publicada"] += 1 if reg["_rca_nao_publicada"] else 0
        linha["sem_kb"] += 1 if reg["_sem_kb"] else 0
        linha["sem_pca"] += 1 if reg["_sem_pca"] else 0
        linha["sem_rca"] += 1 if reg["_sem_rca"] else 0
        linha["rca_incompleto"] += 1 if reg["_rca_incompleta"] else 0

    resumo = list(mapa.values())
    resumo.sort(key=lambda x: (-x["problemas"], x["analista"]))
    return resumo


def calcular_indicadores(unificado):
    total = len(unificado)
    sem_lacuna = sum(
        1 for r in unificado
        if not r["_sem_rca"] and not r["_rca_nao_publicada"]
        and not r["_rca_incompleta"] and not r["_sem_pca"] and not r["_sem_kb"]
    )
    return {
        "problemas": total,
        "analistas": len({r["Opened by"] for r in unificado}),
        "incidentes": sum(r["Related Incidents"] for r in unificado),
        "sem_rca": sum(1 for r in unificado if r["_sem_rca"]),
        "rca_nao_publicada": sum(1 for r in unificado if r["_rca_nao_publicada"]),
        "rca_incompleto": sum(1 for r in unificado if r["_rca_incompleta"]),
        "sem_pca": sum(1 for r in unificado if r["_sem_pca"]),
        "pca_ativo": sum(1 for r in unificado if r["_pca_ativo"]),
        "sem_kb": sum(1 for r in unificado if r["_sem_kb"]),
        "sem_lacuna": sem_lacuna,
        "com_lacuna": total - sem_lacuna,
    }


# =============================================================================
# 5. MARCOS E PENDÊNCIAS
# =============================================================================

def marcos_do_problema(reg):
    """
    Os 5 marcos, nas mesmas definições da tabela por analista.
    Devolve uma lista de (rótulo, cumprido).
    """
    tem_rca = not reg["_sem_rca"]
    tem_pca = not reg["_sem_pca"]

    return [
        ("RCA criada", tem_rca),
        ("RCA publicada", tem_rca and not reg["_rca_nao_publicada"]),
        ("RCA concluída", tem_rca and not reg["_rca_incompleta"]),
        ("PCA criado", tem_pca),
        ("KB publicado", not reg["_sem_kb"]),
    ]


def cor_do_placar(cumpridos):
    """1/5 vermelho · 2/5 laranja · 3/5 e 4/5 azul."""
    if cumpridos <= 1:
        return COR_VERMELHO
    if cumpridos == 2:
        return COR_LARANJA
    return COR_NAVY


def pendencias_por_analista(unificado):
    """
    Devolve [(analista, [(problema, cumpridos, total, faltando), ...]), ...],
    ordenado por analista, com apenas os problemas que têm algum marco aberto.
    """
    por_analista = {}
    for reg in unificado:
        marcos = marcos_do_problema(reg)
        cumpridos = sum(1 for _, ok in marcos if ok)
        if cumpridos >= len(marcos):
            continue
        faltando = [rotulo for rotulo, ok in marcos if not ok]
        por_analista.setdefault(reg["Opened by"], []).append(
            (reg["Problem"], cumpridos, len(marcos), faltando)
        )

    for itens in por_analista.values():
        itens.sort(key=lambda item: (item[1], item[0]))

    return sorted(por_analista.items(), key=lambda par: par[0].lower())


# =============================================================================
# 6. SAÍDA .XLSX
# =============================================================================

LARGURAS = {
    "Problem": 16, "Opened by": 24, "RCA Status": 15, "Problem task type": 19,
    "Related Incidents": 18, "Active": 14, "Problem task type (PCA)": 23,
    "Active (PCA)": 15, "Number (KB)": 16, "Short description (KB)": 60,
}


def gravar_unificada(unificado, caminho):
    wb = Workbook()
    ws = wb.active
    ws.title = "Base unificada"
    ws.append(COL_UNIFICADA)
    for reg in unificado:
        ws.append([reg.get(coluna, "") for coluna in COL_UNIFICADA])

    fina = Side(style="thin", color="D5DCE4")
    borda = Border(left=fina, right=fina, top=fina, bottom=fina)

    for indice, nome in enumerate(COL_UNIFICADA, start=1):
        celula = ws.cell(row=1, column=indice)
        celula.font = Font(name="Arial", bold=True, size=10, color="FFFFFF")
        celula.fill = PatternFill("solid", fgColor="2F4F76")
        celula.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        celula.border = borda
        ws.column_dimensions[get_column_letter(indice)].width = LARGURAS.get(nome, 20)
    ws.row_dimensions[1].height = 30

    for linha in range(2, ws.max_row + 1):
        for coluna in range(1, len(COL_UNIFICADA) + 1):
            celula = ws.cell(row=linha, column=coluna)
            celula.font = Font(name="Arial", size=10)
            celula.border = borda
            celula.alignment = Alignment(horizontal="left", vertical="center")
            if linha % 2 == 0:
                celula.fill = PatternFill("solid", fgColor="F2F5F8")

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(COL_UNIFICADA))}{ws.max_row}"
    wb.save(caminho)


# =============================================================================
# 7. SAÍDA .HTML (NAVEGADOR)
# =============================================================================

CSS = """
*{box-sizing:border-box;}

body{
  margin:0;
  padding:44px 28px 64px;
  background:#eef1f5;
  color:#16202b;
  font-family:"Inter","Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size:16px;
  line-height:1.5;
  -webkit-font-smoothing:antialiased;
}

.pagina{max-width:1120px;margin:0 auto;}

.eyebrow{
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:12px;
  letter-spacing:.18em;
  text-transform:uppercase;
  color:#7a8794;
  margin:0 0 12px;
}

h1{
  font-family:"Archivo","Helvetica Neue",Arial,sans-serif;
  font-weight:900;
  font-size:38px;
  line-height:1.08;
  letter-spacing:-.015em;
  text-transform:uppercase;
  margin:0 0 14px;
}

.lead{max-width:70ch;font-size:17px;color:#3c4d5e;margin:0 0 32px;}
.lead strong{color:#a32b2b;font-weight:700;}

/* ------------------------------------------------------------------ cards */
.cards{display:flex;flex-wrap:wrap;gap:16px;margin-bottom:44px;}

.card{
  flex:1 1 calc(25% - 12px);
  min-width:210px;
  background:#fff;
  border:1px solid #dfe5ec;
  border-left:5px solid #c6ced8;
  border-radius:6px;
  padding:18px 18px 16px;
}

.card--alerta{border-left-color:#a32b2b;}
.card--atencao{border-left-color:#c9700f;}
.card--ok{border-left-color:#2f7a4a;}

.card .valor{
  font-family:"Archivo","Helvetica Neue",Arial,sans-serif;
  font-weight:900;
  font-size:42px;
  line-height:1;
  letter-spacing:-.03em;
  display:block;
  margin-bottom:10px;
  color:#16202b;
}

.card--alerta .valor{color:#a32b2b;}
.card--atencao .valor{color:#c9700f;}
.card--ok .valor{color:#2f7a4a;}

.card .rotulo{display:block;font-size:14.5px;color:#3c4d5e;}

.card .nota{
  display:block;
  margin-top:7px;
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:12px;
  color:#7a8794;
}

/* ----------------------------------------------------------------- seções */
h2{
  font-family:"Archivo","Helvetica Neue",Arial,sans-serif;
  font-weight:900;
  font-size:24px;
  letter-spacing:-.01em;
  text-transform:uppercase;
  margin:0 0 6px;
}

.secao{margin-bottom:44px;}

.subtitulo{
  font-size:14px;
  color:#7a8794;
  margin:0 0 18px;
  padding-bottom:16px;
  border-bottom:1px solid #dfe5ec;
}

/* ----------------------------------------------------------------- tabela */
.quadro{
  background:#fff;
  border:1px solid #dfe5ec;
  border-radius:6px;
  overflow:hidden;
}

table{width:100%;border-collapse:collapse;}

thead th{
  background:#2f4f76;
  color:#fff;
  font-size:12px;
  font-weight:700;
  letter-spacing:.1em;
  text-transform:uppercase;
  text-align:center;
  padding:16px 12px;
  vertical-align:middle;
}

thead th:first-child{text-align:left;padding-left:24px;}

tbody td{
  padding:15px 12px;
  text-align:center;
  border-bottom:1px solid #dfe5ec;
  font-size:16px;
}

tbody td:first-child{text-align:left;padding-left:24px;}
tbody tr:last-child td{border-bottom:none;}
tbody tr:hover td{background:#f7f9fb;}

tfoot td{
  padding:14px 12px;
  text-align:center;
  font-size:15px;
  font-weight:700;
  background:#f4f7fa;
  border-top:2px solid #2f4f76;
}

tfoot td:first-child{
  text-align:left;
  padding-left:24px;
  text-transform:uppercase;
  letter-spacing:.06em;
  font-size:12px;
  color:#3c4d5e;
}

.num{font-weight:700;color:#a32b2b;}
.num.zero{font-weight:400;color:#aab4bf;}
.num.neutro{color:#16202b;}

/* ------------------------------------------------- pendências compactas */
.pendencias{
  background:#fff;
  border:1px solid #dfe5ec;
  border-radius:6px;
  padding:4px 22px;
}

.pendencia-linha{
  display:flex;
  flex-wrap:wrap;
  align-items:baseline;
  gap:6px 10px;
  padding:12px 0;
  border-bottom:1px solid #f1f4f7;
}

.pendencia-linha:last-child{border-bottom:none;}

.pendencia-analista{
  flex:0 0 178px;
  font-weight:700;
  font-size:14.5px;
  color:#16202b;
}

.pendencia-analista span{
  display:block;
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:11px;
  font-weight:400;
  color:#7a8794;
}

.pendencia-itens{
  flex:1 1 0;
  min-width:0;
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:13px;
  line-height:2;
  color:#c3ccd6;
}

.chip{
  white-space:nowrap;
  padding:2px 8px;
  border-radius:4px;
  background:#f4f7fa;
}

.chip b{font-weight:600;color:#3c4d5e;}
.chip i{font-style:normal;font-weight:700;margin-left:5px;}

.chip.n1{background:#f7e6e6;}
.chip.n1 b{color:#7d2222;}
.chip.n1 i{color:#a32b2b;}

.chip.n2{background:#fbeedd;}
.chip.n2 b{color:#8a4d09;}
.chip.n2 i{color:#c9700f;}

.chip.n3{background:#e8eef5;}
.chip.n3 b{color:#24405f;}
.chip.n3 i{color:#2f4f76;}

.legenda{
  display:flex;
  flex-wrap:wrap;
  gap:20px;
  margin-top:14px;
  font-size:13px;
  color:#7a8794;
}

.legenda span{display:flex;align-items:center;gap:7px;}
.ponto{width:11px;height:11px;border-radius:3px;display:inline-block;}
.ponto.n1{background:#a32b2b;}
.ponto.n2{background:#c9700f;}
.ponto.n3{background:#2f4f76;}

.vazio-estado{
  background:#fff;
  border:1px solid #dfe5ec;
  border-radius:6px;
  padding:26px 24px;
  color:#3c4d5e;
}

.rodape{
  margin-top:32px;
  padding-top:16px;
  border-top:1px solid #dfe5ec;
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:12px;
  line-height:1.9;
  color:#7a8794;
}

@media (max-width:1024px){.card{flex:1 1 calc(50% - 8px);}}

@media (max-width:760px){
  body{padding:28px 14px 48px;}
  h1{font-size:28px;}
  .card{flex:1 1 100%;min-width:0;}
  .quadro{overflow-x:auto;}
  table{min-width:680px;}
  .pendencias{padding:4px 14px;}
  .pendencia-analista{flex:1 1 100%;}
}

@media print{
  body{background:#fff;padding:0;}
  .card,.quadro,.pendencias{break-inside:avoid;}
}
"""


def card(valor, rotulo, tom="neutro", nota=""):
    classe = "" if tom == "neutro" else f" card--{tom}"
    nota_html = f'\n      <span class="nota">{escape(nota)}</span>' if nota else ""
    return (
        f'    <div class="card{classe}">\n'
        f'      <span class="valor">{valor}</span>\n'
        f'      <span class="rotulo">{escape(rotulo)}</span>{nota_html}\n'
        f'    </div>\n'
    )


def celula_num(valor, neutro=False):
    if valor == 0:
        return '<td><span class="num zero">0</span></td>'
    classe = "num neutro" if neutro else "num"
    return f'<td><span class="{classe}">{valor}</span></td>'


def classe_chip(cumpridos):
    if cumpridos <= 1:
        return "n1"
    if cumpridos == 2:
        return "n2"
    return "n3"


def montar_pendencias(unificado):
    """Uma linha por analista, com os problemas em linha corrida."""
    grupos = pendencias_por_analista(unificado)

    if not grupos:
        return ('    <div class="vazio-estado">Nenhum problema com pendência — '
                'todos têm RCA publicada e concluída, PCA criado e artigo de '
                'conhecimento.</div>\n'), 0

    total = sum(len(itens) for _, itens in grupos)
    partes = ['    <div class="pendencias">\n']

    for analista, itens in grupos:
        partes.append('      <div class="pendencia-linha">\n')
        partes.append(
            f'        <div class="pendencia-analista">{escape(analista)}'
            f'<span>{len(itens)} pendente(s)</span></div>\n'
        )
        partes.append('        <div class="pendencia-itens">')

        chips = []
        for problema, cumpridos, total_marcos, faltando in itens:
            dica = "Falta: " + ", ".join(faltando)
            chips.append(
                f'<span class="chip {classe_chip(cumpridos)}" title="{escape(dica)}">'
                f'<b>{escape(problema)}</b><i>{cumpridos}/{total_marcos}</i></span>'
            )
        partes.append(" ; ".join(chips))
        partes.append('</div>\n')
        partes.append('      </div>\n')

    partes.append('    </div>\n')
    partes.append(
        '    <div class="legenda">\n'
        '      <span><i class="ponto n1"></i> 1 de 5 marcos cumpridos</span>\n'
        '      <span><i class="ponto n2"></i> 2 de 5</span>\n'
        '      <span><i class="ponto n3"></i> 3 ou 4 de 5</span>\n'
        '    </div>\n'
    )

    return "".join(partes), total


def gerar_html(unificado, indicadores, resumo, data_posicao,
               origem_problemas, origem_kb):
    i = indicadores
    pendencias, qtd_pendentes = montar_pendencias(unificado)

    cards = (
        card(i["problemas"], "problemas na base", "neutro",
             f'{i["incidentes"]} incidentes vinculados · {i["analistas"]} analistas')
        + card(i["sem_rca"], "sem tarefa de RCA", "alerta")
        + card(i["rca_nao_publicada"], "RCA não publicada", "alerta")
        + card(i["rca_incompleto"], "RCA incompleto (ainda ativa)", "atencao")
        + card(i["sem_pca"], "sem tarefa de PCA", "alerta")
        + card(i["pca_ativo"], "PCA ainda em execução", "atencao")
        + card(i["sem_kb"], "sem artigo de conhecimento", "alerta")
        + card(i["sem_lacuna"], "problemas sem nenhuma lacuna", "ok")
    )

    linhas = ""
    for linha in resumo:
        linhas += (
            "          <tr>\n"
            f'            <td>{escape(linha["analista"])}</td>\n'
            f'            {celula_num(linha["problemas"], neutro=True)}\n'
            f'            {celula_num(linha["rca_nao_publicada"])}\n'
            f'            {celula_num(linha["sem_kb"])}\n'
            f'            {celula_num(linha["sem_pca"])}\n'
            f'            {celula_num(linha["sem_rca"])}\n'
            f'            {celula_num(linha["rca_incompleto"])}\n'
            "          </tr>\n"
        )

    rodape_tabela = (
        "          <tr>\n"
        f'            <td>Total ({len(resumo)} analistas)</td>\n'
        f'            <td>{i["problemas"]}</td>\n'
        f'            <td>{i["rca_nao_publicada"]}</td>\n'
        f'            <td>{i["sem_kb"]}</td>\n'
        f'            <td>{i["sem_pca"]}</td>\n'
        f'            <td>{i["sem_rca"]}</td>\n'
        f'            <td>{i["rca_incompleto"]}</td>\n'
        "          </tr>\n"
    )

    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gestão de problemas · Posição de {data_posicao}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;700;900&family=IBM+Plex+Mono:wght@400;600&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
{CSS}
</style>
</head>
<body>
<div class="pagina">

  <p class="eyebrow">Gestão de problemas · Posição de {data_posicao}</p>
  <h1>Lacunas de RCA, PCA e conhecimento</h1>
  <p class="lead">
    Resumo do cruzamento entre a base de problemas e a base de artigos de conhecimento —
    <strong>{i["com_lacuna"]} dos {i["problemas"]} problemas têm pelo menos uma pendência.</strong>
  </p>

  <section class="cards">
{cards}  </section>

  <section class="secao">
    <h2>Lacunas por analista</h2>
    <p class="subtitulo">
      Problemas abertos por analista e em quantos deles cada etapa ficou pendente.
    </p>
    <div class="quadro">
      <table>
        <thead>
          <tr>
            <th>Analista</th>
            <th>Problemas</th>
            <th>RCA não publicada</th>
            <th>Sem KB</th>
            <th>Sem PCA</th>
            <th>Sem RCA</th>
            <th>RCA incompleto</th>
          </tr>
        </thead>
        <tbody>
{linhas}        </tbody>
        <tfoot>
{rodape_tabela}        </tfoot>
      </table>
    </div>
  </section>

  <section class="secao">
    <h2>Problemas com pendência</h2>
    <p class="subtitulo">
      {qtd_pendentes} de {i["problemas"]} problemas com marco em aberto, por analista.
      O número ao lado do PRB é quantos dos 5 marcos foram cumpridos;
      passe o cursor para ver o que falta.
    </p>
{pendencias}  </section>

  <footer class="rodape">
    Origem: {escape(origem_problemas)} + {escape(origem_kb)} · chave da junção: Problem = Source task.<br>
    Marcos: RCA criada · RCA publicada · RCA concluída (Active = FALSO) · PCA criado · KB publicado.
  </footer>

</div>
</body>
</html>
"""


# =============================================================================
# 8. SAÍDA .HTML (CORPO DO E-MAIL, COM ESTILO EM LINHA)
# =============================================================================

def _card_email(valor, rotulo, cor):
    return (
        f'<td width="25%" valign="top" style="padding:6px;">'
        f'<table width="100%" cellpadding="0" cellspacing="0" border="0" '
        f'style="background:#ffffff;border:1px solid {COR_LINHA};'
        f'border-left:4px solid {cor};">'
        f'<tr><td style="padding:14px 16px;">'
        f'<div style="font-family:Arial,Helvetica,sans-serif;font-size:32px;'
        f'font-weight:bold;color:{cor};line-height:1;">{valor}</div>'
        f'<div style="font-family:Arial,Helvetica,sans-serif;font-size:13px;'
        f'color:{COR_TEXTO};padding-top:8px;">{escape(rotulo)}</div>'
        f'</td></tr></table></td>'
    )


def gerar_html_email(unificado, indicadores, resumo, data_posicao,
                     origem_problemas, origem_kb):
    """
    Versão em tabelas com estilo em linha, que é o que o Outlook renderiza bem.
    Traz os cards, a tabela por analista e as pendências em linha corrida.
    """
    i = indicadores
    fonte = "Arial,Helvetica,sans-serif"

    # ---------------------------------------------------------------- cards
    definicao_cards = [
        (i["problemas"], "problemas na base", COR_TINTA),
        (i["sem_rca"], "sem tarefa de RCA", COR_VERMELHO),
        (i["rca_nao_publicada"], "RCA não publicada", COR_VERMELHO),
        (i["rca_incompleto"], "RCA incompleto (ainda ativa)", COR_LARANJA),
        (i["sem_pca"], "sem tarefa de PCA", COR_VERMELHO),
        (i["pca_ativo"], "PCA ainda em execução", COR_LARANJA),
        (i["sem_kb"], "sem artigo de conhecimento", COR_VERMELHO),
        (i["sem_lacuna"], "problemas sem nenhuma lacuna", COR_VERDE),
    ]

    linhas_cards = ""
    for inicio in range(0, len(definicao_cards), 4):
        bloco = definicao_cards[inicio:inicio + 4]
        celulas = "".join(_card_email(valor, rotulo, cor) for valor, rotulo, cor in bloco)
        linhas_cards += f"<tr>{celulas}</tr>"

    # ------------------------------------------------- tabela por analista
    cabecalhos = ["Analista", "Problemas", "RCA não publicada", "Sem KB",
                  "Sem PCA", "Sem RCA", "RCA incompleto"]
    th = "".join(
        f'<th align="{"left" if indice == 0 else "center"}" '
        f'style="background:{COR_NAVY};color:#ffffff;font-family:{fonte};'
        f'font-size:11px;letter-spacing:1px;text-transform:uppercase;'
        f'padding:12px 10px;">{escape(nome)}</th>'
        for indice, nome in enumerate(cabecalhos)
    )

    def td_num(valor):
        cor = COR_ZERO if valor == 0 else COR_VERMELHO
        peso = "normal" if valor == 0 else "bold"
        return (f'<td align="center" style="font-family:{fonte};font-size:14px;'
                f'color:{cor};font-weight:{peso};padding:10px;'
                f'border-bottom:1px solid {COR_LINHA};">{valor}</td>')

    corpo = ""
    for linha in resumo:
        corpo += (
            "<tr>"
            f'<td style="font-family:{fonte};font-size:14px;color:{COR_TINTA};'
            f'padding:10px;border-bottom:1px solid {COR_LINHA};">'
            f'{escape(linha["analista"])}</td>'
            f'<td align="center" style="font-family:{fonte};font-size:14px;'
            f'color:{COR_TINTA};font-weight:bold;padding:10px;'
            f'border-bottom:1px solid {COR_LINHA};">{linha["problemas"]}</td>'
            + td_num(linha["rca_nao_publicada"])
            + td_num(linha["sem_kb"])
            + td_num(linha["sem_pca"])
            + td_num(linha["sem_rca"])
            + td_num(linha["rca_incompleto"])
            + "</tr>"
        )

    totais = [i["problemas"], i["rca_nao_publicada"], i["sem_kb"],
              i["sem_pca"], i["sem_rca"], i["rca_incompleto"]]
    rodape = (
        "<tr>"
        f'<td style="font-family:{fonte};font-size:11px;text-transform:uppercase;'
        f'letter-spacing:1px;color:{COR_TEXTO};background:#f4f7fa;padding:10px;'
        f'border-top:2px solid {COR_NAVY};">Total ({len(resumo)} analistas)</td>'
        + "".join(
            f'<td align="center" style="font-family:{fonte};font-size:14px;'
            f'font-weight:bold;color:{COR_TINTA};background:#f4f7fa;padding:10px;'
            f'border-top:2px solid {COR_NAVY};">{valor}</td>' for valor in totais)
        + "</tr>"
    )

    # ---------------------------------------------------------- pendências
    grupos = pendencias_por_analista(unificado)
    if grupos:
        blocos = ""
        for analista, itens in grupos:
            chips = []
            for problema, cumpridos, total_marcos, _faltando in itens:
                cor = cor_do_placar(cumpridos)
                chips.append(
                    f'<span style="font-family:Consolas,monospace;font-size:12px;'
                    f'color:{COR_TEXTO};white-space:nowrap;">{escape(problema)} '
                    f'<b style="color:{cor};">{cumpridos}/{total_marcos}</b></span>'
                )
            blocos += (
                "<tr>"
                f'<td width="170" valign="top" style="font-family:{fonte};'
                f'font-size:13px;font-weight:bold;color:{COR_TINTA};padding:8px 10px;'
                f'border-bottom:1px solid {COR_LINHA};">{escape(analista)}</td>'
                f'<td valign="top" style="padding:8px 10px;line-height:1.9;'
                f'border-bottom:1px solid {COR_LINHA};color:#c3ccd6;">'
                + " ; ".join(chips) +
                "</td></tr>"
            )
        secao_pendencias = (
            f'<table width="100%" cellpadding="0" cellspacing="0" border="0" '
            f'style="background:#ffffff;border:1px solid {COR_LINHA};">{blocos}</table>'
            f'<div style="font-family:{fonte};font-size:12px;color:{COR_FRACA};'
            f'padding:10px 2px;">'
            f'<b style="color:{COR_VERMELHO};">1/5</b> · '
            f'<b style="color:{COR_LARANJA};">2/5</b> · '
            f'<b style="color:{COR_NAVY};">3/5 e 4/5</b> — marcos cumpridos de 5'
            f'</div>'
        )
    else:
        secao_pendencias = (
            f'<div style="background:#ffffff;border:1px solid {COR_LINHA};'
            f'padding:18px;font-family:{fonte};font-size:14px;color:{COR_TEXTO};">'
            f'Nenhum problema com pendência.</div>'
        )

    titulo_secao = (f'font-family:{fonte};font-size:17px;font-weight:bold;'
                    f'color:{COR_TINTA};text-transform:uppercase;'
                    f'padding:26px 0 10px;')

    return f"""<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body style="margin:0;padding:0;background:{COR_FUNDO};">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:{COR_FUNDO};">
<tr><td align="center" style="padding:24px 12px;">
<table width="820" cellpadding="0" cellspacing="0" border="0" style="width:820px;max-width:100%;">

  <tr><td style="font-family:Consolas,monospace;font-size:11px;letter-spacing:2px;
      text-transform:uppercase;color:{COR_FRACA};padding-bottom:6px;">
    Gestão de problemas &middot; Posição de {data_posicao}
  </td></tr>

  <tr><td style="font-family:{fonte};font-size:26px;font-weight:bold;
      color:{COR_TINTA};text-transform:uppercase;padding-bottom:8px;">
    Lacunas de RCA, PCA e conhecimento
  </td></tr>

  <tr><td style="font-family:{fonte};font-size:14px;color:{COR_TEXTO};
      padding-bottom:16px;">
    <b style="color:{COR_VERMELHO};">{i["com_lacuna"]} dos {i["problemas"]} problemas</b>
    têm pelo menos uma pendência. A base unificada segue em anexo.
  </td></tr>

  <tr><td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0">{linhas_cards}</table>
  </td></tr>

  <tr><td style="{titulo_secao}">Lacunas por analista</td></tr>
  <tr><td>
    <table width="100%" cellpadding="0" cellspacing="0" border="0"
        style="background:#ffffff;border:1px solid {COR_LINHA};border-collapse:collapse;">
      <tr>{th}</tr>
      {corpo}
      {rodape}
    </table>
  </td></tr>

  <tr><td style="{titulo_secao}">Problemas com pendência</td></tr>
  <tr><td>{secao_pendencias}</td></tr>

  <tr><td style="font-family:Consolas,monospace;font-size:11px;color:{COR_FRACA};
      padding:22px 0 4px;border-top:1px solid {COR_LINHA};">
    Origem: {escape(origem_problemas)} + {escape(origem_kb)} &middot;
    chave da junção: Problem = Source task.<br>
    Marcos: RCA criada &middot; RCA publicada &middot; RCA concluída &middot;
    PCA criado &middot; KB publicado.
  </td></tr>

</table>
</td></tr>
</table>
</body></html>"""


# =============================================================================
# 9. LINHA DE COMANDO
# =============================================================================

def localizar(caminho_informado, nomes_padrao, rotulo):
    """
    Resolve o caminho do arquivo. Procura, nesta ordem:
      1. o caminho passado na linha de comando (como veio, e na pasta do script)
      2. os nomes padrão, na pasta atual e na pasta do script
    Encerra com mensagem clara quando não encontra.
    """
    candidatos = []
    if caminho_informado:
        candidatos = [caminho_informado,
                      os.path.join(DIR_SCRIPT, os.path.basename(caminho_informado))]
    else:
        for nome in nomes_padrao:
            candidatos.append(os.path.join(os.getcwd(), nome))
            candidatos.append(os.path.join(DIR_SCRIPT, nome))

    for candidato in candidatos:
        if os.path.isfile(candidato):
            return candidato

    encontrados = sorted({
        nome for pasta in {os.getcwd(), DIR_SCRIPT}
        for nome in os.listdir(pasta)
        if nome.lower().endswith((".xlsx", ".xlsm"))
    })
    print(f"ERRO: não encontrei a planilha de {rotulo}.")
    if caminho_informado:
        print(f"       Caminho informado: {caminho_informado}")
    else:
        print(f"       Procurei por: {', '.join(nomes_padrao)}")
        print(f"       Nas pastas:   {os.getcwd()}")
        if DIR_SCRIPT != os.getcwd():
            print(f"                     {DIR_SCRIPT}")
    if encontrados:
        print(f"       Planilhas disponíveis: {', '.join(encontrados)}")
    print("       Informe o caminho com:  --problemas ARQUIVO.xlsx --kb ARQUIVO.xlsx")
    sys.exit(1)


def obter_argumentos():
    parser = argparse.ArgumentParser(
        description="Gera o dashboard de lacunas de RCA/PCA a partir de dois arquivos .xlsx.",
        epilog="Sem argumentos, procura por problem_task.xlsx e kb_knowledge.xlsx "
               "na pasta atual ou na pasta do script.",
    )
    parser.add_argument("--problemas", default=None,
                        help="Caminho do .xlsx com Problem, Opened by, RCA Status, "
                             "Problem task type, Related Incidents, Active "
                             "(padrão: problem_task.xlsx)")
    parser.add_argument("--kb", default=None,
                        help="Caminho do .xlsx com Source task, Number, Short description "
                             "(padrão: kb_knowledge.xlsx)")
    parser.add_argument("--aba-problemas", default=None, help="Nome da aba do 1º arquivo")
    parser.add_argument("--aba-kb", default=None, help="Nome da aba do 2º arquivo")
    parser.add_argument("--saida-xlsx", default="base_unificada.xlsx")
    parser.add_argument("--saida-html", default="dashboard.html")
    parser.add_argument("--data", default=None,
                        help="Data de posição no formato DD/MM/AAAA (padrão: hoje)")
    parser.add_argument("--email", default=None,
                        help="Destinatário(s) do e-mail, separados por ;")
    parser.add_argument("--cc", default="", help="Destinatário(s) em cópia")
    parser.add_argument("--assunto", default=None, help="Assunto do e-mail")
    parser.add_argument("--somente-abrir-email", action="store_true",
                        help="Abre a janela do Outlook em vez de enviar direto")

    args = parser.parse_args()
    args.problemas = localizar(args.problemas, PADRAO_PROBLEMAS, "problemas")
    args.kb = localizar(args.kb, PADRAO_KB, "conhecimento (KB)")
    return args


# =============================================================================
# 10. EXECUÇÃO
# =============================================================================

def main():
    args = obter_argumentos()
    data_posicao = args.data or date.today().strftime("%d/%m/%Y")

    # ---- leitura -------------------------------------------------------
    linhas_problemas = ler_planilha(args.problemas, MAPA_PROBLEMAS,
                                    args.aba_problemas, "problemas", chave="Problem")
    linhas_kb = ler_planilha(args.kb, MAPA_KB, args.aba_kb, "conhecimento",
                             chave="Source task")

    # ---- junção --------------------------------------------------------
    unificado = juntar(linhas_problemas, linhas_kb)
    if not unificado:
        sys.exit("ERRO: nenhum problema válido encontrado após a junção.")

    indicadores = calcular_indicadores(unificado)
    resumo = resumo_por_analista(unificado)

    origem_problemas = os.path.basename(args.problemas)
    origem_kb = os.path.basename(args.kb)

    # ---- saídas --------------------------------------------------------
    gravar_unificada(unificado, args.saida_xlsx)
    print(f"[saída] {args.saida_xlsx} ({len(unificado)} problemas)")

    html = gerar_html(unificado, indicadores, resumo, data_posicao,
                      origem_problemas, origem_kb)
    with open(args.saida_html, "w", encoding="utf-8") as arquivo:
        arquivo.write(html)
    print(f"[saída] {args.saida_html}")

    print("\nIndicadores:")
    for chave, valor in indicadores.items():
        print(f"    {chave:<20} {valor}")

    # ---- e-mail --------------------------------------------------------
    if args.email:
        try:
            from enviar_email import enviar_email_automatico
        except ImportError:
            print("\n❌ Não encontrei enviar_email.py na mesma pasta do script. "
                  "E-mail não enviado.")
            return

        corpo = gerar_html_email(unificado, indicadores, resumo, data_posicao,
                                 origem_problemas, origem_kb)
        assunto = args.assunto or (
            f"Gestão de problemas · posição de {data_posicao} · "
            f"{indicadores['com_lacuna']} de {indicadores['problemas']} com pendência"
        )
        anexos = [os.path.abspath(args.saida_xlsx), os.path.abspath(args.saida_html)]

        print()
        ok, mensagem = enviar_email_automatico(
            to=args.email,
            cc=args.cc,
            subject=assunto,
            html_body=corpo,
            attachments=anexos,
            display=args.somente_abrir_email,
        )
        if not ok:
            print(f"[e-mail] falhou: {mensagem}")


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""
===============================================================================
 ENVIO DE E-MAIL VIA OUTLOOK LOCAL (Windows COM / macOS AppleScript)
===============================================================================
 Dispara o e-mail pelo Outlook já autenticado na máquina, sem pedir senha e
 sem servidor SMTP.

 Novidades em relação ao modelo original:
   - parâmetro "attachments": lista de caminhos de arquivo anexados no Windows
     E no Mac (o modelo original só anexava screenshot no Windows)
   - validação dos caminhos antes de anexar, com aviso do que foi ignorado
   - "display" opcional: abre a janela do Outlook em vez de enviar direto,
     útil para conferir o e-mail antes do disparo

 Uso como módulo:
     from enviar_email import enviar_email_automatico
     enviar_email_automatico(
         to="fulano@empresa.com",
         cc="",
         subject="Dashboard de problemas",
         html_body="<h1>...</h1>",
         attachments=["base_unificada.xlsx", "dashboard.html"],
     )

 Uso direto (teste):
     python enviar_email.py
===============================================================================
"""

import base64
import os
import platform
import subprocess
from datetime import datetime

# Detect OS
IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"


# =============================================================================
# APOIO
# =============================================================================

def _normalizar_anexos(attachments):
    """
    Recebe None, uma string ou uma lista de caminhos e devolve a lista de
    caminhos absolutos que realmente existem em disco.
    """
    if not attachments:
        return []

    if isinstance(attachments, (str, bytes, os.PathLike)):
        attachments = [attachments]

    validos = []
    for caminho in attachments:
        if not caminho:
            continue
        absoluto = os.path.abspath(str(caminho))
        if os.path.isfile(absoluto):
            validos.append(absoluto)
        else:
            print(f"⚠️ Anexo ignorado (arquivo não encontrado): {caminho}")

    return validos


def _escapar_applescript(texto):
    """Escapa barras e aspas para uso dentro de um literal de string AppleScript."""
    return str(texto).replace('\\', '\\\\').replace('"', '\\"')


# =============================================================================
# WINDOWS
# =============================================================================

def send_outlook_windows(to, cc, subject, html_body,
                         screenshot_base64=None, attachments=None, display=False):
    """
    Envia e-mail de forma silenciosa no Windows via Outlook COM.
    Segue o modelo robusto.
    """
    import win32com.client
    try:
        # Tratamento de segurança para os parâmetros
        safe_to = str(to) if to else ""
        safe_cc = str(cc) if cc else ""
        safe_subject = str(subject) if subject else "Relatório Dashboard - " + datetime.now().strftime('%d/%m/%Y')

        print("--- Preparando envio de E-mail Silencioso via Outlook (Windows) ---")
        outlook = win32com.client.Dispatch("outlook.application")
        mail = outlook.CreateItem(0)

        if safe_to:
            mail.To = safe_to
        else:
            print("⚠️ Aviso: Destinatário vazio. O envio pode falhar.")

        mail.Subject = safe_subject
        mail.HTMLBody = html_body
        mail.Importance = 2  # Normal

        if safe_cc:
            mail.CC = safe_cc

        # Handle Screenshot Attachment
        if screenshot_base64:
            temp_path = os.path.join(os.getcwd(), "temp_screenshot_mail.png")
            try:
                img_data = base64.b64decode(screenshot_base64.split(",")[1])
                with open(temp_path, "wb") as f:
                    f.write(img_data)
                mail.Attachments.Add(os.path.abspath(temp_path))
            except Exception as e_img:
                print(f"⚠️ Erro ao anexar screenshot: {e_img}")

        # Anexos de arquivo (base unificada, dashboard, etc.)
        for caminho in _normalizar_anexos(attachments):
            try:
                mail.Attachments.Add(caminho)
                print(f"📎 Anexado: {os.path.basename(caminho)}")
            except Exception as e_anexo:
                print(f"⚠️ Erro ao anexar {caminho}: {e_anexo}")

        # DISPARO SILENCIOSO
        if display:
            mail.Display()
            print("✉️ Janela do Outlook aberta para conferência (não enviado).")
            return True, "E-mail aberto no Outlook (Windows) para conferência."

        mail.Send()
        print(f"✅ E-mail enviado com sucesso para {safe_to}!")
        return True, f"E-mail enviado silenciosamente via Outlook (Windows) para {safe_to}."
    except Exception as e:
        print(f"❌ Erro crítico ao enviar e-mail (Windows): {e}")
        return False, str(e)


# =============================================================================
# MACOS
# =============================================================================

def send_outlook_mac(to, cc, subject, html_body, attachments=None, display=False):
    """
    Envia e-mail via AppleScript (Outlook Mac).
    Usa a propriedade 'content' do Outlook, que aceita HTML.
    HTML é compactado em linha única para evitar problemas no literal de string do AppleScript.
    """
    try:
        safe_to = str(to).strip() if to else ""
        safe_cc = str(cc).strip() if cc else ""
        safe_subj = _escapar_applescript(subject if subject else "Relatório Dashboard")

        # Compactar HTML em linha única + escapar para string AppleScript
        compact = html_body.replace('\r\n', ' ').replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        compact = _escapar_applescript(compact)

        safe_to_esc = _escapar_applescript(safe_to)

        as_script = (
            'tell application "Microsoft Outlook"\n'
            f'    set newMsg to make new outgoing message with properties'
            f' {{subject:"{safe_subj}", content:"{compact}"}}\n'
            f'    make new to recipient at newMsg with properties'
            f' {{email address:{{address:"{safe_to_esc}"}}}}\n'
        )

        if safe_cc:
            safe_cc_esc = _escapar_applescript(safe_cc)
            as_script += (
                f'    make new cc recipient at newMsg with properties'
                f' {{email address:{{address:"{safe_cc_esc}"}}}}\n'
            )

        # Anexos de arquivo
        for caminho in _normalizar_anexos(attachments):
            caminho_esc = _escapar_applescript(caminho)
            as_script += (
                f'    make new attachment at newMsg with properties'
                f' {{file:POSIX file "{caminho_esc}"}}\n'
            )
            print(f"📎 Anexado: {os.path.basename(caminho)}")

        if display:
            as_script += '    open newMsg\n    activate\nend tell'
        else:
            as_script += '    send newMsg\nend tell'

        subprocess.run(['osascript', '-e', as_script], check=True, capture_output=True)

        if display:
            print("✉️ Janela do Outlook aberta para conferência (não enviado).")
            return True, "E-mail aberto no Outlook (Mac) para conferência."

        print(f"✅ E-mail HTML enviado com sucesso (Mac) para {safe_to}!")
        return True, f"E-mail enviado silenciosamente via Outlook (Mac) para {safe_to}."
    except subprocess.CalledProcessError as e:
        err = e.stderr.decode('utf-8', errors='replace') if e.stderr else str(e)
        print(f"❌ Erro AppleScript ao enviar e-mail (Mac): {err}")
        return False, err
    except Exception as e:
        print(f"❌ Erro crítico ao enviar e-mail (Mac): {e}")
        return False, str(e)


# =============================================================================
# PONTO DE ENTRADA
# =============================================================================

def enviar_email_automatico(to, cc, subject, html_body,
                            screenshot_base64=None, attachments=None, display=False):
    """
    Função principal que identifica o sistema operacional automaticamente
    e dispara o e-mail via Outlook (sem pedir senhas).

    attachments: caminho único ou lista de caminhos de arquivos a anexar.
    display:     True abre a janela do Outlook em vez de enviar direto.
    """
    if IS_WINDOWS:
        return send_outlook_windows(to, cc, subject, html_body,
                                    screenshot_base64, attachments, display)
    elif IS_MAC:
        return send_outlook_mac(to, cc, subject, html_body, attachments, display)
    else:
        err = f"Sistema Operacional não suportado ({platform.system()}) para envio via Outlook."
        print(f"❌ {err}")
        return False, err


if __name__ == "__main__":
    # Teste de execução direta
    teste_to = "rolim.r@icloud.com"
    teste_subj = "Teste de Integração Outlook OS-Aware"
    teste_body = ("<h2>Teste Automático</h2>"
                  "<p>Identificando o SO para disparar via Outlook localmente e "
                  "silenciosamente (sem pedir senhas).</p>")

    print(f"Sistema Operacional Identificado: {platform.system()} {platform.release()}")
    enviar_email_automatico(teste_to, "", teste_subj, teste_body)

"""
================================================================================
LEITURA DE E-MAIL: RESPOSTAS DE APROVAÇÃO (OUTLOOK, SÓ WINDOWS)
================================================================================
Único ponto do projeto que LÊ e-mail (tools/smtp.py só ENVIA). Usado pela tela
'Create ctask' para varrer a Caixa de Entrada do Outlook procurando respostas
às aprovações de Change disparadas pela tela Feature Release (ver
'release_task.release_mailer.ReleaseMailer.send_approval_email' - mesmo
assunto usado para casar a resposta aqui, devolvido por aquela função
justamente para isso).

SÓ WINDOWS (Outlook COM via 'win32com.client' + 'pythoncom', import feito só
dentro da função) - mesmo mecanismo já usado para ENVIAR e-mail em
'tools/smtp.py:send_outlook_windows' (inclusive o CoInitialize/CoUninitialize
por thread). Não existe equivalente Mac/IMAP: fora do Windows, devolve um erro
claro em vez de tentar e falhar silenciosamente.
"""

import platform
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, List

logger = logging.getLogger("MailReader")

IS_WINDOWS = platform.system() == "Windows"

# Palavras que indicam aprovação no CORPO da resposta - inclui grafias/erros de
# digitação comuns observados no uso real (mesma lista do fluxo de referência
# que originou esta tela), comparadas em minúsculas.
PALAVRAS_APROVACAO = [
    "aprovado", "aproavdo", "aproado", "approvado", "aprovada",
    "aprovaod", "approved", "approve", "aprove",
]

OUTLOOK_INBOX_FOLDER = 6  # olFolderInbox
DIAS_LOOKBACK_PADRAO = 30  # respostas mais antigas que isso não são varridas (performance)


def verificar_respostas_aprovacao_outlook(
    pendentes: List[Dict[str, Any]], dias_lookback: int = DIAS_LOOKBACK_PADRAO
) -> Dict[str, Any]:
    """
    :param pendentes: [{'id': <int>, 'assunto': <str>}, ...] - aprovações
        aguardando resposta (ver 'CtaskAprovacao', status='pendente').
    :param dias_lookback: só examina e-mails recebidos nos últimos N dias -
        aprovação de Change é sempre respondida em poucos dias, então isso
        evita varrer a caixa de entrada inteira a cada verificação.

    Varre a Caixa de Entrada do Outlook (mais recentes primeiro) procurando,
    para CADA pendente, um e-mail cujo Subject CONTENHA o assunto original
    (cobre replies com prefixo 'RE: '/'RES: ' etc., que o Outlook antepõe sem
    alterar o resto do assunto) e verifica se o CORPO contém alguma palavra de
    'PALAVRAS_APROVACAO'.

    Devolve {'status': 'success', 'respostas': [{'id', 'aprovado': bool, 'de': str}]} -
    pendentes sem NENHUMA resposta encontrada simplesmente não aparecem em
    'respostas' (continuam pendentes na próxima verificação). Nunca lança
    exceção: falha vira {'status': 'error', 'message': ..., 'respostas': []}.
    """
    if not IS_WINDOWS:
        return {
            "status": "error",
            "message": "Leitura de e-mail só é suportada no Windows (Outlook COM) - "
                       f"sistema atual: {platform.system()}.",
            "respostas": [],
        }

    if not pendentes:
        return {"status": "success", "respostas": []}

    import win32com.client
    import pythoncom

    pythoncom.CoInitialize()
    respostas: List[Dict[str, Any]] = []
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        namespace = outlook.GetNamespace("MAPI")
        inbox = namespace.GetDefaultFolder(OUTLOOK_INBOX_FOLDER)

        items = inbox.Items
        items.Sort("[ReceivedTime]", True)  # mais recentes primeiro

        data_limite = (datetime.now() - timedelta(days=dias_lookback)).strftime("%m/%d/%Y %H:%M %p")
        try:
            items = items.Restrict(f"[ReceivedTime] >= '{data_limite}'")
        except Exception as e_restrict:
            logger.warning(f"⚠️ [MailReader] Falha ao restringir por data (varrendo tudo mesmo assim): {e_restrict}")

        pendentes_restantes = list(pendentes)

        for item in items:
            if not pendentes_restantes:
                break
            try:
                assunto_item = str(getattr(item, "Subject", "") or "")
                corpo_item = str(getattr(item, "Body", "") or "")
                remetente_item = str(getattr(item, "SenderEmailAddress", "") or "")
            except Exception as e_item:
                logger.warning(f"⚠️ [MailReader] Falha ao ler item da caixa de entrada: {e_item}")
                continue

            encontrados = [p for p in pendentes_restantes if p.get("assunto") and p["assunto"] in assunto_item]
            for pendente in encontrados:
                aprovado = any(palavra in corpo_item.lower() for palavra in PALAVRAS_APROVACAO)
                respostas.append({"id": pendente["id"], "aprovado": aprovado, "de": remetente_item})
                pendentes_restantes.remove(pendente)

        logger.info(f"📬 [MailReader] {len(respostas)}/{len(pendentes)} aprovação(ões) com resposta encontrada.")
        return {"status": "success", "respostas": respostas}

    except Exception as e:
        logger.error(f"❌ [MailReader] Erro ao ler Caixa de Entrada do Outlook: {e}")
        return {"status": "error", "message": str(e), "respostas": respostas}
    finally:
        pythoncom.CoUninitialize()

"""
================================================================================
SERVIÇO EXCLUSIVO: CRIAÇÃO DE CTASK (CHANGE TASK) NUMA CHANGE APROVADA
================================================================================
Cria uma nova Change Task (CTASK) dentro de uma Change (CHG) já aberta no
ServiceNow - usado pela tela 'Create ctask' depois de confirmar, por e-mail
(ver tools/mail_reader.py), que a Change foi aprovada.

Herda só de ServiceNowDriver (sem UPM/DB) - mesmo padrão enxuto de
TaskEncerrarService, já que este serviço só mexe no ServiceNow.

Navegação 'change_request.do?sys_id={número legível}' (não o GUID real) é um
padrão JÁ CONFIRMADO funcionando nesta base - ver
'release_close_service.py' (mesma URL usada lá para fechar a Change).
"""

import os
import logging
from typing import Any, Dict, List, Optional
from playwright.async_api import Page

from tools.servicenow_driver import ServiceNowDriver
from tools.chamado import SERVICE_NOW_BASE_URL

logger = logging.getLogger("CtaskCreationService")


class CtaskCreationService(ServiceNowDriver):
    """Cria uma CTASK dentro de uma Change já aprovada."""

    async def criar_ctask(
        self,
        page: Page,
        chg_number: str,
        titulo: str,
        corpo: str,
        assignment_group: str,
        assigned_to: str,
        evidence_files: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Abre a Change 'chg_number', clica em 'New' na related-list de Change
        Tasks, preenche Grupo de Atribuição/Descrição curta/Descrição/Assigned
        to, anexa evidências (se houver) e salva. Devolve
        {'status': 'success', 'sctask': <número da ctask criada>} ou
        {'status': 'error', 'error': ...} - nunca lança exceção.
        """
        url = f"{SERVICE_NOW_BASE_URL}/change_request.do?sys_id={chg_number}"
        logger.info(f"🆕 [CtaskCreationService] Abrindo Change {chg_number} para criar CTASK: {url}")

        resultado: Dict[str, Any] = {"chg": chg_number, "status": "success", "sctask": None, "error": None}

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

            # Confirma que a Change foi de fato encontrada (não redirecionou pra
            # uma página de erro/lista vazia) antes de tentar criar a CTASK dentro
            # dela - mesma checagem do fluxo de referência.
            chg_locator = await self.wait_for_element(scope, "change_number_readonly", timeout=20000)
            chg_atual = (await chg_locator.input_value()).strip()
            if chg_atual and chg_atual != chg_number:
                resultado["status"] = "error"
                resultado["error"] = f"Change '{chg_number}' não encontrada ou encerrada (encontrado: '{chg_atual}')."
                return resultado

            await self.click_element(scope, "change_task_new_button")
            await self.wait_for_element(scope, "change_task_number_readonly", timeout=20000)

            await self.fill_reference_field(scope, "change_task_assignment_group", assignment_group)
            await self.fill_input(scope, "change_task_short_description", titulo)
            await self.fill_input(scope, "change_task_description", corpo)
            if assigned_to:
                await self.fill_reference_field(scope, "change_task_assigned_to", assigned_to)

            # Anexa evidências (ex.: e-mail de aprovação salvo como .txt/.png) - mesma
            # lógica de upload já usada em 'ServiceNowDriver.preencher_e_encerrar_sctask'.
            for file_path in (evidence_files or []):
                if not (file_path and os.path.exists(file_path)):
                    continue
                try:
                    att_btn = scope.locator(self.get_selector("attachment_button")).first
                    if await att_btn.count() > 0:
                        await att_btn.click()
                        await page.wait_for_timeout(500)
                    input_file = scope.locator(self.get_selector("attach_file_input")).first
                    await input_file.set_input_files(file_path)
                    await page.wait_for_timeout(1500)
                except Exception as e_att:
                    logger.warning(f"⚠️ [CtaskCreationService] Falha ao anexar '{file_path}': {e_att}")

            await self.click_element(scope, "update_stay_button")
            await page.wait_for_timeout(2000)

            ctask_locator = await self.wait_for_element(scope, "change_task_number_readonly", timeout=20000)
            resultado["sctask"] = (await ctask_locator.input_value()).strip()

            logger.info(f"✅ [CtaskCreationService] CTASK {resultado['sctask']} criada na Change {chg_number}.")

        except Exception as e:
            logger.error(f"❌ [CtaskCreationService] Erro ao criar CTASK na Change {chg_number}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

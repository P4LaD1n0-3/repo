"""
================================================================================
TELA: CREATE CTASK (CTASK AUTOMÁTICA APÓS APROVAÇÃO POR E-MAIL)
================================================================================
Fecha o ciclo do e-mail de aprovação já disparado pela tela Feature Release
(ver 'release_task.routes._executar_envio_email_manual', que registra 1 linha
em 'CtaskAprovacao' logo após enviar o e-mail com sucesso): varre a Caixa de
Entrada do Outlook (tools/mail_reader.py, só Windows) procurando respostas às
aprovações pendentes e, para as aprovadas, cria a CTASK correspondente na
Change (CtaskCreationService).

Verificação AO VIVO (sem tabela "pendente" separada do legado): o botão
'Verificar aprovações' varre o Outlook agora, processa o que estiver
respondido e devolve. Pendentes sem resposta nenhuma continuam pendentes.
"""

import os
import asyncio
import logging
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from playwright.async_api import async_playwright

from src.models import db, CtaskAprovacaoConfig, CtaskAprovacao
from tools.job_registry import job_registry
from tools.mail_reader import verificar_respostas_aprovacao_outlook
from src.modules.create_ctask.ctask_creation_service import CtaskCreationService

logger = logging.getLogger("CreateCtask")

current_dir = os.path.dirname(os.path.abspath(__file__))
create_ctask_bp = Blueprint('create_ctask', __name__, template_folder=current_dir)


def _criar_coletor_logs(job_id: str = ""):
    """Mesmo padrão de 'release_task.routes._criar_coletor_logs' - acumula em
    'logs' (devolvido na resposta) e publica em tempo real no JobRegistry."""
    logs = []

    def add_message(msg: str):
        timestamp = datetime.now().strftime("%H:%M:%S")
        entrada = f"{timestamp} {msg}"
        logger.info(entrada)
        logs.append(entrada)
        if job_id:
            job_registry.append_log(job_id, entrada)

    return logs, add_message


@create_ctask_bp.route('/create_ctask')
@login_required
def index():
    """
    Renderiza a tela com a configuração do usuário, as solicitações enviadas
    (aprovação pendente - ainda sem resposta no Outlook) e o histórico de
    aprovações JÁ RESOLVIDAS (aprovado/rejeitado/erro) - separados em 2 listas
    pra deixar visível, assim que o e-mail é enviado pela tela Feature Release,
    que a solicitação chegou no banco (antes ficava misturada com o histórico
    resolvido e passava despercebida).
    """
    config = CtaskAprovacaoConfig.get_or_create(current_user.id)
    pendentes = CtaskAprovacao.query.filter_by(status="pendente").order_by(CtaskAprovacao.criado_em.desc()).all()
    historico = (
        CtaskAprovacao.query.filter(CtaskAprovacao.status != "pendente")
        .order_by(CtaskAprovacao.criado_em.desc()).limit(50).all()
    )
    return render_template(
        'create_ctask.html', user=current_user, active_page='create_ctask',
        config=config, pendentes=pendentes, historico=historico,
    )


@create_ctask_bp.route('/api/create_ctask/save_config', methods=['POST'])
@login_required
def save_config():
    """Salva o Grupo de Atribuição / Assigned to usados ao criar a CTASK."""
    data = request.get_json() or {}
    config = CtaskAprovacaoConfig.get_or_create(current_user.id)
    if 'assignment_group' in data:
        config.assignment_group = (data.get('assignment_group') or '').strip()
    if 'assigned_to' in data:
        config.assigned_to = (data.get('assigned_to') or '').strip()
    db.session.commit()
    return jsonify({'status': 'success', 'message': 'Configuração salva com sucesso!'})


@create_ctask_bp.route('/api/create_ctask/verificar', methods=['POST'])
@login_required
def verificar_aprovacoes():
    """
    Ação principal: varre o Outlook procurando resposta às aprovações
    pendentes e cria a CTASK das aprovadas. Nunca deixa uma pendência "no
    limbo": rejeitada vira 'rejeitado', erro ao criar a CTASK vira 'erro' (com
    o motivo salvo em 'erro'), sem resposta continua 'pendente'.
    """
    data = request.get_json() or {}
    headless = bool(data.get('headless', False))
    job_id = (data.get('job_id') or '').strip()

    logs, add_message = _criar_coletor_logs(job_id)
    config = CtaskAprovacaoConfig.get_or_create(current_user.id)

    pendentes = CtaskAprovacao.query.filter_by(status="pendente").all()
    if not pendentes:
        add_message("Nenhuma aprovação pendente para verificar.")
        return jsonify({'status': 'success', 'logs': logs, 'processados': []})

    add_message(f"Verificando resposta de {len(pendentes)} aprovação(ões) pendente(s) no Outlook...")

    resultado_mail = verificar_respostas_aprovacao_outlook(
        [{'id': p.id, 'assunto': p.assunto_email} for p in pendentes]
    )
    if resultado_mail.get('status') != 'success':
        add_message(f"❌ {resultado_mail.get('message')}")
        return jsonify({'status': 'error', 'message': resultado_mail.get('message'), 'logs': logs}), 502

    respostas_por_id = {r['id']: r for r in resultado_mail.get('respostas', [])}
    if not respostas_por_id:
        add_message("Nenhuma resposta nova encontrada - todas continuam pendentes.")
        return jsonify({'status': 'success', 'logs': logs, 'processados': []})

    add_message(f"{len(respostas_por_id)} resposta(s) encontrada(s). Processando...")

    processados = []

    # Rejeitadas: gravadas direto, sem precisar do navegador.
    rejeitados = [p for p in pendentes if p.id in respostas_por_id and not respostas_por_id[p.id]['aprovado']]
    for pendente in rejeitados:
        pendente.status = "rejeitado"
        pendente.processado_em = datetime.utcnow()
        add_message(f"⚠️ {pendente.rlse_number}/{pendente.chg_number}: resposta NÃO aprovou - marcado como rejeitado.")
        processados.append({
            'rlse': pendente.rlse_number, 'chg': pendente.chg_number, 'status': 'rejeitado', 'sctask': None,
        })
    if rejeitados:
        db.session.commit()

    aprovados = [p for p in pendentes if p.id in respostas_por_id and respostas_por_id[p.id]['aprovado']]
    if not aprovados:
        return jsonify({'status': 'success', 'logs': logs, 'processados': processados})

    if job_id:
        job_registry.register(job_id, current_user.id, module='create_ctask')

    async def processar_aprovados():
        service = CtaskCreationService()
        resultados = []
        async with async_playwright() as p:
            context = await service.launch_persistent_context(p, headless=headless, job_id=job_id)
            try:
                page = await context.new_page()
                for pendente in aprovados:
                    titulo = f"{pendente.ambiente} - Aprovação {pendente.rlse_number}/{pendente.chg_number}"
                    corpo = (
                        f"Aprovação de {pendente.rlse_number}/{pendente.chg_number} ({pendente.ambiente}) "
                        f"confirmada por e-mail em {datetime.now().strftime('%d/%m/%Y %H:%M')}. "
                        f"CTASK criada automaticamente via Create ctask."
                    )
                    add_message(f"Criando CTASK para {pendente.rlse_number}/{pendente.chg_number}...")
                    resultado_ctask = await service.criar_ctask(
                        page=page,
                        chg_number=pendente.chg_number,
                        titulo=titulo,
                        corpo=corpo,
                        assignment_group=config.assignment_group or "AIG-PT-BR-DBA-SRV",
                        assigned_to=config.assigned_to or "",
                    )
                    resultados.append(resultado_ctask)
            finally:
                await service.close_context(context)
        return resultados

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    if job_id:
        job_registry.set_loop(job_id, loop)

    try:
        resultados_ctask = loop.run_until_complete(processar_aprovados())
    except Exception as e:
        logger.exception(f"Erro ao criar CTASKs: {e}")
        add_message(f"❌ Erro inesperado ao criar CTASKs: {e}")
        return jsonify({'status': 'error', 'message': str(e), 'logs': logs, 'processados': processados}), 500
    finally:
        loop.close()
        if job_id:
            job_registry.unregister(job_id)

    # Grava o resultado de cada aprovada DEPOIS do loop assíncrono terminar
    # (sessão do banco só é tocada em código síncrono, dentro do request).
    for pendente, resultado_ctask in zip(aprovados, resultados_ctask):
        if resultado_ctask.get('status') == 'success':
            pendente.status = "aprovado"
            pendente.sctask_criada = resultado_ctask.get('sctask')
            add_message(f"✅ CTASK {resultado_ctask.get('sctask')} criada para {pendente.chg_number}.")
        else:
            pendente.status = "erro"
            pendente.erro = resultado_ctask.get('error')
            add_message(f"❌ Falha ao criar CTASK para {pendente.chg_number}: {resultado_ctask.get('error')}")
        pendente.processado_em = datetime.utcnow()
        processados.append({
            'rlse': pendente.rlse_number, 'chg': pendente.chg_number,
            'status': pendente.status, 'sctask': pendente.sctask_criada,
        })

    db.session.commit()
    return jsonify({'status': 'success', 'logs': logs, 'processados': processados})

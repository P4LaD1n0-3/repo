# -*- coding: utf-8 -*-
"""
===============================================================================
 GESTÃO DE PROBLEMAS - LACUNAS DE RCA / PCA / KB
===============================================================================
 Lê DOIS arquivos .xlsx reais, cruza pela chave  Problem = Source task  e gera:

   1) base_unificada.xlsx  -> uma linha por problema:
        Problem | Opened by | RCA Status | Problem task type | Related Incidents |
        Active | Problem task type (PCA) | Active (PCA) | Number (KB) |
        Short description (KB)

   2) dashboard.html       -> cards de resumo + tabela "Lacunas por analista"

 -----------------------------------------------------------------------------
 USO
 -----------------------------------------------------------------------------
   python dashboard_rca_pca.py

   Sem argumentos, o script procura por problem_task.xlsx e kb_knowledge.xlsx
   na pasta atual e na pasta do próprio script. Para apontar outros arquivos:

   python dashboard_rca_pca.py --problemas outro.xlsx --kb outro_kb.xlsx

   Opções:
     --problemas CAMINHO     planilha com as colunas Problem, Opened by,
                             RCA Status, Problem task type, Related Incidents,
                             Active   (padrão: problem_task.xlsx)
     --kb CAMINHO            planilha com as colunas Source task, Number,
                             Short description   (padrão: kb_knowledge.xlsx)
     --aba-problemas NOME    aba a ler no 1º arquivo (padrão: a primeira)
     --aba-kb NOME           aba a ler no 2º arquivo (padrão: a primeira)
     --saida-xlsx CAMINHO    padrão: base_unificada.xlsx
     --saida-html CAMINHO    padrão: dashboard.html
     --data DD/MM/AAAA       data de posição exibida (padrão: data de hoje)

 Os nomes das colunas são reconhecidos sem diferenciar maiúsculas, acentos ou
 espaços extras. Colunas ausentes são tratadas como vazias, com aviso no console.

 Requisito: openpyxl
===============================================================================
"""

import argparse
import os
import sys
import unicodedata
from datetime import date
from html import escape

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


# =============================================================================
# 1. LEITURA E NORMALIZAÇÃO DAS PLANILHAS
# =============================================================================

# Colunas esperadas na planilha de problemas -> apelidos aceitos
MAPA_PROBLEMAS = {
    "Problem": ["problem", "problema", "numero do problema", "prb"],
    "Opened by": ["opened by", "aberto por", "analista", "assigned to"],
    "RCA Status": ["rca status", "status da rca", "status rca"],
    "Problem task type": ["problem task type", "tipo de tarefa", "task type",
                          "tipo da tarefa do problema"],
    "Related Incidents": ["related incidents", "incidentes relacionados",
                          "incidentes vinculados", "incidentes"],
    "Active": ["active", "ativo", "ativa"],
}

# Colunas esperadas na planilha de conhecimento -> apelidos aceitos
MAPA_KB = {
    "Source task": ["source task", "tarefa de origem", "problem", "problema"],
    "Number": ["number", "numero", "kb", "artigo"],
    "Short description": ["short description", "descricao", "descricao curta",
                          "titulo"],
}

VERDADEIROS = {"verdadeiro", "true", "sim", "yes", "1", "y", "s"}
PUBLICADOS = {"published", "publicado", "publicada"}


def normalizar(texto):
    """minúsculas, sem acento e sem espaços duplicados - para casar cabeçalhos."""
    if texto is None:
        return ""
    texto = str(texto).strip().lower()
    texto = unicodedata.normalize("NFKD", texto)
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return " ".join(texto.split())


def texto(valor):
    """Converte qualquer célula em string limpa."""
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return str(valor).strip()


def inteiro(valor):
    """Converte a célula em int; devolve 0 quando não for numérica."""
    if valor is None or valor == "":
        return 0
    try:
        return int(float(str(valor).replace(".", "").replace(",", ".")))
    except (TypeError, ValueError):
        return 0


def eh_verdadeiro(valor):
    return normalizar(valor) in VERDADEIROS


def eh_publicado(valor):
    return normalizar(valor) in PUBLICADOS


def ler_planilha(caminho, mapa_colunas, nome_aba=None, rotulo=""):
    """
    Lê a planilha e devolve uma lista de dicionários já com os nomes de coluna
    canônicos (as chaves de mapa_colunas). Colunas não encontradas viram "".
    """
    if not os.path.isfile(caminho):
        sys.exit(f"ERRO: arquivo não encontrado -> {caminho}")

    try:
        wb = load_workbook(caminho, data_only=True, read_only=True)
    except Exception as erro:
        sys.exit(f"ERRO ao abrir {caminho}: {erro}")

    if nome_aba:
        if nome_aba not in wb.sheetnames:
            sys.exit(f"ERRO: aba '{nome_aba}' não existe em {caminho}. "
                     f"Abas disponíveis: {', '.join(wb.sheetnames)}")
        ws = wb[nome_aba]
    else:
        ws = wb[wb.sheetnames[0]]

    linhas = list(ws.iter_rows(values_only=True))
    wb.close()

    if not linhas:
        sys.exit(f"ERRO: {caminho} está vazio.")

    # localiza a linha de cabeçalho (primeira linha que casa com alguma coluna)
    indice_cabecalho = None
    for indice, linha in enumerate(linhas[:20]):
        normalizadas = {normalizar(c) for c in linha if c is not None}
        for apelidos in mapa_colunas.values():
            if normalizadas & set(apelidos):
                indice_cabecalho = indice
                break
        if indice_cabecalho is not None:
            break

    if indice_cabecalho is None:
        sys.exit(f"ERRO: não encontrei o cabeçalho esperado em {caminho}.")

    cabecalho = [normalizar(c) for c in linhas[indice_cabecalho]]

    # posição de cada coluna canônica dentro do cabeçalho
    posicoes = {}
    for canonico, apelidos in mapa_colunas.items():
        for posicao, nome in enumerate(cabecalho):
            if nome in apelidos:
                posicoes[canonico] = posicao
                break

    faltando = [c for c in mapa_colunas if c not in posicoes]
    if faltando:
        print(f"AVISO [{rotulo}]: colunas não encontradas e tratadas como vazias: "
              f"{', '.join(faltando)}")

    registros = []
    for linha in linhas[indice_cabecalho + 1:]:
        if linha is None or all(v is None or texto(v) == "" for v in linha):
            continue
        registro = {}
        for canonico in mapa_colunas:
            posicao = posicoes.get(canonico)
            registro[canonico] = linha[posicao] if (
                posicao is not None and posicao < len(linha)) else ""
        registros.append(registro)

    print(f"[leitura] {rotulo}: {len(registros)} linhas em '{ws.title}' ({os.path.basename(caminho)})")
    return registros


# =============================================================================
# 2. JUNÇÃO: UMA LINHA POR PROBLEMA
# =============================================================================

COL_UNIFICADA = ["Problem", "Opened by", "RCA Status", "Problem task type",
                 "Related Incidents", "Active", "Problem task type (PCA)",
                 "Active (PCA)", "Number (KB)", "Short description (KB)"]


def juntar(linhas_problemas, linhas_kb):
    """Cruza as duas bases pela chave Problem = Source task."""
    # índice do KB
    kb_por_problema = {}
    for artigo in linhas_kb:
        chave = texto(artigo.get("Source task"))
        if chave and chave not in kb_por_problema:
            kb_por_problema[chave] = artigo

    # agrupa as tarefas por problema, preservando a ordem de leitura
    grupos = {}
    ordem = []
    ignoradas = 0
    for linha in linhas_problemas:
        chave = texto(linha.get("Problem"))
        if not chave:
            ignoradas += 1
            continue
        if chave not in grupos:
            grupos[chave] = []
            ordem.append(chave)
        grupos[chave].append(linha)

    if ignoradas:
        print(f"AVISO: {ignoradas} linha(s) sem 'Problem' foram ignoradas.")

    unificado = []
    for chave in ordem:
        tarefas = grupos[chave]

        rcas = [t for t in tarefas if texto(t.get("Problem task type")).upper() == "RCA"]
        pcas = [t for t in tarefas if texto(t.get("Problem task type")).upper() == "PCA"]
        rca = rcas[0] if rcas else None
        pca = pcas[0] if pcas else None
        artigo = kb_por_problema.get(chave)

        # campos de nível do problema: primeiro valor não vazio entre as linhas
        def primeiro(campo):
            for t in tarefas:
                valor = texto(t.get(campo))
                if valor:
                    return valor
            return ""

        rca_status = primeiro("RCA Status")
        incidentes = max(inteiro(t.get("Related Incidents")) for t in tarefas)

        unificado.append({
            "Problem": chave,
            "Opened by": primeiro("Opened by") or "(sem responsável)",
            "RCA Status": rca_status,
            "Problem task type": "RCA" if rca else "",
            "Related Incidents": incidentes,
            "Active": texto(rca.get("Active")) if rca else "",
            "Problem task type (PCA)": "PCA" if pca else "",
            "Active (PCA)": texto(pca.get("Active")) if pca else "",
            "Number (KB)": texto(artigo.get("Number")) if artigo else "",
            "Short description (KB)": texto(artigo.get("Short description")) if artigo else "",
            # marcações usadas no dashboard
            "_sem_rca": rca is None,
            "_rca_nao_publicada": rca is not None and not eh_publicado(rca_status),
            "_rca_incompleta": any(eh_verdadeiro(t.get("Active")) for t in rcas),
            "_sem_pca": pca is None,
            "_pca_ativo": any(eh_verdadeiro(t.get("Active")) for t in pcas),
            "_sem_kb": artigo is None,
        })

    return unificado


def resumo_por_analista(unificado):
    """Uma linha por analista, na ordem de colunas do relatório."""
    mapa = {}
    for reg in unificado:
        analista = reg["Opened by"]
        linha = mapa.setdefault(analista, {
            "analista": analista, "problemas": 0, "rca_nao_publicada": 0,
            "sem_kb": 0, "sem_pca": 0, "sem_rca": 0, "rca_incompleto": 0,
        })
        linha["problemas"] += 1
        linha["rca_nao_publicada"] += 1 if reg["_rca_nao_publicada"] else 0
        linha["sem_kb"] += 1 if reg["_sem_kb"] else 0
        linha["sem_pca"] += 1 if reg["_sem_pca"] else 0
        linha["sem_rca"] += 1 if reg["_sem_rca"] else 0
        linha["rca_incompleto"] += 1 if reg["_rca_incompleta"] else 0

    resumo = list(mapa.values())
    resumo.sort(key=lambda x: (-x["problemas"], x["analista"]))
    return resumo


def calcular_indicadores(unificado):
    total = len(unificado)
    sem_lacuna = sum(
        1 for r in unificado
        if not r["_sem_rca"] and not r["_rca_nao_publicada"]
        and not r["_rca_incompleta"] and not r["_sem_pca"] and not r["_sem_kb"]
    )
    return {
        "problemas": total,
        "analistas": len({r["Opened by"] for r in unificado}),
        "incidentes": sum(r["Related Incidents"] for r in unificado),
        "sem_rca": sum(1 for r in unificado if r["_sem_rca"]),
        "rca_nao_publicada": sum(1 for r in unificado if r["_rca_nao_publicada"]),
        "rca_incompleto": sum(1 for r in unificado if r["_rca_incompleta"]),
        "sem_pca": sum(1 for r in unificado if r["_sem_pca"]),
        "pca_ativo": sum(1 for r in unificado if r["_pca_ativo"]),
        "sem_kb": sum(1 for r in unificado if r["_sem_kb"]),
        "sem_lacuna": sem_lacuna,
        "com_lacuna": total - sem_lacuna,
    }


# =============================================================================
# 3. SAÍDA .XLSX
# =============================================================================

LARGURAS = {
    "Problem": 16, "Opened by": 24, "RCA Status": 15, "Problem task type": 19,
    "Related Incidents": 18, "Active": 14, "Problem task type (PCA)": 23,
    "Active (PCA)": 15, "Number (KB)": 16, "Short description (KB)": 60,
}


def gravar_unificada(unificado, caminho):
    wb = Workbook()
    ws = wb.active
    ws.title = "Base unificada"
    ws.append(COL_UNIFICADA)
    for reg in unificado:
        ws.append([reg.get(coluna, "") for coluna in COL_UNIFICADA])

    fina = Side(style="thin", color="D5DCE4")
    borda = Border(left=fina, right=fina, top=fina, bottom=fina)

    for indice, nome in enumerate(COL_UNIFICADA, start=1):
        celula = ws.cell(row=1, column=indice)
        celula.font = Font(name="Arial", bold=True, size=10, color="FFFFFF")
        celula.fill = PatternFill("solid", fgColor="2F4F76")
        celula.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        celula.border = borda
        ws.column_dimensions[get_column_letter(indice)].width = LARGURAS.get(nome, 20)
    ws.row_dimensions[1].height = 30

    for linha in range(2, ws.max_row + 1):
        for coluna in range(1, len(COL_UNIFICADA) + 1):
            celula = ws.cell(row=linha, column=coluna)
            celula.font = Font(name="Arial", size=10)
            celula.border = borda
            celula.alignment = Alignment(horizontal="left", vertical="center")
            if linha % 2 == 0:
                celula.fill = PatternFill("solid", fgColor="F2F5F8")

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(COL_UNIFICADA))}{ws.max_row}"
    wb.save(caminho)


# =============================================================================
# 4. SAÍDA .HTML
# =============================================================================

CSS = """
*{box-sizing:border-box;}

body{
  margin:0;
  padding:44px 28px 64px;
  background:#eef1f5;
  color:#16202b;
  font-family:"Inter","Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size:16px;
  line-height:1.5;
  -webkit-font-smoothing:antialiased;
}

.pagina{max-width:1120px;margin:0 auto;}

.eyebrow{
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:12px;
  letter-spacing:.18em;
  text-transform:uppercase;
  color:#7a8794;
  margin:0 0 12px;
}

h1{
  font-family:"Archivo","Helvetica Neue",Arial,sans-serif;
  font-weight:900;
  font-size:38px;
  line-height:1.08;
  letter-spacing:-.015em;
  text-transform:uppercase;
  margin:0 0 14px;
}

.lead{max-width:70ch;font-size:17px;color:#3c4d5e;margin:0 0 32px;}
.lead strong{color:#a32b2b;font-weight:700;}

/* --------------------------------------------------------------- cards */
.cards{display:flex;flex-wrap:wrap;gap:16px;margin-bottom:44px;}

.card{
  flex:1 1 calc(25% - 12px);
  min-width:210px;
  background:#fff;
  border:1px solid #dfe5ec;
  border-left:5px solid #c6ced8;
  border-radius:6px;
  padding:18px 18px 16px;
}

.card--alerta{border-left-color:#a32b2b;}
.card--atencao{border-left-color:#b07d10;}
.card--ok{border-left-color:#2f7a4a;}

.card .valor{
  font-family:"Archivo","Helvetica Neue",Arial,sans-serif;
  font-weight:900;
  font-size:42px;
  line-height:1;
  letter-spacing:-.03em;
  display:block;
  margin-bottom:10px;
  color:#16202b;
}

.card--alerta .valor{color:#a32b2b;}
.card--atencao .valor{color:#b07d10;}
.card--ok .valor{color:#2f7a4a;}

.card .rotulo{display:block;font-size:14.5px;color:#3c4d5e;}

.card .nota{
  display:block;
  margin-top:7px;
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:12px;
  color:#7a8794;
}

/* -------------------------------------------------------------- tabela */
h2{
  font-family:"Archivo","Helvetica Neue",Arial,sans-serif;
  font-weight:900;
  font-size:24px;
  letter-spacing:-.01em;
  text-transform:uppercase;
  margin:0 0 6px;
}

.subtitulo{
  font-size:14px;
  color:#7a8794;
  margin:0 0 18px;
  padding-bottom:16px;
  border-bottom:1px solid #dfe5ec;
}

.quadro{
  background:#fff;
  border:1px solid #dfe5ec;
  border-radius:6px;
  overflow:hidden;
}

table{width:100%;border-collapse:collapse;}

thead th{
  background:#2f4f76;
  color:#fff;
  font-size:12px;
  font-weight:700;
  letter-spacing:.1em;
  text-transform:uppercase;
  text-align:center;
  padding:16px 12px;
  vertical-align:middle;
}

thead th:first-child{text-align:left;padding-left:24px;}

tbody td{
  padding:15px 12px;
  text-align:center;
  border-bottom:1px solid #dfe5ec;
  font-size:16px;
}

tbody td:first-child{text-align:left;padding-left:24px;}
tbody tr:last-child td{border-bottom:none;}
tbody tr:hover td{background:#f7f9fb;}

tfoot td{
  padding:14px 12px;
  text-align:center;
  font-size:15px;
  font-weight:700;
  background:#f4f7fa;
  border-top:2px solid #2f4f76;
}

tfoot td:first-child{
  text-align:left;
  padding-left:24px;
  text-transform:uppercase;
  letter-spacing:.06em;
  font-size:12px;
  color:#3c4d5e;
}

.num{font-weight:700;color:#a32b2b;}
.num.zero{font-weight:400;color:#aab4bf;}
.num.neutro{color:#16202b;}

/* ------------------------------------------------- esteira de pendências */
.esteira{
  background:#fff;
  border:1px solid #dfe5ec;
  border-radius:6px;
  padding:4px 22px 18px;
}

.esteira-cabecalho,.esteira-linha{display:flex;align-items:center;gap:8px;}

.esteira-cabecalho > *:first-child,
.esteira-linha > *:first-child{flex:0 0 190px;width:190px;}

.esteira-cabecalho > *:last-child,
.esteira-linha > *:last-child{flex:0 0 56px;width:56px;}

.esteira-cabecalho > span,
.esteira-linha > .segmento{flex:1 1 0;min-width:0;}

.esteira-cabecalho{padding:14px 0 10px;border-bottom:1px solid #dfe5ec;}

.esteira-cabecalho span{
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:10.5px;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:#7a8794;
  text-align:center;
}

.esteira-cabecalho span:first-child{text-align:left;}
.esteira-cabecalho span:last-child{text-align:right;}

.esteira-grupo{
  padding:16px 0 6px;
  font-family:"Archivo","Helvetica Neue",Arial,sans-serif;
  font-weight:700;
  font-size:13px;
  letter-spacing:.06em;
  text-transform:uppercase;
  color:#2f4f76;
  border-bottom:1px solid #dfe5ec;
}

.esteira-grupo small{
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-weight:400;
  letter-spacing:0;
  text-transform:none;
  color:#7a8794;
  margin-left:8px;
}

.esteira-linha{padding:10px 0;border-bottom:1px solid #f1f4f7;}
.esteira-linha:last-child{border-bottom:none;}

.esteira-id{display:flex;flex-direction:column;line-height:1.25;}
.esteira-id b{font-family:"IBM Plex Mono",Consolas,monospace;font-size:13px;font-weight:600;}
.esteira-id small{font-size:11.5px;color:#7a8794;}

.segmento{height:18px;border-radius:4px;}
.segmento.ok{background:#2f4f76;}
.segmento.ok.final{background:#3d7a4e;}

.segmento.vao{
  background-color:#f7e6e6;
  background-image:repeating-linear-gradient(
      45deg,rgba(163,43,43,.45) 0 3px,transparent 3px 9px);
  border:1px solid rgba(163,43,43,.35);
}

.esteira-placar{
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:13px;
  font-weight:600;
  text-align:right;
  color:#a32b2b;
}

.esteira-placar.brando{color:#7a8794;font-weight:400;}

.legenda{
  display:flex;
  flex-wrap:wrap;
  gap:22px;
  margin-top:16px;
  padding-top:14px;
  border-top:1px solid #dfe5ec;
  font-size:13px;
  color:#7a8794;
}

.legenda span{display:flex;align-items:center;gap:8px;}
.amostra{width:26px;height:12px;border-radius:3px;display:inline-block;}
.amostra.ok{background:#2f4f76;}
.amostra.final{background:#3d7a4e;}
.amostra.vao{
  background-color:#f7e6e6;
  background-image:repeating-linear-gradient(
      45deg,rgba(163,43,43,.45) 0 3px,transparent 3px 9px);
  border:1px solid rgba(163,43,43,.35);
}

.vazio-estado{
  background:#fff;
  border:1px solid #dfe5ec;
  border-radius:6px;
  padding:28px 24px;
  color:#3c4d5e;
}

.rodape{
  margin-top:32px;
  padding-top:16px;
  border-top:1px solid #dfe5ec;
  font-family:"IBM Plex Mono",Consolas,monospace;
  font-size:12px;
  line-height:1.9;
  color:#7a8794;
}

@media (max-width:1024px){.card{flex:1 1 calc(50% - 8px);}}

@media (max-width:760px){
  body{padding:28px 14px 48px;}
  h1{font-size:28px;}
  .card{flex:1 1 100%;min-width:0;}
  .quadro{overflow-x:auto;}
  table{min-width:680px;}
  .esteira{padding:4px 14px 16px;}
  .esteira-cabecalho > *:first-child,
  .esteira-linha > *:first-child{flex:0 0 108px;width:108px;}
  .esteira-cabecalho > *:last-child,
  .esteira-linha > *:last-child{flex:0 0 42px;width:42px;}
  .esteira-cabecalho span{font-size:9px;letter-spacing:.03em;}
  .esteira-id b{font-size:11px;}
  .esteira-id small{font-size:10px;}
}

@media print{
  body{background:#fff;padding:0;}
  .card,.quadro{break-inside:avoid;}
}
"""


def card(valor, rotulo, tom="neutro", nota=""):
    classe = "" if tom == "neutro" else f" card--{tom}"
    nota_html = f'\n      <span class="nota">{escape(nota)}</span>' if nota else ""
    return (
        f'    <div class="card{classe}">\n'
        f'      <span class="valor">{valor}</span>\n'
        f'      <span class="rotulo">{escape(rotulo)}</span>{nota_html}\n'
        f'    </div>\n'
    )


def marcos_do_problema(reg):
    """
    Os 5 marcos da esteira, nas mesmas definições da tabela por analista.
    Devolve uma lista de (rótulo, cumprido, detalhe).
    """
    tem_rca = not reg["_sem_rca"]
    tem_pca = not reg["_sem_pca"]
    status = reg["RCA Status"] or "sem status"

    return [
        ("RCA criada", tem_rca,
         "tarefa de RCA registrada" if tem_rca else "não existe tarefa de RCA"),
        ("RCA publicada", tem_rca and not reg["_rca_nao_publicada"],
         f"RCA Status: {status}"),
        ("RCA concluída", tem_rca and not reg["_rca_incompleta"],
         "RCA com Active = VERDADEIRO" if reg["_rca_incompleta"]
         else ("RCA encerrada" if tem_rca else "não existe tarefa de RCA")),
        ("PCA criado", tem_pca,
         ("PCA em execução" if reg["_pca_ativo"] else "PCA registrado")
         if tem_pca else "não existe tarefa de PCA"),
        ("KB publicado", not reg["_sem_kb"],
         reg["Number (KB)"] if reg["Number (KB)"] else "sem artigo de conhecimento"),
    ]


def montar_esteira(unificado):
    """
    Blocos da esteira apenas com os problemas que têm alguma pendência,
    agrupados e ordenados por analista.
    """
    pendentes = []
    for reg in unificado:
        marcos = marcos_do_problema(reg)
        cumpridos = sum(1 for _, ok, _ in marcos if ok)
        if cumpridos < len(marcos):
            pendentes.append((reg, marcos, cumpridos))

    if not pendentes:
        return ('    <div class="vazio-estado">Nenhum problema com pendência — '
                'todos os registros têm RCA publicada e concluída, PCA criado '
                'e artigo de conhecimento.</div>\n'), 0

    # ordena por analista e, dentro dele, do mais incompleto para o mais completo
    pendentes.sort(key=lambda item: (item[0]["Opened by"].lower(),
                                     item[2], item[0]["Problem"]))

    partes = []
    analista_atual = None

    for reg, marcos, cumpridos in pendentes:
        if reg["Opened by"] != analista_atual:
            analista_atual = reg["Opened by"]
            quantos = sum(1 for p in pendentes if p[0]["Opened by"] == analista_atual)
            partes.append(
                f'      <div class="esteira-grupo">{escape(analista_atual)}'
                f'<small>{quantos} problema(s) com pendência</small></div>\n'
            )

        partes.append('      <div class="esteira-linha">\n')
        partes.append(
            f'        <div class="esteira-id"><b>{escape(reg["Problem"])}</b>'
            f'<small>{escape(reg["Opened by"])}</small></div>\n'
        )
        for indice, (rotulo, cumprido, detalhe) in enumerate(marcos):
            if cumprido:
                classe = "segmento ok final" if indice == len(marcos) - 1 else "segmento ok"
            else:
                classe = "segmento vao"
            titulo = f"{rotulo} — {detalhe}"
            partes.append(f'        <div class="{classe}" title="{escape(titulo)}"></div>\n')

        classe_placar = "esteira-placar" if cumpridos <= 2 else "esteira-placar brando"
        partes.append(f'        <div class="{classe_placar}">{cumpridos}/{len(marcos)}</div>\n')
        partes.append('      </div>\n')

    return "".join(partes), len(pendentes)


def celula_num(valor, neutro=False):
    if valor == 0:
        return '<td><span class="num zero">0</span></td>'
    classe = "num neutro" if neutro else "num"
    return f'<td><span class="{classe}">{valor}</span></td>'


def gerar_html(unificado, indicadores, resumo, data_posicao,
               origem_problemas, origem_kb):
    i = indicadores
    esteira, qtd_pendentes = montar_esteira(unificado)

    cards = (
        card(i["problemas"], "problemas na base", "neutro",
             f'{i["incidentes"]} incidentes vinculados · {i["analistas"]} analistas')
        + card(i["sem_rca"], "sem tarefa de RCA", "alerta")
        + card(i["rca_nao_publicada"], "RCA não publicada", "alerta")
        + card(i["rca_incompleto"], "RCA incompleto (ainda ativa)", "atencao")
        + card(i["sem_pca"], "sem tarefa de PCA", "alerta")
        + card(i["pca_ativo"], "PCA ainda em execução", "atencao")
        + card(i["sem_kb"], "sem artigo de conhecimento", "alerta")
        + card(i["sem_lacuna"], "problemas sem nenhuma lacuna", "ok")
    )

    linhas = ""
    for linha in resumo:
        linhas += (
            "          <tr>\n"
            f'            <td>{escape(linha["analista"])}</td>\n'
            f'            {celula_num(linha["problemas"], neutro=True)}\n'
            f'            {celula_num(linha["rca_nao_publicada"])}\n'
            f'            {celula_num(linha["sem_kb"])}\n'
            f'            {celula_num(linha["sem_pca"])}\n'
            f'            {celula_num(linha["sem_rca"])}\n'
            f'            {celula_num(linha["rca_incompleto"])}\n'
            "          </tr>\n"
        )

    rodape_tabela = (
        "          <tr>\n"
        f'            <td>Total ({len(resumo)} analistas)</td>\n'
        f'            <td>{i["problemas"]}</td>\n'
        f'            <td>{i["rca_nao_publicada"]}</td>\n'
        f'            <td>{i["sem_kb"]}</td>\n'
        f'            <td>{i["sem_pca"]}</td>\n'
        f'            <td>{i["sem_rca"]}</td>\n'
        f'            <td>{i["rca_incompleto"]}</td>\n'
        "          </tr>\n"
    )

    return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Gestão de problemas · Posição de {data_posicao}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;700;900&family=IBM+Plex+Mono:wght@400;600&family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
<style>
{CSS}
</style>
</head>
<body>
<div class="pagina">

  <p class="eyebrow">Gestão de problemas · Posição de {data_posicao}</p>
  <h1>Lacunas de RCA, PCA e conhecimento</h1>
  <p class="lead">
    Resumo do cruzamento entre a base de problemas e a base de artigos de conhecimento —
    <strong>{i["com_lacuna"]} dos {i["problemas"]} problemas têm pelo menos uma pendência.</strong>
  </p>

  <section class="cards">
{cards}  </section>

  <section>
    <h2>Lacunas por analista</h2>
    <p class="subtitulo">
      Problemas abertos por analista e em quantos deles cada etapa ficou pendente.
    </p>
    <div class="quadro">
      <table>
        <thead>
          <tr>
            <th>Analista</th>
            <th>Problemas</th>
            <th>RCA não publicada</th>
            <th>Sem KB</th>
            <th>Sem PCA</th>
            <th>Sem RCA</th>
            <th>RCA incompleto</th>
          </tr>
        </thead>
        <tbody>
{linhas}        </tbody>
        <tfoot>
{rodape_tabela}        </tfoot>
      </table>
    </div>
  </section>

  <section>
    <h2>Problemas com pendência</h2>
    <p class="subtitulo">
      {qtd_pendentes} de {i["problemas"]} problemas têm pelo menos um marco em aberto.
      Agrupados por analista; o vão hachurado marca a etapa que falta.
      Passe o cursor sobre um trecho para ver o motivo.
    </p>
    <div class="esteira">
      <div class="esteira-cabecalho">
        <span>Problema</span>
        <span>RCA criada</span>
        <span>RCA publicada</span>
        <span>RCA concluída</span>
        <span>PCA criado</span>
        <span>KB publicado</span>
        <span>Marcos</span>
      </div>
{esteira}      <div class="legenda">
        <span><i class="amostra ok"></i> marco cumprido</span>
        <span><i class="amostra final"></i> esteira encerrada</span>
        <span><i class="amostra vao"></i> marco em aberto</span>
      </div>
    </div>
  </section>

  <footer class="rodape">
    Origem: {escape(origem_problemas)} + {escape(origem_kb)} · chave da junção: Problem = Source task.<br>
    Sem RCA / Sem PCA: não há linha com aquele Problem task type.
    RCA não publicada: existe RCA e RCA Status diferente de Published.
    RCA incompleto: existe RCA com Active = VERDADEIRO.
    Sem KB: não há Number para o problema.
  </footer>

</div>
</body>
</html>
"""


# =============================================================================
# 5. LINHA DE COMANDO
# =============================================================================

# Nomes procurados automaticamente quando --problemas / --kb não são informados
PADRAO_PROBLEMAS = ["problem_task.xlsx", "problem task.xlsx", "problemas.xlsx",
                    "base_problemas.xlsx"]
PADRAO_KB = ["kb_knowledge.xlsx", "kb knowledge.xlsx", "kb.xlsx",
             "knowledge.xlsx", "base_kb.xlsx"]

DIR_SCRIPT = os.path.dirname(os.path.abspath(__file__))


def localizar(caminho_informado, nomes_padrao, rotulo):
    """
    Resolve o caminho do arquivo. Procura, nesta ordem:
      1. o caminho passado na linha de comando (como veio, e dentro da pasta do script)
      2. os nomes padrão, na pasta atual e na pasta do script
    Encerra com mensagem clara quando não encontra.
    """
    candidatos = []
    if caminho_informado:
        candidatos = [caminho_informado,
                      os.path.join(DIR_SCRIPT, os.path.basename(caminho_informado))]
    else:
        for nome in nomes_padrao:
            candidatos.append(os.path.join(os.getcwd(), nome))
            candidatos.append(os.path.join(DIR_SCRIPT, nome))

    for candidato in candidatos:
        if os.path.isfile(candidato):
            return candidato

    # não achou: mostra o que existe por perto para facilitar a correção
    encontrados = sorted({
        nome for pasta in {os.getcwd(), DIR_SCRIPT}
        for nome in os.listdir(pasta)
        if nome.lower().endswith((".xlsx", ".xlsm"))
    })
    print(f"ERRO: não encontrei a planilha de {rotulo}.")
    if caminho_informado:
        print(f"       Caminho informado: {caminho_informado}")
    else:
        print(f"       Procurei por: {', '.join(nomes_padrao)}")
        print(f"       Nas pastas:   {os.getcwd()}")
        if DIR_SCRIPT != os.getcwd():
            print(f"                     {DIR_SCRIPT}")
    if encontrados:
        print(f"       Planilhas disponíveis: {', '.join(encontrados)}")
    print("       Informe o caminho com:  --problemas ARQUIVO.xlsx --kb ARQUIVO.xlsx")
    sys.exit(1)


def obter_argumentos():
    parser = argparse.ArgumentParser(
        description="Gera o dashboard de lacunas de RCA/PCA a partir de dois arquivos .xlsx.",
        epilog="Sem argumentos, procura por problem_task.xlsx e kb_knowledge.xlsx "
               "na pasta atual ou na pasta do script.",
    )
    parser.add_argument("--problemas", default=None,
                        help="Caminho do .xlsx com Problem, Opened by, RCA Status, "
                             "Problem task type, Related Incidents, Active "
                             "(padrão: problem_task.xlsx)")
    parser.add_argument("--kb", default=None,
                        help="Caminho do .xlsx com Source task, Number, Short description "
                             "(padrão: kb_knowledge.xlsx)")
    parser.add_argument("--aba-problemas", default=None, help="Nome da aba do 1º arquivo")
    parser.add_argument("--aba-kb", default=None, help="Nome da aba do 2º arquivo")
    parser.add_argument("--saida-xlsx", default="base_unificada.xlsx")
    parser.add_argument("--saida-html", default="dashboard.html")
    parser.add_argument("--data", default=None,
                        help="Data de posição no formato DD/MM/AAAA (padrão: hoje)")

    args = parser.parse_args()
    args.problemas = localizar(args.problemas, PADRAO_PROBLEMAS, "problemas")
    args.kb = localizar(args.kb, PADRAO_KB, "conhecimento (KB)")
    return args


def main():
    args = obter_argumentos()
    data_posicao = args.data or date.today().strftime("%d/%m/%Y")

    # ---- leitura -------------------------------------------------------
    linhas_problemas = ler_planilha(args.problemas, MAPA_PROBLEMAS,
                                    args.aba_problemas, "problemas")
    linhas_kb = ler_planilha(args.kb, MAPA_KB, args.aba_kb, "conhecimento")

    # ---- junção --------------------------------------------------------
    unificado = juntar(linhas_problemas, linhas_kb)
    if not unificado:
        sys.exit("ERRO: nenhum problema válido encontrado após a junção.")

    indicadores = calcular_indicadores(unificado)
    resumo = resumo_por_analista(unificado)

    # ---- saídas --------------------------------------------------------
    gravar_unificada(unificado, args.saida_xlsx)
    print(f"[saída] {args.saida_xlsx} ({len(unificado)} problemas)")

    html = gerar_html(unificado, indicadores, resumo, data_posicao,
                      os.path.basename(args.problemas), os.path.basename(args.kb))
    with open(args.saida_html, "w", encoding="utf-8") as arquivo:
        arquivo.write(html)
    print(f"[saída] {args.saida_html}")

    print("\nIndicadores:")
    for chave, valor in indicadores.items():
        print(f"    {chave:<20} {valor}")


if __name__ == "__main__":
    main()

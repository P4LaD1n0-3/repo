# -*- coding: utf-8 -*-
"""
All metric calculations for the dashboard: aging & SLA breach, monthly and
daily throughput with accumulated backlog, cross-type conversion / offender
detection (SCTASK<->INC), rankings (analysts, requesters, status), and the
"pretty" evolution helpers (daily / weekly / today-vs-yesterday).
"""
import re
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from config import (SCTASK_AGING_BINS, SCTASK_AGING_LABELS, INC_AGING_BINS,
                     INC_AGING_LABELS, PRB_AGING_BINS, PRB_AGING_LABELS,
                     MONTH_ABBR_EN, WEEKDAY_ABBR_EN)

AGING_DEFS = {
    "SCTASK": (SCTASK_AGING_BINS, SCTASK_AGING_LABELS),
    "INC": (INC_AGING_BINS, INC_AGING_LABELS),
    "PRB": (PRB_AGING_BINS, PRB_AGING_LABELS),
}


# ---------------------------------------------------------------------------
# Reference date / month helpers
# ---------------------------------------------------------------------------
def get_reference_date(config):
    raw = config.get("REFERENCE_DATE")
    if raw:
        return pd.Timestamp(raw)
    return pd.Timestamp(datetime.now())


def month_bounds(ref, offset_months=0):
    year = ref.year
    month = ref.month + offset_months
    while month <= 0:
        month += 12
        year -= 1
    while month > 12:
        month -= 12
        year += 1
    start = pd.Timestamp(year=year, month=month, day=1)
    end = pd.Timestamp(year=year + (1 if month == 12 else 0),
                        month=1 if month == 12 else month + 1, day=1)
    return start, end


# ---------------------------------------------------------------------------
# Aging & SLA breach (computed on OPEN tickets, aging = now - Opened)
# ---------------------------------------------------------------------------
def add_open_aging(df, ref, sla_days):
    """Return a copy of the OPEN subset of df with AgingDays and SLABreach."""
    open_df = df[df["IsOpen"]].copy()
    open_df["AgingDays"] = (ref - open_df["Opened"]).dt.days.clip(lower=0)
    open_df["SLABreach"] = open_df["AgingDays"] > int(sla_days)
    return open_df


def aging_bucket_table(open_df, ticket_type):
    bins, labels = AGING_DEFS[ticket_type]
    if open_df.empty:
        return pd.DataFrame({"Bucket": labels, "Count": [0] * len(labels)})
    binned = pd.cut(open_df["AgingDays"], bins=bins, labels=labels,
                     include_lowest=False, right=True)
    counts = binned.value_counts().reindex(labels, fill_value=0)
    return pd.DataFrame({"Bucket": labels, "Count": counts.values.astype(int)})


def sla_inside_outside(open_df):
    if open_df.empty:
        return 0, 0
    breach = open_df["SLABreach"].value_counts()
    inside = int(breach.get(False, 0))
    outside = int(breach.get(True, 0))
    return inside, outside


def critical_table(open_df, threshold, top_n=25, category_col="Assignment group"):
    """Rows with AgingDays >= threshold, oldest first."""
    if open_df.empty:
        return open_df
    crit = open_df[open_df["AgingDays"] >= threshold].copy()
    return crit.sort_values("AgingDays", ascending=False).head(top_n)


def critical_summary(open_df, threshold, extra_threshold=None):
    """Compact numbers for the 'smart card' critical panel: how many tickets
    are past the warning threshold, how many are past the extra-critical
    threshold (if any), and which one is the single oldest ticket."""
    if open_df.empty:
        return {"count": 0, "count_extra": 0, "oldest_number": "\u2014",
                "oldest_days": 0, "oldest_assignee": "\u2014", "avg_days": 0.0}
    crit = open_df[open_df["AgingDays"] >= threshold]
    count_extra = int((open_df["AgingDays"] >= extra_threshold).sum()) if extra_threshold else 0
    if crit.empty:
        return {"count": 0, "count_extra": count_extra, "oldest_number": "\u2014",
                "oldest_days": 0, "oldest_assignee": "\u2014", "avg_days": 0.0}
    oldest = crit.sort_values("AgingDays", ascending=False).iloc[0]
    return {
        "count": int(len(crit)), "count_extra": count_extra,
        "oldest_number": oldest["Number"], "oldest_days": int(oldest["AgingDays"]),
        "oldest_assignee": oldest["Assigned to"], "avg_days": round(float(crit["AgingDays"].mean()), 1),
    }


# ---------------------------------------------------------------------------
# Closed-ticket resolution time (MTTR)
# ---------------------------------------------------------------------------
def mttr_days(df):
    closed = df[~df["IsOpen"]].copy()
    if closed.empty:
        return 0.0
    days = ((closed["Closed"] - closed["Opened"]).dt.total_seconds() / 86400.0).clip(lower=0)
    return float(days.mean())


def mttr_days_month(df, ref):
    """MTTR computed ONLY over tickets resolved in the current month - this
    report is a day-to-day operations snapshot, so resolution-time metrics
    must never silently blend in months of unrelated history. Negative
    durations (a bad Closed-before-Opened data entry) are clipped to 0
    instead of being allowed to drag the average down incorrectly."""
    ini, fim = month_bounds(ref)
    closed = df[(df["Closed"] >= ini) & (df["Closed"] < fim)]
    if closed.empty:
        return 0.0
    days = ((closed["Closed"] - closed["Opened"]).dt.total_seconds() / 86400.0).clip(lower=0)
    return float(days.mean())


def current_month_flow(df, ref):
    """(opened_this_month, resolved_this_month) - no other months involved."""
    ini, fim = month_bounds(ref)
    opened = int(((df["Opened"] >= ini) & (df["Opened"] < fim)).sum())
    resolved = int(((df["Closed"] >= ini) & (df["Closed"] < fim)).sum())
    return opened, resolved


# ---------------------------------------------------------------------------
# Status distribution & top analysts (open tickets)
# ---------------------------------------------------------------------------
def status_distribution(open_df, top_n=8):
    if open_df.empty:
        return [], []
    vc = open_df["State"].replace("", "N/A").value_counts().head(top_n)
    return list(vc.index), [int(v) for v in vc.values]


def top_analysts(open_df, top_n=8):
    if open_df.empty:
        return [], []
    vc = open_df["Assigned to"].replace("", "N/A").value_counts().head(top_n)
    return list(vc.index), [int(v) for v in vc.values]


def top_analysts_combined(open_sctask, open_inc, top_n=10):
    """Per-analyst SCTASK count + INC count, ranked by combined total -
    feeds the stacked 'Top Analysts (SCTASK + INC)' bar chart."""
    s_counts = open_sctask["Assigned to"].replace("", "N/A").value_counts()
    i_counts = open_inc["Assigned to"].replace("", "N/A").value_counts()
    combined = s_counts.add(i_counts, fill_value=0).sort_values(ascending=False)
    top_names = list(combined.head(top_n).index)
    sctask_vals = [int(s_counts.get(n, 0)) for n in top_names]
    inc_vals = [int(i_counts.get(n, 0)) for n in top_names]
    return top_names, sctask_vals, inc_vals


# ---------------------------------------------------------------------------
# Monthly throughput with accumulated backlog (window = MONTHS_LOOKBACK)
# ---------------------------------------------------------------------------
def monthly_throughput(df, ref, months_lookback):
    rows = []
    backlog = 0
    for i in range(months_lookback - 1, -1, -1):
        ini, fim = month_bounds(ref, -i)
        opened = int(((df["Opened"] >= ini) & (df["Opened"] < fim)).sum())
        closed = int(((df["Closed"] >= ini) & (df["Closed"] < fim)).sum())
        net = opened - closed
        backlog += net
        rows.append({
            "Month": f"{MONTH_ABBR_EN[ini.month]}/{ini.year}",
            "Opened": opened, "Resolved": closed, "NetFlow": net,
            "BacklogAccum": backlog,
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Daily trend for the CURRENT month, with accumulated backlog
# ---------------------------------------------------------------------------
def daily_trend_current_month(df, ref):
    ini, _ = month_bounds(ref)
    last_day = ref.day
    rows = []
    backlog = 0
    for d in range(1, last_day + 1):
        dt = ini + timedelta(days=d - 1)
        opened = int((df["Opened"].dt.normalize() == dt.normalize()).sum())
        closed = int((df["Closed"].dt.normalize() == dt.normalize()).sum())
        net = opened - closed
        backlog += net
        rows.append({
            "Date": dt.strftime("%d/%m"), "Opened": opened,
            "Resolved": closed, "NetFlow": net, "BacklogAccum": backlog,
        })
    return pd.DataFrame(rows)


def daily_trend_last_n_days(df, ref, n_days):
    """Same shape as daily_trend_current_month, but over a rolling window of
    the last N days (not bounded to the current calendar month) - matches
    the 'Last 10 Days' comparison panel style."""
    end_day = ref.normalize()
    days = [end_day - timedelta(days=i) for i in range(n_days - 1, -1, -1)]
    rows = []
    backlog = 0
    for dt in days:
        opened = int((df["Opened"].dt.normalize() == dt).sum())
        closed = int((df["Closed"].dt.normalize() == dt).sum())
        net = opened - closed
        backlog += net
        rows.append({
            "Date": dt.strftime("%d/%m"), "Opened": opened,
            "Resolved": closed, "NetFlow": net, "BacklogAccum": backlog,
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Pretty evolution helpers (kept from the previous report)
# ---------------------------------------------------------------------------
def daily_evolution(df, ref, n_days):
    end_day = ref.normalize()
    days = [end_day - timedelta(days=i) for i in range(n_days - 1, -1, -1)]
    opened, closed = [], []
    for d in days:
        opened.append(int((df["Opened"].dt.normalize() == d).sum()))
        closed.append(int((df["Closed"].dt.normalize() == d).sum()))
    labels = [d.strftime("%d/%m") for d in days]
    return labels, opened, closed


def week_start(dt):
    return (dt - timedelta(days=dt.weekday())).normalize()


def weekly_evolution(df, ref, n_weeks):
    cur_start = week_start(ref)
    starts = [cur_start - timedelta(weeks=i) for i in range(n_weeks - 1, -1, -1)]
    labels, opened, closed = [], [], []
    for s in starts:
        e = s + timedelta(days=7)
        opened.append(int(((df["Opened"] >= s) & (df["Opened"] < e)).sum()))
        closed.append(int(((df["Closed"] >= s) & (df["Closed"] < e)).sum()))
        labels.append(s.strftime("%d/%m"))
    return labels, opened, closed


def current_vs_last_week_by_weekday(df, ref):
    cur_start = week_start(ref)
    prev_start = cur_start - timedelta(weeks=1)
    cur_counts, prev_counts = [], []
    for i in range(7):
        d_cur = cur_start + timedelta(days=i)
        d_prev = prev_start + timedelta(days=i)
        cur_counts.append(int((df["Opened"].dt.normalize() == d_cur).sum()) if d_cur <= ref else 0)
        prev_counts.append(int((df["Opened"].dt.normalize() == d_prev).sum()))
    return WEEKDAY_ABBR_EN, cur_counts, prev_counts


def today_vs_yesterday(df, ref):
    today = ref.normalize()
    yesterday = today - timedelta(days=1)
    return {
        "opened_today": int((df["Opened"].dt.normalize() == today).sum()),
        "opened_yesterday": int((df["Opened"].dt.normalize() == yesterday).sum()),
        "closed_today": int((df["Closed"].dt.normalize() == today).sum()),
        "closed_yesterday": int((df["Closed"].dt.normalize() == yesterday).sum()),
        "today_label": today.strftime("%d/%m"), "yesterday_label": yesterday.strftime("%d/%m"),
    }


def calc_trend(current, previous, good_when_up=True):
    if previous == 0:
        pct = 0.0 if current == 0 else 100.0
    else:
        pct = (current - previous) / previous * 100.0
    arrow = "\u25b2" if pct >= 0 else "\u25bc"
    is_good = (pct >= 0) == good_when_up
    return pct, arrow, is_good


# ---------------------------------------------------------------------------
# Cross-type conversion / offender detection - replicates the "Classification
# Errors" tab logic: a ticket is a genuine misclassification only when there
# is BOTH an abnormal closure (incomplete/cancelled/rejected) AND textual
# evidence of it (the misclassification reason, or a linked ticket number
# quoted in the notes) - not simply "any cancelled ticket".
# ---------------------------------------------------------------------------
CANCEL_LIKE_KEYWORDS = ["incomplet", "cancel", "rejeit", "reject"]


def _extract_ref(text, prefix):
    if not text:
        return None
    m = re.findall(rf"\b{prefix}[\s\-]?(\d{{6,12}})\b", str(text), re.IGNORECASE)
    return f"{prefix}{m[0]}" if m else None


def _state_matches_any(state_series, keywords):
    s = state_series.astype(str).str.lower()
    pattern = "|".join(keywords)
    return s.str.contains(pattern, regex=True, na=False)


def _cancelled_like_mask(df):
    return _state_matches_any(df["State"], CANCEL_LIKE_KEYWORDS)


def _date_to_compare(df):
    """Closed date if present, else Opened (mirrors the reference logic's
    'performance date' used to bucket a record into a given month)."""
    return df["Closed"].fillna(df["Opened"])


def sctask_misclassified(df_sctask, config):
    """SCTASK tickets closed incomplete/cancelled/rejected AND whose Reason
    field explicitly names a classification problem (SCTASK -> INC)."""
    keywords = [k.lower() for k in config["MISCLASSIFICATION_REASON_KEYWORDS"]]
    state_match = _cancelled_like_mask(df_sctask)
    reason_lower = df_sctask["Reason"].str.lower()
    reason_match = reason_lower.apply(lambda r: any(k in r for k in keywords))
    sub = df_sctask[state_match & reason_match].copy()
    if sub.empty:
        return sub
    combined_text = sub["Close notes"] + " | " + sub["Work notes"] + " | " + sub["Additional comments"]
    sub["LinkedTicket"] = combined_text.apply(lambda t: _extract_ref(t, "INC") or "\u26a0\ufe0f Not linked")
    sub["Direction"] = "SCTASK\u2192INC"
    sub["Requester_norm"] = sub["Requester"]
    sub["Reason_norm"] = sub["Reason"]
    return sub


def inc_reclassified(df_inc, config):
    """INC tickets cancelled AND whose notes explicitly reference a linked
    SCTASK/RITM (INC -> SCTASK) - cancelled alone is not enough evidence."""
    state_match = _state_matches_any(df_inc["State"], ["cancel"])
    combined_text = df_inc["Close notes"] + " | " + df_inc["Additional comments"]
    has_link_ref = combined_text.str.upper().str.contains("RITM|SCTASK", regex=True, na=False)
    sub = df_inc[state_match & has_link_ref].copy()
    if sub.empty:
        return sub
    sub["LinkedTicket"] = combined_text[sub.index].apply(
        lambda t: _extract_ref(t, "SCTASK") or _extract_ref(t, "RITM") or "\u26a0\ufe0f Not linked")
    sub["Direction"] = "INC\u2192SCTASK"
    sub["Requester_norm"] = sub["Caller"]
    sub["Reason_norm"] = "Cancelled \u2014 relinked to SCTASK"
    return sub


def classification_errors(df_sctask, df_inc, ref, config):
    """Full replica of the 'Classification Errors' tab: reconciles the total
    universe of cancelled/incomplete tickets against the subset that is
    specifically a cross-type misclassification, in both directions."""
    ini, fim = month_bounds(ref)

    # ---- Universe: ALL cancelled/incomplete/rejected tickets this month (any reason) ----
    sctask_cancel_mask = _cancelled_like_mask(df_sctask) & \
        _date_to_compare(df_sctask).between(ini, fim - pd.Timedelta(milliseconds=1))
    inc_cancel_mask = _cancelled_like_mask(df_inc) & \
        _date_to_compare(df_inc).between(ini, fim - pd.Timedelta(milliseconds=1))
    sctask_cancel_total = int(sctask_cancel_mask.sum())
    inc_cancel_total = int(inc_cancel_mask.sum())

    # ---- Specific misclassifications, both directions, full history ----
    s2i = sctask_misclassified(df_sctask, config)
    i2s = inc_reclassified(df_inc, config)

    cols = ["Number", "Requester_norm", "Assigned to", "Assignment group", "State",
            "Reason_norm", "LinkedTicket", "Direction", "Opened", "Closed"]
    parts = [d[cols] for d in (s2i, i2s) if not d.empty]
    if not parts:
        empty = pd.DataFrame(columns=["Number", "Requester", "Assigned to", "Assignment group", "State",
                                        "Reason", "LinkedTicket", "Direction", "Opened", "Closed"])
        return {
            "total_month": 0, "sctask_cancel_total": sctask_cancel_total, "inc_cancel_total": inc_cancel_total,
            "other_reasons": max(0, sctask_cancel_total + inc_cancel_total),
            "s2i_month": 0, "i2s_month": 0, "top_group_name": "\u2014", "top_group_count": 0,
            "mttr_month": 0.0, "max_delay_month": 0.0,
            "by_requester": ([], []), "by_group": ([], []), "by_analyst": ([], []),
            "history_labels": [], "history_values": [], "recent_rows": empty,
        }

    combined = pd.concat(parts, ignore_index=True)
    combined = combined.rename(columns={"Requester_norm": "Requester", "Reason_norm": "Reason"})

    ref_date = combined["Closed"].fillna(combined["Opened"])
    combined["AgingDays"] = ((combined["Closed"].fillna(ref) - combined["Opened"]).dt.total_seconds() / 86400).clip(lower=0)
    combined["IsMonth"] = (ref_date >= ini) & (ref_date < fim)
    combined["MonthKey"] = ref_date.dt.strftime("%Y-%m")
    combined["MonthLabel"] = ref_date.apply(lambda d: f"{MONTH_ABBR_EN[d.month]}/{d.year}")

    month = combined[combined["IsMonth"]]
    total_month = int(len(month))
    s2i_month = int((month["Direction"] == "SCTASK\u2192INC").sum())
    i2s_month = int((month["Direction"] == "INC\u2192SCTASK").sum())

    other_reasons = max(0, (sctask_cancel_total + inc_cancel_total) - total_month)

    if not month.empty:
        grp = month.groupby("Assignment group").size().sort_values(ascending=False)
        top_group_name, top_group_count = str(grp.index[0]), int(grp.iloc[0])
        mttr_month = round(float(month["AgingDays"].mean()), 2)
        max_delay_month = round(float(month["AgingDays"].max()), 2)
    else:
        top_group_name, top_group_count, mttr_month, max_delay_month = "\u2014", 0, 0.0, 0.0

    def _breakdown(col, top_n=8):
        if month.empty:
            return [], []
        vc = month[col].replace("", "N/A").value_counts().head(top_n)
        return list(vc.index), [int(v) for v in vc.values]

    by_requester = _breakdown("Requester")
    by_group = _breakdown("Assignment group")
    by_analyst = _breakdown("Assigned to")

    hist = combined.groupby(["MonthKey", "MonthLabel"]).size().reset_index(name="Count").sort_values("MonthKey")
    history_labels = list(hist["MonthLabel"])
    history_values = [int(v) for v in hist["Count"]]

    recent_rows = month.sort_values("AgingDays", ascending=False).head(config["CRITICAL_TABLE_COMPACT_ROWS"])

    return {
        "total_month": total_month, "sctask_cancel_total": sctask_cancel_total, "inc_cancel_total": inc_cancel_total,
        "other_reasons": other_reasons, "s2i_month": s2i_month, "i2s_month": i2s_month,
        "top_group_name": top_group_name, "top_group_count": top_group_count,
        "mttr_month": mttr_month, "max_delay_month": max_delay_month,
        "by_requester": by_requester, "by_group": by_group, "by_analyst": by_analyst,
        "history_labels": history_labels, "history_values": history_values,
        "recent_rows": recent_rows,
    }


SECONDARY_STATE_KEYWORDS = {"SCTASK": ["incomplete"], "INC": ["cancel"], "UAM": ["cancel"]}
SECONDARY_LABEL = {"SCTASK": "Closed Incomplete", "INC": "Canceled", "UAM": "Cancelled"}


def split_uam(df_sctask, config):
    """Splits SCTASK into (df_req, df_uam): UAM (User Access Management)
    tickets are identified by their "Item" field matching any of
    config["UAM_ITEM_KEYWORDS"] (case-insensitive substring match) and are
    reported completely separately from regular support REQs - they were
    previously being silently lumped together."""
    keywords = [k.lower() for k in config["UAM_ITEM_KEYWORDS"]]
    item_lower = df_sctask["Item"].astype(str).str.lower()
    is_uam = item_lower.apply(lambda i: any(k in i for k in keywords))
    df_req = df_sctask[~is_uam].copy()
    df_uam = df_sctask[is_uam].copy()
    return df_req, df_uam


def _classify_closed(df, closed_mask, secondary_keywords):
    """Splits the tickets closed under `closed_mask` into (resolved_count,
    secondary_count) based on their State text - e.g. a SCTASK closed as
    "Closed Incomplete" or an INC that was "Cancelled" both leave the open
    queue, but they are NOT a genuine resolution and are reported as a
    separate bar so that isn't hidden inside "Resolved"."""
    sub = df[closed_mask]
    if sub.empty:
        return 0, 0
    state_lower = sub["State"].astype(str).str.lower()
    pattern = "|".join(k.lower() for k in secondary_keywords)
    is_secondary = state_lower.str.contains(pattern, regex=True, na=False)
    return int((~is_secondary).sum()), int(is_secondary.sum())


def daily_flow_breakdown(df, ref, ticket_type, current_backlog):
    """Current-month, day-by-day: Opened / Resolved / Secondary (Closed
    Incomplete or Canceled) / accumulated Backlog.

    The backlog line is anchored to the REAL current open count
    (`current_backlog`) on the last day, then walked backward day by day
    subtracting each day's net flow - not summed forward from zero. Summing
    forward from zero silently assumes the backlog was 0 at the start of
    the month, which is essentially never true for a live queue that has
    been running for months; anchoring on the real, live count is what
    makes the curve match reality (e.g. starting at 61 in Feb instead of 0)."""
    ini, _ = month_bounds(ref)
    last_day = ref.day
    keywords = SECONDARY_STATE_KEYWORDS[ticket_type]
    rows, nets = [], []
    for d in range(1, last_day + 1):
        dt = ini + timedelta(days=d - 1)
        opened = int((df["Opened"].dt.normalize() == dt.normalize()).sum())
        closed_mask = df["Closed"].dt.normalize() == dt.normalize()
        resolved, secondary = _classify_closed(df, closed_mask, keywords)
        net = opened - resolved - secondary
        nets.append(net)
        rows.append({"Date": dt.strftime("%d/%m"), "Opened": opened, "Resolved": resolved,
                      "Secondary": secondary})
    _anchor_backlog(rows, nets, current_backlog)
    return pd.DataFrame(rows)


def monthly_flow_breakdown(df, ref, months_lookback, ticket_type, current_backlog):
    """Last N months: Opened / Resolved / Secondary / accumulated Backlog,
    anchored to the real current open count on the last month (see
    daily_flow_breakdown's docstring for why forward-summing from zero is
    wrong)."""
    keywords = SECONDARY_STATE_KEYWORDS[ticket_type]
    rows, nets = [], []
    for i in range(months_lookback - 1, -1, -1):
        ini, fim = month_bounds(ref, -i)
        opened = int(((df["Opened"] >= ini) & (df["Opened"] < fim)).sum())
        closed_mask = (df["Closed"] >= ini) & (df["Closed"] < fim)
        resolved, secondary = _classify_closed(df, closed_mask, keywords)
        net = opened - resolved - secondary
        nets.append(net)
        rows.append({"Month": f"{MONTH_ABBR_EN[ini.month]}/{ini.year}", "Opened": opened,
                      "Resolved": resolved, "Secondary": secondary})
    _anchor_backlog(rows, nets, current_backlog)
    return pd.DataFrame(rows)


def _anchor_backlog(rows, nets, current_backlog):
    """Fills rows[i]['BacklogAccum'] by anchoring the LAST period to the
    real, live open count and walking backward: backlog[k] = backlog[k+1]
    - net[k+1]. Mutates `rows` in place."""
    n = len(rows)
    if n == 0:
        return
    backlog = [0] * n
    backlog[-1] = current_backlog
    for i in range(n - 2, -1, -1):
        backlog[i] = backlog[i + 1] - nets[i + 1]
    for row, b in zip(rows, backlog):
        row["BacklogAccum"] = b


def top_requesters(conv_df, requester_col, top_n=10):
    if conv_df.empty or requester_col not in conv_df.columns:
        return [], []
    vc = conv_df[requester_col].replace("", "N/A").value_counts().head(top_n)
    return list(vc.index), [int(v) for v in vc.values]


# ---------------------------------------------------------------------------
# Problems (PRB) overview
# ---------------------------------------------------------------------------
def problems_overview(df_prb, ref, sla_days, top_n=5):
    ini, fim = month_bounds(ref)
    opened_month = int(((df_prb["Opened"] >= ini) & (df_prb["Opened"] < fim)).sum())
    closed_month = int(((df_prb["Closed"] >= ini) & (df_prb["Closed"] < fim)).sum())
    open_df = add_open_aging(df_prb, ref, sla_days)
    top_active = open_df.sort_values("AgingDays", ascending=False).head(top_n)
    priority_counts = df_prb["Priority"].value_counts()
    return {
        "opened_month": opened_month, "closed_month": closed_month,
        "open_total": int(df_prb["IsOpen"].sum()),
        "top_active": top_active[["Number", "Problem", "Assigned to", "Priority", "AgingDays"]].to_dict("records"),
        "priority_labels": list(priority_counts.index),
        "priority_values": [int(v) for v in priority_counts.values],
    }

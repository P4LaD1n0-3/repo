# IT Executive Dashboard (SCTASK x INC x PRB)

**v2 - visual redesign.** Same analytics as before, but the look now follows
the reference `relatorio_email.html` template exactly (soft color palette,
white cards with colored top borders, gradient section headers) instead of
the previous dark-navy "ELITE MASTER" chrome. SCTASK and INC each get their
own clearly color-coded section (blue vs red) with an identical structure,
so the two are easy to compare side by side. The old 25-row "critical
tickets" wall of text was replaced with a compact panel: 3 small stat cards
that surface the key numbers (how many, how old, the average) plus a short
6-row table — not a giant list.

A merge of your production "ELITE MASTER" dashboard (KPI cards, critical
aging tables, SLA breach charts, offender/conversion analysis, monthly
throughput tables with accumulated backlog) with the chart set from the
previous report (daily/weekly evolution, today-vs-yesterday, week-over-week).
Everything is in English and reads directly from the ServiceNow exports
`INC.xlsx` / `SCTASK.xlsx` / `PRB.xlsx`.

## Terminology mapping

Your legacy script used `REQ` / `INC` / `PTASK`. This ServiceNow export uses:

| Legacy name | This export | Meaning |
|---|---|---|
| REQ | **SCTASK** | Service catalog tasks / requests |
| INC | **INC** | Incidents |
| PTASK | **PRB** | Problems / problem tasks |

## Files

| File | Purpose |
|---|---|
| `config.py` | Paths, email settings, SLA targets, aging thresholds, windows |
| `data_loader.py` | Flexible column-matching loader for INC/SCTASK/PRB |
| `metrics.py` | Aging, SLA breach, backlog, monthly/daily throughput, conversions, rankings |
| `charts.py` | QuickChart.io URL builders (donut, pie, bar, dual-axis trend+backlog) |
| `report_builder.py` | Assembles the full HTML dashboard |
| `main.py` | Orchestrates everything and sends the e-mail via `smtp.py` |
| `smtp.py` | Your existing Outlook sender (Windows/Mac) — unchanged |

## How to run

1. Put `INC.xlsx`, `SCTASK.xlsx`, `PRB.xlsx` in this folder (or edit the
   paths in `config.py`).
2. Edit in `config.py`:
   - `EMAIL_TO` / `EMAIL_CC`
   - `SLA_DAYS` per ticket type (defaults: SCTASK=10, INC=7, PRB=10 — same
     numbers as your legacy `SLA_DAYS_REQS/INCS/PTASK`)
   - `CRITICAL_AGING_THRESHOLD` (defaults: SCTASK=20, INC=7, PRB=15)
   - `REFERENCE_DATE` — leave `None` in production
3. Run:
   ```bash
   pip install pandas openpyxl pywin32   # pywin32 only on Windows
   python main.py
   ```

## What's included (mapped to what you asked for)

**KPIs & critical call-outs**
- KPI cards: total open backlog, SCTASK open, INC open, PRB total/open,
  cross-type conversions, overall MTTR
- ⚠️ **Critical SCTASKs** (aging 20+ days, 30+ highlighted in red)
- ⚠️ **Critical INCs** (aging 7+ days) — new table, mirrors the SCTASK one

**Distribution & SLA**
- 1A/1B Top Analysts (SCTASK / INC) — donut charts
- SCTASK / INC — Inside vs Outside SLA — pie charts

**Status & Aging (bar charts)**
- 3A/3B Aging Detail (SCTASK / INC) — horizontal bars
- SCTASK / INC — Status of open tickets — horizontal bars
- Top Requesters (SCTASK → INC) and (INC → SCTASK) — current-month
  misclassification / cancellation offenders (see note below)

**Monthly & daily trend**
- 2A/2B Monthly Entry x Exit x Accumulated Backlog (dual-axis bar+line,
  SCTASK / INC)
- Daily Entry x Exit tracking for the current month, same dual-axis style
  with the backlog line (SCTASK / INC)
- Monthly Tracking Table (Opened x Resolved x Backlog) with totals row,
  for both SCTASK and INC (Throughput tables)

**Bonus sections** (kept from the previous report, since you asked for
"much more complete")
- Problems (PRB) overview: opened/resolved this month, priority mix,
  oldest open problems
- Today vs Yesterday comparison
- Current week vs previous week + weekly evolution chart

## About the offender/conversion detection

`SCTASK → INC` looks for SCTASKs closed as incomplete whose `Reason` field
mentions misclassification keywords (configurable in
`CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]`), then tries to extract a
referenced `INC` number from the close/work notes.

`INC → SCTASK` looks for cancelled incidents (`Close code` or `State`
containing "cancelled"/"canceled") and tries to extract a referenced
`SCTASK`/`RITM` number from the notes.

Both are **pattern-based on your free-text fields** — if your analysts
don't reference the linked ticket number in the notes, or don't use those
exact keywords, the tables will legitimately come back empty (shown as a
green "no data" message rather than an error). Adjust the keyword list and
regex prefixes in `metrics.py` (`_extract_ref`,
`sctask_to_inc_conversions`, `inc_to_sctask_conversions`) to match your
team's actual wording.

## Notes

- Charts use the public QuickChart.io API (same technique as your legacy
  dashboard) — the person opening the e-mail needs internet access to load
  the chart images.
- `smtp.py` was kept exactly as you provided it; `main.py` calls its
  `enviar_email_automatico(to, cc, subject, html_body)` function.
- `example_dashboard_report.html` in this package is a live preview built
  from test data, so you can see the visual before running it yourself.

## Cross-Type Conversions (SCTASK ↔ INC) — replicates "Classification Errors"

This section is a direct port of the "Classification Errors" tab logic from
your analytical dashboard (`index.html`), rebuilt for the static e-mail
report:

- **Detection is evidence-based, not just "cancelled".** A ticket only
  counts as a genuine misclassification when there's BOTH an abnormal
  closure (incomplete/cancelled/rejected) AND textual proof of it:
  - `SCTASK → INC`: State is incomplete/cancelled/rejected **and**
    `Reason` names a classification problem (keywords configurable in
    `CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]`). The linked `INC` number
    is extracted from the close/work notes when present.
  - `INC → SCTASK`: State is cancelled **and** the close/additional
    notes explicitly reference a `RITM`/`SCTASK` number (this mirrors the
    reference tool's `closeNotes.includes('RITM')` check) — a plain
    cancellation with no linked ticket is NOT counted as a reclassification.
- **Canceled Reconciliation panel**: shows the full universe of
  cancelled/incomplete tickets per type this month, how many of those were
  *confirmed* misclassifications, and how many were cancelled for some
  other reason ("Other Reasons") — so leadership can see what fraction
  of cancellations is actually a routing problem.
- **Both directions tracked explicitly** (`INC → SCTASK` and
  `SCTASK → INC` mini-KPIs), plus a historical monthly trend chart,
  Top Offending Group, Monthly MTTR (average correction time) and Maximum
  Delay — same insights as the reference tab's summary cards.
- **Breakdown tables** by Requester, by Group, by Analyst (current month)
  and a Historical Consolidated table (all months, with % of total).
- **Detailed list**: the most critical misclassified tickets this month
  (capped at `CRITICAL_TABLE_COMPACT_ROWS`, oldest first), with a note when
  there are more than shown.

Like the other offender detection in this report, this only surfaces
results when your analysts' `Reason`/close-notes wording actually matches
the configured keywords/patterns — adjust
`CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]` and the regex prefixes in
`metrics.py` (`sctask_misclassified`, `inc_reclassified`, `_extract_ref`)
to fit your team's real vocabulary.

## Fixes: broken chart images in Outlook + backlog-first focus

**1. Charts weren't rendering in Outlook (critical bug, now fixed).**
Complex dual-axis chart configs produced `<img src="https://quickchart.io/chart?...">`
URLs over 2000-2800 characters. Outlook's rendering engine (inherited from
Word) silently fails to load `<img>` tags past roughly that length — you'd
see all the numbers/tables but no chart images, exactly as reported.

Fix: `charts.py` now asks QuickChart to host each chart
(`POST /chart/create`) and embeds the short URL it returns
(`https://quickchart.io/chart/render/<id>`, well under 100 characters)
instead of the long GET URL. This requires internet access when you run
`main.py` (not at send time). If that request fails for any reason — offline,
timeout, QuickChart hiccup — it automatically falls back to the long GET
URL so the script never breaks; you'd just be back to the original bug for
that one chart. Toggle via `CONFIG["USE_SHORT_CHART_URLS"]` /
`CONFIG["SHORT_URL_TIMEOUT_SECONDS"]` in `config.py`.

**2. Responsiveness.** Added a viewport meta tag and strengthened the
`@media (max-width: 768px)` rules so cards, tables and chart images reflow
on narrower screens. Important caveat: **Outlook for Windows desktop
(the classic Word-based rendering engine) does not support CSS media
queries at all** — this is a long-standing Microsoft limitation, not
something fixable from the HTML/CSS side. The responsive layout *will*
work in Outlook Mobile (iOS/Android), Outlook for Mac, Outlook on the web,
and virtually every other modern mail client — just not the Windows
desktop app, which will always render the fixed desktop layout there.

**3. Backlog-first, current-month-only.** This report is a day-to-day
operations snapshot, so:
- Every headline KPI (Overview, and each SCTASK/INC section) is now the
  **live open backlog** — never an all-time count of closed tickets.
- Wherever a resolved/closed number does appear (Opened/Resolved this
  month, MTTR, the Classification Errors KPIs), it is strictly scoped to
  the **current month** via `metrics.current_month_flow()` /
  `metrics.mttr_days_month()` — never blended with older history.
- Removed the two sections that showed a rolling 6-month history
  (*Monthly Evolution & Trend* and the combined *Monthly Tracking Table*),
  since a multi-month resolved-ticket trend doesn't belong in a
  current-month operations report. The *Daily Evolution by Ticket Type*
  section (day-by-day, current month only) remains as the trend view.
- Classification Errors dropped its historical trend chart and
  all-time "Historical Consolidated" table for the same reason; the
  reconciliation panel, direction cards, KPI cards and breakdown tables
  were already current-month-scoped and are unchanged.

## "Ainda não funcionou" — how to actually pin down the cause

If you ran the updated script and the e-mail still looks unchanged (same
numbers, no charts), it's almost certainly one of these three things, in
order of likelihood:

**1. The e-mail you're looking at wasn't regenerated.**
Every run of `main.py` builds a brand-new e-mail and sends it as a new
message — it can never edit an e-mail already sitting in your inbox. If
you're re-opening an old message from an earlier test, of course nothing
changed. Fix: run `python main.py` again, and check the **subject line**
of the new e-mail — it now ends with a build tag like
`[2026-07-backlog-focus-inline-charts]`. If the e-mail you're looking at
doesn't have that tag, it's not from this version.

**2. Not all files were replaced, so old code is still running.**
The console banner now prints `(build: 2026-07-backlog-focus-inline-charts)`
on the very first line. If your terminal doesn't show that exact string
when you run `python main.py`, you're running stale `.py` files — replace
the **entire folder**, not individual files, and delete any `__pycache__`
folder next to the scripts before re-running.

**3. QuickChart isn't reachable from the machine that runs `main.py`.**
This is the most likely real fix needed. Read the new
**"[3/5] Chart image delivery summary"** the console prints after every
run:
- `X embedded inline (base64)` — these charts are bulletproof; they will
  show up in Outlook no matter what.
- `X via long GET URL` — if this is where ALL your charts land, this
  machine could not reach `https://quickchart.io` (corporate proxy,
  firewall, no internet) when `main.py` ran. That's independent of
  Outlook entirely — fixing internet/proxy access to quickchart.io on the
  machine that *generates* the report is what fixes this, not anything in
  Outlook's settings.

**Also worth checking directly in Outlook**, since it's a very common and
completely unrelated cause of "I see numbers but no pictures": Outlook
blocks automatically downloading external images by default in many
corporate configurations, and shows a bar like *"Content blocked. Click
here to download pictures."* at the top of the e-mail. If you see that bar
and haven't clicked it, that alone explains missing images — regardless of
anything in this script. With `EMBED_CHARTS_AS_BASE64` charts (base64
delivery, item 1 above), this doesn't apply, because there's no external
image to block in the first place — it's already inline in the HTML.

**Fastest way to isolate it yourself:** open the local file at
`CONFIG["OUTPUT_HTML"]` (path printed in `[4/5]`) directly in Chrome/Edge.
If the charts show up there, the issue is 100% on the Outlook/e-mail side,
not in this script. If they don't show up there either, it's a
chart-generation problem on this machine — check step 3 above.

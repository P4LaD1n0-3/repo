# -*- coding: utf-8 -*-
"""
Problem Management data model (RCA / PCA / KB gaps) for the IT Executive
Dashboard - "three-source" model ported from the reference `nova_sessao.py`
script (its final `juntar_tres_bases()` / `aplicar_metricas_integradas()`):

    problem.xlsx        Number = master PRB universe + Problem-level attributes
    problem_task.xlsx    first "Number" column = PRB, second "Number" = PTASK
    kb_knowledge.xlsx    Source task = PRB, Number/Short description = article

Only PRB (Problem.Number = the first Number in problem_task.xlsx = Source task
in kb_knowledge.xlsx) is used as the join key - no other cross-reference.

This module is pure data logic (readers + join + KPIs), no HTML - kept fully
independent of `data_loader.load_prb()` / `CONFIG["PRB_PATH"]`, which stay
wired exactly as they were (still feed the Analyst Comparison report and the
legacy flat "PRB" ticket type). Nothing here reads or mutates that pipeline,
so the new problem.xlsx/kb_knowledge.xlsx files never interfere with it.
"""
import os
import unicodedata
from datetime import date, datetime

from openpyxl import load_workbook

GRUPOS_INVEST = {"ebao-brazil", "portal corretor"}
RCA_OVERDUE_LIMIT_DAYS = 28

# "Resolved" is intentionally excluded here - a Resolved problem still counts
# as active (matches nova_sessao.py's final _problema_ativo() rule).
ESTADOS_FECHADOS = {
    "closed", "closed complete", "closed incomplete", "closed skipped",
    "cancelled", "canceled", "fechado", "fechada", "concluido", "concluida",
    "encerrado", "encerrada", "cancelado", "cancelada", "finalizado", "finalizada",
}
ESTADOS_FECHADOS_TASK = {
    "closed", "closed complete", "closed incomplete", "closed skipped",
    "cancelled", "canceled", "fechado", "concluido", "encerrado", "cancelado", "finalizado",
}


def _texto(valor):
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        return str(int(valor))
    return str(valor).strip()


def _normalizar(valor):
    if valor is None:
        return ""
    s = str(valor).strip().lower()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return " ".join(s.split())


def _normalize_prb(valor):
    candidate = _texto(valor).upper().replace(" ", "")
    if candidate.startswith("PRB") and candidate[3:].isdigit():
        return candidate
    return ""


def _inteiro(valor):
    if valor is None or valor == "":
        return 0
    if isinstance(valor, bool):
        return 0
    if isinstance(valor, (int, float)):
        return int(round(valor))
    try:
        s = str(valor).strip()
        if not s:
            return 0
        if "," in s and "." in s:
            s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
        elif "," in s:
            s = s.replace(",", ".")
        return int(round(float(s)))
    except (TypeError, ValueError):
        return 0


def _eh_publicado(valor):
    return _normalizar(valor) in {"published", "publicado", "publicada"}


def _para_data(valor):
    if valor is None or _texto(valor) == "":
        return None
    if isinstance(valor, datetime):
        return valor.date()
    if isinstance(valor, date):
        return valor
    bruto = _texto(valor).replace("T", " ").replace("Z", "")
    for fmt in ("%d/%m/%Y", "%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%Y-%m-%d",
                "%Y-%m-%d %H:%M:%S", "%m/%d/%Y", "%m/%d/%Y %H:%M:%S"):
        try:
            return datetime.strptime(bruto, fmt).date()
        except ValueError:
            pass
    return None


def _first_sheet_rows(caminho):
    try:
        workbook = load_workbook(caminho, data_only=True, read_only=True)
    except Exception:
        return []
    try:
        worksheet = workbook[workbook.sheetnames[0]]
        return [list(row) for row in worksheet.iter_rows(values_only=True)]
    finally:
        workbook.close()


def _find_header_row(rows, required_headers, max_rows=30):
    required = [_normalizar(item) for item in required_headers]
    for index, row in enumerate(rows[:max_rows]):
        normalized = [_normalizar(value) for value in row]
        if all(item in normalized for item in required):
            return index, normalized
    return None, []


def _value_at(row, index):
    if index is None or index < 0 or index >= len(row):
        return ""
    return row[index]


def _read_problem_master(path):
    """problem.xlsx: Number, Short description, Assignment group, State,
    Opened by, Assigned to, Opened, Closed, Related Incidents, RCA Status,
    RCA Owning Group, RCA Due Date, RCA Published Date."""
    if not path or not os.path.isfile(path):
        return []
    rows = _first_sheet_rows(path)
    header_index, header = _find_header_row(
        rows, ["Number", "Short description", "Assignment group", "RCA Status"])
    if header_index is None:
        return []
    aliases = {
        "Problem.Number": ["number"],
        "Problem.Short description": ["short description"],
        "Problem.Assignment group": ["assignment group"],
        "Problem.State": ["state"],
        "Problem.Opened by": ["opened by"],
        "Problem.Assigned to": ["assigned to"],
        "Problem.Opened": ["opened"],
        "Problem.Closed": ["closed"],
        "Problem.Related Incidents": ["related incidents"],
        "Problem.RCA Status": ["rca status"],
        "Problem.RCA Owning Group": ["rca owning group"],
        "Problem.RCA Due Date": ["rca due date"],
        "Problem.RCA Published Date": ["rca published date"],
    }
    positions = {}
    for canonical, names in aliases.items():
        for name in names:
            normalized_name = _normalizar(name)
            if normalized_name in header:
                positions[canonical] = header.index(normalized_name)
                break
    records, seen = [], set()
    for row in rows[header_index + 1:]:
        prb = _normalize_prb(_value_at(row, positions.get("Problem.Number")))
        if not prb or prb in seen:
            continue
        seen.add(prb)
        record = {canonical: _value_at(row, position) for canonical, position in positions.items()}
        record["Problem.Number"] = prb
        records.append(record)
    return records


def _read_problem_task(path):
    """problem_task.xlsx: TWO "Number" columns (1st = PRB, 2nd = PTASK),
    followed by Assignment group / State / Opened by / Assigned to / Opened /
    Closed for the task. Disambiguated by POSITION - both Number columns
    share the exact same header text."""
    if not path or not os.path.isfile(path):
        return []
    rows = _first_sheet_rows(path)
    header_index, header = None, None
    for index, row in enumerate(rows[:30]):
        normalized = [_normalizar(value) for value in row]
        number_positions = [i for i, value in enumerate(normalized) if value in ("number", "numero")]
        if len(number_positions) >= 2 and "assignment group" in normalized:
            header_index, header = index, normalized
            break
    if header_index is None:
        return []
    number_positions = [i for i, value in enumerate(header) if value in ("number", "numero")]
    prb_position, task_position = number_positions[0], number_positions[1]
    after_task = list(range(task_position + 1, len(header)))

    def after(label):
        target = _normalizar(label)
        return next((i for i in after_task if header[i] == target), None)

    positions = {
        "PTASK.Number": task_position,
        "PTASK.Assignment group": after("Assignment group"),
        "PTASK.State": after("State"),
        "PTASK.Opened by": after("Opened by"),
        "PTASK.Assigned to": after("Assigned to"),
        "PTASK.Opened": after("Opened"),
        "PTASK.Closed": after("Closed"),
    }
    records = []
    for row in rows[header_index + 1:]:
        prb = _normalize_prb(_value_at(row, prb_position))
        task_number = _texto(_value_at(row, task_position)).upper()
        if not prb or not task_number:
            continue
        record = {"Problem.Number": prb}
        for canonical, position in positions.items():
            record[canonical] = _value_at(row, position)
        records.append(record)
    return records


def _read_kb(path):
    """kb_knowledge.xlsx: Source task, Number, Short description."""
    if not path or not os.path.isfile(path):
        return []
    rows = _first_sheet_rows(path)
    header_index, header = _find_header_row(rows, ["Source task", "Number", "Short description"])
    if header_index is None:
        return []
    positions = {
        "Source task": header.index(_normalizar("Source task")),
        "Number": header.index(_normalizar("Number")),
        "Short description": header.index(_normalizar("Short description")),
    }
    records = []
    for row in rows[header_index + 1:]:
        prb = _normalize_prb(_value_at(row, positions["Source task"]))
        if not prb:
            continue
        records.append({
            "Source task": prb,
            "Number": _value_at(row, positions["Number"]),
            "Short description": _value_at(row, positions["Short description"]),
        })
    return records


def _problema_ativo(reg):
    estado = _normalizar(reg.get("Problem.State"))
    if estado in {"resolved", "resolvido", "resolvida"}:
        return True
    if _texto(reg.get("Problem.Closed")):
        return False
    if not estado:
        return True
    return not any(f == estado or f in estado for f in ESTADOS_FECHADOS)


def _task_is_open(task):
    if _texto(task.get("PTASK.Closed")):
        return False
    estado = _normalizar(task.get("PTASK.State"))
    if not estado:
        return bool(_texto(task.get("PTASK.Number")))
    return estado not in ESTADOS_FECHADOS_TASK


def _ptask_sort_key(task):
    opened = _para_data(task.get("PTASK.Opened"))
    return (opened is None, opened or date.max, _texto(task.get("PTASK.Number")))


def _marcos_do_problema(reg):
    """The 6 problem-management milestones (English labels, this report is
    fully English): RCA created/published/completed, PCA created, KB
    published, Incident linked."""
    tem_rca, tem_pca, tem_inc = not reg["_sem_rca"], not reg["_sem_pca"], not reg["_sem_inc"]
    return [
        ("RCA created", tem_rca),
        ("RCA published", tem_rca and not reg["_rca_nao_publicada"]),
        ("RCA completed", tem_rca and not reg["_rca_incompleta"]),
        ("PCA created", tem_pca),
        ("KB published", not reg["_sem_kb"]),
        ("Incident linked", tem_inc),
    ]


def build_three_source_model(problem_path, problem_task_path, kb_path, referencia):
    """Reads and joins the 3 sources. Returns (unificado, indicators,
    analyst_summary, disposition). All empty when problem.xlsx can't be read
    (missing file, or no recognizable header) - callers should skip the
    section entirely in that case rather than show an empty shell."""
    linhas_problem = _read_problem_master(problem_path)
    if not linhas_problem:
        return [], {}, [], {}

    linhas_tasks = _read_problem_task(problem_task_path)
    linhas_kb = _read_kb(kb_path)

    problem_by_prb = {}
    for item in linhas_problem:
        prb = _normalize_prb(item.get("Problem.Number"))
        if prb and prb not in problem_by_prb:
            problem_by_prb[prb] = item

    tasks_by_prb = {}
    for task in linhas_tasks:
        prb = _normalize_prb(task.get("Problem.Number"))
        if prb:
            tasks_by_prb.setdefault(prb, []).append(task)
    for prb in tasks_by_prb:
        tasks_by_prb[prb].sort(key=_ptask_sort_key)

    kb_by_prb = {}
    for article in linhas_kb:
        prb = _normalize_prb(article.get("Source task"))
        if prb and prb not in kb_by_prb:
            kb_by_prb[prb] = article

    unificado = []
    for prb, problem in problem_by_prb.items():
        artigo = kb_by_prb.get(prb)
        reg = {
            "Problem": prb, "Problem.Number": prb,
            "Problem.Short description": _texto(problem.get("Problem.Short description")),
            "Problem.Assignment group": _texto(problem.get("Problem.Assignment group")),
            "Problem.State": _texto(problem.get("Problem.State")),
            "Opened by": _texto(problem.get("Problem.Opened by")) or "(unassigned)",
            "Problem.Assigned to": _texto(problem.get("Problem.Assigned to")),
            "Problem.Opened": problem.get("Problem.Opened"),
            "Problem.Closed": problem.get("Problem.Closed"),
            "Problem.Related Incidents": _inteiro(problem.get("Problem.Related Incidents")),
            "Problem.Number (KB)": _texto(artigo.get("Number")) if artigo else "",
            "Problem.RCA Status": _texto(problem.get("Problem.RCA Status")),
            "Problem.RCA Owning Group": _texto(problem.get("Problem.RCA Owning Group")),
            "Problem.RCA Due Date": problem.get("Problem.RCA Due Date"),
            "Problem.RCA Published Date": problem.get("Problem.RCA Published Date"),
            "_sem_kb": artigo is None,
        }
        reg["_sem_inc"] = reg["Problem.Related Incidents"] == 0
        reg["App Disposition"] = "Invest" if _normalizar(reg["Problem.Assignment group"]) in GRUPOS_INVEST else "Maintain"
        reg["_ativo"] = _problema_ativo(reg)
        unificado.append(reg)

    # Integrated RCA/PCA proxy metrics: problem_task.xlsx has no task-type
    # column, so - same fix as nova_sessao.py's aplicar_metricas_integradas() -
    # PTASKs are sorted by Opened date per PRB; the earliest is the RCA-stage
    # proxy, the rest are PCA-stage proxies.
    for reg in unificado:
        prb = reg["Problem.Number"]
        tasks = tasks_by_prb.get(prb, [])
        rca_proxy, pca_proxy = tasks[:1], tasks[1:]
        has_rca_control = any(_texto(reg.get(f)) for f in (
            "Problem.RCA Status", "Problem.RCA Due Date",
            "Problem.RCA Published Date", "Problem.RCA Owning Group")) or bool(rca_proxy)
        reg["_sem_rca"] = not has_rca_control
        reg["_rca_nao_publicada"] = not _eh_publicado(reg.get("Problem.RCA Status"))
        reg["_rca_incompleta"] = (
            _normalizar(reg.get("Problem.RCA Status")) == "in progress"
            or any(_task_is_open(t) for t in rca_proxy)
        )
        reg["_sem_pca"] = not bool(pca_proxy)
        reg["_pca_ativo"] = any(_task_is_open(t) for t in pca_proxy)

        marcos = _marcos_do_problema(reg)
        completed = sum(1 for _, ok in marcos if ok)
        reg["Milestones"] = f"{completed}/{len(marcos)}"
        faltando = [label for label, ok in marcos if not ok]
        reg["Pending"] = "; ".join(faltando) if faltando else "None (Complete)"

        opened = _para_data(reg.get("Problem.Opened"))
        problem_aging = None
        if opened:
            fim = _para_data(reg.get("Problem.Closed")) or referencia
            problem_aging = max((fim - opened).days, 0)
        reg["Problem Aging (days)"] = problem_aging

        published = _para_data(reg.get("Problem.RCA Published Date"))
        reg["RCA Aging (days)"] = max((referencia - published).days, 0) if published else None

    indicators = _calcular_indicadores(unificado)
    analyst_summary = _resumo_por_analista(unificado)
    disposition = _calcular_app_disposition(unificado)
    return unificado, indicators, analyst_summary, disposition


def _calcular_indicadores(unificado):
    total = len(unificado)
    no_gaps = sum(
        1 for r in unificado
        if not r["_sem_rca"] and not r["_rca_nao_publicada"] and not r["_rca_incompleta"]
        and not r["_sem_pca"] and not r["_sem_kb"] and not r["_sem_inc"]
    )
    return {
        "problems": total,
        "analysts": len({r["Opened by"] for r in unificado}),
        "incidents": sum(r["Problem.Related Incidents"] for r in unificado),
        "missing_rca": sum(1 for r in unificado if r["_sem_rca"]),
        "rca_not_published": sum(1 for r in unificado if r["_rca_nao_publicada"]),
        "rca_incomplete": sum(1 for r in unificado if r["_rca_incompleta"]),
        "missing_pca": sum(1 for r in unificado if r["_sem_pca"]),
        "pca_in_progress": sum(1 for r in unificado if r["_pca_ativo"]),
        "missing_kb": sum(1 for r in unificado if r["_sem_kb"]),
        "missing_inc": sum(1 for r in unificado if r["_sem_inc"]),
        "no_gaps": no_gaps,
        "with_gaps": total - no_gaps,
    }


def _resumo_por_analista(unificado):
    mapa = {}
    for reg in unificado:
        analista = reg["Opened by"]
        linha = mapa.setdefault(analista, {
            "analyst": analista, "problems": 0, "rca_not_published": 0, "missing_kb": 0,
            "missing_pca": 0, "missing_rca": 0, "rca_incomplete": 0, "missing_inc": 0,
        })
        linha["problems"] += 1
        linha["rca_not_published"] += int(reg["_rca_nao_publicada"])
        linha["missing_kb"] += int(reg["_sem_kb"])
        linha["missing_pca"] += int(reg["_sem_pca"])
        linha["missing_rca"] += int(reg["_sem_rca"])
        linha["rca_incomplete"] += int(reg["_rca_incompleta"])
        linha["missing_inc"] += int(reg["_sem_inc"])
    resumo = list(mapa.values())
    resumo.sort(key=lambda x: (-x["problems"], x["analyst"]))
    return resumo


def _calcular_app_disposition(unificado):
    def vazio():
        return {"problems": 0, "active_problems": 0, "missing_rca": 0, "rca_within_28": 0, "rca_overdue": 0}

    resultado = {"Invest": vazio(), "Maintain": vazio()}
    for reg in unificado:
        metricas = resultado[reg["App Disposition"]]
        metricas["problems"] += 1
        if reg["_ativo"]:
            metricas["active_problems"] += 1
        if reg["_sem_rca"]:
            metricas["missing_rca"] += 1
        aging = reg.get("RCA Aging (days)")
        if aging is not None:
            if aging > RCA_OVERDUE_LIMIT_DAYS:
                metricas["rca_overdue"] += 1
            else:
                metricas["rca_within_28"] += 1

    total = vazio()
    for disposition in ("Invest", "Maintain"):
        for chave in total:
            total[chave] += resultado[disposition][chave]
    resultado["Total"] = total
    return resultado


def pending_by_analyst(unificado):
    """One entry per analyst, each holding the problems that still have an
    open milestone - ports nova_sessao.py's `pendencias_por_analista()`
    (same grouping the reference dashboard's "Problems With Pending
    Milestones" chip list uses). Returns
    [(analyst, [(problem, completed, total_milestones, [missing_labels]), ...]), ...],
    sorted by analyst (case-insensitive); each analyst's own list is sorted
    by fewest milestones completed first, then by problem number."""
    por_analista = {}
    for reg in unificado:
        marcos = _marcos_do_problema(reg)
        completed = sum(1 for _, ok in marcos if ok)
        if completed >= len(marcos):
            continue
        faltando = [label for label, ok in marcos if not ok]
        por_analista.setdefault(reg["Opened by"], []).append(
            (reg["Problem"], completed, len(marcos), faltando))
    for itens in por_analista.values():
        itens.sort(key=lambda item: (item[1], item[0]))
    return sorted(por_analista.items(), key=lambda par: par[0].lower())

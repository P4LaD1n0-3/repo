from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(100), default="Operacional")
    servicenow_name = db.Column(db.String(150), nullable=True)
    signature_name = db.Column(db.String(150), nullable=True)
    pinned_modules = db.Column(db.Text, nullable=True, default='["portal_task"]')

    @property
    def pinned_list(self):
        """Retorna a lista de chaves de módulos pino como lista Python"""
        import json
        try:
            if self.pinned_modules:
                return json.loads(self.pinned_modules)
        except Exception:
            pass
        return ["portal_task"]


    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def display_servicenow_name(self):
        return self.servicenow_name or self.full_name

    @property
    def display_signature_name(self):
        return self.signature_name or self.full_name


    @property
    def short_name(self):
        """Retorna o primeiro e último nome ou nome resumido (ex: Wesley Simões)"""
        parts = self.full_name.split()
        if len(parts) > 1:
            return f"{parts[0]} {parts[-1]}"
        return self.full_name

    @property
    def initials(self):
        """Retorna as iniciais do usuário para o avatar (ex: WS)"""
        parts = self.full_name.split()
        if len(parts) >= 2:
            return f"{parts[0][0]}{parts[-1][0]}".upper()
        elif len(parts) == 1 and len(parts[0]) > 0:
            return parts[0][0:2].upper()
        return "US"


class PortalTaskConfig(db.Model):
    """
    Tabela exclusiva para persistência de configurações, URLs e caminhos do módulo Portal Task.
    """
    __tablename__ = 'portal_task_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    url_cadastrar = db.Column(db.Text, nullable=True, default="")
    url_reset_senha = db.Column(db.Text, nullable=True, default="")
    url_reset_mfa = db.Column(db.Text, nullable=True, default="")
    url_encerrar = db.Column(db.Text, nullable=True, default="")
    url_desabilitar = db.Column(db.Text, nullable=True, default="")


    output_format = db.Column(db.String(50), nullable=True, default="excel")
    output_directory = db.Column(db.Text, nullable=True, default="C:\\Users\\wsimoes\\Downloads\\PortalTasks")
    headless = db.Column(db.Boolean, default=True)

    # Opções de Automação & Campos do Modal 'Alterar usuário'
    automation_action = db.Column(db.String(100), nullable=True, default="Cadastro de usuário")
    alt_is_assessoria = db.Column(db.Boolean, default=True)
    alt_de_email = db.Column(db.String(255), nullable=True)
    alt_de_ritm = db.Column(db.String(100), nullable=True, default="RITM0000000")
    alt_para_email = db.Column(db.String(255), nullable=True)
    alt_para_cnpj = db.Column(db.String(50), nullable=True, default="00.000.000/0001-00")
    alt_para_nome = db.Column(db.String(255), nullable=True)
    alt_para_produto_id = db.Column(db.String(100), nullable=True)

    user = db.relationship('User', backref=db.backref('portal_config', uselist=False))


    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class EmailReportConfig(db.Model):
    """
    Tabela para persistência das configurações dos 2 reportes de e-mail (Dashboard Executive e Analyst Comparison),
    seleção de região (BRAZIL / MEX) e opções de relatórios automatizados do usuário.
    """
    __tablename__ = 'email_report_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    selected_region = db.Column(db.String(50), nullable=True, default="BRAZIL")
    
    # 4 Campos para Configuração de E-mail do Reporte 1: Dashboard Executive (Brasil e México)
    # Sem endereço padrão de fábrica - cada usuário configura os próprios destinatários
    # reais no modal antes do primeiro envio (ver email_report.html / routes.py).
    brazil_to = db.Column(db.Text, nullable=True, default="")
    brazil_cc = db.Column(db.Text, nullable=True, default="")
    mex_to = db.Column(db.Text, nullable=True, default="")
    mex_cc = db.Column(db.Text, nullable=True, default="")
    subject_prefix = db.Column(db.String(200), nullable=True, default="IT Dashboard - REQ x INC x PRB")
    send_email_enabled = db.Column(db.Boolean, default=True)

    # Campos para Configuração de E-mail do Reporte 2: Analyst Comparison Report
    analyst_to = db.Column(db.Text, nullable=True, default="")
    analyst_cc = db.Column(db.Text, nullable=True, default="")
    analyst_subject_prefix = db.Column(db.String(200), nullable=True, default="IT Analyst Performance Comparison - Dashboard")
    analyst_send_email_enabled = db.Column(db.Boolean, default=True)

    output_directory = db.Column(db.Text, nullable=True, default="C:\\Users\\wsimoes\\Downloads\\ReportExports")

    user = db.relationship('User', backref=db.backref('email_report_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração de e-mail do usuário ou cria uma nova com valores padrão."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class ReleaseTaskConfig(db.Model):
    """
    Tabela exclusiva para persistência de dados e configurações do formulário Release task.
    """
    __tablename__ = 'release_task_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    assigned_to_ebao = db.Column(db.String(150), nullable=True, default="")
    assigned_to_portal = db.Column(db.String(150), nullable=True, default="")
    assigned_to_dba = db.Column(db.String(150), nullable=True, default="")
    copy = db.Column(db.String(150), nullable=True, default="")

    # NOMES (não e-mails) preenchidos nos campos de referência "Assigned to" do ServiceNow
    # ao ABRIR a Release/Change - antes fixos no código-fonte legado ("Mauricio Murakami"
    # para a Release, "Wellington Da Silva" para a Change), agora configuráveis na tela.
    # Distintos de 'assigned_to_dba' (usado apenas no fluxo de ENCERRAMENTO/ctask).
    release_assigned_to_name = db.Column(db.String(150), nullable=True, default="Mauricio Murakami")
    change_assigned_to_name = db.Column(db.String(150), nullable=True, default="Wellington Da Silva")

    open_time = db.Column(db.String(50), nullable=True, default="")
    release_number = db.Column(db.String(100), nullable=True, default="")

    choice = db.Column(db.String(50), nullable=True, default="Ebao")
    # Vazios por padrão de propósito: "RLESE00000"/"CHG0000000" existem apenas como
    # placeholder visual no HTML (atributo placeholder). Se fossem o valor REAL salvo,
    # o backend interpretaria como "RLESE e CHG preenchidos" e disparia o e-mail de
    # aprovação manual sem o usuário ter digitado nada.
    rlese = db.Column(db.String(100), nullable=True, default="")
    chg = db.Column(db.String(100), nullable=True, default="")

    # URLs de origem (favoritos/lista) usadas para abrir uma nova Release por ambiente.
    # Se vazias, o backend cai no padrão direto rm_release.do?sys_id=-1 (novo registro).
    ebao_link = db.Column(db.String(500), nullable=True, default="")
    portal_link = db.Column(db.String(500), nullable=True, default="")

    # Configuration Item usado ao criar a Release/Change de cada ambiente - antes fixo
    # no código ("EBAO-BRAZIL-Production" / "Portal Corretor-Production"), agora dinâmico.
    ebao_configuration_item = db.Column(db.String(150), nullable=True, default="EBAO-BRAZIL-Production")
    portal_configuration_item = db.Column(db.String(150), nullable=True, default="Portal Corretor-Production")

    # Horário (HH:MM:SS) usado no planned_start_date (abertura) e no planned_end_date/due_date
    # (fechamento) da Release/Change - antes fixo em "12:00:02" no código, agora dinâmico.
    open_hour = db.Column(db.String(20), nullable=True, default="12:00:02")
    close_hour = db.Column(db.String(20), nullable=True, default="12:00:02")

    user = db.relationship('User', backref=db.backref('release_task_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração de Release task do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class SendDmlConfig(db.Model):
    """
    Tabela exclusiva para persistência de dados e configurações do formulário Send dml
    (equivalente ao 'sendmail_exemplo/mail_sender.txt' + 'mail.html' do legado).
    """
    __tablename__ = 'send_dml_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    # Últimos valores usados no formulário (reaproveitados como default na próxima visita).
    change = db.Column(db.String(100), nullable=True, default="")
    ritm = db.Column(db.String(100), nullable=True, default="")
    send_to = db.Column(db.String(255), nullable=True, default="")
    copia = db.Column(db.String(255), nullable=True, default="")

    # Configuração do "puxar Change" (modal de engrenagem) - qual ambiente (EBAO/PORTAL) e,
    # opcionalmente, qual caixa de e-mail (Outlook) monitorar ao buscar o e-mail de
    # aprovação do dia (ver dml_change_finder.buscar_change_do_dia).
    change_monitor_ambiente = db.Column(db.String(20), nullable=True, default="EBAO")
    change_monitor_mailbox = db.Column(db.String(255), nullable=True, default="")

    user = db.relationship('User', backref=db.backref('send_dml_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração de Send dml do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class ServiceNowExportConfig(db.Model):
    """
    Configuração GLOBAL (não por usuário - linha única, id=1) das URLs de
    exportação (.xlsx) do ServiceNow por região (SCTASK/INC/KB/PROBLEM_TASK/
    PROBLEM x MEX/BRAZIL). Compartilhada por qualquer tela que precise baixar
    essas planilhas automaticamente (Dashboard hoje - ver
    src/modules/dash/routes.py e src/modules/system/routes.py -, Email Report
    no futuro), por isso não segue o padrão 'user_id' das demais *Config: é a
    mesma fila/relatório para o sistema todo, não uma preferência pessoal de
    cada analista.

    KB/PROBLEM_TASK/PROBLEM substituem o antigo PRB único (mex_prb_url/
    brazil_prb_url, removidos) - passam a alimentar a futura seção PROBLEM do
    Executive Dashboard (ver src/modules/email_report/report_builder.py),
    baseada no cruzamento Problem.Number = Source task de 'nova_sessao.py'.
    Atenção: a aba PRB/RCA do dashboard AO VIVO (src/modules/dash/index.html)
    dependia do antigo problem_task.xlsx (schema rico com RCA Status/Due
    Date/Published Date) - com essa troca, ela fica sem fonte de dado até ser
    adaptada para os 3 arquivos novos.
    """
    __tablename__ = 'servicenow_export_configs'

    id = db.Column(db.Integer, primary_key=True)

    selected_region = db.Column(db.String(50), nullable=True, default="MEX")

    # Visitada ANTES das URLs de exportação (.xlsx) para validar/renovar a sessão Okta -
    # os links de export por si só nem sempre disparam o fluxo de login corretamente;
    # uma URL "normal" do ServiceNow (ex.: a home ou o app do Okta) valida certo.
    validation_url = db.Column(db.Text, nullable=True, default="")

    mex_sctask_url = db.Column(db.Text, nullable=True, default="")
    mex_inc_url = db.Column(db.Text, nullable=True, default="")
    mex_kb_url = db.Column(db.Text, nullable=True, default="")
    mex_problem_task_url = db.Column(db.Text, nullable=True, default="")
    mex_problem_url = db.Column(db.Text, nullable=True, default="")

    brazil_sctask_url = db.Column(db.Text, nullable=True, default="")
    brazil_inc_url = db.Column(db.Text, nullable=True, default="")
    brazil_kb_url = db.Column(db.Text, nullable=True, default="")
    brazil_problem_task_url = db.Column(db.Text, nullable=True, default="")
    brazil_problem_url = db.Column(db.Text, nullable=True, default="")

    # Pasta de destino ESCOLHIDA PELO USUÁRIO para os 5 xlsx baixados (SCTASK/INC/
    # KB/PROBLEM_TASK/PROBLEM). Quando preenchida, '/system/servicenow_export/download'
    # baixa SOMENTE aqui (não mais em 'path_temp', que é compartilhada com outros
    # módulos) e '/dash/auto_data' passa a ler daqui também - mesmo local em todo o
    # ciclo baixar->abrir com dados. Vazio = comportamento anterior (path_temp), só
    # como fallback antes de configurar.
    output_directory = db.Column(db.Text, nullable=True, default="")

    @classmethod
    def get_or_create(cls):
        """Busca a configuração global (id=1) ou cria uma nova com valores padrão se não existir."""
        config = db.session.get(cls, 1)
        if not config:
            config = cls(id=1)
            db.session.add(config)
            db.session.commit()
        return config


class CtaskAprovacaoConfig(db.Model):
    """
    Config POR USUÁRIO (mesmo padrão de PortalTaskConfig) da tela 'Create ctask':
    Grupo de Atribuição e Assigned to usados ao criar a CTASK no ServiceNow.
    """
    __tablename__ = 'ctask_aprovacao_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    assignment_group = db.Column(db.String(150), nullable=True, default="AIG-PT-BR-DBA-SRV")
    assigned_to = db.Column(db.String(150), nullable=True, default="")

    user = db.relationship('User', backref=db.backref('ctask_aprovacao_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class CtaskAprovacao(db.Model):
    """
    Histórico/fila GLOBAL (não por usuário - mesmo espírito de
    ServiceNowExportConfig) de aprovações de Change enviadas pela tela Feature
    Release (ver 'release_task.routes._executar_envio_email_manual', que
    insere 1 linha aqui logo após o envio bem-sucedido do e-mail de aprovação)
    e processadas pela tela 'Create ctask' (ver 'create_ctask.routes').
    """
    __tablename__ = 'ctask_aprovacoes'

    id = db.Column(db.Integer, primary_key=True)

    rlse_number = db.Column(db.String(20), nullable=False)
    chg_number = db.Column(db.String(20), nullable=False)
    # Preenchido só para aprovações vindas do Send dml (INC/SCTASK do formulário) -
    # linhas vindas do Feature Release deixam este campo em branco (usam rlse_number).
    ritm_number = db.Column(db.String(20), nullable=True)
    ambiente = db.Column(db.String(20), nullable=True)
    assunto_email = db.Column(db.Text, nullable=False)
    destinatario = db.Column(db.String(200), nullable=True)

    # pendente -> aguardando resposta | aprovado -> CTASK criada | rejeitado -> resposta
    # negou a aprovação | erro -> resposta aprovada mas falhou ao criar a CTASK
    status = db.Column(db.String(20), nullable=True, default="pendente")
    sctask_criada = db.Column(db.String(20), nullable=True)
    erro = db.Column(db.Text, nullable=True)

    criado_em = db.Column(db.DateTime, default=datetime.utcnow)
    processado_em = db.Column(db.DateTime, nullable=True)


class TicketAssignmentConfig(db.Model):
    """
    Config POR USUÁRIO (mesmo padrão de PortalTaskConfig) da tela de Atribuição
    de Chamados: links das filas SCTASK/INC e o analista fixo usado para INC
    (SCTASK usa o motor de regras em tools/ticket_assignment_rules.py em vez
    de um analista fixo - muitos analistas possíveis, um por regra).
    """
    __tablename__ = 'ticket_assignment_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    sctask_queue_url = db.Column(db.Text, nullable=True, default="")
    inc_queue_url = db.Column(db.Text, nullable=True, default="")
    inc_analista = db.Column(db.String(150), nullable=True, default="")
    headless = db.Column(db.Boolean, default=False)

    user = db.relationship('User', backref=db.backref('ticket_assignment_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class DmlApprovalContact(db.Model):
    """
    Lista GLOBAL (não por usuário - mesmo espírito de ServiceNowExportConfig)
    de contatos habilitados a aprovar execução de DML, mantida pelo modal de
    configuração da tela 'Send dml' e usada para preencher rapidamente o
    campo 'Destinatário' do formulário de envio.
    """
    __tablename__ = 'dml_approval_contacts'

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)



# -*- coding: utf-8 -*-
"""
IT Executive Dashboard - Main Orchestrator
============================================
Loads INC / SCTASK / PRB exports from ServiceNow, computes every metric
(aging, SLA breach, backlog, monthly/daily throughput, cross-type
conversions, rankings), renders the full HTML dashboard and sends it by
e-mail through Outlook via `smtp.py`.

Usage
-----
1. Place INC.xlsx, SCTASK.xlsx and PRB.xlsx in this same folder
   (or edit the paths in config.py).
2. Edit CONFIG["EMAIL_TO"] / CONFIG["EMAIL_CC"] in config.py.
3. Run:  python main.py
"""
import sys
import traceback

from config import CONFIG
from data_loader import load_all
from report_builder import build_report

try:
    from smtp import enviar_email_automatico
except ImportError:
    enviar_email_automatico = None


def main():
    print("=" * 70)
    print("IT Executive Dashboard - SCTASK / INC / PRB")
    print("=" * 70)

    print("\n[1/4] Loading ServiceNow exports...")
    try:
        sctask, inc, prb = load_all(CONFIG)
    except FileNotFoundError as e:
        print(f"File not found: {e}")
        print("Check the paths in config.py (SCTASK_PATH / INC_PATH / PRB_PATH).")
        sys.exit(1)
    print(f"   -> SCTASK: {len(sctask)} | INC: {len(inc)} | PRB: {len(prb)} records loaded.")

    print("\n[2/4] Computing metrics and building the HTML dashboard...")
    html, kpis, ref = build_report(sctask, inc, prb, CONFIG)
    print(f"   -> Period: {kpis['period_label']} | Reference date: {ref.strftime('%d/%m/%Y %H:%M')}")
    print(f"   -> Open SCTASK: {kpis['open_sctask']} | Open INC: {kpis['open_inc']} "
          f"| Open PRB: {kpis['open_prb']} | Total backlog: {kpis['total_backlog']} | MTTR: {kpis['mttr_overall']}d")

    if CONFIG.get("SAVE_LOCAL_COPY"):
        with open(CONFIG["OUTPUT_HTML"], "w", encoding="utf-8") as f:
            f.write(html)
        print(f"   -> Local copy saved to: {CONFIG['OUTPUT_HTML']}")

    if not CONFIG.get("SEND_EMAIL", True):
        print("\n[3/4] Email sending disabled (SEND_EMAIL=False). Done.")
        return

    print("\n[3/4] Sending e-mail via Outlook (smtp.py)...")
    if enviar_email_automatico is None:
        print("   -> smtp.py not found/importable. Copy smtp.py into this folder.")
        sys.exit(1)

    subject = f"{CONFIG['EMAIL_SUBJECT_PREFIX']} - {ref.strftime('%d/%m/%Y')}"
    ok, msg = enviar_email_automatico(
        to=CONFIG["EMAIL_TO"],
        cc=CONFIG.get("EMAIL_CC", ""),
        subject=subject,
        html_body=html,
    )

    print("\n[4/4] Send result:")
    if ok:
        print(f"   -> SUCCESS: {msg}")
    else:
        print(f"   -> FAILED: {msg}")
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("\nUnexpected error while generating/sending the dashboard:")
        traceback.print_exc()
        sys.exit(1)

# -*- coding: utf-8 -*-
"""
Assembles the full dashboard HTML - visual language ported directly from the
reference "relatorio_email.html" template (soft card style, colored KPI
top-borders, gradient section headers) with SCTASK (blue) and INC (red)
kept in clearly separated, parallel sections, plus compact "smart card"
panels for critical/SLA-breaching tickets instead of long raw tables.
"""
import pandas as pd
from datetime import datetime
from config import QC, Colors
import metrics as m
import charts as c

CSS = """
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px 10px; }
        .email-container { max-width: 1300px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .header { background-color: #0B1E40; color: #ffffff; padding: 18px 20px; text-align: center; }
        .header h2 { margin: 0 0 6px 0; font-size: 22px; letter-spacing: 0.3px; }
        .header p { margin: 0; color: #9BBAD2; font-size: 13px; }
        .content { padding: 22px; }
        .kpi-container { width: 100%; margin-bottom: 22px; }
        .kpi-card { border: 1px solid #dddddd; border-radius: 6px; background-color: #fcfcfc; padding: 14px 8px; text-align: center; border-top: 4px solid #329EF4; }
        .kpi-card.blue { border-top-color: #329EF4; }
        .kpi-card.green { border-top-color: #649f40; }
        .kpi-card.red { border-top-color: #EB1E77; }
        .kpi-card.orange { border-top-color: #ff9800; }
        .kpi-card.purple { border-top-color: #9b59b6; }
        .kpi-title { color: #888888; font-size: 11px; text-transform: uppercase; font-weight: bold; margin-bottom: 6px; letter-spacing: 0.3px; }
        .kpi-value { color: #333333; font-size: 26px; font-weight: bold; margin-bottom: 4px; }
        .kpi-subtitle { font-size: 11px; color: #999999; }
        .kpi-trend-up { color: #EB1E77; font-weight: bold; }
        .kpi-trend-down { color: #649f40; font-weight: bold; }
        .stat-card { border: 1px solid #eeeeee; border-radius: 6px; background-color: #fcfcfc; padding: 12px 8px; text-align: center; border-top: 3px solid #cccccc; }
        .stat-card.warn { border-top-color: #ff9800; }
        .stat-card.danger { border-top-color: #EB1E77; }
        .stat-card.info { border-top-color: #329EF4; }
        .stat-card.flat { border: 1px solid #e0e0e0; border-top: 1px solid #e0e0e0; background-color: #fafafa; }
        .stat-title { color: #888888; font-size: 10px; text-transform: uppercase; font-weight: bold; margin-bottom: 5px; }
        .stat-value { color: #333333; font-size: 22px; font-weight: bold; }
        .stat-subtitle { font-size: 10px; color: #999999; margin-top: 3px; }
        .chart-card-full { border: 1px solid #eeeeee; border-radius: 6px; padding: 15px; margin-bottom: 18px; text-align: center; background-color: #ffffff; }
        .chart-title { color: #585858; font-size: 13px; font-weight: bold; text-transform: uppercase; margin-bottom: 10px; text-align: left; border-bottom: 1px solid #f4f4f4; padding-bottom: 8px; }
        .chart-img { max-width: 100%; height: auto; display: block; margin: 0 auto; }
        .grid-cell { border: 1px solid #eeeeee; border-radius: 6px; padding: 12px; background-color: #ffffff; vertical-align: top; }
        .data-table { width: 100%; border-collapse: collapse; font-size: 12px; color: #333333; }
        .data-table th { background-color: #f4f4f4; color: #585858; font-weight: bold; padding: 7px; border: 1px solid #dddddd; text-align: center; }
        .data-table td { padding: 6px; border: 1px solid #dddddd; text-align: center; }
        .data-table tr:nth-child(even) { background-color: #fcfcfc; }
        .data-table .total-row { font-weight: bold; background-color: #e2e8f0; font-size: 13px; }
        .text-left { text-align: left !important; }
        .table-note { font-size: 11px; color: #999999; text-align: right; margin-top: 6px; font-style: italic; }
        .section-divider { border: none; border-top: 2px solid #e8ecf0; margin: 26px 0 20px 0; }
        .section-header { background: linear-gradient(135deg, #0B1E40 0%, #1a3a6b 100%); color: #ffffff; padding: 11px 16px; border-radius: 6px; margin-bottom: 15px; font-size: 14px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; }
        .section-header.req { background: linear-gradient(135deg, #1565C0 0%, #1976D2 100%); }
        .section-header.inc { background: linear-gradient(135deg, #B71C1C 0%, #C62828 100%); }
        .section-header.prb { background: linear-gradient(135deg, #4A148C 0%, #6A1B9A 100%); }
        .sub-header { color: #585858; font-size: 12px; font-weight: bold; text-transform: uppercase; margin: 16px 0 10px 0; letter-spacing: 0.3px; }
        .mini-kpi-row { margin-bottom: 14px; }
        .mini-kpi { display: inline-block; background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; padding: 6px 14px; margin-right: 8px; margin-bottom: 6px; font-size: 11px; color: #555; }
        .mini-kpi strong { font-size: 15px; color: #222; display: block; }
        .footer { text-align: center; padding: 15px; font-size: 12px; color: #888888; background-color: #f4f4f4; border-top: 1px solid #dddddd; }
        @media only screen and (max-width: 768px) {
            body { padding: 8px 4px !important; }
            .content { padding: 12px !important; }
            .header { padding: 14px !important; }
            .header h2 { font-size: 18px !important; }
            .responsive-td-3 { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-bottom: 15px !important; }
            .grid-cell { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-bottom: 15px !important; }
            .spacer-hide-mobile { display: none !important; }
            .kpi-responsive-td { display: inline-block !important; width: 48% !important; box-sizing: border-box !important; margin-bottom: 12px !important; }
            .kpi-spacer { display: inline-block !important; width: 4% !important; }
            .kpi-value { font-size: 22px !important; }
            .stat-value { font-size: 18px !important; }
            .mini-kpi { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-right: 0 !important; }
            .data-table { font-size: 11px !important; }
            .chart-title { font-size: 12px !important; }
        }
"""


# ---------------------------------------------------------------------------
# Generic layout helpers (fixed table structure - no nested <td> bugs)
# ---------------------------------------------------------------------------
def kpi_row(cards):
    """cards: list of (color_class, title, value, subtitle_html). Builds one
    <tr> with N equal-width cards + thin spacers, exactly like the reference
    template (no double-nested <td> - each card sits directly in the row)."""
    n = len(cards)
    spacer_total = (n - 1) * 2
    card_w = (100 - spacer_total) / n
    cells = []
    for i, (color_class, title, value, subtitle) in enumerate(cards):
        cells.append(f"""<td width="{card_w:.1f}%" class="kpi-responsive-td">
            <div class="kpi-card {color_class}">
                <div class="kpi-title">{title}</div>
                <div class="kpi-value">{value}</div>
                <div class="kpi-subtitle">{subtitle}</div>
            </div>
        </td>""")
        if i < n - 1:
            cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
    return f'<table class="kpi-container" cellpadding="0" cellspacing="0" border="0"><tr>{"".join(cells)}</tr></table>'


def stat_row(cards):
    """Small stat cards (compact critical panel). cards: list of
    (modifier_class, title, value, subtitle)."""
    n = len(cards)
    spacer_total = (n - 1) * 2
    card_w = (100 - spacer_total) / n
    cells = []
    for i, (mod, title, value, subtitle) in enumerate(cards):
        cells.append(f"""<td width="{card_w:.1f}%" class="kpi-responsive-td">
            <div class="stat-card {mod}">
                <div class="stat-title">{title}</div>
                <div class="stat-value">{value}</div>
                <div class="stat-subtitle">{subtitle}</div>
            </div>
        </td>""")
        if i < n - 1:
            cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
    return f'<table class="kpi-container" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:14px;"><tr>{"".join(cells)}</tr></table>'


def section_header(text, css_class=""):
    return f'<div class="section-header {css_class}">{text}</div>'


def sub_header(text):
    return f'<div class="sub-header">{text}</div>'


def chart_card(title, img_url):
    return f'<div class="chart-title">{title}</div><img class="chart-img" src="{img_url}">'


def grid_row(cells, widths=None):
    """cells: list of inner-HTML strings, each wrapped in a .grid-cell."""
    n = len(cells)
    if widths is None:
        spacer_total = (n - 1) * 2
        w = (100 - spacer_total) / n
        widths = [w] * n
    html = '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 18px;"><tr>'
    for i, content in enumerate(cells):
        html += f'<td width="{widths[i]:.1f}%" class="grid-cell responsive-td-3">{content}</td>'
        if i < n - 1:
            html += '<td width="2%" class="spacer-hide-mobile">&nbsp;</td>'
    html += "</tr></table>"
    return html


def mini_kpi_row(items):
    spans = "".join(f'<span class="mini-kpi">{label}<strong>{value}</strong></span>' for label, value in items)
    return f'<div class="mini-kpi-row">{spans}</div>'


def full_width_card(title, img_url):
    return f'<div class="chart-card-full">{chart_card(title, img_url)}</div>'


# ---------------------------------------------------------------------------
# Data tables
# ---------------------------------------------------------------------------
def data_table(df, header_bg="#f4f4f4", header_color="#585858", show_totals=False,
                empty_message="No data available for this period."):
    if df is None or df.empty:
        return (f"<div style='padding:14px; color:{Colors.SUCCESS}; background-color:{Colors.SUCCESS_LIGHT}; "
                f"text-align:center; font-weight:bold; border:1px solid {Colors.SUCCESS}; border-radius:4px; "
                f"font-size:12px;'>&#10003; {empty_message}</div>")

    html = "<table class='data-table'><thead><tr>"
    for i, col in enumerate(df.columns):
        html += f"<th style='background-color:{header_bg}; color:{header_color};'>{col}</th>"
    html += "</tr></thead><tbody>"
    for _, row in df.iterrows():
        html += "<tr>"
        for j, val in enumerate(row):
            cls = "text-left" if j == 0 else ""
            html += f"<td class='{cls}'>{val}</td>"
        html += "</tr>"
    html += "</tbody></table>"
    return html


def monthly_table_with_totals(df, css_scope="req"):
    if df.empty:
        return data_table(df)
    header_bg = "#1976D2" if css_scope == "req" else "#C62828"
    render = df.rename(columns={"NetFlow": "Net Flow", "BacklogAccum": "Backlog"})
    rows = ""
    for _, r in render.iterrows():
        sign = "+" if r["Net Flow"] > 0 else ""
        color = "#EB1E77" if r["Net Flow"] > 0 else ("#649f40" if r["Net Flow"] < 0 else "#585858")
        rows += (f"<tr><td class='text-left'>{r['Month']}</td><td>{r['Opened']}</td><td>{r['Resolved']}</td>"
                 f"<td style='color:{color}; font-weight:bold;'>{sign}{r['Net Flow']}</td>"
                 f"<td style='font-weight:bold;'>{r['Backlog']}</td></tr>")
    tot_o, tot_c, tot_n = render["Opened"].sum(), render["Resolved"].sum(), render["Net Flow"].sum()
    last_backlog = render["Backlog"].iloc[-1]
    sign_t = "+" if tot_n > 0 else ""
    color_t = "#EB1E77" if tot_n > 0 else ("#649f40" if tot_n < 0 else "#585858")
    rows += (f"<tr class='total-row'><td class='text-left'>TOTAL</td><td>{tot_o}</td><td>{tot_c}</td>"
             f"<td style='color:{color_t};'>{sign_t}{tot_n}</td><td>{last_backlog}</td></tr>")

    return (f"<table class='data-table'><thead><tr>"
            f"<th class='text-left' style='background-color:{header_bg}; color:#fff;'>Month</th>"
            f"<th style='background-color:{header_bg}; color:#fff;'>Opened</th>"
            f"<th style='background-color:{header_bg}; color:#fff;'>Resolved</th>"
            f"<th style='background-color:{header_bg}; color:#fff;'>Net Flow</th>"
            f"<th style='background-color:{header_bg}; color:#fff;'>Backlog</th>"
            f"</tr></thead><tbody>{rows}</tbody></table>")


# ---------------------------------------------------------------------------
# Compact "smart card" critical panel (replaces the old 25-row raw table)
# ---------------------------------------------------------------------------
def critical_panel(open_df, ticket_type_label, threshold, extra_threshold, id_cols,
                    compact_rows=6, accent="danger"):
    summary = m.critical_summary(open_df, threshold, extra_threshold)

    cards = [
        (accent, f"Aging {threshold}+ days", summary["count"], "tickets need attention"),
    ]
    if extra_threshold:
        cards.append((accent, f"Aging {extra_threshold}+ days", summary["count_extra"], "extra-critical"))
    cards.append(("warn", "Oldest Ticket", f"{summary['oldest_days']}d",
                   summary["oldest_number"] if summary["oldest_number"] != "\u2014" else "\u2014"))
    cards.append(("info", "Avg. Aging (critical)", f"{summary['avg_days']}d", "days open, on average"))

    panel = stat_row(cards)

    if summary["count"] == 0:
        panel += data_table(pd.DataFrame(), empty_message=f"No {ticket_type_label} above the aging threshold.")
        return panel

    crit = m.critical_table(open_df, threshold, top_n=compact_rows)
    render = crit.copy()
    render["Opened"] = render["Opened"].dt.strftime("%d/%m/%Y")
    cols = ["Number"] + id_cols + ["State", "Opened", "AgingDays"]
    render = render[cols].rename(columns={"AgingDays": "Aging (d)"})
    panel += data_table(render)

    if summary["count"] > compact_rows:
        panel += (f"<div class='table-note'>+ {summary['count'] - compact_rows} additional critical "
                   f"{ticket_type_label} not shown here (see the full export for details).</div>")
    return panel


# ---------------------------------------------------------------------------
# Parallel SCTASK / INC section builder (shared structure, type-specific colors)
# ---------------------------------------------------------------------------
def build_ticket_type_section(df, ref, config, *, ticket_type, css_class, label,
                                donut_colors, bar_color, bar_color_soft, requester_col,
                                id_cols, critical_threshold, extra_critical=None):
    sla_days = config["SLA_DAYS"][ticket_type]
    open_df = m.add_open_aging(df, ref, sla_days)

    # This is a day-to-day operations snapshot: "Opened/Resolved" only ever
    # look at the current month, and the backlog counts are always the LIVE
    # open queue - never an all-time total of closed tickets.
    opened_month, resolved_month = m.current_month_flow(df, ref)
    backlog = len(open_df)
    mttr = round(m.mttr_days_month(df, ref), 1)
    inside, outside = m.sla_inside_outside(open_df)

    html = section_header(label, css_class)
    html += mini_kpi_row([
        ("Opened (month)", opened_month), ("Resolved (month)", resolved_month),
        ("Open Backlog", backlog), ("Inside SLA", inside), ("Outside SLA", outside),
        ("MTTR (month)", f"{mttr}d"),
    ])

    html += sub_header(f"Critical {ticket_type}s")
    html += critical_panel(open_df, ticket_type, critical_threshold, extra_critical,
                             id_cols, config["CRITICAL_TABLE_COMPACT_ROWS"],
                             accent="danger")

    return html, open_df


# ---------------------------------------------------------------------------
# Combined Distribution & SLA section (1A/1B donuts + both SLA pies together)
# ---------------------------------------------------------------------------
def build_distribution_sla_section(open_sctask, open_inc, config):
    an_s_l, an_s_v = m.top_analysts(open_sctask, config["TOP_N_ANALYSTS"])
    an_i_l, an_i_v = m.top_analysts(open_inc, config["TOP_N_ANALYSTS"])
    # Varied, easy-to-tell-apart palette for both donuts (a single-hue gradient
    # makes similarly-sized slices indistinguishable at a glance).
    img_an_s = c.donut(an_s_l, an_s_v, QC["varied"])
    img_an_i = c.donut(an_i_l, an_i_v, QC["varied"])

    in_s, out_s = m.sla_inside_outside(open_sctask)
    in_i, out_i = m.sla_inside_outside(open_inc)
    img_sla_s = c.sla_pie(in_s, out_s)
    img_sla_i = c.sla_pie(in_i, out_i)

    return section_header("Distribution & SLA (Donut / Pie Charts)") + grid_row([
        chart_card("1A. Top Analysts - SCTASK", img_an_s),
        chart_card("1B. Top Analysts - INC", img_an_i),
        chart_card("SCTASK: Inside vs Outside SLA", img_sla_s),
        chart_card("INC: Inside vs Outside SLA", img_sla_i),
    ])


# ---------------------------------------------------------------------------
# Combined Status & Aging section (3A/3B aging bars + both status bars)
# ---------------------------------------------------------------------------
def build_status_aging_section(open_sctask, open_inc, config):
    aging_s = m.aging_bucket_table(open_sctask, "SCTASK")
    aging_i = m.aging_bucket_table(open_inc, "INC")
    img_aging_s = c.horizontal_bar_scale(aging_s["Bucket"], aging_s["Count"])
    img_aging_i = c.horizontal_bar_scale(aging_i["Bucket"], aging_i["Count"])

    st_s_l, st_s_v = m.status_distribution(open_sctask, config["TOP_N_ANALYSTS"])
    st_i_l, st_i_v = m.status_distribution(open_inc, config["TOP_N_ANALYSTS"])
    img_st_s = c.horizontal_bar(st_s_l, st_s_v, QC["blue_a"])
    img_st_i = c.horizontal_bar(st_i_l, st_i_v, QC["red_a"])

    return section_header("Status & Aging of Open Tickets (Bar Charts)") + grid_row([
        chart_card("3A. Aging Detail - SCTASK", img_aging_s),
        chart_card("3B. Aging Detail - INC", img_aging_i),
        chart_card("SCTASK: Status (Open)", img_st_s),
        chart_card("INC: Status (Open)", img_st_i),
    ])


# ---------------------------------------------------------------------------
# Side-by-side trend comparison panels (SCTASK vs INC) - styled to match the
# reference screenshot exactly: colored top border per panel, bold colored
# title, 3 plain stat boxes (Opened / Closed / Net Balance) and a rich
# dual-axis chart with datalabels on both the bars and the line.
# ---------------------------------------------------------------------------
def two_col_row(left_html, right_html, widths=(49, 49)):
    return f"""<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 18px;">
        <tr>
            <td width="{widths[0]}%" valign="top" class="responsive-td-3">{left_html}</td>
            <td width="2%" class="spacer-hide-mobile">&nbsp;</td>
            <td width="{widths[1]}%" valign="top" class="responsive-td-3">{right_html}</td>
        </tr>
    </table>"""


def build_trend_panel(number_label, ticket_type, df_metrics, border_color, title_color,
                        color_opened, color_closed, color_line, line_label, w=780, h=340):
    label_col = "Month" if "Month" in df_metrics.columns else "Date"
    total_opened = int(df_metrics["Opened"].sum())
    total_closed = int(df_metrics["Resolved"].sum())
    net_balance = total_opened - total_closed
    net_html = (f"<span style='color:#EB1E77;'>+{net_balance}</span>" if net_balance > 0
                else (f"<span style='color:#649f40;'>{net_balance}</span>" if net_balance < 0
                      else f"<span style='color:#585858;'>0</span>"))

    stats = stat_row([
        ("flat", "Opened", total_opened, ""),
        ("flat", "Closed", total_closed, ""),
        ("flat", line_label, net_html, ""),
    ])

    img = c.dual_axis_trend_rich(
        df_metrics[label_col], df_metrics["Opened"], df_metrics["Resolved"], df_metrics["BacklogAccum"],
        color_opened, color_closed, color_line, line_label=line_label, w=w, h=h)

    return f"""
    <div style="border-top: 4px solid {border_color}; border-left: 1px solid #eeeeee; border-right: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee; border-radius: 6px; padding: 16px; background-color:#ffffff;">
        <div style="color:{title_color}; font-size:16px; font-weight:bold; margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #f4f4f4;">{number_label}. {ticket_type} - Opened / Closed / {line_label}</div>
        {stats}
        <img class="chart-img" src="{img}" style="margin-top:14px;">
    </div>"""


def build_trend_comparison_section(section_title, sctask_metrics, inc_metrics,
                                     label_a, label_b, line_label="Net Balance", css_class="",
                                     layout="side_by_side"):
    if layout == "stacked":
        panel_sctask = build_trend_panel(label_a, "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
                                           QC["blue"], QC["bright_green"], QC["red"], line_label,
                                           w=1180, h=380)
        panel_inc = build_trend_panel(label_b, "INC", inc_metrics, "#C62828", "#B71C1C",
                                        QC["coral"], QC["purple"], QC["orange"], line_label,
                                        w=1180, h=380)
        body = (f'<div style="margin-bottom: 18px;">{panel_sctask}</div>'
                f'<div style="margin-bottom: 18px;">{panel_inc}</div>')
        return section_header(section_title, css_class) + body

    panel_sctask = build_trend_panel(label_a, "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
                                       QC["blue"], QC["bright_green"], QC["red"], line_label)
    panel_inc = build_trend_panel(label_b, "INC", inc_metrics, "#C62828", "#B71C1C",
                                    QC["coral"], QC["purple"], QC["orange"], line_label)
    return section_header(section_title, css_class) + two_col_row(panel_sctask, panel_inc)


# ---------------------------------------------------------------------------
# Combined Monthly Tracking Table (SCTASK + INC side by side, one section)
# ---------------------------------------------------------------------------
def build_monthly_tracking_section(monthly_sctask, monthly_inc):
    left = (f'<div class="chart-card-full" style="margin-bottom:0;">'
            f'<div class="chart-title">Throughput - SCTASK</div>'
            f'{monthly_table_with_totals(monthly_sctask, css_scope="req")}</div>')
    right = (f'<div class="chart-card-full" style="margin-bottom:0;">'
             f'<div class="chart-title">Throughput - INC</div>'
             f'{monthly_table_with_totals(monthly_inc, css_scope="inc")}</div>')
    return section_header("Monthly Tracking Table: Opened x Resolved x Backlog") + two_col_row(left, right)


# ---------------------------------------------------------------------------
# Cross-type conversions (offenders)
# ---------------------------------------------------------------------------
def stat_grid_2x2(cards):
    """2x2 grid of plain stat cards (used for the classification KPI block)."""
    html = '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="height:100%;">'
    for i in range(0, len(cards), 2):
        row = cards[i:i + 2]
        html += "<tr>"
        for mod, title, value, subtitle in row:
            html += (f'<td width="50%" style="padding:5px;"><div class="stat-card {mod}" style="height:100%;">'
                     f'<div class="stat-title">{title}</div>'
                     f'<div class="stat-value" style="font-size:24px;">{value}</div>'
                     f'<div class="stat-subtitle">{subtitle}</div></div></td>')
        html += "</tr>"
    html += "</table>"
    return html


def breakdown_card(title, labels, values, show_pct=False):
    if not labels:
        return f'<div class="chart-title">{title}</div>' + data_table(pd.DataFrame(), empty_message="No records this period.")
    total = sum(values) or 1
    if show_pct:
        rows = [{"Name": l, "Count": v, "%": f"{v / total * 100:.1f}%"} for l, v in zip(labels, values)]
    else:
        rows = [{"Name": l, "Count": v} for l, v in zip(labels, values)]
    return f'<div class="chart-title">{title}</div>' + data_table(pd.DataFrame(rows))


def build_conversions_section(sctask, inc, ref, config):
    r = m.classification_errors(sctask, inc, ref, config)

    html = section_header("Cross-Type Conversions (SCTASK &harr; INC)")
    html += ('<div style="font-size:11px; color:#999999; margin-bottom:12px;">'
              'How canceled/incomplete tickets in SCTASK and INC reconcile with genuine '
              'cross-type misclassifications (tracked in both directions).</div>')

    # ---- Reconciliation panel ----
    html += sub_header("Canceled Reconciliation (Current Month)")
    html += stat_row([
        ("warn", "INC Canceled", r["inc_cancel_total"], "Total in INC"),
        ("info", "SCTASK Canceled", r["sctask_cancel_total"], "Total in SCTASK"),
        ("", "Total Canceled", r["inc_cancel_total"] + r["sctask_cancel_total"], "INC + SCTASK"),
        ("danger", "Incorrect Classif.", r["total_month"], "Confirmed misclassification"),
        ("", "Other Reasons", r["other_reasons"], "Non-classification cancels"),
    ])
    html += mini_kpi_row([
        ("INC \u2192 SCTASK (reclassified)", r["i2s_month"]),
        ("SCTASK \u2192 INC (reclassified)", r["s2i_month"]),
    ])

    # ---- KPI cards (all scoped to the current month) ----
    html += stat_row([
        ("danger", "Incorrect Tickets (Month)", r["total_month"], "Volume detected this period"),
        ("warn", "Top Offending Group", r["top_group_count"], r["top_group_name"]),
        ("info", "MTTR (Month)", f"{r['mttr_month']}d", "Average correction time"),
        ("", "Maximum Delay (Month)", f"{r['max_delay_month']}d", "Longest response time"),
    ])

    # ---- Analytical breakdowns (current month only) ----
    req_l, req_v = r["by_requester"]
    grp_l, grp_v = r["by_group"]
    an_l, an_v = r["by_analyst"]
    html += grid_row([
        breakdown_card("By Requester (Month)", req_l, req_v),
        breakdown_card("By Group (Month)", grp_l, grp_v),
        breakdown_card("By Analyst (Month)", an_l, an_v),
    ], widths=[32, 32, 32])

    # ---- Detailed list (compact) ----
    html += sub_header("Detailed List of Incorrect Classifications (Current Month)")
    recent = r["recent_rows"]
    if recent is None or recent.empty:
        html += data_table(pd.DataFrame(), empty_message="No incorrect classifications identified in the period.")
    else:
        render = recent.copy()
        render["Opened"] = render["Opened"].dt.strftime("%d/%m/%Y")
        render["Closed"] = render["Closed"].apply(lambda d: d.strftime("%d/%m/%Y") if pd.notna(d) else "\u2014")
        render["AgingDays"] = render["AgingDays"].round(1)
        cols = ["Number", "Direction", "LinkedTicket", "Requester", "Assigned to",
                "Assignment group", "Reason", "State", "Opened", "Closed", "AgingDays"]
        render = render[cols].rename(columns={"LinkedTicket": "Linked Ticket", "AgingDays": "Aging (d)"})
        html += data_table(render)
        if r["total_month"] > len(recent):
            html += (f"<div class='table-note'>+ {r['total_month'] - len(recent)} additional misclassified "
                      f"tickets not shown here (see the full export for details).</div>")

    return html



# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def build_report(sctask, inc, prb, config):
    ref = m.get_reference_date(config)
    crit = config["CRITICAL_AGING_THRESHOLD"]

    open_sctask_quick = m.add_open_aging(sctask, ref, config["SLA_DAYS"]["SCTASK"])
    open_inc_quick = m.add_open_aging(inc, ref, config["SLA_DAYS"]["INC"])
    open_prb_quick = m.add_open_aging(prb, ref, config["SLA_DAYS"]["PRB"])
    total_backlog = len(open_sctask_quick) + len(open_inc_quick)
    mttr_overall = round((m.mttr_days_month(sctask, ref) + m.mttr_days_month(inc, ref)) / 2, 1)

    overview = kpi_row([
        ("blue", "Total Backlog", total_backlog, "SCTASK + INC open, right now"),
        ("blue", "SCTASK Open", len(open_sctask_quick), "Service requests"),
        ("red", "INC Open", len(open_inc_quick), "Incidents"),
        ("purple", "PRB Open", len(open_prb_quick), f"of {len(prb)} total"),
        ("orange", "MTTR (month)", f"{mttr_overall}d", "Current-month resolution time"),
    ])

    sctask_html, open_sctask = build_ticket_type_section(
        sctask, ref, config, ticket_type="SCTASK", css_class="req", label="SCTASK \u2014 Service Requests",
        donut_colors=QC["req_donut"], bar_color=QC["blue_a"], bar_color_soft=QC["blue_a"],
        requester_col="Requester", id_cols=["Assigned to", "Requester"],
        critical_threshold=crit["SCTASK"], extra_critical=config.get("SCTASK_EXTRA_CRITICAL_DAYS"))

    inc_html, open_inc = build_ticket_type_section(
        inc, ref, config, ticket_type="INC", css_class="inc", label="INC \u2014 Incidents",
        donut_colors=QC["inc_donut"], bar_color=QC["red_a"], bar_color_soft=QC["red_a"],
        requester_col="Caller", id_cols=["Assigned to", "Caller"],
        critical_threshold=crit["INC"], extra_critical=None)

    distribution_sla_html = build_distribution_sla_section(open_sctask, open_inc, config)
    status_aging_html = build_status_aging_section(open_sctask, open_inc, config)

    daily_current_sctask = m.daily_trend_current_month(sctask, ref)
    daily_current_inc = m.daily_trend_current_month(inc, ref)

    daily_trend_html = build_trend_comparison_section(
        "Daily Evolution by Ticket Type (Current Month)",
        daily_current_sctask, daily_current_inc, "2A", "2B", line_label="Net Balance",
        layout="stacked")

    conversions_html = build_conversions_section(sctask, inc, ref, config)

    ini, _ = m.month_bounds(ref)
    period_label = ini.strftime("%m/%Y")
    sla = config["SLA_DAYS"]

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Executive Dashboard</title>
    <style>{CSS}</style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h2>IT Executive Dashboard &mdash; SCTASK x INC x PRB</h2>
            <p>Period: {period_label} &nbsp;|&nbsp; Generated: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')} &nbsp;|&nbsp;
               SLA SCTASK={sla['SCTASK']}d &nbsp; SLA INC={sla['INC']}d &nbsp; SLA PRB={sla['PRB']}d</p>
        </div>
        <div class="content">

            {section_header("Overview")}
            {overview}

            {sctask_html}

            <hr class="section-divider">
            {inc_html}

            <hr class="section-divider">
            {distribution_sla_html}

            <hr class="section-divider">
            {status_aging_html}

            <hr class="section-divider">
            {daily_trend_html}

            <hr class="section-divider">
            {conversions_html}

        </div>
        <div class="footer">
            Automated report generated by the IT Metrics Dashboard script &middot; {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
        </div>
    </div>
</body>
</html>"""

    kpis = {
        "total_backlog": total_backlog, "open_sctask": len(open_sctask_quick),
        "open_inc": len(open_inc_quick), "open_prb": len(open_prb_quick),
        "mttr_overall": mttr_overall, "period_label": period_label,
    }
    return html, kpis, ref

from tools.base_automation import BaseAutomation, SelectorManager
from tools.servicenow_driver import ServiceNowDriver
from tools.upm_driver import UpmDriver
from tools.okta_auth import OktaAuthManager
from tools.smtp import enviar_email_automatico, SmtpMailer, send_outlook_windows, send_outlook_mac
from tools.portal_automations import (
    PortalAutomationFactory,
    PortalBaseTaskAutomation,
    UserCadastroAutomation,
    AssessoriaCadastroAutomation,
    UserDesabilitarAutomation,
    UserAlterarAutomation,
    PasswordResetAutomation,
    MfaResetAutomation,
    TaskEncerrarAutomation
)

__all__ = [
    "BaseAutomation",
    "SelectorManager",
    "ServiceNowDriver",
    "UpmDriver",
    "OktaAuthManager",
    "enviar_email_automatico",
    "SmtpMailer",
    "send_outlook_windows",
    "send_outlook_mac",
    "PortalAutomationFactory",
    "PortalBaseTaskAutomation",
    "UserCadastroAutomation",
    "AssessoriaCadastroAutomation",
    "UserDesabilitarAutomation",
    "UserAlterarAutomation",
    "PasswordResetAutomation",
    "MfaResetAutomation",
    "TaskEncerrarAutomation"
]

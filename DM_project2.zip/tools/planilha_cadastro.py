"""
================================================================================
LEITURA DINÂMICA DA PLANILHA DE CADASTRO DE USUÁRIO (.xlsx)
================================================================================
Colunas esperadas no anexo do chamado (em qualquer ordem/posição):
    Email_Master | Usuario (Nome Completo) | CPF_Master | Celular (Opcional) |
    Razao Social | CNPJ | SUSEP | SENHA

O cabeçalho é localizado e mapeado DINAMICAMENTE pelo NOME da coluna (não por
posição fixa), o que permite reordenar/inserir colunas no template sem quebrar
a automação. Linhas com QUALQUER campo obrigatório faltando são IGNORADAS
(a automação segue normalmente para as próximas linhas), seguindo a mesma
lógica de saneamento de dados do arquivo de referência 'cadastro_usuario.txt'.
"""

import re
import logging
import unicodedata
from typing import Any, Dict, List, Optional, Tuple

import openpyxl

from tools.usuario import Usuario

logger = logging.getLogger("PlanilhaCadastro")

# Nome da coluna (normalizado) -> campo do Usuario
COLUNAS_ESPERADAS: Dict[str, str] = {
    "email_master": "email_master",
    "usuario": "nome_completo",  # "Usuario (Nome Completo)"
    "cpf_master": "cpf",
    "celular": "celular",  # "Celular (Opcional)"
    "razao_social": "razao_social",
    "cnpj": "cnpj",
    "susep": "susep",
    "senha": "senha",
}

# Campos obrigatórios: se QUALQUER um faltar, a linha é ignorada.
# 'celular' é explicitamente opcional e 'senha' é uma coluna de SAÍDA
# (preenchida pela automação após o reset no UPM), por isso ambos ficam de fora.
CAMPOS_OBRIGATORIOS: List[str] = ["email_master", "nome_completo", "cpf", "razao_social", "cnpj", "susep"]

# Marcadores de rodapé/exemplo que sinalizam o fim dos dados (mesmo critério do cadastro_usuario.txt)
MARCADORES_FIM = {
    "email_exemplo",
    "observacoes_gerais",
    "1_observacoes_gerais",
    "observacoes",
    "",
}


def _remover_acentos(texto: str) -> str:
    return unicodedata.normalize("NFD", texto).encode("ascii", "ignore").decode("utf-8")


def _normalizar_chave(texto: Any) -> str:
    """Normaliza nomes de coluna/valores para comparação robusta (sem acento/maiúscula/parênteses)."""
    if texto is None:
        return ""
    texto = _remover_acentos(str(texto)).lower().strip()
    texto = re.sub(r"\(.*?\)", "", texto)  # remove "(Nome Completo)", "(Opcional)"
    texto = re.sub(r"[^a-z0-9]+", "_", texto).strip("_")
    return texto


def _limpar_email(valor: Any) -> str:
    return _remover_acentos(str(valor)).strip().lower() if valor not in (None, "") else ""


def _limpar_nome(valor: Any) -> str:
    if valor in (None, ""):
        return ""
    texto = _remover_acentos(str(valor)).strip()
    return re.sub(r"[^a-zA-Z\s]", "", texto).title()


def _apenas_digitos(valor: Any, tamanho: Optional[int] = None) -> str:
    if valor in (None, ""):
        return ""
    digitos = "".join(filter(str.isdigit, str(valor)))
    return digitos.zfill(tamanho) if tamanho and digitos else digitos


def _limpar_texto_simples(valor: Any) -> str:
    return str(valor).strip() if valor not in (None, "") else ""


LIMPADORES = {
    "email_master": _limpar_email,
    "nome_completo": _limpar_nome,
    "cpf": lambda v: _apenas_digitos(v, 11),
    "celular": lambda v: _apenas_digitos(v),
    "razao_social": _limpar_texto_simples,
    "cnpj": lambda v: _apenas_digitos(v, 14),
    "susep": lambda v: _apenas_digitos(v),
    "senha": _limpar_texto_simples,
}


def _mapear_colunas(valores_linha: Tuple[Any, ...]) -> Dict[int, str]:
    """Mapeia índice_da_coluna (1-based) -> campo do Usuario, lendo o cabeçalho pelo NOME."""
    mapa: Dict[int, str] = {}
    for idx, valor in enumerate(valores_linha, start=1):
        campo = COLUNAS_ESPERADAS.get(_normalizar_chave(valor))
        if campo:
            mapa[idx] = campo
    return mapa


def _linha_e_marcador_de_fim(valores: Dict[str, Any]) -> bool:
    if not any(v not in (None, "") for v in valores.values()):
        return True  # linha totalmente vazia
    referencia = _normalizar_chave(valores.get("email_master") or valores.get("nome_completo") or "")
    return referencia in MARCADORES_FIM


def ler_planilha_cadastro(caminho_arquivo: str) -> Tuple[List[Usuario], List[Dict[str, Any]]]:
    """
    Lê a planilha de cadastro (.xlsx) anexada ao chamado.

    :return: (usuarios_validos, linhas_invalidas)
        - usuarios_validos: lista de 'Usuario' prontos para o cadastro no UPM.
        - linhas_invalidas: [{"linha": n, "motivo": [...campos...], "dados": {...}}]
          para log/auditoria das linhas ignoradas por dado obrigatório faltando.
    """
    usuarios: List[Usuario] = []
    linhas_invalidas: List[Dict[str, Any]] = []

    workbook = openpyxl.load_workbook(caminho_arquivo, data_only=True)
    planilha = workbook.active

    mapa_colunas: Dict[int, str] = {}
    linha_dados_inicio: Optional[int] = None

    # Localiza o cabeçalho dinamicamente nas primeiras linhas (não depende de posição fixa)
    limite_busca_cabecalho = min(planilha.max_row, 10)
    for linha_cells in planilha.iter_rows(min_row=1, max_row=limite_busca_cabecalho):
        candidato = _mapear_colunas(tuple(c.value for c in linha_cells))
        if len(candidato) >= len(CAMPOS_OBRIGATORIOS):
            mapa_colunas = candidato
            linha_dados_inicio = linha_cells[0].row + 1
            break

    if not mapa_colunas or linha_dados_inicio is None:
        logger.warning(f"⚠️ [PlanilhaCadastro] Não foi possível localizar o cabeçalho esperado em '{caminho_arquivo}'.")
        return usuarios, linhas_invalidas

    logger.info(f"📊 [PlanilhaCadastro] Cabeçalho mapeado dinamicamente (coluna->campo): {mapa_colunas}")

    for linha_cells in planilha.iter_rows(min_row=linha_dados_inicio, max_row=planilha.max_row):
        num_linha = linha_cells[0].row
        valores_brutos = {
            campo: linha_cells[idx - 1].value
            for idx, campo in mapa_colunas.items()
            if idx - 1 < len(linha_cells)
        }

        if _linha_e_marcador_de_fim(valores_brutos):
            break  # fim dos dados (rodapé/observações/linha vazia)

        valores_limpos = {campo: LIMPADORES.get(campo, _limpar_texto_simples)(valor) for campo, valor in valores_brutos.items()}

        campos_faltando = [campo for campo in CAMPOS_OBRIGATORIOS if not valores_limpos.get(campo)]
        if campos_faltando:
            logger.warning(
                f"⚠️ [PlanilhaCadastro] Linha {num_linha} IGNORADA por dado(s) obrigatório(s) faltando: {campos_faltando}. "
                f"A automação segue normalmente com as próximas linhas."
            )
            linhas_invalidas.append({"linha": num_linha, "motivo": campos_faltando, "dados": valores_brutos})
            continue

        usuarios.append(
            Usuario(
                email_master=valores_limpos.get("email_master", ""),
                nome_completo=valores_limpos.get("nome_completo", ""),
                cpf=valores_limpos.get("cpf", ""),
                celular=valores_limpos.get("celular", ""),
                razao_social=valores_limpos.get("razao_social", ""),
                cnpj=valores_limpos.get("cnpj", ""),
                susep=valores_limpos.get("susep", ""),
                senha=valores_limpos.get("senha", ""),
                linha=num_linha,
            )
        )

    logger.info(
        f"✅ [PlanilhaCadastro] {len(usuarios)} usuário(s) válido(s) | "
        f"{len(linhas_invalidas)} linha(s) ignorada(s) em '{caminho_arquivo}'."
    )
    return usuarios, linhas_invalidas

# -*- coding: utf-8 -*-
"""
Assembles the full dashboard HTML - visual language ported directly from the
reference "relatorio_email.html" template (soft card style, colored KPI
top-borders, gradient section headers) with SCTASK (blue) and INC (red)
kept in clearly separated, parallel sections, plus compact "smart card"
panels for critical/SLA-breaching tickets instead of long raw tables.
"""
import logging
import pandas as pd
from datetime import datetime
from .config import QC, Colors
from . import metrics as m
from . import charts as c

logger = logging.getLogger("report_builder")

CSS = """
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px 10px; }
        .email-container { max-width: 1300px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .header { background-color: #0B1E40; color: #ffffff; padding: 18px 20px; text-align: center; }
        .header h2 { margin: 0 0 6px 0; font-size: 22px; letter-spacing: 0.3px; }
        .header p { margin: 0; color: #9BBAD2; font-size: 13px; }
        .content { padding: 22px; }
        .kpi-container { width: 100%; margin-bottom: 22px; }
        .kpi-card { border: 1px solid #dddddd; border-radius: 6px; background-color: #fcfcfc; padding: 14px 8px; text-align: center; border-top: 4px solid #329EF4; }
        .kpi-card.blue { border-top-color: #329EF4; }
        .kpi-card.green { border-top-color: #649f40; }
        .kpi-card.red { border-top-color: #EB1E77; }
        .kpi-card.orange { border-top-color: #ff9800; }
        .kpi-card.purple { border-top-color: #9b59b6; }
        .kpi-title { color: #888888; font-size: 11px; text-transform: uppercase; font-weight: bold; margin-bottom: 6px; letter-spacing: 0.3px; }
        .kpi-value { color: #333333; font-size: 26px; font-weight: bold; margin-bottom: 4px; }
        .kpi-subtitle { font-size: 11px; color: #999999; }
        .kpi-trend-up { color: #EB1E77; font-weight: bold; }
        .kpi-trend-down { color: #649f40; font-weight: bold; }
        .stat-card { border: 1px solid #eeeeee; border-radius: 6px; background-color: #fcfcfc; padding: 12px 8px; text-align: center; border-top: 3px solid #cccccc; }
        .stat-card.warn { border-top-color: #ff9800; }
        .stat-card.danger { border-top-color: #EB1E77; }
        .stat-card.info { border-top-color: #329EF4; }
        .stat-card.flat { border: 1px solid #e0e0e0; border-top: 1px solid #e0e0e0; background-color: #fafafa; }
        .stat-title { color: #888888; font-size: 10px; text-transform: uppercase; font-weight: bold; margin-bottom: 5px; }
        .stat-value { color: #333333; font-size: 22px; font-weight: bold; }
        .stat-subtitle { font-size: 10px; color: #999999; margin-top: 3px; }
        .chart-card-full { border: 1px solid #eeeeee; border-radius: 6px; padding: 15px; margin-bottom: 18px; text-align: center; background-color: #ffffff; }
        .chart-title { color: #585858; font-size: 13px; font-weight: bold; text-transform: uppercase; margin-bottom: 10px; text-align: left; border-bottom: 1px solid #f4f4f4; padding-bottom: 8px; }
        .chart-img { max-width: 100%; height: auto; display: block; margin: 0 auto; }
        .grid-cell { border: 1px solid #eeeeee; border-radius: 6px; padding: 12px; background-color: #ffffff; vertical-align: top; }
        .data-table { width: 100%; border-collapse: collapse; font-size: 12px; color: #333333; }
        .data-table th { background-color: #f4f4f4; color: #585858; font-weight: bold; padding: 7px; border: 1px solid #dddddd; text-align: center; }
        .data-table td { padding: 6px; border: 1px solid #dddddd; text-align: center; }
        .data-table tr:nth-child(even) { background-color: #fcfcfc; }
        .data-table .total-row { font-weight: bold; background-color: #e2e8f0; font-size: 13px; }
        .text-left { text-align: left !important; }
        .table-note { font-size: 11px; color: #999999; text-align: right; margin-top: 6px; font-style: italic; }
        .section-divider { border: none; border-top: 2px solid #e8ecf0; margin: 26px 0 20px 0; }
        .section-header { background: linear-gradient(135deg, #0B1E40 0%, #1a3a6b 100%); color: #ffffff; padding: 11px 16px; border-radius: 6px; margin-bottom: 15px; font-size: 14px; font-weight: bold; text-transform: uppercase; letter-spacing: 0.5px; }
        .section-header.req { background: linear-gradient(135deg, #1565C0 0%, #1976D2 100%); }
        .section-header.inc { background: linear-gradient(135deg, #B71C1C 0%, #C62828 100%); }
        .section-header.prb { background: linear-gradient(135deg, #4A148C 0%, #6A1B9A 100%); }
        .sub-header { color: #585858; font-size: 12px; font-weight: bold; text-transform: uppercase; margin: 16px 0 10px 0; letter-spacing: 0.3px; }
        .mini-kpi-row { margin-bottom: 14px; }
        .mini-kpi { display: inline-block; background-color: #f8f9fa; border: 1px solid #dee2e6; border-radius: 4px; padding: 6px 14px; margin-right: 8px; margin-bottom: 6px; font-size: 11px; color: #555; }
        .mini-kpi strong { font-size: 15px; color: #222; display: block; }
        .footer { text-align: center; padding: 15px; font-size: 12px; color: #888888; background-color: #f4f4f4; border-top: 1px solid #dddddd; }
        @media only screen and (max-width: 768px) {
            body { padding: 8px 4px !important; }
            .content { padding: 12px !important; }
            .header { padding: 14px !important; }
            .header h2 { font-size: 18px !important; }
            .responsive-td-3 { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-bottom: 15px !important; }
            .grid-cell { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-bottom: 15px !important; }
            .spacer-hide-mobile { display: none !important; }
            .kpi-responsive-td { display: block !important; width: 100% !important; box-sizing: border-box !important; padding: 0 0 12px 0 !important; }
            .kpi-spacer { display: none !important; }
            .kpi-value { font-size: 22px !important; }
            .stat-value { font-size: 18px !important; }
            .mini-kpi { display: block !important; width: 100% !important; box-sizing: border-box !important; margin-right: 0 !important; }
            .data-table { font-size: 11px !important; }
            .chart-title { font-size: 12px !important; }
        }
"""


# ---------------------------------------------------------------------------
# Generic layout helpers - EVERY visual property is set as an inline style
# attribute directly on each element, not just via the <style> block above.
#
# Why: Outlook's HTMLBody/MAPI pipeline (used by smtp.py through win32com)
# is known to drop or mangle <style> blocks - especially compound class
# selectors like ".kpi-card.blue" - so cards can render with zero styling
# (exactly the "cards have no color" symptom). Inline styles survive that
# pipeline reliably. The class="..." attributes are kept too, purely as a
# progressive enhancement for clients that DO honor <style> + @media
# (Outlook Mobile/Mac/Web, Gmail, Apple Mail, etc.) - Outlook Windows
# desktop will just use the inline baseline, which already looks correct.
# ---------------------------------------------------------------------------
KPI_BORDER = {"blue": "#329EF4", "green": "#649f40", "red": "#EB1E77",
              "orange": "#ff9800", "purple": "#9b59b6", "": "#329EF4"}
STAT_BORDER = {"warn": "#ff9800", "danger": "#EB1E77", "info": "#329EF4",
               "flat": "#e0e0e0", "": "#cccccc"}
SECTION_BG = {"req": "#1976D2", "inc": "#C62828", "prb": "#6A1B9A", "uam": "#00695C", "": "#0B1E40"}

# Each numbered section of the report gets its own color, used for both
# the section header badge and the table-of-contents entry - gives the
# whole report a clear, professional "chapter" structure at a glance.
SECTION_TOC = [
    (1, "SCTASK \u2014 Service Requests", "#1976D2", "\U0001F6E0\ufe0f"),
    (2, "INC \u2014 Incidents", "#C62828", "\U0001F6A8"),
    (3, "Distribution & SLA", "#7B1FA2", "\U0001F4CA"),
    (4, "Status & Aging", "#EF6C00", "\u23F3"),
    (5, "UAM \u2014 User Access Management", "#00695C", "\U0001F510"),
    (6, "Daily Evolution & Trend", "#283593", "\U0001F4C8"),
    (7, "Monthly Evolution & Trend", "#0277BD", "\U0001F5D3\ufe0f"),
    (8, "Monthly Tracking Table", "#37474F", "\U0001F4CB"),
    (9, "Cross-Type Conversions", "#AD1457", "\U0001F504"),
]
SECTION_COLOR_BY_NUM = {n: color for n, _, color, _ in SECTION_TOC}

# Two-tier "big card" style used ONLY for the main Overview KPI row (a light
# gray icon/label header strip, then a tinted, color-matched body) - every
# other card in the report (critical panel stats, mini-kpi badges, trend
# panel stats) intentionally keeps the simpler single-tone card style.
KPI_CARD_STYLE = {
    "blue": {"border": "#0B1E40", "body_bg": Colors.PRIMARY_LIGHT, "value_color": "#0B1E40"},
    "orange": {"border": "#E67E22", "body_bg": Colors.ORANGE_LIGHT, "value_color": "#E67E22"},
    "red": {"border": "#C0392B", "body_bg": Colors.DANGER_LIGHT, "value_color": "#C0392B"},
    "purple": {"border": "#6A1B9A", "body_bg": Colors.PURPLE_LIGHT, "value_color": "#6A1B9A"},
    "green": {"border": "#27AE60", "body_bg": Colors.SUCCESS_LIGHT, "value_color": "#27AE60"},
    "": {"border": "#0B1E40", "body_bg": Colors.PRIMARY_LIGHT, "value_color": "#0B1E40"},
}

FONT_STACK = "Arial, Helvetica, sans-serif"


def _labels_with_pct(names, values, name_limit=20):
    """Turns ['Alice', 'Bob'], [18, 13] into ['Alice | 18 (58.1%)', 'Bob | 13 (41.9%)']
    - the richer bar-chart label style used throughout the reference
    dashboard (name/bucket + raw count + share of the total). The name
    portion is truncated FIRST so the "| count (pct%)" suffix always
    survives the chart library's own label-length limit downstream."""
    total = sum(values) or 1
    out = []
    for n, v in zip(names, values):
        n = str(n)
        short = n[:name_limit] + "\u2026" if len(n) > name_limit else n
        out.append(f"{short} | {v} ({v / total * 100:.1f}%)")
    return out


def kpi_row(cards):
    """cards: list of (color_class, icon, title, value, subtitle_html).
    Renders the reference "big card" look: a neutral light-gray header
    strip (icon + label) on top, and a color-tinted body below holding the
    large value and subtitle, all wrapped in a single color-matched border.
    Both rows get an explicit, fixed height (HTML attribute + inline CSS,
    for Outlook) so every card in the row is exactly the same height
    regardless of how long its title/subtitle text happens to be - a
    longer subtitle no longer stretches just that one card taller than
    its neighbors."""
    n = len(cards)
    spacer_total = (n - 1) * 2
    card_w = (100 - spacer_total) / n
    cells = []
    for i, (color_class, icon, title, value, subtitle) in enumerate(cards):
        style = KPI_CARD_STYLE.get(color_class, KPI_CARD_STYLE[""])
        cells.append(f"""<td width="{card_w:.1f}%" class="kpi-responsive-td" style="padding:0 6px 12px 6px;">
            <table width="100%" height="128" cellpadding="0" cellspacing="0" border="0" class="kpi-card {color_class}"
                   style="border:1.5px solid {style['border']}; border-radius:6px; border-collapse:separate; height:128px;">
                <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:{Colors.GRAY_LIGHT}; padding:0 12px; border-bottom:1px solid {style['border']}; border-radius:5px 5px 0 0; font-family:{FONT_STACK};">
                    <span class="kpi-title" style="color:#37474F; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.3px; font-family:{FONT_STACK};">{icon}&nbsp; {title}</span>
                </td></tr>
                <tr><td align="center" valign="middle" height="92" style="height:92px; background-color:{style['body_bg']}; padding:8px 10px; border-radius:0 0 5px 5px; font-family:{FONT_STACK};">
                    <div class="kpi-value" style="color:{style['value_color']}; font-size:30px; font-weight:bold; margin-bottom:6px; font-family:{FONT_STACK}; line-height:1.1;">{value}</div>
                    <div class="kpi-subtitle" style="font-size:11px; color:#5a6b78; font-family:{FONT_STACK}; line-height:1.3;">{subtitle}</div>
                </td></tr>
            </table>
        </td>""")
        if i < n - 1:
            cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
    return f'<table class="kpi-container" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:20px;"><tr>{"".join(cells)}</tr></table>'


def stat_row(cards):
    """Small stat cards (compact critical panel). cards: list of
    (modifier_class, title, value, subtitle). Fixed height (HTML attribute
    + inline CSS, for Outlook) so a title that wraps to two lines (e.g.
    "Closed Incomplete", "Net Balance") doesn't make that one card taller
    than its neighbors in the same row."""
    n = len(cards)
    spacer_total = (n - 1) * 2
    card_w = (100 - spacer_total) / n
    cells = []
    for i, (mod, title, value, subtitle) in enumerate(cards):
        border = STAT_BORDER.get(mod, "#cccccc")
        bg = "#fafafa" if mod == "flat" else "#fcfcfc"
        cells.append(f"""<td width="{card_w:.1f}%" class="kpi-responsive-td" style="padding:0 6px 12px 6px;">
            <table width="100%" height="104" cellpadding="0" cellspacing="0" border="0" class="stat-card {mod}"
                   style="border:1px solid #eeeeee; border-top:3px solid {border}; border-radius:6px; background-color:{bg}; height:104px;">
                <tr><td align="center" valign="middle" height="104" style="height:104px; padding:8px 8px; font-family:{FONT_STACK};">
                    <div class="stat-title" style="color:#888888; font-size:10px; text-transform:uppercase; font-weight:bold; margin-bottom:5px; font-family:{FONT_STACK}; line-height:1.25;">{title}</div>
                    <div class="stat-value" style="color:#333333; font-size:22px; font-weight:bold; font-family:{FONT_STACK}; line-height:1.1;">{value}</div>
                    <div class="stat-subtitle" style="font-size:10px; color:#999999; margin-top:3px; font-family:{FONT_STACK}; line-height:1.25;">{subtitle}</div>
                </td></tr>
            </table>
        </td>""")
        if i < n - 1:
            cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
    return f'<table class="kpi-container" width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:14px;"><tr>{"".join(cells)}</tr></table>'


def section_header(text, css_class="", number=None):
    """Section title bar. When `number` is given, renders a small circular
    white badge with that number before the title, and uses that section's
    dedicated color (SECTION_COLOR_BY_NUM) instead of the generic css_class
    color - gives every numbered section of the report its own identity,
    consistent with the table-of-contents entry for the same number."""
    bg = SECTION_COLOR_BY_NUM.get(number, SECTION_BG.get(css_class, "#0B1E40"))
    if number is not None:
        badge = (f'<td width="42" valign="middle" style="padding:11px 0 11px 14px;">'
                  f'<table cellpadding="0" cellspacing="0" border="0"><tr>'
                  f'<td width="26" height="26" align="center" valign="middle" '
                  f'style="width:26px; height:26px; min-width:26px; background-color:#ffffff; border-radius:13px; '
                  f'color:{bg}; font-size:13px; font-weight:bold; font-family:{FONT_STACK};">{number}</td>'
                  f'</tr></table></td>')
        title_pad = "11px 16px 11px 8px"
    else:
        badge = ""
        title_pad = "11px 16px"
    return (f'<table width="100%" cellpadding="0" cellspacing="0" border="0" class="section-header {css_class}" '
            f'style="margin-bottom:15px;"><tr><td style="background-color:{bg}; border-radius:6px;">'
            f'<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>{badge}'
            f'<td valign="middle" style="color:#ffffff; padding:{title_pad}; '
            f'font-size:14px; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; '
            f'font-family:{FONT_STACK};">{text}</td>'
            f'</tr></table></td></tr></table>')


def sub_header(text):
    return (f'<div class="sub-header" style="color:#585858; font-size:12px; font-weight:bold; text-transform:uppercase; '
            f'margin:16px 0 10px 0; letter-spacing:0.3px; font-family:{FONT_STACK};">{text}</div>')


def chart_card(title, img_url):
    """Chart title + image. The <img> gets an explicit width="100%" HTML
    attribute (not just CSS) - Outlook's Word engine largely ignores
    max-width:100% unless the width attribute is also present, which is
    why charts were rendering at native/oversized pixel dimensions and
    overflowing their container instead of shrinking to fit."""
    return (f'<div class="chart-title" style="color:#585858; font-size:13px; font-weight:bold; text-transform:uppercase; '
            f'margin-bottom:10px; text-align:left; border-bottom:1px solid #f4f4f4; padding-bottom:8px; '
            f'font-family:{FONT_STACK};">{title}</div>'
            f'<img class="chart-img" src="{img_url}" width="100%" '
            f'style="max-width:100%; width:100%; height:auto; display:block; margin:0 auto; border:0;">')


def grid_row(cells, widths=None):
    """cells: list of inner-HTML strings, each wrapped in a card-styled cell.

    table-layout:fixed is required here: these cells hold chart <img>s whose
    real embedded pixel size (base64-embedded, so fully known at layout
    time - unlike a remote URL the client fetches lazily) is much larger
    than the intended display size (e.g. 840x560 for a chart meant to show
    at ~300px). Under the default table-layout:auto, that intrinsic image
    size drives the column's preferred width, which blows way past its
    declared width="X%" and collapses the row into stacked, oversized
    charts instead of a clean side-by-side grid. Fixed layout makes the
    browser honor the declared percentages unconditionally."""
    n = len(cells)
    if widths is None:
        spacer_total = (n - 1) * 2
        w = (100 - spacer_total) / n
        widths = [w] * n
    html = '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 18px; table-layout: fixed;"><tr>'
    for i, content in enumerate(cells):
        html += (f'<td width="{widths[i]:.1f}%" class="grid-cell responsive-td-3" valign="top" '
                 f'style="border:1px solid #eeeeee; border-radius:6px; padding:12px; background-color:#ffffff;">{content}</td>')
        if i < n - 1:
            html += '<td width="2%" class="spacer-hide-mobile">&nbsp;</td>'
    html += "</tr></table>"
    return html


def mini_kpi_row(items):
    """Small badge row - ALL items in a single, unbroken row (no wrapping),
    each as its own bordered/colored mini-card. Uses a <table> of cells,
    NOT inline <span> pills: Outlook's Word engine reliably ignores
    border/padding/background-color on inline elements like <span>, which
    is exactly why these were rendering as unstyled, run-together text."""
    n = len(items)
    if n == 0:
        return ""
    cells = []
    for label, value in items:
        cells.append(f"""<td style="padding:0 4px 10px 0;">
            <table cellpadding="0" cellspacing="0" border="0" style="background-color:#eef3fb; border:1px solid #b8cbe8; border-radius:5px;">
                <tr><td style="padding:8px 16px; font-family:{FONT_STACK};">
                    <div style="font-size:11px; color:#5a6b8c; white-space:nowrap; font-weight:bold; text-transform:uppercase; letter-spacing:0.3px;">{label}</div>
                    <div style="font-size:18px; color:#0B1E40; font-weight:bold; white-space:nowrap;">{value}</div>
                </td></tr>
            </table>
        </td>""")
    return (f'<table class="mini-kpi-row" cellpadding="0" cellspacing="0" border="0" '
            f'style="margin-bottom:14px;"><tr>{"".join(cells)}</tr></table>')


def full_width_card(title, img_url):
    return (f'<div class="chart-card-full" style="border:1px solid #eeeeee; border-radius:6px; padding:15px; '
            f'margin-bottom:18px; text-align:center; background-color:#ffffff;">{chart_card(title, img_url)}</div>')


def two_col_row(left_html, right_html, widths=(49, 49)):
    # table-layout:fixed - same reasoning as grid_row() above.
    return (f'<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom: 18px; table-layout: fixed;"><tr>'
            f'<td width="{widths[0]}%" valign="top" class="responsive-td-3" style="padding-right:8px;">{left_html}</td>'
            f'<td width="2%" class="spacer-hide-mobile">&nbsp;</td>'
            f'<td width="{widths[1]}%" valign="top" class="responsive-td-3" style="padding-left:8px;">{right_html}</td>'
            f'</tr></table>')


# ---------------------------------------------------------------------------
# Data tables
# ---------------------------------------------------------------------------
def data_table(df, header_bg="#2C5AA0", header_color="#ffffff", show_totals=False,
                empty_message="No data available for this period."):
    if df is None or df.empty:
        return (f"<div style='padding:14px; color:{Colors.SUCCESS}; background-color:{Colors.SUCCESS_LIGHT}; "
                f"text-align:center; font-weight:bold; border:1px solid {Colors.SUCCESS}; border-radius:4px; "
                f"font-size:12px; font-family:{FONT_STACK};'>&#10003; {empty_message}</div>")

    html = (f"<table class='data-table' width='100%' cellpadding='0' cellspacing='0' border='0' "
            f"style='border-collapse:collapse; font-size:12px; color:#333333; font-family:{FONT_STACK};'>"
            f"<thead><tr>")
    for i, col in enumerate(df.columns):
        html += (f"<th style='background-color:{header_bg}; color:{header_color}; font-weight:bold; padding:7px; "
                 f"border:1px solid #dddddd; text-align:center;'>{col}</th>")
    html += "</tr></thead><tbody>"
    for r, (_, row) in enumerate(df.iterrows()):
        row_bg = "#dce8f7" if r % 2 == 0 else "#ffffff"
        html += f"<tr style='background-color:{row_bg};'>"
        for j, val in enumerate(row):
            align = "left" if j == 0 else "center"
            html += f"<td style='padding:6px; border:1px solid #c8d6ea; text-align:{align};'>{val}</td>"
        html += "</tr>"
    html += "</tbody></table>"
    return html


def monthly_table_with_totals(df, css_scope="req", secondary_label="Cancelled"):
    if df.empty:
        return data_table(df)
    header_colors = {"req": "#1976D2", "inc": "#C62828", "uam": "#00695C"}
    header_bg = header_colors.get(css_scope, "#263238")
    render = df.copy()
    render["NetFlow"] = render["Opened"] - render["Resolved"] - render["Secondary"]
    rows = ""
    for i, (_, r) in enumerate(render.iterrows()):
        sign = "+" if r["NetFlow"] > 0 else ""
        color = "#EB1E77" if r["NetFlow"] > 0 else ("#649f40" if r["NetFlow"] < 0 else "#585858")
        row_bg = "#dce8f7" if i % 2 == 0 else "#ffffff"
        rows += (f"<tr style='background-color:{row_bg};'>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:left;'>{r['Month']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{r['Opened']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{r['Resolved']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{r['Secondary']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center; color:{color}; font-weight:bold;'>{sign}{r['NetFlow']}</td>"
                 f"<td style='padding:6px; border:1px solid #dddddd; text-align:center; font-weight:bold;'>{r['BacklogAccum']}</td></tr>")
    tot_o, tot_r, tot_s, tot_n = render["Opened"].sum(), render["Resolved"].sum(), render["Secondary"].sum(), render["NetFlow"].sum()
    last_backlog = render["BacklogAccum"].iloc[-1]
    sign_t = "+" if tot_n > 0 else ""
    color_t = "#EB1E77" if tot_n > 0 else ("#649f40" if tot_n < 0 else "#585858")
    rows += (f"<tr style='background-color:#e2e8f0; font-weight:bold; font-size:13px;'>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:left;'>TOTAL</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{tot_o}</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{tot_r}</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{tot_s}</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center; color:{color_t};'>{sign_t}{tot_n}</td>"
             f"<td style='padding:6px; border:1px solid #dddddd; text-align:center;'>{last_backlog}</td></tr>")

    return (f"<table class='data-table' width='100%' cellpadding='0' cellspacing='0' border='0' "
            f"style='border-collapse:collapse; font-size:12px; font-family:{FONT_STACK};'><thead><tr>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd; text-align:left;'>Month</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Opened</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Resolved</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>{secondary_label}</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Net Flow</th>"
            f"<th style='background-color:{header_bg}; color:#fff; padding:7px; border:1px solid #dddddd;'>Backlog</th>"
            f"</tr></thead><tbody>{rows}</tbody></table>")


def critical_panel(open_df, ticket_type_label, threshold, extra_threshold, id_cols,
                    compact_rows=6, accent="danger", extra_cols=None):
    summary = m.critical_summary(open_df, threshold, extra_threshold)

    cards = [
        (accent, f"Aging {threshold}+ days", summary["count"], "tickets need attention"),
    ]
    if extra_threshold:
        cards.append((accent, f"Aging {extra_threshold}+ days", summary["count_extra"], "extra-critical"))
    cards.append(("warn", "Oldest Ticket", f"{summary['oldest_days']}d",
                   summary["oldest_number"] if summary["oldest_number"] != "\u2014" else "\u2014"))
    cards.append(("info", "Avg. Aging (critical)", f"{summary['avg_days']}d", "days open, on average"))

    panel = stat_row(cards)

    if summary["count"] == 0:
        panel += data_table(pd.DataFrame(), empty_message=f"No {ticket_type_label} above the aging threshold.")
        return panel

    crit = m.critical_table(open_df, threshold, top_n=compact_rows)
    render = crit.copy()
    render["Opened"] = render["Opened"].dt.strftime("%d/%m/%Y")

    extra_cols = extra_cols or []
    rename_map = {"AgingDays": "Aging (d)"}
    for col in extra_cols:
        if col not in render.columns:
            render[col] = ""
        render[col] = render[col].replace("", "\u2014").fillna("\u2014")
    if "On hold reason" in extra_cols:
        # Only meaningful for rows actually On Hold - blank it out everywhere
        # else so the column doesn't imply a reason that doesn't apply.
        render.loc[render["State"].str.lower() != "on hold", "On hold reason"] = "\u2014"
        rename_map["On hold reason"] = "On Hold Reason"
    if "Problem" in extra_cols:
        rename_map["Problem"] = "Linked Problem"

    cols = ["Number"] + id_cols + ["State"] + extra_cols + ["Opened", "AgingDays"]
    render = render[cols].rename(columns=rename_map)
    panel += data_table(render)

    if summary["count"] > compact_rows:
        panel += (f"<div class='table-note' style='font-size:11px; color:#999999; text-align:right; "
                   f"margin-top:6px; font-style:italic; font-family:{FONT_STACK};'>"
                   f"+ {summary['count'] - compact_rows} additional critical "
                   f"{ticket_type_label} not shown here (see the full export for details).</div>")
    return panel


# ---------------------------------------------------------------------------
# Parallel SCTASK / INC section builder (shared structure, type-specific colors)
# ---------------------------------------------------------------------------
def build_ticket_type_section(df, ref, config, *, ticket_type, css_class, label,
                                donut_colors, bar_color, bar_color_soft, requester_col,
                                id_cols, critical_threshold, extra_critical=None, number=None):
    sla_days = config["SLA_DAYS"][ticket_type]
    open_df = m.add_open_aging(df, ref, sla_days)

    # This is a day-to-day operations snapshot: "Opened/Resolved" only ever
    # look at the current month, and the backlog counts are always the LIVE
    # open queue - never an all-time total of closed tickets.
    opened_month, resolved_month = m.current_month_flow(df, ref)
    backlog = len(open_df)
    mttr = round(m.mttr_days_month(df, ref), 1)
    inside, outside = m.sla_inside_outside(open_df)

    html = section_header(label, css_class, number=number)
    html += mini_kpi_row([
        ("Open Backlog", backlog), ("Inside SLA", inside), ("Outside SLA", outside),
        ("Opened (month)", opened_month), ("Resolved (month)", resolved_month),
        ("MTTR (month)", f"{mttr}d"),
    ])

    html += sub_header(f"Critical {ticket_type}s")
    inc_extra_cols = ["On hold reason", "Problem"] if ticket_type == "INC" else []
    html += critical_panel(open_df, ticket_type, critical_threshold, extra_critical,
                             id_cols, config["CRITICAL_TABLE_COMPACT_ROWS"],
                             accent="danger", extra_cols=inc_extra_cols)

    return html, open_df


# ---------------------------------------------------------------------------
# Combined Distribution & SLA section (1A/1B donuts + both SLA pies together)
# ---------------------------------------------------------------------------
def build_distribution_sla_section(open_sctask, open_inc, config):
    an_s_l, an_s_v = m.top_analysts(open_sctask, config["TOP_N_ANALYSTS"])
    an_i_l, an_i_v = m.top_analysts(open_inc, config["TOP_N_ANALYSTS"])
    # Varied, easy-to-tell-apart palette (a single-hue gradient makes
    # similarly-sized slices/bars indistinguishable at a glance).
    img_an_s = c.donut(an_s_l, an_s_v, QC["varied"], center_color="#1976D2")
    img_an_i = c.donut(an_i_l, an_i_v, QC["varied"], center_color="#C62828")

    in_s, out_s = m.sla_inside_outside(open_sctask)
    in_i, out_i = m.sla_inside_outside(open_inc)
    img_sla_s = c.sla_pie(in_s, out_s, center_color="#1976D2")
    img_sla_i = c.sla_pie(in_i, out_i, center_color="#C62828")

    top_html = section_header("Distribution & SLA (Donut / Pie Charts)", number=3) + grid_row([
        chart_card("Top Analysts - SCTASK", img_an_s),
        chart_card("Top Analysts - INC", img_an_i),
        chart_card("SCTASK: Inside vs Outside SLA", img_sla_s),
        chart_card("INC: Inside vs Outside SLA", img_sla_i),
    ])

    # ---- Top Analysts ranking (bar view): combined SCTASK+INC, plus each
    # type on its own, every bar a different color from the varied palette.
    # Every label carries "name | count (pct%)" for richer at-a-glance detail.
    names, sctask_vals, inc_vals = m.top_analysts_combined(open_sctask, open_inc, config["TOP_N_ANALYSTS"])
    combined_totals = [s + i for s, i in zip(sctask_vals, inc_vals)]
    names_pct = _labels_with_pct(names, combined_totals)
    img_combined = c.stacked_horizontal_bar(names_pct, sctask_vals, inc_vals, "SCTASK", "INC",
                                              QC["blue"], QC["red"],
                                              title=f"TOTAL TICKETS PER ANALYST: {sum(sctask_vals) + sum(inc_vals)}",
                                              w=560, h=340)
    img_bar_s = c.horizontal_bar_varied(_labels_with_pct(an_s_l, an_s_v), an_s_v, QC["varied"], w=460, h=320)
    img_bar_i = c.horizontal_bar_varied(_labels_with_pct(an_i_l, an_i_v), an_i_v, QC["varied"], w=460, h=320)

    bottom_html = sub_header("Top Analysts Ranking (Bar View)") + grid_row([
        chart_card("Top Analysts (SCTASK + INC Combined)", img_combined),
        chart_card("Top Analysts - SCTASK (Bar View)", img_bar_s),
        chart_card("Top Analysts - INC (Bar View)", img_bar_i),
    ], widths=[34, 33, 33])

    return top_html + bottom_html


# ---------------------------------------------------------------------------
# Combined Status & Aging section (3A/3B aging bars + both status bars)
# ---------------------------------------------------------------------------
def build_status_aging_section(open_sctask, open_inc, config):
    aging_s = m.aging_bucket_table(open_sctask, "SCTASK")
    aging_i = m.aging_bucket_table(open_inc, "INC")
    img_aging_s = c.horizontal_bar_scale(_labels_with_pct(aging_s["Bucket"], aging_s["Count"]), aging_s["Count"])
    img_aging_i = c.horizontal_bar_scale(_labels_with_pct(aging_i["Bucket"], aging_i["Count"]), aging_i["Count"])

    st_s_l, st_s_v = m.status_distribution(open_sctask, config["TOP_N_ANALYSTS"])
    st_i_l, st_i_v = m.status_distribution(open_inc, config["TOP_N_ANALYSTS"])
    img_st_s = c.horizontal_bar(_labels_with_pct(st_s_l, st_s_v), st_s_v, QC["blue_a"])
    img_st_i = c.horizontal_bar(_labels_with_pct(st_i_l, st_i_v), st_i_v, QC["red_a"])

    return section_header("Status & Aging of Open Tickets (Bar Charts)", number=4) + grid_row([
        chart_card("Aging Detail - SCTASK", img_aging_s),
        chart_card("Aging Detail - INC", img_aging_i),
        chart_card("SCTASK: Status (Open)", img_st_s),
        chart_card("INC: Status (Open)", img_st_i),
    ])


# ---------------------------------------------------------------------------
# Side-by-side trend comparison panels (SCTASK vs INC) - styled to match the
# reference screenshot exactly: colored top border per panel, bold colored
# title, 3 plain stat boxes (Opened / Closed / Net Balance) and a rich
# dual-axis chart with datalabels on both the bars and the line.
# ---------------------------------------------------------------------------
def build_trend_panel(number_label, ticket_type, df_metrics, border_color, title_color,
                        color_opened, color_closed, color_line, line_label, current_backlog=None,
                        w=780, h=340):
    label_col = "Month" if "Month" in df_metrics.columns else "Date"
    total_opened = int(df_metrics["Opened"].sum())
    total_closed = int(df_metrics["Resolved"].sum())
    net_balance = total_opened - total_closed
    net_html = (f"<span style='color:#EB1E77;'>+{net_balance}</span>" if net_balance > 0
                else (f"<span style='color:#649f40;'>{net_balance}</span>" if net_balance < 0
                      else f"<span style='color:#585858;'>0</span>"))

    cards = []
    if current_backlog is not None:
        cards.append(("info", "Current", current_backlog, "open right now"))
    cards += [
        ("flat", "Opened", total_opened, ""),
        ("flat", "Closed", total_closed, ""),
        ("flat", line_label, net_html, ""),
    ]
    stats = stat_row(cards)

    img = c.dual_axis_trend_rich(
        df_metrics[label_col], df_metrics["Opened"], df_metrics["Resolved"], df_metrics["BacklogAccum"],
        color_opened, color_closed, color_line, line_label=line_label, w=w, h=h)

    return f"""
    <div style="border-top: 4px solid {border_color}; border-left: 1px solid #eeeeee; border-right: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee; border-radius: 6px; padding: 16px; background-color:#ffffff;">
        <div style="color:{title_color}; font-size:16px; font-weight:bold; margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #f4f4f4; font-family:{FONT_STACK};">{number_label}. {ticket_type} - Opened / Closed / {line_label}</div>
        {stats}
        <img class="chart-img" src="{img}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; margin-top:14px; border:0;">
    </div>"""


def build_trend_comparison_section(section_title, sctask_metrics, inc_metrics,
                                     label_a, label_b, line_label="Net Balance", css_class="",
                                     layout="side_by_side", sctask_backlog=None, inc_backlog=None):
    if layout == "stacked":
        panel_sctask = build_trend_panel(label_a, "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
                                           QC["blue"], QC["bright_green"], QC["red"], line_label,
                                           current_backlog=sctask_backlog, w=1180, h=380)
        panel_inc = build_trend_panel(label_b, "INC", inc_metrics, "#C62828", "#B71C1C",
                                        QC["coral"], QC["purple"], QC["orange"], line_label,
                                        current_backlog=inc_backlog, w=1180, h=380)
        body = (f'<div style="margin-bottom: 18px;">{panel_sctask}</div>'
                f'<div style="margin-bottom: 18px;">{panel_inc}</div>')
        return section_header(section_title, css_class) + body

    panel_sctask = build_trend_panel(label_a, "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
                                       QC["blue"], QC["bright_green"], QC["red"], line_label,
                                       current_backlog=sctask_backlog)
    panel_inc = build_trend_panel(label_b, "INC", inc_metrics, "#C62828", "#B71C1C",
                                    QC["coral"], QC["purple"], QC["orange"], line_label,
                                    current_backlog=inc_backlog)
    return section_header(section_title, css_class) + two_col_row(panel_sctask, panel_inc)


# ---------------------------------------------------------------------------
# 4-series trend panels (Opened / Resolved / Closed Incomplete-Canceled /
# Accumulated Backlog) - matches the reference dashboard's own daily and
# monthly trend charts exactly, colors included.
# ---------------------------------------------------------------------------
def build_quad_trend_panel(ticket_type, df_metrics, border_color, title_color,
                             color_opened, color_resolved, color_secondary, color_backlog,
                             secondary_label, current_backlog=None, w=780, h=340):
    label_col = "Month" if "Month" in df_metrics.columns else "Date"
    total_opened = int(df_metrics["Opened"].sum())
    total_resolved = int(df_metrics["Resolved"].sum())
    total_secondary = int(df_metrics["Secondary"].sum())
    total_closed = total_resolved + total_secondary
    net_balance = total_opened - total_closed
    net_html = (f"<span style='color:#EB1E77;'>+{net_balance}</span>" if net_balance > 0
                else (f"<span style='color:#649f40;'>{net_balance}</span>" if net_balance < 0
                      else f"<span style='color:#585858;'>0</span>"))

    cards = []
    if current_backlog is not None:
        cards.append(("info", "Current", current_backlog, "open right now"))
    cards += [
        ("flat", "Opened", total_opened, ""),
        ("flat", "Resolved", total_resolved, ""),
        ("flat", secondary_label, total_secondary, ""),
        ("flat", "Net Balance", net_html, ""),
    ]
    stats = stat_row(cards)

    title = f"TOTAL OPENED: {total_opened} | TOTAL CLOSED: {total_closed}"
    img = c.dual_axis_trend_quad(
        df_metrics[label_col], df_metrics["Opened"], df_metrics["Resolved"], df_metrics["Secondary"],
        df_metrics["BacklogAccum"], color_opened, color_resolved, color_secondary, color_backlog,
        secondary_label, title=title, w=w, h=h)

    return f"""
    <div style="border-top: 4px solid {border_color}; border-left: 1px solid #eeeeee; border-right: 1px solid #eeeeee; border-bottom: 1px solid #eeeeee; border-radius: 6px; padding: 16px; background-color:#ffffff;">
        <div style="color:{title_color}; font-size:16px; font-weight:bold; margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #f4f4f4; font-family:{FONT_STACK};">{ticket_type}: Entry x Exit x Accumulated Backlog</div>
        {stats}
        <img class="chart-img" src="{img}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; margin-top:14px; border:0;">
    </div>"""


def build_quad_trend_comparison_section(section_title, sctask_metrics, inc_metrics,
                                          css_class="", layout="side_by_side",
                                          sctask_backlog=None, inc_backlog=None,
                                          uam_metrics=None, uam_backlog=None, number=None):
    w, h = (1180, 380) if layout == "stacked" else (780, 340)
    panel_sctask = build_quad_trend_panel(
        "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
        QC["blue"], QC["navy_dark"], QC["concrete_gray"], QC["backlog_line"],
        m.SECONDARY_LABEL["SCTASK"], current_backlog=sctask_backlog, w=w, h=h)
    panel_inc = build_quad_trend_panel(
        "INC", inc_metrics, "#C62828", "#B71C1C",
        QC["blue"], QC["bright_green"], QC["pink"], QC["backlog_line"],
        m.SECONDARY_LABEL["INC"], current_backlog=inc_backlog, w=w, h=h)

    if layout == "stacked":
        body = (f'<div style="margin-bottom: 18px;">{panel_inc}</div>'
                f'<div style="margin-bottom: 18px;">{panel_sctask}</div>')
        if uam_metrics is not None:
            panel_uam = build_quad_trend_panel(
                "UAM", uam_metrics, "#00695C", "#004D40",
                QC["blue"], QC["mint"], QC["concrete_gray"], QC["backlog_line"],
                m.SECONDARY_LABEL["UAM"], current_backlog=uam_backlog, w=w, h=h)
            body += f'<div style="margin-bottom: 18px;">{panel_uam}</div>'
        return section_header(section_title, css_class, number=number) + body
    return section_header(section_title, css_class, number=number) + two_col_row(panel_sctask, panel_inc)


def build_quad_trend_2x2_section(section_title, sctask_metrics, inc_metrics, uam_metrics, all_metrics,
                                   css_class="", sctask_backlog=None, inc_backlog=None,
                                   uam_backlog=None, all_backlog=None, number=None):
    """4 quad-trend panels (SCTASK, INC, UAM, Combined/All) arranged 2x2 -
    used for the Monthly Evolution & Trend section."""
    w, h = 560, 320
    panel_sctask = build_quad_trend_panel(
        "SCTASK", sctask_metrics, "#1976D2", "#1565C0",
        QC["blue"], QC["navy_dark"], QC["concrete_gray"], QC["backlog_line"],
        m.SECONDARY_LABEL["SCTASK"], current_backlog=sctask_backlog, w=w, h=h)
    panel_inc = build_quad_trend_panel(
        "INC", inc_metrics, "#C62828", "#B71C1C",
        QC["blue"], QC["bright_green"], QC["pink"], QC["backlog_line"],
        m.SECONDARY_LABEL["INC"], current_backlog=inc_backlog, w=w, h=h)
    panel_uam = build_quad_trend_panel(
        "UAM", uam_metrics, "#00695C", "#004D40",
        QC["blue"], QC["mint"], QC["concrete_gray"], QC["backlog_line"],
        m.SECONDARY_LABEL["UAM"], current_backlog=uam_backlog, w=w, h=h)
    panel_all = build_quad_trend_panel(
        "ALL (SCTASK + UAM + INC Combined)", all_metrics, "#263238", "#000000",
        QC["blue"], QC["blue_grey_dark"], QC["pink"], QC["backlog_line"],
        m.SECONDARY_LABEL["ALL"], current_backlog=all_backlog, w=w, h=h)

    body = two_col_row(panel_sctask, panel_inc) + two_col_row(panel_uam, panel_all)
    return section_header(section_title, css_class, number=number) + body


# ---------------------------------------------------------------------------
# Combined Monthly Tracking Table (SCTASK + INC side by side, one section)
# ---------------------------------------------------------------------------
def _throughput_card(title, monthly_df, css_scope, secondary_label):
    return (f'<div class="chart-card-full" style="border:1px solid #eeeeee; border-radius:6px; padding:15px; '
            f'background-color:#ffffff; margin-bottom:0;">'
            f'{_chart_title_div(title)}'
            f'{monthly_table_with_totals(monthly_df, css_scope=css_scope, secondary_label=secondary_label)}</div>')


def build_monthly_tracking_section(monthly_sctask, monthly_inc, monthly_uam=None, monthly_all=None):
    """4 throughput tables (SCTASK, INC, UAM, Combined/All) in a 2x2 grid."""
    card_sctask = _throughput_card("Throughput - SCTASK", monthly_sctask, "req", m.SECONDARY_LABEL["SCTASK"])
    card_inc = _throughput_card("Throughput - INC", monthly_inc, "inc", m.SECONDARY_LABEL["INC"])
    html = section_header("Monthly Tracking Table: Opened x Resolved x Backlog", number=8) + two_col_row(card_sctask, card_inc)

    if monthly_uam is not None and monthly_all is not None:
        card_uam = _throughput_card("Throughput - UAM", monthly_uam, "uam", m.SECONDARY_LABEL["UAM"])
        card_all = _throughput_card("Throughput - ALL (Combined)", monthly_all, "", m.SECONDARY_LABEL["ALL"])
        html += two_col_row(card_uam, card_all)
    elif monthly_uam is not None:
        html += (f'<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top:18px;">'
                 f'<tr><td width="100%" valign="top">{_throughput_card("Throughput - UAM", monthly_uam, "uam", m.SECONDARY_LABEL["UAM"])}</td></tr></table>')
    return html


# ---------------------------------------------------------------------------
# UAM (User Access Management) - tracked completely separately from REQ
# ---------------------------------------------------------------------------
def build_uam_section(df_uam, ref, config):
    sla_days = config["SLA_DAYS"]["SCTASK"]  # UAM is a SCTASK subset, same SLA family
    open_uam = m.add_open_aging(df_uam, ref, sla_days)
    opened_month, resolved_month = m.current_month_flow(df_uam, ref)
    backlog = len(open_uam)

    html = section_header("UAM \u2014 User Access Management (separated from REQ Support)", "uam", number=5)
    html += ('<div style="font-size:11px; color:#999999; margin-bottom:12px;">'
              'SCTASK tickets whose Item matches an access-management catalog entry '
              '(see CONFIG["UAM_ITEM_KEYWORDS"]) - tracked here instead of being folded '
              'into the REQ (Support) numbers above. Its daily/monthly trend charts are '
              'consolidated into the sections below, alongside SCTASK and INC.</div>')
    html += mini_kpi_row([
        ("Open Backlog", backlog), ("Opened (month)", opened_month),
        ("Resolved (month)", resolved_month),
    ])

    monthly_uam = m.monthly_flow_breakdown(df_uam, ref, config["MONTHS_LOOKBACK"], "UAM", backlog)
    return html, open_uam, monthly_uam


# ---------------------------------------------------------------------------
# Cross-type conversions (offenders)
# ---------------------------------------------------------------------------
def _chart_title_div(title):
    return (f'<div class="chart-title" style="color:#585858; font-size:13px; font-weight:bold; '
            f'text-transform:uppercase; margin-bottom:10px; text-align:left; border-bottom:1px solid #f4f4f4; '
            f'padding-bottom:8px; font-family:{FONT_STACK};">{title}</div>')


def breakdown_card(title, labels, values, show_pct=False):
    if not labels:
        return _chart_title_div(title) + data_table(pd.DataFrame(), empty_message="No records this period.")
    total = sum(values) or 1
    if show_pct:
        rows = [{"Name": l, "Count": v, "%": f"{v / total * 100:.1f}%"} for l, v in zip(labels, values)]
    else:
        rows = [{"Name": l, "Count": v} for l, v in zip(labels, values)]
    return _chart_title_div(title) + data_table(pd.DataFrame(rows))


def stat_grid_2x2(cards):
    """2x2 grid of plain stat cards (fixed height, same style as stat_row)
    - used for the Classification Errors KPI block sitting next to the
    Monthly Trend chart."""
    rows = []
    for i in range(0, len(cards), 2):
        pair = cards[i:i + 2]
        cells = []
        for mod, title, value, subtitle in pair:
            border = STAT_BORDER.get(mod, "#cccccc")
            bg = "#fafafa" if mod == "flat" else "#fcfcfc"
            cells.append(f"""<td width="50%" style="padding:5px;">
                <table width="100%" height="98" cellpadding="0" cellspacing="0" border="0"
                       style="border:1px solid #eeeeee; border-top:3px solid {border}; border-radius:6px; background-color:{bg}; height:98px;">
                    <tr><td align="center" valign="middle" height="98" style="height:98px; padding:6px 6px; font-family:{FONT_STACK};">
                        <div style="color:#888888; font-size:10px; text-transform:uppercase; font-weight:bold; margin-bottom:4px; font-family:{FONT_STACK}; line-height:1.2;">{title}</div>
                        <div style="color:#333333; font-size:20px; font-weight:bold; font-family:{FONT_STACK}; line-height:1.1;">{value}</div>
                        <div style="font-size:9px; color:#999999; margin-top:3px; font-family:{FONT_STACK}; line-height:1.2;">{subtitle}</div>
                    </td></tr>
                </table>
            </td>""")
        rows.append(f"<tr>{''.join(cells)}</tr>")
    return f'<table width="100%" height="100%" cellpadding="0" cellspacing="0" border="0">{"".join(rows)}</table>'


def build_conversions_section(sctask, inc, ref, config):
    r = m.classification_errors(sctask, inc, ref, config)

    html = section_header("Cross-Type Conversions (SCTASK &harr; INC)", number=9)
    html += ('<div style="font-size:11px; color:#999999; margin-bottom:12px;">'
              'How canceled/incomplete tickets in SCTASK and INC reconcile with genuine '
              'cross-type misclassifications (tracked in both directions).</div>')

    # ---- Reconciliation panel ----
    html += sub_header("Canceled Reconciliation (Current Month)")
    html += stat_row([
        ("warn", "INC Canceled", r["inc_cancel_total"], "Total in INC"),
        ("info", "SCTASK Canceled", r["sctask_cancel_total"], "Total in SCTASK"),
        ("", "Total Canceled", r["inc_cancel_total"] + r["sctask_cancel_total"], "INC + SCTASK"),
        ("danger", "Incorrect Classif.", r["total_month"], "Confirmed misclassification"),
        ("", "Other Reasons", r["other_reasons"], "Non-classification cancels"),
    ])
    html += mini_kpi_row([
        ("INC \u2192 SCTASK (reclassified)", r["i2s_month"]),
        ("SCTASK \u2192 INC (reclassified)", r["s2i_month"]),
    ])

    # ---- Monthly Trend chart (left) + KPI cards (right), matching the
    # reference dashboard's "Monthly Trend" panel exactly ----
    html += sub_header("Monthly Trend")
    img_trend = c.area_line_trend(r["history_labels"], r["history_values"],
                                    "rgba(220,38,38,0.9)", "rgba(220,38,38,0.08)")
    kpi_cards = stat_grid_2x2([
        ("danger", "Incorrect Tickets (Month)", r["total_month"], "Volume detected this period"),
        ("warn", "Top Offending Group", r["top_group_count"], r["top_group_name"]),
        ("info", "Monthly MTTR", f"{r['mttr_month']}d", "Average correction time"),
        ("", "Maximum Delay", f"{r['max_delay_month']}d", "Longest response time"),
    ])
    html += two_col_row(
        f'<div class="chart-card-full" style="margin-bottom:0; height:100%;">'
        f'<div class="chart-title">Historical Cumulative</div>'
        f'<img class="chart-img" src="{img_trend}" width="100%" style="max-width:100%; width:100%; height:auto; display:block; border:0;"></div>',
        kpi_cards,
    )

    # ---- Analytical breakdowns (current month + full history) ----
    req_l, req_v = r["by_requester"]
    grp_l, grp_v = r["by_group"]
    an_l, an_v = r["by_analyst"]
    html += grid_row([
        breakdown_card("By Requester (Month)", req_l, req_v),
        breakdown_card("By Group (Month)", grp_l, grp_v),
        breakdown_card("By Analyst (Month)", an_l, an_v),
        breakdown_card("Historical Consolidated", r["history_labels"], r["history_values"], show_pct=True),
    ])

    # ---- Detailed list (compact) ----
    html += sub_header("Detailed List of Incorrect Classifications (Current Month)")
    recent = r["recent_rows"]
    if recent is None or recent.empty:
        html += data_table(pd.DataFrame(), empty_message="No incorrect classifications identified in the period.")
    else:
        render = recent.copy()
        render["Opened"] = render["Opened"].dt.strftime("%d/%m/%Y")
        render["Closed"] = render["Closed"].apply(lambda d: d.strftime("%d/%m/%Y") if pd.notna(d) else "\u2014")
        render["AgingDays"] = render["AgingDays"].round(1)
        cols = ["Number", "Direction", "LinkedTicket", "Requester", "Assigned to",
                "Assignment group", "Reason", "State", "Opened", "Closed", "AgingDays"]
        render = render[cols].rename(columns={"LinkedTicket": "Linked Ticket", "AgingDays": "Aging (d)"})
        html += data_table(render)
        if r["total_month"] > len(recent):
            html += (f"<div class='table-note' style='font-size:11px; color:#999999; text-align:right; "
                      f"margin-top:6px; font-style:italic; font-family:{FONT_STACK};'>"
                      f"+ {r['total_month'] - len(recent)} additional misclassified "
                      f"tickets not shown here (see the full export for details).</div>")

    return html



# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def build_toc():
    """Table-of-contents strip sitting right below the Overview KPI cards:
    one small "chip" per numbered section, each carrying that section's own
    color (matching its header badge) so the whole report's structure is
    visible at a glance before scrolling through it."""
    cells = []
    per_row = 3
    for num, label, color, icon in SECTION_TOC:
        cells.append(f"""<td width="{100/per_row:.2f}%" style="padding:4px;">
            <table width="100%" height="54" cellpadding="0" cellspacing="0" border="0"
                   style="background-color:#ffffff; border:1px solid #eeeeee; border-left:4px solid {color}; border-radius:5px; height:54px;">
                <tr>
                    <td width="34" align="center" valign="middle" style="padding-left:10px;">
                        <table cellpadding="0" cellspacing="0" border="0"><tr>
                            <td width="24" height="24" align="center" valign="middle"
                                style="width:24px; height:24px; min-width:24px; background-color:{color}; border-radius:12px; color:#ffffff; font-size:11px; font-weight:bold; font-family:{FONT_STACK};">{num}</td>
                        </tr></table>
                    </td>
                    <td valign="middle" style="padding:6px 10px 6px 8px; font-family:{FONT_STACK};">
                        <span style="font-size:11px; color:#37474F; font-weight:bold; line-height:1.25;">{icon}&nbsp; {label}</span>
                    </td>
                </tr>
            </table>
        </td>""")
    rows = []
    for i in range(0, len(cells), per_row):
        rows.append(f"<tr>{''.join(cells[i:i + per_row])}</tr>")
    table = f'<table width="100%" cellpadding="0" cellspacing="0" border="0">{"".join(rows)}</table>'
    return (f'<div style="margin:4px 0 22px 0;">'
            f'<div style="font-size:11px; color:#8a97a3; font-weight:bold; text-transform:uppercase; '
            f'letter-spacing:0.6px; margin-bottom:8px; font-family:{FONT_STACK};">Report Contents</div>'
            f'{table}</div>')


def build_report(sctask, inc, prb, config):
    c.reset_delivery_stats()
    ref = m.get_reference_date(config)
    crit = config["CRITICAL_AGING_THRESHOLD"]

    # UAM (User Access Management) is split out of SCTASK right away, so
    # every REQ number downstream (KPIs, critical panel, distribution,
    # aging, trend charts, throughput table) reflects support requests
    # ONLY - it no longer silently includes access-management tickets.
    df_req, df_uam = m.split_uam(sctask, config)

    open_req_quick = m.add_open_aging(df_req, ref, config["SLA_DAYS"]["SCTASK"])
    open_uam_quick = m.add_open_aging(df_uam, ref, config["SLA_DAYS"]["SCTASK"])
    open_inc_quick = m.add_open_aging(inc, ref, config["SLA_DAYS"]["INC"])
    open_prb_quick = m.add_open_aging(prb, ref, config["SLA_DAYS"]["PRB"])
    total_backlog = len(open_req_quick) + len(open_uam_quick) + len(open_inc_quick)
    mttr_overall = round((m.mttr_days_month(df_req, ref) + m.mttr_days_month(inc, ref)) / 2, 1)

    overview = kpi_row([
        ("blue", "\U0001F4E6", "Total Backlog", total_backlog, "REQ + UAM + INC open, right now"),
        ("blue", "\U0001F6E0\ufe0f", "REQ Open (Support)", len(open_req_quick), "Excludes UAM"),
        ("green", "\U0001F510", "UAM Open", len(open_uam_quick), "Access management"),
        ("red", "\U0001F6A8", "INC Open", len(open_inc_quick), "Incidents"),
        ("purple", "\U0001F4CB", "PRB Open", len(open_prb_quick), f"of {len(prb)} total"),
        ("orange", "\u23F1\ufe0f", "MTTR (month)", f"{mttr_overall}d", "Current-month resolution time"),
    ])

    sctask_html, open_sctask = build_ticket_type_section(
        df_req, ref, config, ticket_type="SCTASK", css_class="req", label="SCTASK \u2014 Service Requests (excl. UAM)",
        donut_colors=QC["req_donut"], bar_color=QC["blue_a"], bar_color_soft=QC["blue_a"],
        requester_col="Requester", id_cols=["Assigned to", "Requester"],
        critical_threshold=crit["SCTASK"], extra_critical=config.get("SCTASK_EXTRA_CRITICAL_DAYS"), number=1)

    inc_html, open_inc = build_ticket_type_section(
        inc, ref, config, ticket_type="INC", css_class="inc", label="INC \u2014 Incidents",
        donut_colors=QC["inc_donut"], bar_color=QC["red_a"], bar_color_soft=QC["red_a"],
        requester_col="Caller", id_cols=["Assigned to", "Caller"],
        critical_threshold=crit["INC"], extra_critical=None, number=2)

    distribution_sla_html = build_distribution_sla_section(open_sctask, open_inc, config)
    status_aging_html = build_status_aging_section(open_sctask, open_inc, config)

    # UAM built early so its open/backlog numbers are ready for the trend
    # sections below (daily 3-panel, monthly 2x2, throughput table).
    uam_html, open_uam, monthly_uam = build_uam_section(df_uam, ref, config)

    # Combined (SCTASK + UAM + INC) view, for the "ALL" panel/table.
    df_all = pd.concat([df_req, df_uam, inc], ignore_index=True, sort=False)
    all_backlog = len(open_sctask) + len(open_uam) + len(open_inc)

    daily_current_sctask = m.daily_flow_breakdown(df_req, ref, "SCTASK", len(open_sctask))
    daily_current_inc = m.daily_flow_breakdown(inc, ref, "INC", len(open_inc))
    daily_current_uam = m.daily_flow_breakdown(df_uam, ref, "UAM", len(open_uam))

    daily_trend_html = build_quad_trend_comparison_section(
        "Daily Evolution and Trend - Current Month (SCTASK x INC x UAM)",
        daily_current_sctask, daily_current_inc,
        layout="stacked", sctask_backlog=len(open_sctask), inc_backlog=len(open_inc),
        uam_metrics=daily_current_uam, uam_backlog=len(open_uam), number=6)

    monthly_flow_sctask = m.monthly_flow_breakdown(df_req, ref, config["MONTHS_LOOKBACK"], "SCTASK", len(open_sctask))
    monthly_flow_inc = m.monthly_flow_breakdown(inc, ref, config["MONTHS_LOOKBACK"], "INC", len(open_inc))
    monthly_flow_all = m.monthly_flow_breakdown(df_all, ref, config["MONTHS_LOOKBACK"], "ALL", all_backlog)

    monthly_trend_html = build_quad_trend_2x2_section(
        f"Monthly Evolution and Trend - Last {config['MONTHS_LOOKBACK']} Months (SCTASK x INC x UAM x ALL)",
        monthly_flow_sctask, monthly_flow_inc, monthly_uam, monthly_flow_all,
        sctask_backlog=len(open_sctask), inc_backlog=len(open_inc),
        uam_backlog=len(open_uam), all_backlog=all_backlog, number=7)

    monthly_tracking_html = build_monthly_tracking_section(
        monthly_flow_sctask, monthly_flow_inc, monthly_uam, monthly_flow_all)

    conversions_html = build_conversions_section(sctask, inc, ref, config)

    ini, _ = m.month_bounds(ref)
    period_label = ini.strftime("%m/%Y")
    sla = config["SLA_DAYS"]

    divider = '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="border-top:2px solid #e8ecf0; font-size:1px; line-height:1px;">&nbsp;</td></tr></table><div style="height:20px; line-height:20px;">&nbsp;</div>'

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IT Executive Dashboard</title>
    <style>{CSS}</style>
</head>
<body style="font-family:{FONT_STACK}; background-color:#f4f4f4; margin:0; padding:20px 10px;">
    <table class="email-container" width="100%" cellpadding="0" cellspacing="0" border="0" align="center"
           style="max-width:1300px; margin:0 auto; background-color:#ffffff; border-radius:8px;">
        <tr><td>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
            <tr><td align="center" style="background-color:#0B1E40; color:#ffffff; padding:18px 20px; border-radius:8px 8px 0 0; font-family:{FONT_STACK};">
                <h2 style="margin:0 0 6px 0; font-size:22px; letter-spacing:0.3px; color:#ffffff; font-family:{FONT_STACK};">IT Executive Dashboard &mdash; SCTASK x INC x PRB x UAM</h2>
                <p style="margin:0; color:#9BBAD2; font-size:13px; font-family:{FONT_STACK};">Period: {period_label} &nbsp;|&nbsp; Generated: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')} &nbsp;|&nbsp;
                   SLA SCTASK={sla['SCTASK']}d &nbsp; SLA INC={sla['INC']}d &nbsp; SLA PRB={sla['PRB']}d</p>
            </td></tr>
        </table>
        <div class="content" style="padding:22px;">

            {section_header("Overview")}
            {overview}
            {build_toc()}

            {sctask_html}

            {divider}
            {inc_html}

            {divider}
            {distribution_sla_html}

            {divider}
            {status_aging_html}

            {divider}
            {uam_html}

            {divider}
            {daily_trend_html}

            {divider}
            {monthly_trend_html}

            {divider}
            {monthly_tracking_html}

            {divider}
            {conversions_html}

        </div>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="footer">
            <tr><td align="center" style="padding:15px; font-size:12px; color:#888888; background-color:#f4f4f4; border-top:1px solid #dddddd; border-radius:0 0 8px 8px; font-family:{FONT_STACK};">
                Automated report generated by the IT Metrics Dashboard script &middot; {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
            </td></tr>
        </table>
        </td></tr>
    </table>
</body>
</html>"""

    kpis = {
        "total_backlog": total_backlog, "open_sctask": len(open_req_quick), "open_uam": len(open_uam_quick),
        "open_inc": len(open_inc_quick), "open_prb": len(open_prb_quick),
        "mttr_overall": mttr_overall, "period_label": period_label,
    }

    stats = c.get_delivery_stats()
    logger.info(f"📊 Entrega de gráficos (Executive Dashboard): {stats}")
    return html, kpis, ref

"""
================================================================================
SERVIÇO EXCLUSIVO: ENCERRAR TAREFA
================================================================================
Módulo exclusivo responsável pela automação de 'Encerrar'.
Localizado em: src/modules/portal_task/task_encerrar_service.py
"""

import logging
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import BrowserContext, Page
from tools.servicenow_driver import ServiceNowDriver
from tools.base_automation import SelectorManager

logger = logging.getLogger("TaskEncerrarService")

class TaskEncerrarService(ServiceNowDriver):
    """
    Classe especialista para automação de 'Encerrar'.
    Herda de ServiceNowDriver (que por sua vez herda de BaseAutomation).
    """

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_encerrar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Processa a automação de Encerrar em 1 URL do ServiceNow."""
        logger.info(f"🛑 [TaskEncerrarService] Encerrando tarefa em: {url}")
        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Encerrar",
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            # Captura de SCTASK em Página Única
            dados_captura = await self.capturar_sctask_pagina_unica(page=page, url=url)
            resultado["sctasks"] = dados_captura.get("sctasks", [])
            resultado["ritm"] = dados_captura.get("ritm")

            # Preenchimento e encerramento da SCTASK via método herdado
            if resultado["sctasks"]:
                for sctask_id in resultado["sctasks"]:
                    await self.preencher_e_encerrar_sctask(
                        page=page,
                        sctask_id_ou_url=sctask_id,
                        configuration_item="Portal Corretor",
                        state="Closed Complete",
                        work_notes="Tarefa encerrada automaticamente via PortalTask TaskEncerrarService."
                    )

            logger.info(f"✅ [TaskEncerrarService] Concluído em {url}. SCTASKs: {resultado['sctasks']}")
        except Exception as e:
            logger.error(f"❌ [TaskEncerrarService] Erro em {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

    async def executar_lote_concorrente(
        self, 
        context: BrowserContext, 
        urls: List[str], 
        max_concurrency: int = 3,
        dados_formulario: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Executa a automação para 1 ou N URLs com controle de Semáforo (max_concurrency)."""
        logger.info(f"🚀 [TaskEncerrarService] Processando lote de {len(urls)} URLs (Semáforo={max_concurrency})...")

        async def worker_task(page: Page, url: str):
            return await self.executar_encerrar_individual(page, url, dados_formulario=dados_formulario)

        return await self.run_concurrent_tasks(context=context, items=urls, task_fn=worker_task, max_concurrency=max_concurrency)

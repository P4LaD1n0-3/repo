"""
================================================================================
ARQUIVO MODELO E REFERÊNCIA: AUTOMAÇÃO DE CADASTRO DE USUÁRIO
================================================================================
Este arquivo fica localizado dentro da pasta do módulo 'src/modules/portal_task/'
e serve como REFERÊNCIA ARQUITETURAL para a implementação das demais ações do sistema.

CONCEITOS CHAVE ILUSTRADOS NESTE ARQUIVO:
1. HERANÇA POO: A classe 'CadastroUsuarioService' herda de 'ServiceNowDriver'
   (que herda de 'BaseAutomation'), aproveitando toda a inteligência de iFrames,
   seletores desacoplados e perfil de navegação persistente.
2. EXECUÇÃO INDIVIDUAL (1 PÁGINA): O método 'executar_cadastro_individual' lida
   com o fluxo de uma única página/URL do ServiceNow.
3. CONCORRÊNCIA E THREADS/SEMÁFORO (N PÁGINAS): O método 'executar_lote_concorrente'
   utiliza o 'run_concurrent_tasks' com asyncio.Semaphore para processar 1 ou N
   páginas simultaneamente sem travar a CPU ou memória do computador.
"""

import os
import logging
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import BrowserContext, Page, FrameLocator
from tools.servicenow_driver import ServiceNowDriver
from tools.upm_driver import UpmDriver
from tools.base_automation import SelectorManager
from tools.chamado import Chamado
from tools.usuario import Usuario
from tools.planilha_cadastro import ler_planilha_cadastro


# Configuração de Logger dedicado para este serviço
logger = logging.getLogger("CadastroUsuarioService")


class ChamadoCadastro(Chamado):
    """
    Especialização de 'Chamado' exclusiva do fluxo 'Cadastro de usuário'.
    REUSO POR HERANÇA: aproveita sctask/ritm/requester/assignment_group e o
    anexo/texto já resolvidos pelo 'Chamado' base, adicionando apenas o que é
    específico deste serviço (usuários lidos da planilha .xlsx da RITM, prontos
    para o cadastro no Portal UPM).
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.usuarios: List[Usuario] = []
        self.linhas_invalidas: List[Dict[str, Any]] = []

    def to_dict(self) -> Dict[str, Any]:
        dados = super().to_dict()
        dados["usuarios"] = [u.to_dict() for u in self.usuarios]
        dados["linhas_invalidas"] = self.linhas_invalidas
        return dados


class CadastroUsuarioService(ServiceNowDriver):
    """
    Classe especialista responsável pela automação de 'Cadastro de usuário'.
    Herda todos os métodos do ServiceNowDriver e BaseAutomation.
    """

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        # Chama o construtor da classe pai (ServiceNowDriver -> BaseAutomation)
        # permitindo injeção de seletores desacoplados de um JSON ou Dicionário
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_cadastro_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        ========================================================================
        FLUXO DE EXECUÇÃO DE 1 PÁGINA / URL INDIVIDUAL — CADASTRO DE USUÁRIO
        ========================================================================
        1. VARREDURA: percorre a fila em 'url' e monta o array de chamados
           (SCTASK, RITM, Requester, Assignment group) via método herdado
           'varrer_chamados' (regex + deduplicação, sem repetir chamados já capturados).
        2. Para cada chamado, acessa a RITM diretamente (sc_req_item.do?sys_id=<ritm>):
           baixa o anexo .xlsx (salvo na pasta temporária 'path_temp', preservada em
           caso de falha) se existir, ou extrai o texto da RITM quando não há anexo.
        3. Lê a planilha .xlsx DINAMICAMENTE pelo nome das colunas (Email_Master,
           Usuario (Nome Completo), CPF_Master, Celular (Opcional), Razao Social,
           CNPJ, SUSEP, SENHA), ignorando linhas com dado obrigatório faltando e
           seguindo a automação normalmente para as demais.
        4. Cadastra cada usuário válido no Portal UPM/PUMA e, na sequência, reseta
           a senha para gerar a credencial temporária de acesso (UpmDriver).

        REGRA DE NEGÓCIO OBRIGATÓRIA: 'Realizar cadastro' NUNCA preenche nem
        encerra a SCTASK no ServiceNow. Encerrar o chamado é responsabilidade
        exclusiva da ação "Encerrar" (TaskEncerrarService) e deve ser disparada
        manualmente pelo usuário somente depois de validar o cadastro.
        """
        logger.info(f"👤 [CadastroUsuarioService] Iniciando processamento da URL: {url}")

        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Cadastro de usuário",
            "chamados": [],
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            # PASSO 1: Varredura de chamados da fila -> array de 'ChamadoCadastro' (herda de Chamado)
            # Método herdado de ServiceNowDriver: aplica regex e não repete chamados já capturados.
            chamados: List[ChamadoCadastro] = await self.varrer_chamados(
                page=page, url=url, chamado_cls=ChamadoCadastro
            )

            # PASSO 2 e 3: para cada chamado, acessa a RITM diretamente, baixa o anexo
            # (ou extrai texto quando não há anexo) e lê a planilha .xlsx dinamicamente.
            for chamado in chamados:
                if not chamado.ritm:
                    logger.warning(
                        f"⚠️ [CadastroUsuarioService] Chamado {chamado.sctask_number} sem RITM identificada, "
                        f"não é possível acessar a RITM diretamente."
                    )
                    continue

                dados_ritm = await self.acessar_ritm_e_obter_anexo_ou_texto(page=page, ritm=chamado.ritm)
                chamado.anexos = dados_ritm.get("anexos", [])
                chamado.texto_extraido = dados_ritm.get("texto_extraido")

                arquivos_xlsx = [a for a in chamado.anexos if a.lower().endswith(".xlsx")]
                if not arquivos_xlsx:
                    logger.info(
                        f"ℹ️ [CadastroUsuarioService] Chamado {chamado.sctask_number or chamado.ritm_number} "
                        f"sem planilha .xlsx para processar."
                    )
                    continue

                for caminho_planilha in arquivos_xlsx:
                    usuarios, linhas_invalidas = ler_planilha_cadastro(caminho_planilha)
                    chamado.usuarios.extend(usuarios)
                    chamado.linhas_invalidas.extend(linhas_invalidas)

                    if linhas_invalidas:
                        logger.warning(
                            f"⚠️ [CadastroUsuarioService] {len(linhas_invalidas)} linha(s) ignorada(s) em "
                            f"'{os.path.basename(caminho_planilha)}' (linhas: {[li['linha'] for li in linhas_invalidas]}) "
                            f"por dado obrigatório faltando — automação segue normalmente."
                        )

            # PASSO 4: Cadastro efetivo no Portal UPM/PUMA + reset de senha (fica de fora do ServiceNow)
            upm_driver = UpmDriver(selectors=self.selector_manager)
            login_realizado = False

            for chamado in chamados:
                if not chamado.usuarios:
                    continue

                if not login_realizado:
                    await upm_driver.login_upm(page=page)
                    login_realizado = True

                for usuario in chamado.usuarios:
                    resultado_cadastro = await upm_driver.cadastrar_usuario_upm(page=page, dados_usuario=usuario.to_dict())
                    usuario.retorno = resultado_cadastro.get("mensagem") or ""

                    if resultado_cadastro.get("status") == "success":
                        # Cadastro efetuado -> reseta a senha em seguida para gerar a credencial temporária
                        resultado_reset = await upm_driver.resetar_senha_mfa_upm(
                            page=page, email=usuario.email_master, type_reset="reset"
                        )
                        usuario.senha = resultado_reset.get("senha_gerada") or ""
                    else:
                        logger.warning(
                            f"⚠️ [CadastroUsuarioService] Cadastro de '{usuario.email_master}' (linha {usuario.linha}) "
                            f"retornou: {usuario.retorno}"
                        )

            resultado["chamados"] = [c.to_dict() for c in chamados]
            resultado["sctasks"] = [c.sctask_number or c.sctask for c in chamados if c.sctask_number or c.sctask]
            resultado["ritm"] = (chamados[0].ritm_number or chamados[0].ritm) if chamados else None

            # IMPORTANTE: nenhuma escrita/encerramento é feita na SCTASK neste serviço.
            # Ver docstring do método acima e TaskEncerrarService para o encerramento manual.

            logger.info(
                f"✅ [CadastroUsuarioService] Concluído com sucesso em {url}. "
                f"Chamados capturados: {resultado['sctasks']}"
            )

        except Exception as e:
            logger.error(f"❌ [CadastroUsuarioService] Erro ao cadastrar usuário na URL {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

    async def executar_lote_concorrente(
        self, 
        context: BrowserContext, 
        urls: List[str], 
        max_concurrency: int = 3,
        dados_formulario: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        ========================================================================
        FLUXO DE EXECUÇÃO EM LOTE PARA 1 OU N TAREFAS (CONCORRÊNCIA COM SEMÁFORO)
        ========================================================================
        Como funciona a integração do Playwright com Threads/Asyncio:
        - O Playwright opera sobre o loop de eventos assíncrono (asyncio).
        - Para processar N URLs simultaneamente sem abrir 50 abas e travar o computador,
          utilizamos o método herdado 'run_concurrent_tasks()' que utiliza um 'asyncio.Semaphore'.
        - Se 'max_concurrency = 3', o Semáforo permite que no máximo 3 abas fiquem abertas ao mesmo tempo.
        - Quando uma aba conclui o cadastro de usuário, a próxima URL da lista assume a vaga no Semáforo.
        """
        logger.info(f"🚀 [CadastroUsuarioService] Iniciando processamento em lote de {len(urls)} URLs (Semáforo = {max_concurrency} abas simultâneas)...")

        # Define a função trabalhadora assíncrona que liga o parâmetro da página à URL atual
        async def worker_task(page: Page, url: str):
            return await self.executar_cadastro_individual(page, url, dados_formulario=dados_formulario)

        # Dispara a execução concorrente controlada pelo Semáforo herdado de BaseAutomation
        resultados = await self.run_concurrent_tasks(
            context=context,
            items=urls,
            task_fn=worker_task,
            max_concurrency=max_concurrency
        )

        logger.info(f"🏁 [CadastroUsuarioService] Processamento em lote finalizado. Total de respostas: {len(resultados)}")
        return resultados

# -*- coding: utf-8 -*-
"""
IT Metrics Dashboard - Configuration
=====================================
Single place to edit paths, email recipients, SLA targets and thresholds.

Terminology mapping (this ServiceNow export uses INC / SCTASK / PRB):
    SCTASK  ~  "REQ" in the legacy dashboard (service catalog tasks / requests)
    INC     ~  "INC" in the legacy dashboard (incidents)
    PRB     ~  "PTASK" in the legacy dashboard (problem tasks)
"""
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

CONFIG = {
    # --- Source files (ServiceNow exports) ---
    "INC_PATH": os.path.join(BASE_DIR, "INC.xlsx"),
    "SCTASK_PATH": os.path.join(BASE_DIR, "SCTASK.xlsx"),
    "PRB_PATH": os.path.join(BASE_DIR, "PRB.xlsx"),

    # --- Output ---
    "OUTPUT_HTML": os.path.join(BASE_DIR, "dashboard_report.html"),
    "SAVE_LOCAL_COPY": True,

    # --- Email ---
    "EMAIL_TO": "rolim.r@icloud.com",
    "EMAIL_CC": "",
    "EMAIL_SUBJECT_PREFIX": "IT Executive Dashboard - REQ x INC x PRB",
    "SEND_EMAIL": True,

    # --- Reference date ---
    # None  -> use the real current date/time (normal production use)
    # "2026-07-24" -> pin a fixed date (useful to test against historical data)
    "REFERENCE_DATE": None,

    # --- SLA targets, in calendar days (used for Inside/Outside SLA + aging) ---
    "SLA_DAYS": {"SCTASK": 10, "INC": 7, "PRB": 10},

    # --- Critical aging thresholds (days) used for the "Critical" call-out tables ---
    "CRITICAL_AGING_THRESHOLD": {"SCTASK": 20, "INC": 7, "PRB": 15},
    "SCTASK_EXTRA_CRITICAL_DAYS": 30,   # highlighted in red inside the REQ critical table

    # --- Manually curated ETA shown on the critical-REQ table (optional, free text) ---
    "ETA_LABEL": "",

    # --- Analysis windows ---
    "MONTHS_LOOKBACK": 6,          # monthly evolution / throughput tables
    "WEEKS_LOOKBACK": 8,           # weekly evolution chart
    "DAILY_EVOLUTION_DAYS": 10,    # "last N days" mini trend chart
    "TOP_N_ANALYSTS": 8,
    "TOP_N_REQUESTERS": 10,
    "TOP_N_CRITICAL_ROWS": 25,
    "CRITICAL_TABLE_COMPACT_ROWS": 6,   # rows shown in the compact critical tables

    # --- Cross-type conversion / offender detection ---
    # SCTASK -> INC: tickets closed as incomplete because the item was really an
    # incident (misclassification). We look for these keywords in the Reason
    # field and try to extract a referenced INC number from the free-text notes.
    "MISCLASSIFICATION_REASON_KEYWORDS": ["incorrect classification", "wrong classification",
                                            "deveria ser incidente", "classificacao incorreta"],
    # INC -> SCTASK: incidents cancelled because they were really a request.
    "CANCELLATION_STATE_VALUES": ["cancelled", "canceled"],
}

# ---------------------------------------------------------------------------
# Aging buckets (kept close to the legacy dashboard's bucket definitions)
# ---------------------------------------------------------------------------
SCTASK_AGING_BINS = [-1, 3, 5, 7, 10, 20, 30, float("inf")]
SCTASK_AGING_LABELS = ["1-3 days", "3-5 days", "5-7 days", "7-10 days",
                        "10-20 days", "20-30 days", "30+ days"]

INC_AGING_BINS = [-1, 3, 5, 7, float("inf")]
INC_AGING_LABELS = ["1-3 days", "3-5 days", "5-7 days", "7+ days"]

PRB_AGING_BINS = [-1, 7, 15, 30, float("inf")]
PRB_AGING_LABELS = ["1-7 days", "7-15 days", "15-30 days", "30+ days"]

# ---------------------------------------------------------------------------
# Color palette - high-contrast blue, matching the production dashboard
# ---------------------------------------------------------------------------
class Colors:
    PRIMARY_DARK = "#001B69"
    PRIMARY = "#4A90E2"
    PRIMARY_LIGHT = "#EBF5FB"
    SUCCESS = "#27AE60"
    SUCCESS_LIGHT = "#D5F4E6"
    WARNING = "#F39C12"
    WARNING_LIGHT = "#FCF3CF"
    DANGER = "#E74C3C"
    DANGER_LIGHT = "#FADBD8"
    ORANGE = "#E67E22"
    ORANGE_LIGHT = "#FDEBD0"
    GRAY_DARK = "#1A365D"
    GRAY = "#7F8C8D"
    GRAY_LIGHT = "#ECF0F1"
    WHITE = "#FFFFFF"
    ACCENT = "#2B6CB0"
    ACCENT_LIGHT = "#E2E8F0"
    INFO = "#3182CE"
    INFO_LIGHT = "#BEE3F8"
    BACKGROUND = "#F5F6FA"
    PURPLE = "#6A1B9A"
    PURPLE_LIGHT = "#F3E5F5"


HIGH_CONTRAST_BLUES = ["#001B69", "#60A5FA", "#1D4ED8", "#93C5FD",
                        "#1E3A8A", "#3B82F6", "#BFDBFE", "#2563EB"]
MIXED_PALETTE = [Colors.WARNING, Colors.ORANGE, Colors.DANGER, Colors.PRIMARY,
                  Colors.ACCENT, Colors.INFO, Colors.GRAY, Colors.PRIMARY_DARK]

# ---------------------------------------------------------------------------
# Soft chart palette - matches the reference "relatorio_email.html" template
# exactly (this is the palette used for every QuickChart config, as opposed
# to the Colors class above which is only used for card/section HTML chrome)
# ---------------------------------------------------------------------------
QC = {
    "blue": "rgb(52,152,219)", "blue_a": "rgba(52,152,219,0.80)",
    "blue_soft": "rgba(74,144,226,0.85)",
    "green": "rgb(39,174,96)", "green_a": "rgba(39,174,96,0.75)",
    "red": "rgb(231,76,60)", "red_a": "rgba(231,76,60,0.75)",
    "purple": "rgb(155,89,182)", "purple_a": "rgba(155,89,182,0.75)",
    "orange": "rgb(243,156,18)", "gold": "rgb(241,196,15)",
    "orange_bar": "rgb(230,126,34)", "dark_red": "rgb(192,57,43)",
    "coral": "rgb(231,111,81)", "bright_green": "rgb(46,204,113)",
    "gray": "rgb(169,169,169)", "pink": "rgb(231,30,119)",
    "req_donut": ["rgb(52,152,219)", "rgb(93,173,226)", "rgb(133,193,233)",
                   "rgb(41,128,185)", "rgb(84,153,199)", "rgb(21,101,192)",
                   "rgb(174,214,241)", "rgb(31,58,147)"],
    "inc_donut": ["rgb(231,76,60)", "rgb(236,112,99)", "rgb(241,148,138)",
                   "rgb(192,57,43)", "rgb(211,84,0)", "rgb(230,126,34)",
                   "rgb(243,156,18)", "rgb(146,43,33)"],
    "aging_scale": ["rgb(46,204,113)", "rgb(52,152,219)", "rgb(241,196,15)",
                      "rgb(230,126,34)", "rgb(231,76,60)", "rgb(192,57,43)"],
    # Varied categorical palette - used for donuts where every slice must be
    # easy to tell apart at a glance (e.g. Top Analysts), regardless of
    # section theme. Monochromatic shades of one hue are hard to read.
    "varied": ["rgb(52,152,219)", "rgb(231,76,60)", "rgb(46,204,113)", "rgb(243,156,18)",
                "rgb(155,89,182)", "rgb(26,188,156)", "rgb(241,196,15)", "rgb(230,126,34)",
                "rgb(52,73,94)", "rgb(149,165,166)"],
}

MONTH_ABBR_EN = {1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun",
                  7: "Jul", 8: "Aug", 9: "Sep", 10: "Oct", 11: "Nov", 12: "Dec"}
WEEKDAY_ABBR_EN = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

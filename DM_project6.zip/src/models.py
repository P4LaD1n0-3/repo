from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(100), default="Operacional")
    servicenow_name = db.Column(db.String(150), nullable=True)
    signature_name = db.Column(db.String(150), nullable=True)
    pinned_modules = db.Column(db.Text, nullable=True, default='["portal_task"]')

    @property
    def pinned_list(self):
        """Retorna a lista de chaves de módulos pino como lista Python"""
        import json
        try:
            if self.pinned_modules:
                return json.loads(self.pinned_modules)
        except Exception:
            pass
        return ["portal_task"]


    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def display_servicenow_name(self):
        return self.servicenow_name or self.full_name

    @property
    def display_signature_name(self):
        return self.signature_name or self.full_name


    @property
    def short_name(self):
        """Retorna o primeiro e último nome ou nome resumido (ex: Wesley Simões)"""
        parts = self.full_name.split()
        if len(parts) > 1:
            return f"{parts[0]} {parts[-1]}"
        return self.full_name

    @property
    def initials(self):
        """Retorna as iniciais do usuário para o avatar (ex: WS)"""
        parts = self.full_name.split()
        if len(parts) >= 2:
            return f"{parts[0][0]}{parts[-1][0]}".upper()
        elif len(parts) == 1 and len(parts[0]) > 0:
            return parts[0][0:2].upper()
        return "US"


class PortalTaskConfig(db.Model):
    """
    Tabela exclusiva para persistência de configurações, URLs e caminhos do módulo Portal Task.
    """
    __tablename__ = 'portal_task_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    url_cadastrar = db.Column(db.Text, nullable=True, default="")
    url_reset_senha = db.Column(db.Text, nullable=True, default="")
    url_reset_mfa = db.Column(db.Text, nullable=True, default="")
    url_encerrar = db.Column(db.Text, nullable=True, default="")
    url_desabilitar = db.Column(db.Text, nullable=True, default="")


    output_format = db.Column(db.String(50), nullable=True, default="excel")
    output_directory = db.Column(db.Text, nullable=True, default="C:\\Users\\wsimoes\\Downloads\\PortalTasks")
    headless = db.Column(db.Boolean, default=True)

    # Opções de Automação & Campos do Modal 'Alterar usuário'
    automation_action = db.Column(db.String(100), nullable=True, default="Cadastro de usuário")
    alt_is_assessoria = db.Column(db.Boolean, default=True)
    alt_de_email = db.Column(db.String(255), nullable=True)
    alt_de_ritm = db.Column(db.String(100), nullable=True, default="RITM0000000")
    alt_para_email = db.Column(db.String(255), nullable=True)
    alt_para_cnpj = db.Column(db.String(50), nullable=True, default="00.000.000/0001-00")
    alt_para_nome = db.Column(db.String(255), nullable=True)
    alt_para_produto_id = db.Column(db.String(100), nullable=True)

    user = db.relationship('User', backref=db.backref('portal_config', uselist=False))


    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class EmailReportConfig(db.Model):
    """
    Tabela para persistência das configurações dos 2 reportes de e-mail (Dashboard Executive e Analyst Comparison),
    seleção de região (BRAZIL / MEX) e opções de relatórios automatizados do usuário.
    """
    __tablename__ = 'email_report_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    selected_region = db.Column(db.String(50), nullable=True, default="BRAZIL")
    
    # 4 Campos para Configuração de E-mail do Reporte 1: Dashboard Executive (Brasil e México)
    brazil_to = db.Column(db.Text, nullable=True, default="rolim.r@icloud.com")
    brazil_cc = db.Column(db.Text, nullable=True, default="copia.br@empresa.com")
    mex_to = db.Column(db.Text, nullable=True, default="rolim.r@icloud.com")
    mex_cc = db.Column(db.Text, nullable=True, default="copia.mex@empresa.com")
    subject_prefix = db.Column(db.String(200), nullable=True, default="IT Executive Dashboard — SCTASK x INC x PRB x UAM")
    send_email_enabled = db.Column(db.Boolean, default=True)

    # Campos para Configuração de E-mail do Reporte 2: Analyst Comparison Report
    analyst_to = db.Column(db.Text, nullable=True, default="rolim.r@icloud.com")
    analyst_cc = db.Column(db.Text, nullable=True, default="copia.br@empresa.com")
    analyst_subject_prefix = db.Column(db.String(200), nullable=True, default="IT Analyst Performance Comparison - Dashboard")
    analyst_send_email_enabled = db.Column(db.Boolean, default=True)

    output_directory = db.Column(db.Text, nullable=True, default="C:\\Users\\wsimoes\\Downloads\\ReportExports")

    user = db.relationship('User', backref=db.backref('email_report_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração de e-mail do usuário ou cria uma nova com valores padrão."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class ReleaseTaskConfig(db.Model):
    """
    Tabela exclusiva para persistência de dados e configurações do formulário Release task.
    """
    __tablename__ = 'release_task_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    assigned_to_ebao = db.Column(db.String(150), nullable=True, default="")
    assigned_to_portal = db.Column(db.String(150), nullable=True, default="")
    assigned_to_dba = db.Column(db.String(150), nullable=True, default="")
    copy = db.Column(db.String(150), nullable=True, default="")

    # NOMES (não e-mails) preenchidos nos campos de referência "Assigned to" do ServiceNow
    # ao ABRIR a Release/Change - antes fixos no código-fonte legado ("Mauricio Murakami"
    # para a Release, "Wellington Da Silva" para a Change), agora configuráveis na tela.
    # Distintos de 'assigned_to_dba' (usado apenas no fluxo de ENCERRAMENTO/ctask).
    release_assigned_to_name = db.Column(db.String(150), nullable=True, default="Mauricio Murakami")
    change_assigned_to_name = db.Column(db.String(150), nullable=True, default="Wellington Da Silva")

    open_time = db.Column(db.String(50), nullable=True, default="")
    release_number = db.Column(db.String(100), nullable=True, default="")

    choice = db.Column(db.String(50), nullable=True, default="Ebao")
    # Vazios por padrão de propósito: "RLESE00000"/"CHG0000000" existem apenas como
    # placeholder visual no HTML (atributo placeholder). Se fossem o valor REAL salvo,
    # o backend interpretaria como "RLESE e CHG preenchidos" e disparia o e-mail de
    # aprovação manual sem o usuário ter digitado nada.
    rlese = db.Column(db.String(100), nullable=True, default="")
    chg = db.Column(db.String(100), nullable=True, default="")

    # URLs de origem (favoritos/lista) usadas para abrir uma nova Release por ambiente.
    # Se vazias, o backend cai no padrão direto rm_release.do?sys_id=-1 (novo registro).
    ebao_link = db.Column(db.String(500), nullable=True, default="")
    portal_link = db.Column(db.String(500), nullable=True, default="")

    # Configuration Item usado ao criar a Release/Change de cada ambiente - antes fixo
    # no código ("EBAO-BRAZIL-Production" / "Portal Corretor-Production"), agora dinâmico.
    ebao_configuration_item = db.Column(db.String(150), nullable=True, default="EBAO-BRAZIL-Production")
    portal_configuration_item = db.Column(db.String(150), nullable=True, default="Portal Corretor-Production")

    # Horário (HH:MM:SS) usado no planned_start_date (abertura) e no planned_end_date/due_date
    # (fechamento) da Release/Change - antes fixo em "12:00:02" no código, agora dinâmico.
    open_hour = db.Column(db.String(20), nullable=True, default="12:00:02")
    close_hour = db.Column(db.String(20), nullable=True, default="12:00:02")

    user = db.relationship('User', backref=db.backref('release_task_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração de Release task do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config



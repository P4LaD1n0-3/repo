"""
================================================================================
SERVIÇO EXCLUSIVO: E-MAIL DE APROVAÇÃO DE RELEASE/CHANGE (DML)
================================================================================
Módulo exclusivo do 'release_task', responsável por montar e disparar o e-mail
de aprovação da Change DML (equivalente a 'bodyMail' + 'sendEmail' do legado
em release_exemplo/release_open.txt).

REUSO POR HERANÇA: 'ReleaseMailer' herda de 'tools.smtp.SmtpMailer' e reaproveita
o disparo multiplataforma (Outlook Windows/COM ou Outlook/Mail no Mac via
AppleScript) já implementado em 'enviar_email_automatico', sem duplicar nenhuma
lógica de envio - apenas adiciona a composição do HTML e as regras específicas
de aprovação de Release deste módulo.
"""

import logging
from datetime import date, timedelta
from typing import Tuple

from tools.smtp import SmtpMailer

logger = logging.getLogger("ReleaseMailer")


class ReleaseMailer(SmtpMailer):
    """
    Especialização de SmtpMailer exclusiva para os e-mails de aprovação de
    Release/Change DML. Herda 'send()' (e toda a infraestrutura de envio
    multiplataforma) e adiciona apenas a composição do corpo HTML.
    """

    def __init__(self, default_cc: str = ""):
        super().__init__(
            default_to="",
            default_cc=default_cc,
            default_subject_prefix="Aprovação Requerida - Execução DML - Produção",
        )

    @staticmethod
    def _parse_nome_email(valor: str) -> Tuple[str, str]:
        """
        Interpreta o campo 'Responsável' (assigned_to_ebao / assigned_to_portal)
        configurado pelo usuário, aceitando os formatos:
          - "Nome Completo <email@dominio.com>"
          - "email@dominio.com"
          - "Nome Completo" (sem e-mail; usado somente como nome de exibição)
        Retorna a tupla (nome_exibicao, endereco_email).
        """
        valor = (valor or "").strip()
        if not valor:
            return "", ""

        if "<" in valor and ">" in valor:
            nome = valor.split("<")[0].strip().strip('"')
            email = valor.split("<")[1].split(">")[0].strip()
            return (nome or email), email

        if "@" in valor:
            nome_extraido = valor.split("@")[0].replace(".", " ").replace("_", " ").strip().title()
            return nome_extraido, valor

        return valor, ""

    @staticmethod
    def calcular_datas_execucao(usar_data_hoje: bool = False) -> Tuple[date, date, date]:
        """
        ========================================================================
        REGRA D+1 / D+0 — REUTILIZADA TANTO NA ABERTURA DA RELEASE QUANTO NO E-MAIL
        ========================================================================
        Por padrão a Release/e-mail são sempre para o dia SEGUINTE (D+1), pois a
        automação roda no fim do dia anterior. Em dias específicos (ex.: segunda-feira,
        cobrindo o que não foi aberto durante o fim de semana) é preciso que a
        PRIMEIRA execução do dia use a data de HOJE (D+0) em vez de amanhã.

        No sistema legado isso era controlado editando o código-fonte à mão -
        trocando 'if tomorrow.weekday() == 23' (permanentemente inalcançável, ou
        seja, "D+1 sempre") para 'if tomorrow.weekday() == <dia da semana real>'
        somente na execução especial, e revertendo depois manualmente. O parâmetro
        'usar_data_hoje' substitui esse ajuste manual por uma flag explícita
        marcada na tela, eliminando o risco de esquecer de reverter o código.

        Retorna (today, tomorrow, day_hour) - 'day_hour' é a data usada nos
        textos/short_description (igual a 'today').
        """
        today_1 = date.today()
        today = today_1 if usar_data_hoje else today_1 + timedelta(days=1)
        tomorrow = today + timedelta(days=1)
        day_hour = today
        return today, tomorrow, day_hour

    @classmethod
    def build_approval_body(
        cls,
        rlse_number: str,
        chg_number: str,
        ambiente: str,
        send_to_valor: str,
        assinatura_nome: str,
        assinatura_email: str,
        usar_data_hoje: bool = False,
    ) -> str:
        """
        Monta o corpo HTML do e-mail de aprovação (equivalente a 'bodyMail' do legado).
        Preserva integralmente a formatação/estilo original (cores, fontes, assinatura AIG).
        """
        _, _, data_execucao = cls.calcular_datas_execucao(usar_data_hoje)
        send_name, send_to_email = cls._parse_nome_email(send_to_valor)
        mailto_alvo = send_to_email or send_name

        corpo = (
            f'<span lang=PT-BR style="color:#23538D">Prezado(s),</span><br><br>'
            f'<span lang=PT-BR><a style="font-family: \'Segoe UI\', Tahoma, Geneva, Verdana, sans-serif; '
            f'font-weight:500; font-size: 12px; text-decoration: none; color: #2B579A; '
            f'background-color: #E1DFDD; display: inline; padding: 2px;" '
            f'href="mailto:{mailto_alvo}">@{send_name}</a>, '
            f'<span lang=PT-BR style="color:#23538D">solicito aprovação para Change DML</span> '
            f'{rlse_number} - {chg_number} <b><span style="color:#23538D">({ambiente}).</span></b></br></br>'
            f'<span lang=PT-BR style="color:#23538D"><br>A DML está relacionada a atividades de BAU e '
            f'correções de incidentes de produção que ocorrerão em </span> '
            f'<span lang=PT-BR style="background:yellow;mso-highlight:yellow"> '
            f'{data_execucao.strftime("%d/%m/%Y")}</span><b><span style="color:#23538D">.</span></b><br><br>'
        )

        assinatura = (
            f'<span lang=PT-BR style="color:#23538D">Atenciosamente,</span>'
            f'<p class=MsoNormal><span lang=PT-BR><o:p>&nbsp;</span></p>'
            f'<p class=MsoNormal><b><span lang=PT-BR style="font-size:12.0pt; sans-serif;color:#001871">'
            f'{assinatura_nome}</span></b>'
            f'<span lang=PT-BR style="font-size:12.0pt; sans-serif;color:#001871"><span><br>'
            f'LAC Production Support<br>Torre Z, Av. Doutor Chucri Zaidan, 296 – 17º andar, Vila Cordeiro'
            f'<br>São Paulo - SP<br>{assinatura_email}</span>'
        )

        return corpo.replace("'", "") + assinatura.replace("'", "")

    def send_approval_email(
        self,
        rlse_number: str,
        chg_number: str,
        ambiente: str,
        send_to_valor: str,
        assinatura_nome: str,
        assinatura_email: str,
        copia: str = "",
        usar_data_hoje: bool = False,
    ) -> Tuple[bool, str]:
        """
        Compõe e dispara o e-mail de aprovação da Change DML (equivalente a 'sendEmail' do legado).
        Reaproveita 'self.send()' herdado de SmtpMailer para o disparo multiplataforma real.
        """
        rlse_number = (rlse_number or "").strip()
        chg_number = (chg_number or "").strip()

        _, send_to_email = self._parse_nome_email(send_to_valor)
        destinatario = send_to_email or send_to_valor

        html_body = self.build_approval_body(
            rlse_number=rlse_number,
            chg_number=chg_number,
            ambiente=ambiente,
            send_to_valor=send_to_valor,
            assinatura_nome=assinatura_nome,
            assinatura_email=assinatura_email,
            usar_data_hoje=usar_data_hoje,
        )

        assunto = (
            f"Aprovação Requerida - Execução DML - Produção - "
            f"{rlse_number} - {chg_number} ({ambiente}) - OO Approval"
        )

        logger.info(f"📧 [ReleaseMailer] Enviando e-mail de aprovação {rlse_number}/{chg_number} ({ambiente}) para '{destinatario}'...")
        sucesso, mensagem = self.send(html_body=html_body, subject=assunto, to=destinatario, cc=copia)

        if sucesso:
            logger.info(f"✅ [ReleaseMailer] E-mail enviado com sucesso. {ambiente} - {rlse_number} - {chg_number}")
        else:
            logger.error(f"❌ [ReleaseMailer] Erro ao enviar e-mail. {ambiente} - {rlse_number} - {chg_number}: {mensagem}")

        return sucesso, mensagem

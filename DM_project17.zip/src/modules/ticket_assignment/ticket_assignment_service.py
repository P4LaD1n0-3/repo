"""
================================================================================
SERVIÇO EXCLUSIVO: ATRIBUIÇÃO AUTOMÁTICA DE SCTASK / INC
================================================================================
Varre a fila de SCTASK ou de INC e ATRIBUI cada chamado ao analista certo:
- SCTASK: decide pelo motor de regras (tools/ticket_assignment_rules.py -
  palavra-chave do assunto/descrição contra config/ticket_assignment_rules.json).
- INC: analista ÚNICO fixo, configurado na tela (sem motor de regra).

Herda de ServiceNowDriver - reaproveita POR HERANÇA (não reimplementa):
'varrer_chamados' (varredura da fila de SCTASK, já pronta), 'get_iframe_scope',
'fill_reference_field', 'fill_input', 'click_element', 'wait_for_element' e as
peças de baixo nível de varredura ('_mapear_cabecalho_lista'/'_extrair_celula'/
'_extrair_codigo_por_link', usadas aqui com 'INC_REGEX' para a fila de INC,
que 'varrer_chamados' em si não suporta - é hardcoded para SCTASK/RITM).

Só GRAVA no ticket 'Assigned to' + 'Assignment group' (+ uma nota de trabalho
confirmando a atribuição, para deixar rastro visível no próprio ticket) - os
demais campos do JSON de regras (Type/Reason/Justification/Short_description)
parecem campos de abertura de um REQ novo, não editáveis assim num SCTASK já
existente; ficam só no resultado/log, como referência.

CADA PASSO é reportado via 'add_message' (callback opcional injetado por
'routes.py', mesmo padrão de 'release_task'/'reset_common') - sem isso, uma
falha no meio da varredura só aparecia no resumo final; agora aparece em
tempo real no Entry log, inclusive se o FORMULÁRIO do ticket não carregar a
tempo (antes disso falhava silenciosamente).
"""

import logging
from typing import Any, Callable, Dict, List, Optional
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError

from tools.servicenow_driver import ServiceNowDriver
from tools.chamado import SERVICE_NOW_BASE_URL
from tools.ticket_assignment_rules import encontrar_melhor_regra

logger = logging.getLogger("TicketAssignmentService")


def _sem_callback(_msg: str) -> None:
    """add_message padrão (no-op) quando o chamador não injeta um coletor de log."""
    return None


class TicketAssignmentService(ServiceNowDriver):
    """Atribui SCTASKs (por regra de palavra-chave) e INCs (analista fixo) ao analista certo."""

    async def _ler_campo_texto(self, scope, selector_key: str) -> str:
        """Lê o valor de um campo (input/textarea) pela chave do dicionário de paths - "" se não achar."""
        try:
            selector = self.get_selector(selector_key)
            locator = scope.locator(selector).first
            if await locator.count() == 0:
                return ""
            try:
                valor = await locator.input_value()
            except Exception:
                valor = await locator.inner_text()
            return (valor or "").strip()
        except Exception as e:
            logger.debug(f"Aviso ao ler campo '{selector_key}': {e}")
            return ""

    async def _aguardar_formulario_pronto(self, scope, add_message: Callable[[str], None]) -> bool:
        """
        Confirma que o FORMULÁRIO do ticket (não só o iframe 'gsft_main')
        realmente terminou de carregar, esperando pelo container do activity
        stream ('sn_form_inline_stream_entries' - presente em qualquer tela de
        ticket clássica do ServiceNow). Sem essa confirmação explícita, uma
        página ainda carregando parecia "não fazer nada" sem nenhum erro.
        """
        try:
            await self.wait_for_element(scope, "activity_stream_ready", timeout=15000, state="attached")
            return True
        except PlaywrightTimeoutError:
            add_message("⚠️ Formulário do ticket não terminou de carregar a tempo (activity stream não apareceu).")
            return False
        except Exception as e:
            add_message(f"⚠️ Aviso ao aguardar formulário do ticket: {e}")
            return True  # seletor pode não existir nesta instância - segue tentando mesmo assim

    async def _postar_nota_trabalho(self, scope, texto: str) -> None:
        """Posta uma nota de trabalho confirmando a atribuição - rastro visível no próprio ticket."""
        try:
            campo = scope.locator(self.get_selector("release_work_notes_textarea")).first
            if await campo.count() == 0:
                return
            await campo.click()
            await campo.fill(texto)
            try:
                await self.click_element(scope, "post_comments_btn")
            except Exception:
                pass
        except Exception as e:
            logger.debug(f"Aviso ao postar nota de trabalho: {e}")

    async def atribuir_sctasks(
        self,
        page: Page,
        url: str,
        regras: Dict[str, Any],
        add_message: Callable[[str], None] = _sem_callback,
    ) -> Dict[str, Any]:
        """
        Varre a fila 'url' (reaproveita 'self.varrer_chamados', já pronto),
        abre CADA SCTASK individualmente, lê assunto+descrição, decide a regra
        (tools.ticket_assignment_rules.encontrar_melhor_regra) e grava
        Assigned to/Assignment group + nota de trabalho. Sem regra encontrada
        -> pula (não mexe no ticket). Nunca lança exceção - erro por chamado
        fica no item, não derruba os demais.
        """
        resultado: Dict[str, Any] = {"url": url, "processados": [], "status": "success", "error": None}

        try:
            add_message(f"Varrendo a lista de SCTASK em: {url}")
            chamados = await self.varrer_chamados(page=page, url=url)
            add_message(f"{len(chamados)} SCTASK(s) capturada(s) na fila.")

            for chamado in chamados:
                numero = chamado.sctask_number or chamado.sctask
                sys_id = chamado.sctask or numero
                if not numero:
                    continue

                item: Dict[str, Any] = {"sctask": numero, "topico": None, "analista": None, "status": "sem_regra", "erro": None}

                try:
                    detalhe_url = f"{SERVICE_NOW_BASE_URL}/sc_task.do?sys_id={sys_id}"
                    add_message(f"Abrindo {numero}: {detalhe_url}")
                    await page.goto(detalhe_url, wait_until="domcontentloaded", timeout=30000)
                    scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

                    if not await self._aguardar_formulario_pronto(scope, add_message):
                        item["status"] = "erro"
                        item["erro"] = "Formulário não carregou a tempo."
                        resultado["processados"].append(item)
                        continue

                    numero_confirmado = await self._ler_campo_texto(scope, "sctask_number_readonly")
                    if numero_confirmado and numero_confirmado.upper() != numero.upper():
                        add_message(f"⚠️ {numero}: página abriu em '{numero_confirmado}' (número diferente do esperado) - seguindo mesmo assim.")

                    short_desc = await self._ler_campo_texto(scope, "sctask_short_description_field")
                    descricao = await self._ler_campo_texto(scope, "sctask_description_field")
                    texto_completo = f"{short_desc} {descricao}".strip()
                    add_message(f"{numero} - descrição: '{short_desc[:80] or '(vazia)'}'")

                    regra = encontrar_melhor_regra(texto_completo, regras)
                    if not regra:
                        add_message(f"⚠️ {numero}: nenhuma regra de atribuição bateu - não atribuído.")
                        resultado["processados"].append(item)
                        continue

                    analista = (regra.get("Assigned to") or [None])[0]
                    grupo = regra.get("Assignment group")
                    topico = (regra.get("Topic") or [None])[0]
                    item["topico"] = topico
                    item["analista"] = analista
                    add_message(f"{numero}: regra '{topico}' -> {analista} ({grupo})")

                    if grupo:
                        await self.fill_reference_field(scope, "assignment_group", grupo)
                    if analista:
                        await self.fill_reference_field(scope, "sctask_assigned_to", analista)
                    await self._postar_nota_trabalho(
                        scope, f"Atribuído automaticamente para {analista} ({grupo}) - regra: '{topico}'."
                    )
                    await self.click_element(scope, "update_stay_button")
                    await page.wait_for_timeout(1500)
                    item["status"] = "atribuido"
                    add_message(f"✅ {numero} salvo.")

                except Exception as e_item:
                    logger.error(f"❌ [TicketAssignmentService] Erro ao atribuir SCTASK {numero}: {e_item}")
                    add_message(f"❌ {numero}: erro ao atribuir - {e_item}")
                    item["status"] = "erro"
                    item["erro"] = str(e_item)

                resultado["processados"].append(item)

        except Exception as e:
            logger.error(f"❌ [TicketAssignmentService] Erro ao varrer fila de SCTASK: {e}")
            add_message(f"❌ Erro ao varrer fila de SCTASK: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

    async def atribuir_incs(
        self,
        page: Page,
        url: str,
        analista: str,
        grupo: Optional[str] = None,
        add_message: Callable[[str], None] = _sem_callback,
    ) -> Dict[str, Any]:
        """
        Varre a fila de INCIDENT em 'url' (própria - 'varrer_chamados' é
        hardcoded pra SCTASK/RITM - reaproveita as peças genéricas de baixo
        nível já existentes: '_mapear_cabecalho_lista'/'_extrair_celula'/
        '_extrair_codigo_por_link', com 'INC_REGEX' no lugar de 'SCTASK_REGEX')
        e atribui TODOS ao mesmo 'analista' fixo - sem motor de regra.
        """
        resultado: Dict[str, Any] = {"url": url, "processados": [], "status": "success", "error": None}

        try:
            add_message(f"Varrendo a lista de INC em: {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=10000)
            await page.wait_for_timeout(2000)

            linhas = scope.locator(self.get_selector("incident_table_rows"))
            total = await linhas.count()
            add_message(f"{total} linha(s) na fila de INC.")

            vistos = set()
            incidentes: List[Any] = []
            for i in range(total):
                linha = linhas.nth(i)
                inc_sys_id, inc_num = await self._extrair_codigo_por_link(linha, self.INC_REGEX)
                if not inc_num or inc_num in vistos:
                    continue
                vistos.add(inc_num)
                incidentes.append((inc_sys_id or inc_num, inc_num))

            add_message(f"{len(incidentes)} INC(s) único(s) capturado(s).")

            for inc_id, numero in incidentes:
                item: Dict[str, Any] = {"inc": numero, "analista": analista, "status": "atribuido", "erro": None}
                try:
                    detalhe_url = f"{SERVICE_NOW_BASE_URL}/incident.do?sys_id={inc_id}"
                    add_message(f"Abrindo {numero}: {detalhe_url}")
                    await page.goto(detalhe_url, wait_until="domcontentloaded", timeout=30000)
                    scope_detalhe = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

                    if not await self._aguardar_formulario_pronto(scope_detalhe, add_message):
                        item["status"] = "erro"
                        item["erro"] = "Formulário não carregou a tempo."
                        resultado["processados"].append(item)
                        continue

                    await self.fill_reference_field(scope_detalhe, "incident_assigned_to", analista)
                    if grupo:
                        await self.fill_reference_field(scope_detalhe, "incident_assignment_group", grupo)
                    await self._postar_nota_trabalho(scope_detalhe, f"Atribuído automaticamente para {analista}.")
                    await self.click_element(scope_detalhe, "update_stay_button")
                    await page.wait_for_timeout(1500)
                    add_message(f"✅ {numero} -> {analista} salvo.")
                except Exception as e_item:
                    logger.error(f"❌ [TicketAssignmentService] Erro ao atribuir INC {numero}: {e_item}")
                    add_message(f"❌ {numero}: erro ao atribuir - {e_item}")
                    item["status"] = "erro"
                    item["erro"] = str(e_item)

                resultado["processados"].append(item)

        except Exception as e:
            logger.error(f"❌ [TicketAssignmentService] Erro ao varrer fila de INC: {e}")
            add_message(f"❌ Erro ao varrer fila de INC: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

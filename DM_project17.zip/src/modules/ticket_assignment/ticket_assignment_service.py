"""
================================================================================
SERVIÇO EXCLUSIVO: ATRIBUIÇÃO AUTOMÁTICA DE SCTASK / INC
================================================================================
Varre a fila de SCTASK ou de INC e ATRIBUI cada chamado ao analista certo:
- SCTASK: decide pelo motor de regras (tools/ticket_assignment_rules.py -
  palavra-chave do assunto/descrição contra config/ticket_assignment_rules.json).
- INC: analista ÚNICO fixo, configurado na tela (sem motor de regra).

Herda de ServiceNowDriver - reaproveita POR HERANÇA (não reimplementa):
'varrer_chamados' (varredura da fila de SCTASK, já pronta), 'get_iframe_scope',
'fill_reference_field', 'click_element' e as peças de baixo nível de varredura
('_mapear_cabecalho_lista'/'_extrair_celula'/'_extrair_codigo_por_link', usadas
aqui com 'INC_REGEX' para a fila de INC, que 'varrer_chamados' em si não
suporta - é hardcoded para SCTASK/RITM).

Só GRAVA no ticket 'Assigned to' + 'Assignment group' - os demais campos do
JSON de regras (Type/Reason/Justification/Short_description) parecem campos de
abertura de um REQ novo, não editáveis assim num SCTASK já existente; ficam só
no resultado/log, como referência.
"""

import logging
from typing import Any, Dict, List, Optional
from playwright.async_api import Page

from tools.servicenow_driver import ServiceNowDriver
from tools.chamado import SERVICE_NOW_BASE_URL
from tools.ticket_assignment_rules import encontrar_melhor_regra

logger = logging.getLogger("TicketAssignmentService")


class TicketAssignmentService(ServiceNowDriver):
    """Atribui SCTASKs (por regra de palavra-chave) e INCs (analista fixo) ao analista certo."""

    async def _ler_campo_texto(self, scope, selector_key: str) -> str:
        """Lê o valor de um campo (input/textarea) pela chave do dicionário de paths - "" se não achar."""
        try:
            selector = self.get_selector(selector_key)
            locator = scope.locator(selector).first
            if await locator.count() == 0:
                return ""
            try:
                valor = await locator.input_value()
            except Exception:
                valor = await locator.inner_text()
            return (valor or "").strip()
        except Exception as e:
            logger.debug(f"Aviso ao ler campo '{selector_key}': {e}")
            return ""

    async def atribuir_sctasks(self, page: Page, url: str, regras: Dict[str, Any]) -> Dict[str, Any]:
        """
        Varre a fila 'url' (reaproveita 'self.varrer_chamados', já pronto),
        abre CADA SCTASK individualmente, lê assunto+descrição, decide a regra
        (tools.ticket_assignment_rules.encontrar_melhor_regra) e grava
        Assigned to/Assignment group. Sem regra encontrada -> pula (não mexe
        no ticket). Nunca lança exceção - erro por chamado fica no item, não
        derruba os demais.
        """
        resultado: Dict[str, Any] = {"url": url, "processados": [], "status": "success", "error": None}

        try:
            chamados = await self.varrer_chamados(page=page, url=url)
            logger.info(f"📋 [TicketAssignmentService] {len(chamados)} SCTASK(s) capturada(s) para atribuição.")

            for chamado in chamados:
                numero = chamado.sctask_number or chamado.sctask
                sys_id = chamado.sctask or numero
                if not numero:
                    continue

                item: Dict[str, Any] = {"sctask": numero, "topico": None, "analista": None, "status": "sem_regra", "erro": None}

                try:
                    detalhe_url = f"{SERVICE_NOW_BASE_URL}/sc_task.do?sys_id={sys_id}"
                    await page.goto(detalhe_url, wait_until="domcontentloaded", timeout=30000)
                    scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

                    short_desc = await self._ler_campo_texto(scope, "sctask_short_description_field")
                    descricao = await self._ler_campo_texto(scope, "sctask_description_field")
                    texto_completo = f"{short_desc} {descricao}".strip()

                    regra = encontrar_melhor_regra(texto_completo, regras)
                    if not regra:
                        resultado["processados"].append(item)
                        continue

                    analista = (regra.get("Assigned to") or [None])[0]
                    grupo = regra.get("Assignment group")
                    item["topico"] = (regra.get("Topic") or [None])[0]
                    item["analista"] = analista

                    if grupo:
                        await self.fill_reference_field(scope, "assignment_group", grupo)
                    if analista:
                        await self.fill_reference_field(scope, "sctask_assigned_to", analista)
                    await self.click_element(scope, "update_stay_button")
                    await page.wait_for_timeout(1500)
                    item["status"] = "atribuido"

                except Exception as e_item:
                    logger.error(f"❌ [TicketAssignmentService] Erro ao atribuir SCTASK {numero}: {e_item}")
                    item["status"] = "erro"
                    item["erro"] = str(e_item)

                resultado["processados"].append(item)

        except Exception as e:
            logger.error(f"❌ [TicketAssignmentService] Erro ao varrer fila de SCTASK: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

    async def atribuir_incs(self, page: Page, url: str, analista: str, grupo: Optional[str] = None) -> Dict[str, Any]:
        """
        Varre a fila de INCIDENT em 'url' (própria - 'varrer_chamados' é
        hardcoded pra SCTASK/RITM - reaproveita as peças genéricas de baixo
        nível já existentes: '_mapear_cabecalho_lista'/'_extrair_celula'/
        '_extrair_codigo_por_link', com 'INC_REGEX' no lugar de 'SCTASK_REGEX')
        e atribui TODOS ao mesmo 'analista' fixo - sem motor de regra.
        """
        resultado: Dict[str, Any] = {"url": url, "processados": [], "status": "success", "error": None}

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=10000)
            await page.wait_for_timeout(2000)

            linhas = scope.locator(self.get_selector("incident_table_rows"))
            total = await linhas.count()
            logger.info(f"📋 [TicketAssignmentService] {total} linha(s) na fila de INC.")

            vistos = set()
            incidentes: List[Any] = []
            for i in range(total):
                linha = linhas.nth(i)
                inc_sys_id, inc_num = await self._extrair_codigo_por_link(linha, self.INC_REGEX)
                if not inc_num or inc_num in vistos:
                    continue
                vistos.add(inc_num)
                incidentes.append((inc_sys_id or inc_num, inc_num))

            for inc_id, numero in incidentes:
                item: Dict[str, Any] = {"inc": numero, "analista": analista, "status": "atribuido", "erro": None}
                try:
                    detalhe_url = f"{SERVICE_NOW_BASE_URL}/incident.do?sys_id={inc_id}"
                    await page.goto(detalhe_url, wait_until="domcontentloaded", timeout=30000)
                    scope_detalhe = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

                    await self.fill_reference_field(scope_detalhe, "incident_assigned_to", analista)
                    if grupo:
                        await self.fill_reference_field(scope_detalhe, "incident_assignment_group", grupo)
                    await self.click_element(scope_detalhe, "update_stay_button")
                    await page.wait_for_timeout(1500)
                except Exception as e_item:
                    logger.error(f"❌ [TicketAssignmentService] Erro ao atribuir INC {numero}: {e_item}")
                    item["status"] = "erro"
                    item["erro"] = str(e_item)

                resultado["processados"].append(item)

        except Exception as e:
            logger.error(f"❌ [TicketAssignmentService] Erro ao varrer fila de INC: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

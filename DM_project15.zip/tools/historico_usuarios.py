"""
================================================================================
LOCALIZAÇÃO DE E-MAIL ANTIGO POR CPF (HISTÓRICO DE USUÁRIOS)
================================================================================
Replica o mecanismo de 'cadastro_usuario.txt' usado no branch "CPF existe com
o usuário diferente": quando o UPM recusa o cadastro porque o CPF já pertence
a OUTRO e-mail, o script legado abria uma planilha de controle/histórico de
usuários (coluna C = e-mail, coluna D = CPF formatado com pontuação) para
achar o e-mail antigo associado a esse CPF, inativar aquela conta no UPM e
reaproveitá-la com os dados novos (ver 'PortalTaskUpmService.resolver_cpf_existente').

DIFERENÇA DELIBERADA EM RELAÇÃO AO ORIGINAL: o script legado pegava "o
segundo arquivo" da pasta às cegas (`os.listdir("src/documents")[1]`), sem
validar se era realmente a planilha certa - qualquer outro arquivo salvo
naquela pasta quebrava essa busca silenciosamente. Aqui, em vez de confiar na
ordem/posição dos arquivos, TODAS as planilhas .xlsx do diretório configurado
são varridas em busca do CPF - mesma fonte de dados (planilha em disco),
localização mais robusta.

PASTA COMUM DO APP: o diretório padrão é 'config' (raiz do projeto) - mesma pasta
já usada como local padronizado para os demais arquivos .xlsx/.sql de apoio do
app (ex.: 'config/sql_templates', 'config/servicenow_paths.json'), em vez de uma
pasta exclusiva deste módulo. Substitui o antigo 'src/documents' do script legado,
que nunca existiu nesta estrutura de projeto. A planilha (ex.: 'BR_users2.xlsx')
pode ser colocada ali manualmente OU enviada pela tela do Portal Task (ver
'upload_historico_usuarios' em src/modules/portal_task/routes.py - salva na MESMA
DEFAULT_DIR). Continua sendo OPCIONAL: se a pasta estiver vazia ou a planilha não
existir, 'localizar_email_por_cpf' apenas devolve None e o cadastro segue com uma
pendência registrada - NUNCA trava a automação.
"""

import glob
import logging
import os
import re
from typing import Optional

import openpyxl

logger = logging.getLogger("HistoricoUsuarios")

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Diretório onde fica a(s) planilha(s) de histórico/controle de usuários -
# pasta comum do app (criada automaticamente), configurável via .env
# (HISTORICO_USUARIOS_DIR) para quem preferir apontar para outro local.
DEFAULT_DIR = os.environ.get(
    "HISTORICO_USUARIOS_DIR",
    os.path.join(PROJECT_ROOT, "config"),
)


def garantir_diretorio_historico(diretorio: Optional[str] = None) -> str:
    """Garante a existência da pasta comum do histórico de usuários e devolve seu caminho absoluto."""
    diretorio = diretorio or DEFAULT_DIR
    os.makedirs(diretorio, exist_ok=True)
    return diretorio

# Colunas da planilha histórica (1-based): C = e-mail, D = CPF formatado.
COLUNA_EMAIL = 3
COLUNA_CPF = 4


def _formatar_cpf_com_pontuacao(cpf: str) -> str:
    """111.444.777-35 - mesmo formato usado na coluna D da planilha histórica."""
    digitos = re.sub(r"\D", "", cpf or "")
    if len(digitos) != 11:
        return cpf or ""
    return re.sub(r"(\d{3})(\d{3})(\d{3})(\d{2})", r"\1.\2.\3-\4", digitos)


def _somente_digitos(valor) -> str:
    """
    Normaliza um valor de célula de CPF para dígitos puros, para comparação robusta
    (em vez de exigir string EXATA com pontuação, que quebra se a planilha guardar o
    CPF sem pontuação ou como número). Trata o caso de o Excel/openpyxl entregar o
    CPF como float (ex.: 11144477735.0) - sem o `.is_integer()` abaixo, o '.' viraria
    lixo e o '\\D'-strip deixaria 12 dígitos corrompidos (11144477735 + '0' do ".0").
    """
    if valor is None:
        return ""
    if isinstance(valor, float) and valor.is_integer():
        valor = int(valor)
    return re.sub(r"\D", "", str(valor))


def localizar_email_por_cpf(cpf: str, diretorio: Optional[str] = None) -> Optional[str]:
    """
    Varre todas as planilhas .xlsx do diretório histórico procurando o CPF
    (coluna D, formatado com pontuação) e devolve o e-mail associado (coluna C).

    Nunca lança exceção: devolve None se o diretório/planilhas não existirem
    ou o CPF não for encontrado - quem chama trata isso como pendência manual,
    no mesmo espírito das demais consultas deste projeto (nunca derrubar a
    automação por falta de um dado auxiliar).
    """
    diretorio = diretorio or DEFAULT_DIR
    cpf_formatado = _formatar_cpf_com_pontuacao(cpf)  # só para exibição/log, ver comparação abaixo

    # Comparação feita por DÍGITOS normalizados (não pela string pontuada) - robusta a
    # células da planilha guardando o CPF sem pontuação ou como número (ver
    # '_somente_digitos'). Guarda ANTES do zfill: sem isso, um CPF vazio (11144477735
    # -> "") e uma célula vazia-mas-não-None também zfillariam para a MESMA string de
    # 11 zeros e dariam falso-positivo.
    digitos_alvo = _somente_digitos(cpf)
    if not digitos_alvo or len(digitos_alvo) > 11:
        logger.warning(f"⚠️ [HistoricoUsuarios] CPF '{cpf}' inválido para busca no histórico.")
        return None
    digitos_alvo = digitos_alvo.zfill(11)

    if not os.path.isdir(diretorio):
        logger.warning(f"⚠️ [HistoricoUsuarios] Diretório histórico '{diretorio}' não encontrado - pulando busca por CPF.")
        return None

    arquivos = sorted(glob.glob(os.path.join(diretorio, "*.xlsx")))
    if not arquivos:
        logger.warning(f"⚠️ [HistoricoUsuarios] Nenhuma planilha .xlsx encontrada em '{diretorio}'.")
        return None

    for caminho in arquivos:
        try:
            workbook = openpyxl.load_workbook(caminho, data_only=True, read_only=True)
            planilha = workbook.active
            for linha in planilha.iter_rows(min_row=2, values_only=True):
                if len(linha) < COLUNA_CPF:
                    continue
                email_col = linha[COLUNA_EMAIL - 1]
                cpf_col = linha[COLUNA_CPF - 1]
                digitos_cel = _somente_digitos(cpf_col)
                if digitos_cel and len(digitos_cel) <= 11 and digitos_cel.zfill(11) == digitos_alvo:
                    email_antigo = str(email_col).strip() if email_col else None
                    logger.info(
                        f"✅ [HistoricoUsuarios] CPF '{cpf_formatado}' localizado em "
                        f"'{os.path.basename(caminho)}' -> e-mail antigo: {email_antigo}"
                    )
                    return email_antigo
            workbook.close()
        except Exception as e:
            logger.warning(f"⚠️ [HistoricoUsuarios] Erro ao ler '{caminho}': {e}")
            continue

    logger.warning(f"⚠️ [HistoricoUsuarios] CPF '{cpf_formatado}' não encontrado em nenhuma planilha de '{diretorio}'.")
    return None

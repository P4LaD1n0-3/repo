# -*- coding: utf-8 -*-
"""
ServiceNow Direct Download (HTTP, no browser)
================================================
Downloads incident.xlsx / sc_task.xlsx / problem_task.xlsx straight from
ServiceNow via authenticated HTTP requests - no Selenium, no browser at
all. A full browser automation round-trip (launch Chrome, wait for the
page/JS to load, click through the UI, wait for the download) typically
costs 10-30+ seconds *per file*. A direct HTTP GET against the exact same
export URL, with the same credentials, finishes in 1-3 seconds because
there's no rendering engine involved - just the request/response.

Destination paths are read from config.py's CONFIG (INC_PATH / SCTASK_PATH
/ PRB_PATH) - the SAME values main.py uses to read the files back - so
there is exactly one place that decides where these files live
(DOWNLOAD_DIR / the individual *_PATH overrides in .env), never two
diverging path calculations to keep in sync by hand.

Setup
-----
1. Copy `.env.example` to `.env` and fill in:
   - INC_EXPORT_URL / SCTASK_EXPORT_URL / PRB_EXPORT_URL: the 3 export
     links you currently open by hand / via Selenium (list export links
     such as `.../incident_list.do?XLS&sysparm_query=...`, or a Table API
     URL - anything that returns the file when fetched with the right
     auth headers).
   - SERVICENOW_USER / SERVICENOW_PASSWORD: a service account with Basic
     Auth enabled on your instance (see README - "Why this might not work
     out of the box" if your instance is SSO-only).
2. Run:  python download_data.py   (or double-click download_data.bat)
"""
import os
import sys
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

from config import CONFIG  # noqa: E402 (must load .env first, see above)

SN_USER = os.environ.get("SERVICENOW_USER", "")
SN_PASSWORD = os.environ.get("SERVICENOW_PASSWORD", "")
# Optional fallback for SSO-protected instances where Basic Auth is not
# available: paste the session cookie string from an already-authenticated
# browser tab (DevTools -> Application/Storage -> Cookies) here. Whatever
# is pasted is sent verbatim as the Cookie header.
SN_SESSION_COOKIE = os.environ.get("SERVICENOW_SESSION_COOKIE", "")

TIMEOUT = int(os.environ.get("DOWNLOAD_TIMEOUT_SECONDS", "60") or 60)
RETRIES = int(os.environ.get("DOWNLOAD_RETRIES", "2") or 2)

# (label, env var holding the URL, destination path - straight from CONFIG)
SOURCES = [
    ("INC", "INC_EXPORT_URL", CONFIG["INC_PATH"]),
    ("SCTASK", "SCTASK_EXPORT_URL", CONFIG["SCTASK_PATH"]),
    ("PRB", "PRB_EXPORT_URL", CONFIG["PRB_PATH"]),
]


def _build_session():
    session = requests.Session()
    session.headers.update({
        "Accept": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, "
                  "application/vnd.ms-excel, application/octet-stream, */*",
        "User-Agent": "Mozilla/5.0 (compatible; IT-Dashboard-Downloader/1.0)",
    })
    if SN_SESSION_COOKIE:
        session.headers["Cookie"] = SN_SESSION_COOKIE
    return session


def _looks_like_login_page(content, content_type):
    """Heuristic: if we asked for a spreadsheet and got back HTML that
    smells like a login/SSO redirect, the download silently failed even
    though the HTTP status was 200."""
    if content_type and "html" in content_type.lower():
        head = content[:500].lower()
        if b"<html" in head or b"<!doctype html" in head:
            return True
    return False


def download_one(label, url, dest_path, session):
    if not url:
        print(f"   -> SKIP {label}: no URL configured ({label}_EXPORT_URL is empty in .env)")
        return False

    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)
    auth = (SN_USER, SN_PASSWORD) if SN_USER and SN_PASSWORD else None

    last_error = None
    for attempt in range(1, RETRIES + 2):
        try:
            t0 = time.time()
            resp = session.get(url, auth=auth, timeout=TIMEOUT, allow_redirects=True)
            elapsed = time.time() - t0
            resp.raise_for_status()

            content_type = resp.headers.get("Content-Type", "")
            if _looks_like_login_page(resp.content, content_type):
                print(f"   -> WARNING {label}: got an HTML page back, not a spreadsheet. "
                      f"This usually means Basic Auth isn't enabled for this instance "
                      f"(SSO redirected the request) - see README 'Why this might not "
                      f"work out of the box'.")
                return False

            if len(resp.content) < 100:
                raise ValueError(f"response body too small ({len(resp.content)} bytes) - likely not a real file")

            with open(dest_path, "wb") as f:
                f.write(resp.content)

            print(f"   -> OK {label}: {dest_path} ({len(resp.content) / 1024:.1f} KB, {elapsed:.1f}s)")
            return True

        except (requests.exceptions.RequestException, ValueError) as e:
            last_error = e
            if attempt <= RETRIES:
                print(f"   -> retry {attempt}/{RETRIES} for {label} after error: {e}")
                time.sleep(1.5)
            continue

    print(f"   -> FAILED {label}: {last_error}")
    return False


def main():
    print("=" * 70)
    print("ServiceNow Direct Download (HTTP, no browser)")
    print("=" * 70)
    if not (SN_USER and SN_PASSWORD) and not SN_SESSION_COOKIE:
        print("\nWARNING: no SERVICENOW_USER/SERVICENOW_PASSWORD and no "
              "SERVICENOW_SESSION_COOKIE set in .env - requests will be sent "
              "unauthenticated and will likely fail or return a login page.")

    session = _build_session()
    results = []
    for label, url_env, dest in SOURCES:
        url = os.environ.get(url_env, "")
        print(f"\n[{label}] {'-> ' + url if url else '(no URL configured)'}")
        ok = download_one(label, url, dest, session)
        results.append((label, ok))

    print("\n" + "=" * 70)
    ok_count = sum(1 for _, ok in results if ok)
    print(f"{ok_count}/{len(results)} files downloaded successfully.")
    if ok_count < len(results):
        print("Some downloads failed - check the messages above, then see")
        print("README.md -> 'Why this might not work out of the box' for the")
        print("most common cause (SSO-protected instances need a different auth path).")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

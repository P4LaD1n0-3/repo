@echo off
REM Downloads the 3 ServiceNow exports via direct HTTP (no browser/Selenium).
REM Double-click this file, or run it from Task Scheduler.

setlocal
cd /d "%~dp0"

echo ============================================================
echo  Downloading ServiceNow data (incident / sc_task / problem_task)
echo ============================================================

python download_data.py
set EXIT_CODE=%ERRORLEVEL%

if %EXIT_CODE% NEQ 0 (
    echo.
    echo Download finished with errors - see messages above.
    pause
    exit /b %EXIT_CODE%
)

echo.
echo Download complete.
endlocal

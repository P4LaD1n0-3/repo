@echo off
REM Full pipeline: download the 3 ServiceNow exports, then build and send
REM the dashboard e-mail. Ideal for Task Scheduler (e.g. run every morning
REM at 8am) - no manual steps, no browser window ever opens.

setlocal
cd /d "%~dp0"

echo ============================================================
echo  Step 1/2 - Downloading ServiceNow data
echo ============================================================
python download_data.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Download step failed - aborting before sending an e-mail with stale data.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Step 2/2 - Building and sending the dashboard
echo ============================================================
python main.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Report/e-mail step failed - see messages above.
    pause
    exit /b 1
)

echo.
echo All done.
endlocal

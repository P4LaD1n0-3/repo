import re
import asyncio
import logging
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import async_playwright, BrowserContext, Page, FrameLocator
from tools.base_automation import BaseAutomation, SelectorManager
from tools.okta_auth import OktaAuthManager

logger = logging.getLogger("ServiceNowDriver")

class ServiceNowDriver(BaseAutomation):
    """
    Driver especializado para automações no ServiceNow.
    Herda todos os métodos utilitários de BaseAutomation e adiciona
    regras e métodos específicos para ServiceNow (Slushbuckets, Reference Fields, iFrames, SCTASKs e Okta SSO).
    """

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def select_servicenow_slushbucket(
        self, 
        scope: Union[Page, FrameLocator], 
        values: List[str], 
        available_key: str = "slushbucket_available", 
        add_btn_key: str = "slushbucket_add_btn"
    ) -> bool:
        """
        Método especializado para selecionar múltiplas opções no menu Slushbucket do ServiceNow.
        (Componente visual do ServiceNow com 2 caixas de seleção e botões de adicionar/remover).
        :param scope: Escopo (Page ou FrameLocator gsft_main).
        :param values: Lista de valores ou rótulos dos itens a serem selecionados.
        :param available_key: Chave do dicionário de paths para o <select> de itens disponíveis.
        :param add_btn_key: Chave do dicionário de paths para o botão de adicionar (> / Add).
        """
        logger.info(f"📋 [ServiceNow] Selecionando itens no Slushbucket: {values}")
        try:
            available_select_key = self.get_selector(available_key)
            # Seleciona as opções desejadas no menu da esquerda
            await scope.locator(available_select_key).select_option(values=values)
            await asyncio.sleep(0.5)
            # Clica no botão de adicionar (Add / >)
            await self.click_element(scope, add_btn_key)
            logger.info("✅ Itens adicionados no Slushbucket com sucesso.")
            return True
        except Exception as e:
            logger.error(f"❌ Erro ao manipular o Slushbucket do ServiceNow: {e}")
            raise e

    async def fill_reference_field(
        self, 
        scope: Union[Page, FrameLocator], 
        selector_key: str, 
        search_text: str, 
        confirm_with_enter: bool = True
    ):
        """
        Preenche um campo de referência/lupa do ServiceNow e aguarda auto-complete ou confirma com Enter.
        :param scope: Escopo (Page ou FrameLocator gsft_main).
        :param selector_key: Chave do dicionário de paths referente ao campo input.
        :param search_text: Texto para buscar na referência.
        :param confirm_with_enter: Se True, envia a tecla Enter após digitar.
        """
        logger.info(f"🔎 [ServiceNow] Preenchendo campo de referência [{selector_key}] com '{search_text}'...")
        selector = self.get_selector(selector_key)
        locator = scope.locator(selector).first
        await locator.click()
        await locator.fill(search_text)
        await asyncio.sleep(0.5)
        if confirm_with_enter:
            await locator.press("Enter")
            await asyncio.sleep(1)

    async def click_form_button(
        self, 
        scope: Union[Page, FrameLocator], 
        button_key: str = "form_save_button"
    ):
        """Clica em um botão de formulário do ServiceNow (como Salvar, Atualizar, Inserir)."""
        logger.info(f"🔘 [ServiceNow] Clicando no botão de formulário [{button_key}]...")
        await self.click_element(scope, button_key)

    async def process_servicenow_page(self, page: Page, url: str) -> Dict[str, Any]:
        """
        Processa uma página individual do ServiceNow:
        1. Acessa a URL.
        2. Identifica e altera o contexto para o iFrame 'gsft_main' (com fallback seguro).
        3. Extrai códigos e textos contendo 'SCTASK'.
        """
        logger.info(f"📄 [ServiceNowDriver] Processando URL: {url}")

        result: Dict[str, Any] = {
            "url": url,
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # Utiliza o método herdado de BaseAutomation com suporte ao dicionario de paths
            target_scope = await self.get_iframe_scope(
                page=page, 
                iframe_key_or_selector="gsft_main", 
                timeout=20000
            )

            await page.wait_for_timeout(3000)

            found_texts = set()

            # Estratégia 1: Busca por seletores de texto do Playwright
            try:
                sctask_locators = target_scope.locator("text=/SCTASK\\d*/")
                count = await sctask_locators.count()
                for i in range(count):
                    text = await sctask_locators.nth(i).inner_text()
                    clean_text = text.strip()
                    if clean_text:
                        found_texts.add(clean_text)
            except Exception as ex_loc:
                logger.warning(f"Aviso na Estratégia 1 de busca: {ex_loc}")

            # Estratégia 2: Regex direto no HTML / Corpo do DOM
            try:
                if target_scope == page:
                    body_text = await page.inner_text("body")
                else:
                    body_text = await target_scope.locator("body").inner_text()

                matches = re.findall(r"SCTASK\d+", body_text)
                for m in matches:
                    found_texts.add(m)
            except Exception as ex_body:
                logger.warning(f"Aviso na Estratégia 2 (body regex): {ex_body}")

            result["sctasks"] = sorted(list(found_texts))
            logger.info(f"✅ [ServiceNowDriver] {len(result['sctasks'])} SCTASK(s) encontrados em {url}: {result['sctasks']}")

        except Exception as e:
            logger.error(f"❌ [ServiceNowDriver] Erro ao processar a página {url}: {e}")
            result["status"] = "error"
            result["error"] = str(e)

        return result

    async def process_multiple_pages(
        self, 
        context: BrowserContext, 
        urls: List[str], 
        max_concurrency: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Processa múltiplas URLs do ServiceNow utilizando a infraestrutura de concorrência assíncrona herdada.
        """
        return await self.run_concurrent_tasks(context, urls, self.process_servicenow_page, max_concurrency)


    async def run_extraction(
        self, 
        urls: List[str], 
        headless: bool = False, 
        max_concurrency: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Método principal que gerencia o ciclo de vida da execução:
        Inicia contexto persistente -> Valida Okta -> Executa raspagem em paralelo -> Retorna os dados.
        """
        async with async_playwright() as p:
            context = await self.launch_persistent_context(p, headless=headless)
            try:
                if urls:
                    check_page = await context.new_page()
                    await OktaAuthManager.wait_for_okta_login_if_needed(check_page, urls[0])
                    await check_page.close()

                logger.info(f"🚀 Iniciando processamento de {len(urls)} páginas no ServiceNow...")
                resultados = await self.process_multiple_pages(context, urls, max_concurrency=max_concurrency)
                return resultados
            finally:
                await self.close_context(context)

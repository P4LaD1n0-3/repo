import os
import base64
import platform
import subprocess
import logging
from datetime import datetime

logger = logging.getLogger("SmtpTools")

# Detect OS
IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"

def send_outlook_windows(to, cc, subject, html_body, screenshot_base64=None, attachments=None):
    """
    Envia e-mail de forma silenciosa no Windows via Outlook COM com suporte a anexos de arquivo e screenshot.
    """
    import win32com.client
    try:
        safe_to = str(to) if to else ""
        safe_cc = str(cc) if cc else ""
        safe_subject = str(subject) if subject else "Relatório Automação - " + datetime.now().strftime('%d/%m/%Y')
        
        logger.info(f"--- Preparando envio de E-mail Silencioso via Outlook (Windows) ---")
        outlook = win32com.client.Dispatch("outlook.application")
        mail = outlook.CreateItem(0)
        
        if safe_to:
            mail.To = safe_to
        else:
            logger.warning("⚠️ Aviso: Destinatário vazio. O envio pode falhar.")
            
        mail.Subject = safe_subject
        mail.HTMLBody = html_body
        mail.Importance = 2  # Normal
        
        if safe_cc:
            mail.CC = safe_cc
            
        # Handle Screenshot Attachment
        if screenshot_base64:
            temp_path = os.path.join(os.getcwd(), "temp_screenshot_mail.png")
            try:
                img_data = base64.b64decode(screenshot_base64.split(",")[1])
                with open(temp_path, "wb") as f:
                    f.write(img_data)
                mail.Attachments.Add(os.path.abspath(temp_path))
            except Exception as e_img:
                logger.warning(f"⚠️ Erro ao anexar screenshot: {e_img}")

        # Handle File Attachments (Planilhas xlsx, PDF, etc.)
        if attachments and isinstance(attachments, (list, tuple)):
            for att_path in attachments:
                if att_path and os.path.exists(att_path):
                    try:
                        mail.Attachments.Add(os.path.abspath(att_path))
                        logger.info(f"📎 Anexo adicionado no Windows: {att_path}")
                    except Exception as e_att:
                        logger.warning(f"⚠️ Erro ao anexar arquivo '{att_path}': {e_att}")

        # DISPARO SILENCIOSO
        mail.Send()
        logger.info(f"✅ E-mail enviado com sucesso para {safe_to}!")
        return True, f"E-mail enviado silenciosamente via Outlook (Windows) para {safe_to}."
    except Exception as e:
        logger.error(f"❌ Erro crítico ao enviar e-mail (Windows): {e}")
        return False, str(e)


def send_outlook_mac(to, cc, subject, html_body, attachments=None):
    """
    Envia e-mail HTML renderizado via AppleScript no Mac OS.
    Grava o corpo HTML em arquivo temporário UTF-8 e instrui o Microsoft Outlook (ou Mail)
    a definir a propriedade 'html content', evitando exibição de código HTML puro.
    """
    try:
        safe_to = str(to).strip() if to else ""
        safe_cc = str(cc).strip() if cc else ""
        safe_subj = (str(subject) if subject else "Relatório Automação") \
            .replace('\\', '\\\\').replace('"', '\\"')

        # Grava o HTML em arquivo temporário para evitar estouro de comando bash e problemas de escape
        temp_html_path = os.path.join(os.getcwd(), "temp_email_body_mac.html")
        with open(temp_html_path, "w", encoding="utf-8") as f:
            f.write(html_body)

        abs_temp_html = os.path.abspath(temp_html_path).replace('\\', '\\\\').replace('"', '\\"')
        safe_to_esc = safe_to.replace('\\', '\\\\').replace('"', '\\"')

        # Script principal para Microsoft Outlook Mac
        as_script = (
            f'set htmlFile to POSIX file "{abs_temp_html}"\n'
            'set htmlText to (read htmlFile as «class utf8»)\n'
            'tell application "Microsoft Outlook"\n'
            f'    set newMsg to make new outgoing message with properties {{subject:"{safe_subj}"}}\n'
            '    set html content of newMsg to htmlText\n'
            f'    make new to recipient at newMsg with properties {{email address:{{address:"{safe_to_esc}"}}}}\n'
        )

        if safe_cc:
            safe_cc_esc = safe_cc.replace('\\', '\\\\').replace('"', '\\"')
            as_script += (
                f'    make new cc recipient at newMsg with properties'
                f' {{email address:{{address:"{safe_cc_esc}"}}}}\n'
            )

        # Handle File Attachments no Mac
        if attachments and isinstance(attachments, (list, tuple)):
            for att_path in attachments:
                if att_path and os.path.exists(att_path):
                    abs_att = os.path.abspath(att_path).replace('\\', '\\\\').replace('"', '\\"')
                    as_script += (
                        f'    make new attachment at newMsg with properties'
                        f' {{file:POSIX file "{abs_att}"}}\n'
                    )
                    logger.info(f"📎 Anexo preparado para Outlook Mac: {abs_att}")

        as_script += '    send newMsg\nend tell'

        try:
            subprocess.run(['osascript', '-e', as_script], check=True, capture_output=True)
            logger.info(f"✅ E-mail HTML renderizado com sucesso (Outlook Mac) para {safe_to}!")
            return True, f"E-mail HTML renderizado enviado via Outlook (Mac) para {safe_to}."
        except subprocess.CalledProcessError as e_outlook:
            err_outlook = e_outlook.stderr.decode('utf-8', errors='replace') if e_outlook.stderr else str(e_outlook)
            logger.warning(f"⚠️ Outlook Mac não disponível ({err_outlook}). Tentando via Apple Mail...")

            # Fallback para Apple Mail
            as_mail_script = (
                f'set htmlFile to POSIX file "{abs_temp_html}"\n'
                'set htmlText to (read htmlFile as «class utf8»)\n'
                'tell application "Mail"\n'
                f'    set newMsg to make new outgoing message with properties {{subject:"{safe_subj}", visible:false}}\n'
                '    tell newMsg\n'
                '        set html content to htmlText\n'
                f'        make new to recipient at end of to recipients with properties {{address:"{safe_to_esc}"}}\n'
            )
            if safe_cc:
                as_mail_script += f'        make new cc recipient at end of cc recipients with properties {{address:"{safe_cc_esc}"}}\n'
            
            if attachments and isinstance(attachments, (list, tuple)):
                for att_path in attachments:
                    if att_path and os.path.exists(att_path):
                        abs_att = os.path.abspath(att_path).replace('\\', '\\\\').replace('"', '\\"')
                        as_mail_script += f'        make new attachment with properties {{file name:"{abs_att}"}} at end of attachments\n'

            as_mail_script += '        send\n    end tell\nend tell'

            try:
                subprocess.run(['osascript', '-e', as_mail_script], check=True, capture_output=True)
                logger.info(f"✅ E-mail HTML renderizado enviado via Apple Mail para {safe_to}!")
                return True, f"E-mail HTML renderizado enviado via Apple Mail para {safe_to}."
            except Exception as e_mail:
                logger.error(f"❌ Erro ao enviar via Apple Mail: {e_mail}")
                return False, f"Falha ao enviar e-mail via Outlook/Mail: {err_outlook}"

    except Exception as e:
        logger.error(f"❌ Erro crítico ao enviar e-mail (Mac): {e}")
        return False, str(e)


def enviar_email_automatico(to, cc, subject, html_body, screenshot_base64=None, attachments=None):
    """
    Função principal que identifica o sistema operacional automaticamente 
    e dispara o e-mail via Outlook (sem pedir senhas) com suporte a arquivos anexados.
    """
    if IS_WINDOWS:
        return send_outlook_windows(to, cc, subject, html_body, screenshot_base64, attachments)
    elif IS_MAC:
        return send_outlook_mac(to, cc, subject, html_body, attachments)
    else:
        err = f"Sistema Operacional não suportado ({platform.system()}) para envio via Outlook."
        logger.error(f"❌ {err}")
        return False, err


class SmtpMailer:
    """
    Classe modular para reuso e herança em diferentes automações do sistema.
    Permite instanciar um cliente de envio pré-configurado para um módulo ou região específica,
    simplificando o despacho contínuo de relatórios e alertas.
    """
    def __init__(self, default_to="", default_cc="", default_subject_prefix="Automação Web"):
        self.default_to = default_to
        self.default_cc = default_cc
        self.default_subject_prefix = default_subject_prefix

    def send(self, html_body, subject=None, to=None, cc=None, attachments=None, screenshot_base64=None):
        """Dispara o e-mail combinando configurações padrão com os overrides específicos de execução."""
        target_to = to if to is not None else self.default_to
        target_cc = cc if cc is not None else self.default_cc
        final_subject = subject if subject is not None else f"{self.default_subject_prefix} - {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        
        return enviar_email_automatico(
            to=target_to,
            cc=target_cc,
            subject=final_subject,
            html_body=html_body,
            screenshot_base64=screenshot_base64,
            attachments=attachments
        )

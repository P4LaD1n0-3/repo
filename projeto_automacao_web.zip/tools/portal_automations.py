import logging
import asyncio
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import BrowserContext, Page, FrameLocator
from tools.servicenow_driver import ServiceNowDriver
from tools.base_automation import SelectorManager


logger = logging.getLogger("PortalAutomations")

class PortalBaseTaskAutomation(ServiceNowDriver):
    """
    Classe base para automações de tarefas do Portal no ServiceNow.
    Herda de ServiceNowDriver que por sua vez herda de BaseAutomation.
    Fornece métodos genéricos de execução e logging.
    """

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Método base de execução para uma URL individual.
        Classes filhas podem sobrescrever este método para implementar fluxos específicos.
        """
        logger.info(f"⚙️ [{self.__class__.__name__}] Processando URL: {url}")
        return await self.process_servicenow_page(page, url)


class UserCadastroAutomation(PortalBaseTaskAutomation):
    """Automação especializada para 'Cadastro de usuário'."""

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        logger.info(f"👤 [UserCadastroAutomation] Iniciando fluxo de Cadastro de Usuário em: {url}")
        res = await super().execute_single_url(page, url, extra_params)
        res["action_type"] = "Cadastro de usuário"
        return res


class AssessoriaCadastroAutomation(PortalBaseTaskAutomation):
    """Automação especializada para 'Cadastro de assessoria'."""

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        logger.info(f"🏢 [AssessoriaCadastroAutomation] Iniciando fluxo de Cadastro de Assessoria em: {url}")
        res = await super().execute_single_url(page, url, extra_params)
        res["action_type"] = "Cadastro de assessoria"
        return res


class UserDesabilitarAutomation(PortalBaseTaskAutomation):
    """Automação especializada para 'Desabilitar usuário'."""

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        logger.info(f"🚫 [UserDesabilitarAutomation] Desabilitando usuário em: {url}")
        res = await super().execute_single_url(page, url, extra_params)
        res["action_type"] = "Desabilitar usuário"
        return res


class UserAlterarAutomation(PortalBaseTaskAutomation):
    """
    Automação especializada para 'Alterar usuário'.
    Captura e processa todos os campos do modal (E-mail origem/destino, RITM, CNPJ, Nome, Produto ID).
    """

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = extra_params or {}
        logger.info("=" * 60)
        logger.info(f"✏️ [UserAlterarAutomation] Executando Alteração de Usuário em: {url}")
        logger.info(f"   ► Alteração Assessoria: {params.get('alt_is_assessoria')}")
        logger.info(f"   ► Origem: E-mail='{params.get('alt_de_email')}' | RITM='{params.get('alt_de_ritm')}'")
        logger.info(f"   ► Destino: E-mail='{params.get('alt_para_email')}' | CNPJ='{params.get('alt_para_cnpj')}' | Nome='{params.get('alt_para_nome')}' | ProdutoID='{params.get('alt_para_produto_id')}'")
        logger.info("=" * 60)

        # Executa acesso à página do ServiceNow e resolução de iframe
        res = await self.process_servicenow_page(page, url)
        res["action_type"] = "Alterar usuário"
        res["modal_params"] = params
        return res


class PasswordResetAutomation(PortalBaseTaskAutomation):
    """Automação especializada para 'Reset de senha'."""

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        logger.info(f"🔑 [PasswordResetAutomation] Executando Reset de Senha em: {url}")
        res = await super().execute_single_url(page, url, extra_params)
        res["action_type"] = "Reset de senha"
        return res


class MfaResetAutomation(PortalBaseTaskAutomation):
    """Automação especializada para 'Reset de mfa'."""

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        logger.info(f"📱 [MfaResetAutomation] Executando Reset de MFA em: {url}")
        res = await super().execute_single_url(page, url, extra_params)
        res["action_type"] = "Reset de mfa"
        return res


class TaskEncerrarAutomation(PortalBaseTaskAutomation):
    """Automação especializada para 'Encerrar'."""

    async def execute_single_url(self, page: Page, url: str, extra_params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        logger.info(f"🛑 [TaskEncerrarAutomation] Encerrando tarefa em: {url}")
        res = await super().execute_single_url(page, url, extra_params)
        res["action_type"] = "Encerrar"
        return res


class PortalAutomationFactory:
    """
    Fábrica (Factory Pattern) que instancia dinamicamente o manipulador
    de automação correto com base na ação selecionada no frontend.
    """

    _ACTION_MAP = {
        "Cadastro de usuário": UserCadastroAutomation,
        "Cadastro de assessoria": AssessoriaCadastroAutomation,
        "Desabilitar usuário": UserDesabilitarAutomation,
        "Alterar usuário": UserAlterarAutomation,
        "Reset de senha": PasswordResetAutomation,
        "Reset de mfa": MfaResetAutomation,
        "Encerrar": TaskEncerrarAutomation,
    }

    @classmethod
    def get_automation(
        cls, 
        action_name: str, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ) -> PortalBaseTaskAutomation:
        """
        Retorna uma instância da classe especialista correspondente à ação solicitada.
        Se a ação não for reconhecida, retorna PortalBaseTaskAutomation como fallback seguro.
        """
        automation_class = cls._ACTION_MAP.get(action_name, PortalBaseTaskAutomation)
        logger.info(f"🏭 [PortalAutomationFactory] Ação '{action_name}' mapeada para classe: {automation_class.__name__}")
        return automation_class(selectors=selectors, user_data_dir=user_data_dir)

from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(100), default="Operacional")
    servicenow_name = db.Column(db.String(150), nullable=True)
    signature_name = db.Column(db.String(150), nullable=True)
    pinned_modules = db.Column(db.Text, nullable=True, default='["portal_task"]')

    @property
    def pinned_list(self):
        """Retorna a lista de chaves de módulos pino como lista Python"""
        import json
        try:
            if self.pinned_modules:
                return json.loads(self.pinned_modules)
        except Exception:
            pass
        return ["portal_task"]


    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def display_servicenow_name(self):
        return self.servicenow_name or self.full_name

    @property
    def display_signature_name(self):
        return self.signature_name or self.full_name


    @property
    def short_name(self):
        """Retorna o primeiro e último nome ou nome resumido (ex: Wesley Simões)"""
        parts = self.full_name.split()
        if len(parts) > 1:
            return f"{parts[0]} {parts[-1]}"
        return self.full_name

    @property
    def initials(self):
        """Retorna as iniciais do usuário para o avatar (ex: WS)"""
        parts = self.full_name.split()
        if len(parts) >= 2:
            return f"{parts[0][0]}{parts[-1][0]}".upper()
        elif len(parts) == 1 and len(parts[0]) > 0:
            return parts[0][0:2].upper()
        return "US"


class PortalTaskConfig(db.Model):
    """
    Tabela exclusiva para persistência de configurações, URLs e caminhos do módulo Portal Task.
    """
    __tablename__ = 'portal_task_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    url_cadastrar = db.Column(db.Text, nullable=True, default="https://aig.service-now.com/nav_to.do?uri=%2Fsc_task.do%3Fsys_id%3Dcadastrar_user")
    url_reset_senha = db.Column(db.Text, nullable=True, default="https://aig.service-now.com/nav_to.do?uri=%2Fsc_task.do%3Fsys_id%3Dreset_senha")
    url_reset_mfa = db.Column(db.Text, nullable=True, default="https://aig.service-now.com/nav_to.do?uri=%2Fsc_task.do%3Fsys_id%3Dreset_mfa")
    url_encerrar = db.Column(db.Text, nullable=True, default="https://aig.service-now.com/nav_to.do?uri=%2Fsc_task.do%3Fsys_id%3Dencerrar")
    url_desabilitar = db.Column(db.Text, nullable=True, default="https://aig.service-now.com/nav_to.do?uri=%2Fsc_task.do%3Fsys_id%3Ddesabilitar")

    output_format = db.Column(db.String(50), nullable=True, default="excel")
    output_directory = db.Column(db.Text, nullable=True, default="C:\\Users\\wsimoes\\Downloads\\PortalTasks")
    headless = db.Column(db.Boolean, default=True)

    # Opções de Automação & Campos do Modal 'Alterar usuário'
    automation_action = db.Column(db.String(100), nullable=True, default="Cadastro de usuário")
    alt_is_assessoria = db.Column(db.Boolean, default=True)
    alt_de_email = db.Column(db.String(255), nullable=True)
    alt_de_ritm = db.Column(db.String(100), nullable=True, default="RITM0000000")
    alt_para_email = db.Column(db.String(255), nullable=True)
    alt_para_cnpj = db.Column(db.String(50), nullable=True, default="00.000.000/0001-00")
    alt_para_nome = db.Column(db.String(255), nullable=True)
    alt_para_produto_id = db.Column(db.String(100), nullable=True)

    user = db.relationship('User', backref=db.backref('portal_config', uselist=False))


    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração do usuário ou cria uma nova com valores padrão se não existir."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config


class EmailReportConfig(db.Model):
    """
    Tabela para persistência dos 4 campos de configuração de e-mail, seleção de região
    (BRAZIL / MEX) e opções de relatórios automatizados do usuário.
    """
    __tablename__ = 'email_report_configs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, unique=True)

    selected_region = db.Column(db.String(50), nullable=True, default="BRAZIL")
    
    # 4 Campos para Configuração de E-mail (Brasil e México)
    brazil_to = db.Column(db.Text, nullable=True, default="rolim.r@hotmail.com;wesley.simoes@aig.com")
    brazil_cc = db.Column(db.Text, nullable=True, default="brasil.copia@aig.com")
    mex_to = db.Column(db.Text, nullable=True, default="mexico.ops@aig.com")
    mex_cc = db.Column(db.Text, nullable=True, default="mexico.copia@aig.com")

    subject_prefix = db.Column(db.String(200), nullable=True, default="IT Analyst Performance Comparison - Dashboard")
    output_directory = db.Column(db.Text, nullable=True, default="C:\\Users\\wsimoes\\Downloads\\ReportExports")
    send_email_enabled = db.Column(db.Boolean, default=True)

    user = db.relationship('User', backref=db.backref('email_report_config', uselist=False))

    @classmethod
    def get_or_create(cls, user_id):
        """Busca a configuração de e-mail do usuário ou cria uma nova com valores padrão."""
        config = cls.query.filter_by(user_id=user_id).first()
        if not config:
            config = cls(user_id=user_id)
            db.session.add(config)
            db.session.commit()
        return config

import os
import sys
import logging
import traceback
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from src.models import db, EmailReportConfig

# Garantir que a raiz do projeto e a pasta exemple estejam no sys.path
root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)
exemple_dir = os.path.join(root_dir, 'exemple')
if exemple_dir not in sys.path:
    sys.path.insert(0, exemple_dir)

try:
    from tools.smtp import enviar_email_automatico
except ImportError:
    try:
        from exemple.smtp import enviar_email_automatico
    except ImportError:
        enviar_email_automatico = None

try:
    import pandas as pd
    from exemple.analyst_report_builder import build_analyst_report
    from exemple.report_builder import build_report
    from exemple.data_loader import load_all, load_sctask, load_inc, load_prb
    import exemple.metrics as m
    from exemple.config import CONFIG as EXEMPLE_CONFIG
except Exception as e_imp:
    build_analyst_report = None
    build_report = None
    EXEMPLE_CONFIG = {}

logger = logging.getLogger("EmailReport")

current_dir = os.path.dirname(os.path.abspath(__file__))
email_report_bp = Blueprint('email_report', __name__, template_folder=current_dir)

@email_report_bp.route('/email_report')
@login_required
def index():
    """Renderiza a aba Email Report com as configurações persistidas no SQLite."""
    config = EmailReportConfig.get_or_create(current_user.id)
    return render_template('email_report.html', user=current_user, active_page='email_report', config=config)

def _update_config_from_request(config, data):
    """Atualiza as propriedades do EmailReportConfig (incluindo os 4 campos e região)."""
    config.selected_region = data.get('selected_region', config.selected_region)
    config.brazil_to = data.get('brazil_to', config.brazil_to)
    config.brazil_cc = data.get('brazil_cc', config.brazil_cc)
    config.mex_to = data.get('mex_to', config.mex_to)
    config.mex_cc = data.get('mex_cc', config.mex_cc)
    config.subject_prefix = data.get('subject_prefix', config.subject_prefix)
    config.output_directory = data.get('output_directory', config.output_directory)
    
    if 'send_email_enabled' in data:
        raw_val = data.get('send_email_enabled')
        config.send_email_enabled = str(raw_val).lower() in ('true', '1', 'on', 'yes')

@email_report_bp.route('/api/email_report/save_config', methods=['POST'])
@login_required
def save_config():
    """Salva no banco SQLite os 4 campos de e-mail, região selecionada e opções."""
    data = request.get_json(silent=True)
    if not data:
        data = request.form
    
    config = EmailReportConfig.get_or_create(current_user.id)
    _update_config_from_request(config, data)
    db.session.commit()
    
    logger.info(f"✅ Configuração do Email Report salva para o usuário ID {current_user.id}. Região: {config.selected_region}")
    return jsonify({'status': 'success', 'message': 'Configurações e e-mails salvos no banco SQLite com sucesso!'})

@email_report_bp.route('/api/email_report/execute', methods=['POST'])
@login_required
def execute_email_report():
    """
    ============================================================================
    EXECUÇÃO E DISPARO DE RELATÓRIO VIA E-MAIL (COM ANEXOS XLSX & SELETOR BR/MEX)
    ============================================================================
    1. Atualiza as configurações no banco SQLite.
    2. Identifica a Região (BRAZIL ou MEX) e seleciona automaticamente o par TO/CC.
    3. Processa e salva os arquivos carregados manualmente no input de anexos.
    4. Constrói o Dashboard HTML completo utilizando o pipeline de exemple.
    5. Dispara via Outlook/Mail renderizando o HTML corretamente com todos os anexos.
    """
    try:
        # 1. Atualizar e salvar config
        config = EmailReportConfig.get_or_create(current_user.id)
        form_data = request.form
        _update_config_from_request(config, form_data)
        db.session.commit()

        # 2. Seleção de e-mails com base na opção de região
        region = (config.selected_region or "BRAZIL").upper()
        if region == "MEX":
            target_to = config.mex_to
            target_cc = config.mex_cc
            region_name = "México (MEX)"
        else:
            target_to = config.brazil_to
            target_cc = config.brazil_cc
            region_name = "Brasil (BRAZIL)"

        if not target_to:
            return jsonify({
                'status': 'error',
                'message': f'Nenhum e-mail de destinatário (Para) configurado para a região {region_name}.'
            }), 400

        # 3. Processamento de Anexos (Arquivos .xlsx carregados manualmente)
        upload_dir = os.path.join(root_dir, 'instance', 'uploads', 'email_reports', f'user_{current_user.id}')
        os.makedirs(upload_dir, exist_ok=True)

        uploaded_files = request.files.getlist('anexos')
        attachments_list = []
        file_info_list = []

        for file_obj in uploaded_files:
            if file_obj and file_obj.filename:
                filename = secure_filename(file_obj.filename)
                file_path = os.path.join(upload_dir, filename)
                file_obj.save(file_path)
                
                size_kb = round(os.path.getsize(file_path) / 1024, 1)
                attachments_list.append(file_path)
                file_info_list.append(f"{filename} ({size_kb} KB)")

        # 4. Geração do Corpo HTML do Dashboard (@exemple_dashboard_report.html)
        html_body = None
        report_type = "Executive IT Dashboard HTML"

        # Tentar resolver caminhos das planilhas nos uploads recentes do usuário ou na pasta default
        sctask_path = next((p for p in attachments_list if 'sc_task' in p.lower() or 'sctask' in p.lower()), None)
        inc_path = next((p for p in attachments_list if 'inc' in p.lower()), None)
        prb_path = next((p for p in attachments_list if 'prob' in p.lower() or 'prb' in p.lower()), None)

        if not sctask_path and os.path.exists(os.path.join(upload_dir, "sc_task.xlsx")):
            sctask_path = os.path.join(upload_dir, "sc_task.xlsx")
        if not inc_path and os.path.exists(os.path.join(upload_dir, "incident.xlsx")):
            inc_path = os.path.join(upload_dir, "incident.xlsx")
        if not prb_path and os.path.exists(os.path.join(upload_dir, "problem_task.xlsx")):
            prb_path = os.path.join(upload_dir, "problem_task.xlsx")

        if not sctask_path and EXEMPLE_CONFIG and os.path.exists(EXEMPLE_CONFIG.get("SCTASK_PATH", "")):
            sctask_path = EXEMPLE_CONFIG.get("SCTASK_PATH")
        if not inc_path and EXEMPLE_CONFIG and os.path.exists(EXEMPLE_CONFIG.get("INC_PATH", "")):
            inc_path = EXEMPLE_CONFIG.get("INC_PATH")
        if not prb_path and EXEMPLE_CONFIG and os.path.exists(EXEMPLE_CONFIG.get("PRB_PATH", "")):
            prb_path = EXEMPLE_CONFIG.get("PRB_PATH")

        try:
            if sctask_path and os.path.exists(sctask_path) and inc_path and os.path.exists(inc_path):
                df_sctask = load_sctask(sctask_path)
                df_inc = load_inc(inc_path)
                df_prb = load_prb(prb_path) if (prb_path and os.path.exists(prb_path)) else None

                for df in (df_sctask, df_inc, df_prb):
                    if df is not None and "Opened" in df.columns:
                        df.dropna(subset=["Opened"], inplace=True)

                if build_report:
                    res = build_report(df_sctask, df_inc, df_prb, EXEMPLE_CONFIG)
                    html_body = res[0] if isinstance(res, (tuple, list)) else res
                    report_type = "Executive IT Dashboard HTML (Gerado via exemple)"
                elif build_analyst_report:
                    df_req, df_uam = m.split_uam(df_sctask, EXEMPLE_CONFIG)
                    ref_date = m.get_reference_date(EXEMPLE_CONFIG)
                    res = build_analyst_report(df_req, df_uam, df_inc, df_prb, EXEMPLE_CONFIG, ref_date)
                    html_body = res[0] if isinstance(res, (tuple, list)) else res
                    report_type = "Analyst Comparison Dashboard HTML (Gerado via exemple)"
        except Exception as e_engine:
            logger.warning(f"⚠️ Erro ao gerar relatório dinâmico via exemple: {e_engine}")

        # Fallback de segurança: carrega o modelo oficial example_dashboard_report.html da pasta exemple
        if not html_body:
            fallback_template_path = os.path.join(exemple_dir, "example_dashboard_report.html")
            if not os.path.exists(fallback_template_path):
                fallback_template_path = os.path.join(exemple_dir, "example_analyst_comparison_report.html")

            if os.path.exists(fallback_template_path):
                with open(fallback_template_path, "r", encoding="utf-8") as f_tpl:
                    html_body = f_tpl.read()
                report_type = f"Executive Dashboard Template ({os.path.basename(fallback_template_path)})"

        # Salva cópia local no diretório configurado ou em instance
        out_file_path = os.path.join(upload_dir, f"report_{region}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
        with open(out_file_path, "w", encoding="utf-8") as f:
            f.write(html_body)

        # 5. Disparo de E-mail via Outlook (COM / AppleScript)
        email_sent = False
        email_status_msg = "Envio desabilitado (send_email_enabled=False)."

        if config.send_email_enabled:
            if enviar_email_automatico is None:
                email_status_msg = "Módulo de e-mail (smtp.py) não localizado no servidor."
            else:
                subject = f"{config.subject_prefix or 'Report Automático'} [{region}] - {datetime.now().strftime('%d/%m/%Y')}"
                try:
                    ok, msg = enviar_email_automatico(
                        to=target_to,
                        cc=target_cc,
                        subject=subject,
                        html_body=html_body,
                        attachments=attachments_list
                    )
                    email_sent = ok
                    email_status_msg = msg
                except Exception as e_mail:
                    email_status_msg = f"Falha de comunicação com cliente Outlook/AppleScript: {str(e_mail)}"

        return jsonify({
            'status': 'success',
            'region': region,
            'region_name': region_name,
            'target_to': target_to,
            'target_cc': target_cc,
            'attachments_count': len(attachments_list),
            'files_info': file_info_list,
            'report_type': report_type,
            'saved_report_html': out_file_path,
            'email_sent': email_sent,
            'email_status': email_status_msg
        })

    except Exception as e:
        logger.error(f"Erro ao executar Email Report: {str(e)}")
        traceback.print_exc()
        return jsonify({
            'status': 'error',
            'message': f"Falha interna ao processar relatório: {str(e)}"
        }), 500

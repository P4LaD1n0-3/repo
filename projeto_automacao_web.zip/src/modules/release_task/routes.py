import os
from flask import Blueprint, render_template
from flask_login import login_required, current_user

current_dir = os.path.dirname(os.path.abspath(__file__))
release_task_bp = Blueprint('release_task', __name__, template_folder=current_dir)

@release_task_bp.route('/release_task')
@login_required
def index():
    return render_template('release_task.html', user=current_user, active_page='release_task')

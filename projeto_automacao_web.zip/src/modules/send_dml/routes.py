import os
from flask import Blueprint, render_template
from flask_login import login_required, current_user

current_dir = os.path.dirname(os.path.abspath(__file__))
send_dml_bp = Blueprint('send_dml', __name__, template_folder=current_dir)

@send_dml_bp.route('/send_dml')
@login_required
def index():
    return render_template('send_dml.html', user=current_user, active_page='send_dml')

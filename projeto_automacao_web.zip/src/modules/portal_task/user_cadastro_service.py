"""
================================================================================
ARQUIVO MODELO E REFERÊNCIA: AUTOMAÇÃO DE CADASTRO DE USUÁRIO
================================================================================
Este arquivo fica localizado dentro da pasta do módulo 'src/modules/portal_task/'
e serve como REFERÊNCIA ARQUITETURAL para a implementação das demais ações do sistema.

CONCEITOS CHAVE ILUSTRADOS NESTE ARQUIVO:
1. HERANÇA POO: A classe 'CadastroUsuarioService' herda de 'ServiceNowDriver'
   (que herda de 'BaseAutomation'), aproveitando toda a inteligência de iFrames,
   seletores desacoplados e perfil de navegação persistente.
2. EXECUÇÃO INDIVIDUAL (1 PÁGINA): O método 'executar_cadastro_individual' lida
   com o fluxo de uma única página/URL do ServiceNow.
3. CONCORRÊNCIA E THREADS/SEMÁFORO (N PÁGINAS): O método 'executar_lote_concorrente'
   utiliza o 'run_concurrent_tasks' com asyncio.Semaphore para processar 1 ou N
   páginas simultaneamente sem travar a CPU ou memória do computador.
"""

import logging
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import BrowserContext, Page, FrameLocator
from tools.servicenow_driver import ServiceNowDriver
from tools.base_automation import SelectorManager


# Configuração de Logger dedicado para este serviço
logger = logging.getLogger("CadastroUsuarioService")

class CadastroUsuarioService(ServiceNowDriver):
    """
    Classe especialista responsável pela automação de 'Cadastro de usuário'.
    Herda todos os métodos do ServiceNowDriver e BaseAutomation.
    """

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        # Chama o construtor da classe pai (ServiceNowDriver -> BaseAutomation)
        # permitindo injeção de seletores desacoplados de um JSON ou Dicionário
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_cadastro_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        ========================================================================
        FLUXO DE EXECUÇÃO DE 1 PÁGINA / URL INDIVIDUAL
        ========================================================================
        1. Acessa a URL da tarefa no ServiceNow.
        2. Resolve o escopo do iFrame 'gsft_main' automaticamente.
        3. Preenche os campos do formulário via seletores desacoplados.
        4. Clica no botão de ação e extrai as SCTASKs resultantes.
        """
        logger.info(f"👤 [CadastroUsuarioService] Iniciando processamento da URL: {url}")

        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Cadastro de usuário",
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            # PASSO 1: Navegação na página via Playwright
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # PASSO 2: Alteração de contexto para o iFrame 'gsft_main' do ServiceNow
            # O método herdado 'get_iframe_scope' aguarda a presença do iFrame e retorna
            # o escopo do FrameLocator. Se não houver iFrame, faz fallback seguro para a Page.
            scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

            # PASSO 3: Interação com formulários (Exemplo de preenchimento por chave desacoplada)
            # Se houvesse campos específicos para preencher nesta tarefa:
            # await self.fill_input(scope, "user_name", "novo.usuario")
            # await self.click_element(scope, "submit_button")

            # PASSO 4: Aguarda carregamento dos elementos dinâmicos do ServiceNow
            await page.wait_for_timeout(3000)

            # PASSO 5: Extração automática de códigos SCTASK presentes na tela
            # Utiliza o método herdado 'process_servicenow_page' para fazer varredura via regex e locators
            dados_raspagem = await self.process_servicenow_page(page, url)
            resultado["sctasks"] = dados_raspagem.get("sctasks", [])

            logger.info(f"✅ [CadastroUsuarioService] Concluído com sucesso em {url}. SCTASKs: {resultado['sctasks']}")

        except Exception as e:
            logger.error(f"❌ [CadastroUsuarioService] Erro ao cadastrar usuário na URL {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

    async def executar_lote_concorrente(
        self, 
        context: BrowserContext, 
        urls: List[str], 
        max_concurrency: int = 3,
        dados_formulario: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """
        ========================================================================
        FLUXO DE EXECUÇÃO EM LOTE PARA 1 OU N TAREFAS (CONCORRÊNCIA COM SEMÁFORO)
        ========================================================================
        Como funciona a integração do Playwright com Threads/Asyncio:
        - O Playwright opera sobre o loop de eventos assíncrono (asyncio).
        - Para processar N URLs simultaneamente sem abrir 50 abas e travar o computador,
          utilizamos o método herdado 'run_concurrent_tasks()' que utiliza um 'asyncio.Semaphore'.
        - Se 'max_concurrency = 3', o Semáforo permite que no máximo 3 abas fiquem abertas ao mesmo tempo.
        - Quando uma aba conclui o cadastro de usuário, a próxima URL da lista assume a vaga no Semáforo.
        """
        logger.info(f"🚀 [CadastroUsuarioService] Iniciando processamento em lote de {len(urls)} URLs (Semáforo = {max_concurrency} abas simultâneas)...")

        # Define a função trabalhadora assíncrona que liga o parâmetro da página à URL atual
        async def worker_task(page: Page, url: str):
            return await self.executar_cadastro_individual(page, url, dados_formulario=dados_formulario)

        # Dispara a execução concorrente controlada pelo Semáforo herdado de BaseAutomation
        resultados = await self.run_concurrent_tasks(
            context=context,
            items=urls,
            task_fn=worker_task,
            max_concurrency=max_concurrency
        )

        logger.info(f"🏁 [CadastroUsuarioService] Processamento em lote finalizado. Total de respostas: {len(resultados)}")
        return resultados

"""
================================================================================
SERVIÇO EXCLUSIVO: DESABILITAR USUÁRIO
================================================================================
Módulo exclusivo responsável pela automação de 'Desabilitar usuário'.
Localizado em: src/modules/portal_task/user_desabilitar_service.py
"""

import logging
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import BrowserContext, Page
from tools.servicenow_driver import ServiceNowDriver
from tools.base_automation import SelectorManager

logger = logging.getLogger("UserDesabilitarService")

class UserDesabilitarService(ServiceNowDriver):
    """
    Classe especialista para automação de 'Desabilitar usuário'.
    Herda de ServiceNowDriver (que por sua vez herda de BaseAutomation).
    """

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_desabilitar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Processa a automação de Desabilitar Usuário em 1 URL do ServiceNow."""
        logger.info(f"🚫 [UserDesabilitarService] Desabilitando usuário em: {url}")
        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Desabilitar usuário",
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)
            await page.wait_for_timeout(3000)

            # Processa a página e extrai os códigos SCTASK
            dados_raspagem = await self.process_servicenow_page(page, url)
            resultado["sctasks"] = dados_raspagem.get("sctasks", [])
            logger.info(f"✅ [UserDesabilitarService] Concluído em {url}. SCTASKs: {resultado['sctasks']}")
        except Exception as e:
            logger.error(f"❌ [UserDesabilitarService] Erro em {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

    async def executar_lote_concorrente(
        self, 
        context: BrowserContext, 
        urls: List[str], 
        max_concurrency: int = 3,
        dados_formulario: Optional[Dict[str, Any]] = None
    ) -> List[Dict[str, Any]]:
        """Executa a automação para 1 ou N URLs com controle de Semáforo (max_concurrency)."""
        logger.info(f"🚀 [UserDesabilitarService] Processando lote de {len(urls)} URLs (Semáforo={max_concurrency})...")

        async def worker_task(page: Page, url: str):
            return await self.executar_desabilitar_individual(page, url, dados_formulario=dados_formulario)

        return await self.run_concurrent_tasks(context=context, items=urls, task_fn=worker_task, max_concurrency=max_concurrency)

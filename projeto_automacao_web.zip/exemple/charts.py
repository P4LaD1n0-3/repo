# -*- coding: utf-8 -*-
"""
QuickChart.io URL builders - clean, minimal style matching the reference
"relatorio_email.html" template: soft color palette, no datalabel clutter
on multi-bar trend charts, generous spacing, bottom legends.
"""
import json
import base64
import urllib.parse
import urllib.request
from config import QC, CONFIG

QC_BASE = "https://quickchart.io/chart"
QC_CREATE_ENDPOINT = "https://quickchart.io/chart/create"

# Small in-process cache so identical configs (rare, but possible) don't
# trigger duplicate network round-trips within a single report build.
_short_url_cache = {}

# Diagnostics: how each chart actually got delivered. Printed by main.py
# after the report is built, so you can see straight in the console which
# layer is failing on your machine instead of guessing.
_delivery_stats = {"base64": 0, "short_url": 0, "long_url": 0}


def get_delivery_stats():
    return dict(_delivery_stats)


def reset_delivery_stats():
    for k in _delivery_stats:
        _delivery_stats[k] = 0


def _fetch_png_base64(cfg, w, h, timeout):
    """POSTs to QuickChart's render endpoint and returns the PNG bytes
    directly (not a URL) so they can be embedded inline. Returns None on
    any failure (network, non-2xx, non-image response, etc.)."""
    try:
        body = json.dumps({
            "chart": cfg, "width": w, "height": h,
            "backgroundColor": "white", "format": "png", "devicePixelRatio": 1.5,
        }).encode("utf-8")
        req = urllib.request.Request(
            QC_BASE, data=body,
            headers={"Content-Type": "application/json", "Accept": "image/png"}, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content_type = resp.headers.get("Content-Type", "")
            png_bytes = resp.read()
        if "image" not in content_type or not png_bytes:
            return None
        b64 = base64.b64encode(png_bytes).decode("ascii")
        return f"data:image/png;base64,{b64}"
    except Exception:
        return None


def _create_short_url(cfg, w, h, timeout):
    """POSTs the chart config to QuickChart's hosting endpoint and returns a
    short, stable URL (https://quickchart.io/chart/render/<id>). Returns
    None on any failure so the caller can fall back further."""
    cache_key = (json.dumps(cfg, sort_keys=True, default=str), w, h)
    if cache_key in _short_url_cache:
        return _short_url_cache[cache_key]
    try:
        body = json.dumps({
            "chart": cfg, "width": w, "height": h,
            "backgroundColor": "white", "format": "png",
        }).encode("utf-8")
        req = urllib.request.Request(
            QC_CREATE_ENDPOINT, data=body,
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        url = data.get("url") if data.get("success") else None
        _short_url_cache[cache_key] = url
        return url
    except Exception:
        _short_url_cache[cache_key] = None
        return None


def qc_url(cfg, w=500, h=300):
    """
    Gera a URL direta do QuickChart (https://quickchart.io/chart?w=...&h=...&c=...)
    idêntica ao modelo oficial 'example_dashboard_report.html'.
    Garante renderização instantânea em 100% dos clientes de e-mail (Apple Mail, Outlook, Gmail).
    """
    try:
        payload = json.dumps(cfg, separators=(",", ":"))
        return f"{QC_BASE}?w={w}&h={h}&c={urllib.parse.quote(payload)}"
    except Exception as e:
        logger.error(f"Erro ao codificar URL do gráfico: {e}")
        return ""


def _sanitize(label, limit=38):
    label = str(label).strip()
    return label[:limit] + "\u2026" if len(label) > limit else label


def _pad(labels, data):
    labels = list(labels)
    data = list(data)
    if not labels:
        return ["No data"], [0]
    return labels, data


# ---------------------------------------------------------------------------
# Donut / Pie
# ---------------------------------------------------------------------------
def horizontal_bar_varied(labels, values, colors, w=460, h=320):
    """Horizontal bar where EACH bar gets its own color from a varied
    palette (not one flat color) - used for Top Analysts rankings."""
    labels, values = _pad(labels, values)
    palette = (colors * (len(labels) // len(colors) + 1))[:len(labels)]
    cfg = {
        "type": "horizontalBar",
        "data": {"labels": [_sanitize(l) for l in labels],
                  "datasets": [{"data": values, "backgroundColor": palette}]},
        "options": {"legend": {"display": False},
                     "scales": {"xAxes": [{"ticks": {"beginAtZero": True}}],
                                 "yAxes": [{"ticks": {"autoSkip": False}}]},
                     "plugins": {"datalabels": {"display": True, "color": "#fff", "anchor": "center",
                                                  "align": "center", "font": {"size": 14, "weight": "bold"}}}},
    }
    return qc_url(cfg, w, h)


def stacked_horizontal_bar(labels, values_a, values_b, label_a, label_b, color_a, color_b,
                            title="", w=520, h=380, legend=True):
    """Per-analyst SCTASK + INC stacked horizontal bar."""
    labels, values_a = _pad(labels, values_a)
    _, values_b = _pad(labels, values_b)
    cfg = {
        "type": "horizontalBar",
        "data": {"labels": [_sanitize(l, limit=22) for l in labels], "datasets": [
            {"label": label_a, "data": values_a, "backgroundColor": color_a},
            {"label": label_b, "data": values_b, "backgroundColor": color_b},
        ]},
        "options": {
            "legend": {"display": legend, "position": "bottom", "labels": {"fontSize": 10, "boxWidth": 12}},
            "scales": {"xAxes": [{"stacked": True, "ticks": {"beginAtZero": True, "fontSize": 10}}],
                        "yAxes": [{"stacked": True, "ticks": {"autoSkip": False, "fontSize": 11}}]},
            "plugins": {"datalabels": {"display": True, "color": "#fff", "anchor": "center",
                                         "align": "center", "font": {"size": 11, "weight": "bold"},
                                         "formatter": "function(v){ return v > 0 ? v : ''; }"}},
        },
    }
    if title:
        cfg["options"]["title"] = {"display": True, "text": title, "fontSize": 13, "fontColor": "#1a3a6b"}
    return qc_url(cfg, w, h)


def donut(labels, values, colors, legend=True, w=420, h=280, center_color="#333333"):
    labels, values = _pad(labels, values)
    total = sum(v for v in values if isinstance(v, (int, float)))
    cfg = {
        "type": "doughnut",
        "data": {"labels": [_sanitize(l) for l in labels],
                  "datasets": [{"data": values, "backgroundColor": colors[:len(labels)] if len(colors) >= len(labels) else colors * 3}]},
        "options": {"legend": {"display": legend, "position": "bottom", "labels": {"fontSize": 10, "boxWidth": 12}},
                     "cutoutPercentage": 62,
                     "plugins": {
                         "datalabels": {"color": "#fff", "font": {"size": 10, "weight": "bold"}},
                         # Big, bold total shown right in the donut hole. White text isn't
                         # readable against the hole's white background, so this uses a
                         # high-contrast accent color instead - still large and centered.
                         "doughnutlabel": {"labels": [
                             {"text": str(total), "font": {"size": 30, "weight": "bold"}, "color": center_color},
                             {"text": "TOTAL", "font": {"size": 11, "weight": "bold"}, "color": "#999999"},
                         ]},
                     }},
    }
    return qc_url(cfg, w, h)


def pie(labels, values, colors, w=380, h=260):
    labels, values = _pad(labels, values)
    cfg = {
        "type": "pie",
        "data": {"labels": labels, "datasets": [{"data": values, "backgroundColor": colors}]},
        "options": {"legend": {"display": True, "position": "bottom", "labels": {"fontSize": 11}},
                     "plugins": {"datalabels": {"color": "#fff", "font": {"weight": "bold", "size": 16},
                                                  "anchor": "center", "align": "center"}}},
    }
    return qc_url(cfg, w, h)


def sla_pie(inside, outside, w=380, h=260, center_color="#329EF4"):
    """Donut (not solid pie) so the total open count can be shown centered,
    large and bold - matching the 'number in the middle' treatment used on
    every other chart in this report."""
    labels, values = ["Inside SLA", "Outside SLA"], [inside, outside]
    total = inside + outside
    cfg = {
        "type": "doughnut",
        "data": {"labels": labels, "datasets": [{"data": values, "backgroundColor": [QC["green"], QC["red"]]}]},
        "options": {"legend": {"display": True, "position": "bottom", "labels": {"fontSize": 11}},
                     "cutoutPercentage": 62,
                     "plugins": {
                         "datalabels": {"color": "#fff", "font": {"weight": "bold", "size": 15}},
                         "doughnutlabel": {"labels": [
                             {"text": str(total), "font": {"size": 28, "weight": "bold"}, "color": center_color},
                             {"text": "OPEN", "font": {"size": 10, "weight": "bold"}, "color": "#999999"},
                         ]},
                     }},
    }
    return qc_url(cfg, w, h)


def status_pie(open_count, closed_count, w=380, h=260):
    return pie(["Open", "Resolved"], [open_count, closed_count], [QC["orange"], QC["green"]], w, h)


# ---------------------------------------------------------------------------
# Horizontal bar (aging buckets, status, rankings)
# ---------------------------------------------------------------------------
def horizontal_bar(labels, values, color, w=420, h=280, legend=False):
    labels, values = _pad(labels, values)
    cfg = {
        "type": "horizontalBar",
        "data": {"labels": [_sanitize(l) for l in labels],
                  "datasets": [{"data": values, "backgroundColor": color}]},
        "options": {"legend": {"display": legend},
                     "scales": {"xAxes": [{"ticks": {"beginAtZero": True}}],
                                 "yAxes": [{"ticks": {"autoSkip": False}}]},
                     "plugins": {"datalabels": {"display": True, "color": "#fff", "anchor": "center",
                                                  "align": "center", "font": {"size": 15, "weight": "bold"}}}},
    }
    return qc_url(cfg, w, h)


def horizontal_bar_scale(labels, values, w=460, h=300):
    """Aging-style bucket bar: green -> red gradient across the buckets."""
    labels, values = _pad(labels, values)
    palette = QC["aging_scale"][:len(labels)]
    cfg = {
        "type": "horizontalBar",
        "data": {"labels": labels, "datasets": [{"data": values, "backgroundColor": palette}]},
        "options": {"legend": {"display": False},
                     "scales": {"xAxes": [{"stacked": True, "ticks": {"beginAtZero": True}}],
                                 "yAxes": [{"stacked": True}]},
                     "plugins": {"datalabels": {"display": True, "color": "#fff", "anchor": "center",
                                                  "align": "center", "font": {"size": 15, "weight": "bold"}}}},
    }
    return qc_url(cfg, w, h)


# ---------------------------------------------------------------------------
# Line / Bar trend charts (daily, weekly, monthly)
# ---------------------------------------------------------------------------
def line_open_closed(labels, opened, closed, legend=True, w=420, h=280):
    cfg = {
        "type": "line",
        "data": {"labels": labels, "datasets": [
            {"label": "Opened", "data": opened, "fill": False, "borderColor": QC["blue"], "borderWidth": 2},
            {"label": "Resolved", "data": closed, "fill": False, "borderColor": QC["green"], "borderWidth": 2},
        ]},
        "options": {"legend": {"display": legend, "position": "bottom"}},
    }
    return qc_url(cfg, w, h)


def netflow_bar(labels, in_vals, out_vals, w=560, h=280):
    cfg = {
        "type": "bar",
        "data": {"labels": labels, "datasets": [
            {"label": "IN (Opened)", "data": in_vals, "backgroundColor": QC["red_a"]},
            {"label": "OUT (Resolved)", "data": out_vals, "backgroundColor": QC["green_a"]},
        ]},
        "options": {"legend": {"display": True, "position": "bottom"}},
    }
    return qc_url(cfg, w, h)


def dual_axis_trend_backlog(labels, opened, resolved, backlog, color_opened, color_resolved,
                             color_backlog, title="", w=900, h=300):
    """Clean bar+bar+line dual-axis trend: Opened/Resolved bars (left axis) and
    Accumulated Backlog line (right axis). No per-bar datalabels - the legend
    and axes carry the information, keeping the chart readable even with
    ~30 data points (a full month)."""
    labels, opened = _pad(labels, opened)
    _, resolved = _pad(labels, resolved)
    _, backlog = _pad(labels, backlog)
    cfg = {
        "type": "bar",
        "data": {"labels": labels, "datasets": [
            {"type": "bar", "label": "Opened", "data": opened, "backgroundColor": color_opened, "yAxisID": "y1"},
            {"type": "bar", "label": "Resolved", "data": resolved, "backgroundColor": color_resolved, "yAxisID": "y1"},
            {"type": "line", "label": "Accum. Backlog", "data": backlog, "fill": False,
             "borderColor": color_backlog, "backgroundColor": color_backlog, "borderWidth": 2,
             "pointRadius": 2, "yAxisID": "y2"},
        ]},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 10}},
            "scales": {
                "xAxes": [{"ticks": {"fontSize": 9, "maxRotation": 60, "minRotation": 45}}],
                "yAxes": [
                    {"id": "y1", "position": "left", "ticks": {"beginAtZero": True, "fontSize": 10},
                     "scaleLabel": {"display": True, "labelString": "Tickets"}},
                    {"id": "y2", "position": "right", "gridLines": {"drawOnChartArea": False},
                     "ticks": {"fontSize": 10}, "scaleLabel": {"display": True, "labelString": "Backlog"}},
                ],
            },
        },
    }
    if title:
        cfg["options"]["title"] = {"display": True, "text": title, "fontSize": 12, "fontColor": "#585858"}
    return qc_url(cfg, w, h)


def dual_axis_trend_rich(labels, opened, closed, net_line, color_opened, color_closed,
                          color_line, line_label="Net Balance", w=780, h=340):
    """Richer bar+bar+line dual-axis trend WITH datalabels - matches the
    reference screenshot exactly: bold white numbers on the bars, and the
    line's points shown as small colored 'bubbles' with white numbers.
    Intended for short/medium windows (~10-30 points) where labels stay
    readable; for long windows prefer dual_axis_trend_backlog instead."""
    labels, opened = _pad(labels, opened)
    _, closed = _pad(labels, closed)
    _, net_line = _pad(labels, net_line)
    cfg = {
        "type": "bar",
        "data": {"labels": labels, "datasets": [
            {"type": "bar", "label": "Opened", "data": opened, "backgroundColor": color_opened,
             "yAxisID": "y1", "datalabels": {"display": True, "color": "#fff", "anchor": "center", "align": "center",
                                               "font": {"weight": "bold", "size": 13}}},
            {"type": "bar", "label": "Closed", "data": closed, "backgroundColor": color_closed,
             "yAxisID": "y1", "datalabels": {"display": True, "color": "#fff", "anchor": "center", "align": "center",
                                               "font": {"weight": "bold", "size": 13}}},
            {"type": "line", "label": line_label, "data": net_line, "fill": False,
             "borderColor": color_line, "backgroundColor": color_line, "borderWidth": 3,
             "pointRadius": 4, "pointBackgroundColor": color_line, "yAxisID": "y2",
             "datalabels": {"display": True, "color": "#fff", "backgroundColor": color_line,
                             "borderRadius": 10, "padding": {"top": 4, "bottom": 4, "left": 7, "right": 7},
                             "font": {"weight": "bold", "size": 12}}},
        ]},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 11, "boxWidth": 14}},
            "scales": {
                "xAxes": [{"ticks": {"fontSize": 10}}],
                "yAxes": [
                    {"id": "y1", "position": "left", "ticks": {"beginAtZero": True, "fontSize": 10},
                     "scaleLabel": {"display": True, "labelString": "Qty"}},
                    {"id": "y2", "position": "right", "gridLines": {"drawOnChartArea": False},
                     "ticks": {"fontSize": 10}, "scaleLabel": {"display": True, "labelString": line_label}},
                ],
            },
        },
    }
    return qc_url(cfg, w, h)


def dual_axis_trend_quad(labels, opened, resolved, secondary, backlog, color_opened, color_resolved,
                          color_secondary, color_backlog, secondary_label, title="", w=1000, h=340):
    """Trend chart matching the reference dashboard: an "Opened" bar next
    to a single stacked "Closed" bar (Resolved segment + Secondary segment
    stacked together, not three separate bars), with the Accumulated
    Backlog line on its own zoomed-in right axis."""
    labels, opened = _pad(labels, opened)
    _, resolved = _pad(labels, resolved)
    _, secondary = _pad(labels, secondary)
    _, backlog = _pad(labels, backlog)
    bar_labels = {"display": True, "color": "#fff", "anchor": "center", "align": "center",
                  "font": {"weight": "bold", "size": 11}}

    # Visual separation matching the reference dashboard: bars stay compact
    # near the bottom of the chart, and the Backlog line rides clearly
    # above them near the top - never tangled together. Two moves make
    # that happen on a dual-axis chart:
    #   1) The bars' own axis (y1) is given a MAX well beyond the actual
    #      bar data, so the bars only ever fill the bottom portion of the
    #      canvas instead of stretching the full height.
    #   2) The line's axis (y2) starts at 0 (not at the data's own min),
    #      so the backlog values - which are usually much higher than any
    #      single bar - land in the upper portion of the canvas by
    #      construction, while still keeping enough range above the data
    #      (not a huge fixed ceiling) that the line's real shape stays
    #      visible instead of flattening out.
    numeric_bars = [v for v in (list(opened) + list(resolved) + list(secondary)) if isinstance(v, (int, float))]
    bar_max = max(numeric_bars) if numeric_bars else 10
    y1_max = max(bar_max * 2.5, bar_max + 8)

    numeric_backlog = [v for v in backlog if isinstance(v, (int, float))]
    if numeric_backlog:
        b_max = max(numeric_backlog)
        pad = max(3, round(b_max * 0.15))
        y2_min = 0
        y2_max = b_max + pad
    else:
        y2_min, y2_max = 0, 10

    cfg = {
        "type": "bar",
        "data": {"labels": labels, "datasets": [
            {"type": "bar", "label": "Opened", "data": opened, "backgroundColor": color_opened,
             "yAxisID": "y1", "stack": "opened", "datalabels": bar_labels},
            {"type": "bar", "label": "Resolved", "data": resolved, "backgroundColor": color_resolved,
             "yAxisID": "y1", "stack": "closed", "datalabels": bar_labels},
            {"type": "bar", "label": secondary_label, "data": secondary, "backgroundColor": color_secondary,
             "yAxisID": "y1", "stack": "closed", "datalabels": dict(bar_labels, font={"weight": "bold", "size": 10})},
            {"type": "line", "label": "Backlog (Accum.)", "data": backlog, "fill": False,
             "borderColor": color_backlog, "backgroundColor": color_backlog, "borderWidth": 3,
             "pointRadius": 4, "pointBackgroundColor": color_backlog, "yAxisID": "y2",
             "datalabels": {"display": True, "color": "#fff", "backgroundColor": color_backlog,
                             "borderRadius": 10, "padding": {"top": 4, "bottom": 4, "left": 7, "right": 7},
                             "font": {"weight": "bold", "size": 11}}},
        ]},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 11, "boxWidth": 14}},
            "scales": {
                "xAxes": [{"stacked": True, "ticks": {"fontSize": 10}}],
                "yAxes": [
                    {"id": "y1", "stacked": True, "position": "left",
                     "ticks": {"beginAtZero": True, "fontSize": 10, "max": y1_max},
                     "scaleLabel": {"display": True, "labelString": "Qty"}},
                    {"id": "y2", "position": "right", "gridLines": {"drawOnChartArea": False},
                     "ticks": {"fontSize": 10, "min": y2_min, "max": y2_max},
                     "scaleLabel": {"display": True, "labelString": "Backlog"}},
                ],
            },
        },
    }
    if title:
        cfg["options"]["title"] = {"display": True, "text": title, "fontSize": 14, "fontColor": "#1a3a6b"}
    return qc_url(cfg, w, h)


def area_line_trend(labels, values, color, fill_color, w=560, h=320):
    """Filled line chart for the historical classification-errors trend."""
    labels, values = _pad(labels, values)
    cfg = {
        "type": "line",
        "data": {"labels": labels, "datasets": [{
            "label": "Classification Errors", "data": values, "fill": True,
            "borderColor": color, "backgroundColor": fill_color, "borderWidth": 2.5,
            "tension": 0.35, "pointRadius": 4, "pointBackgroundColor": color,
            "datalabels": {"display": True, "align": "top", "color": color, "font": {"weight": "bold", "size": 10}},
        }]},
        "options": {"legend": {"display": False},
                     "scales": {"xAxes": [{"gridLines": {"display": False}, "ticks": {"fontSize": 10}}],
                                 "yAxes": [{"ticks": {"beginAtZero": True, "fontSize": 10}}]}},
    }
    return qc_url(cfg, w, h)


def performance_quadrant_scatter(points, median_x, median_y, x_label, y_label, w=760, h=560):
    """Volume x Quality quadrant scatter - a standard workforce-analytics
    view (who's high-volume/high-quality vs high-volume/rushing vs
    careful-but-slow vs needs-support). Each point is colored by ITS OWN
    quadrant (computed in Python) rather than relying on chart-level
    annotation/divider lines, which some chart renderers don't support
    consistently - this way the quadrant read is guaranteed correct
    regardless of rendering engine.
    `points`: list of (name, x, y) tuples.
    """
    QUAD_COLORS = {
        "star": "rgb(39,174,96)",       # high volume, high quality
        "fast_risky": "rgb(230,126,34)",  # high volume, lower quality
        "careful_slow": "rgb(52,152,219)",  # lower volume, high quality
        "needs_support": "rgb(192,57,43)",  # lower volume, lower quality
    }
    datasets_data = {k: [] for k in QUAD_COLORS}
    for name, x, y in points:
        if x >= median_x and y >= median_y:
            quad = "star"
        elif x >= median_x and y < median_y:
            quad = "fast_risky"
        elif x < median_x and y >= median_y:
            quad = "careful_slow"
        else:
            quad = "needs_support"
        datasets_data[quad].append({"x": x, "y": y, "label": _sanitize(name, 22)})

    legend_names = {"star": "High volume + High SLA%", "fast_risky": "High volume + Lower SLA%",
                     "careful_slow": "Lower volume + High SLA%", "needs_support": "Lower volume + Lower SLA%"}
    datasets = []
    for key, color in QUAD_COLORS.items():
        datasets.append({
            "label": legend_names[key], "data": datasets_data[key],
            "backgroundColor": color, "borderColor": color, "pointRadius": 7, "pointHoverRadius": 9,
            "datalabels": {"display": True, "align": "top", "color": color, "font": {"weight": "bold", "size": 9},
                            "formatter": "function(v){return v.label;}"},
        })
    cfg = {
        "type": "scatter",
        "data": {"datasets": datasets},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 10, "boxWidth": 12}},
            "scales": {
                "xAxes": [{"scaleLabel": {"display": True, "labelString": x_label}, "ticks": {"fontSize": 10}}],
                "yAxes": [{"scaleLabel": {"display": True, "labelString": y_label}, "ticks": {"fontSize": 10}}],
            },
        },
    }
    return qc_url(cfg, w, h)


def workload_balance_bar(labels, values, fair_share, color="#EF6C00", w=1000, h=420):
    """Open backlog per analyst, sorted descending, with a dashed
    "fair share" reference line (total backlog / active analysts)."""
    labels = [_sanitize(l, limit=22) for l in labels]
    labels, values = _pad(labels, values)
    n = max(len(labels), 1)
    cfg = {
        "type": "bar",
        "data": {"labels": labels, "datasets": [
            {"type": "bar", "label": "Backlog Aberto Total", "data": values, "backgroundColor": color,
             "datalabels": {"display": True, "color": "#fff", "anchor": "center", "align": "center",
                             "font": {"weight": "bold", "size": 11}}},
            {"type": "line", "label": f"Linha de Equilíbrio / Fair Share ({fair_share:.1f})", "data": [fair_share] * n,
             "borderColor": "rgb(211,84,0)", "borderWidth": 2.5, "borderDash": [6, 4],
             "fill": False, "pointRadius": 0, "datalabels": {"display": False}},
        ]},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 11, "boxWidth": 14}},
            "scales": {
                "xAxes": [{"ticks": {"fontSize": 10}}],
                "yAxes": [{"ticks": {"beginAtZero": True, "fontSize": 10}}],
            },
        },
    }
    return qc_url(cfg, w, h)


def stacked_workload_balance_bar(labels, sct_values, inc_values, fair_share_sct, fair_share_inc, w=1050, h=440):
    """Stacked bar chart for Workload Balance: SCTASK Aberto (#06B6D4) + INC Aberto (#8B5CF6) per analyst,
    with TWO distinct balance cut-off lines:
    1. Linha de Corte SCTASK (Média SCTASK: fair_share_sct)
    2. Linha de Corte INC (Média INC: fair_share_inc)
    """
    labels = [_sanitize(l, limit=22) for l in labels]
    labels, sct_values = _pad(labels, sct_values)
    _, inc_values = _pad(labels, inc_values)
    n = max(len(labels), 1)
    cfg = {
        "type": "bar",
        "data": {"labels": labels, "datasets": [
            {"type": "bar", "label": "SCTASK Aberto", "data": sct_values, "backgroundColor": "#06B6D4",
             "stack": "backlog", "datalabels": {"display": True, "color": "#ffffff", "font": {"weight": "bold", "size": 11},
                                             "formatter": "function(v){return v>0?v:'';}"}},
            {"type": "bar", "label": "INC Aberto", "data": inc_values, "backgroundColor": "#8B5CF6",
             "stack": "backlog", "datalabels": {"display": True, "color": "#ffffff", "font": {"weight": "bold", "size": 11},
                                             "formatter": "function(v){return v>0?v:'';}"}},
            {"type": "line", "label": f"Linha de Corte SCTASK ({fair_share_sct:.1f})", "data": [fair_share_sct] * n,
             "borderColor": "#0284C7", "borderWidth": 2.5, "borderDash": [6, 4],
             "fill": False, "pointRadius": 0, "datalabels": {"display": False}},
            {"type": "line", "label": f"Linha de Corte INC ({fair_share_inc:.1f})", "data": [fair_share_inc] * n,
             "borderColor": "#6D28D9", "borderWidth": 2.5, "borderDash": [6, 4],
             "fill": False, "pointRadius": 0, "datalabels": {"display": False}},
        ]},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 11, "boxWidth": 14}},
            "scales": {
                "xAxes": [{"stacked": True, "ticks": {"fontSize": 10}}],
                "yAxes": [{"stacked": True, "ticks": {"beginAtZero": True, "fontSize": 10}}],
            },
        },
    }
    return qc_url(cfg, w, h)


def grouped_horizontal_bar(labels, series_a, series_b, label_a, label_b, color_a, color_b,
                             title="", w=560, h=380):
    """Two side-by-side (not stacked) bars per row - used for every
    period-over-period analyst comparison (today/yesterday, this
    week/last week, this month/last month)."""
    labels = [_sanitize(l, limit=26) for l in labels]
    labels, series_a = _pad(labels, series_a)
    _, series_b = _pad(labels, series_b)
    bar_labels = {"display": True, "color": "#fff", "anchor": "center", "align": "center",
                  "font": {"weight": "bold", "size": 10}}
    n = max(len(labels), 1)
    cfg = {
        "type": "horizontalBar",
        "data": {"labels": labels, "datasets": [
            {"label": label_a, "data": series_a, "backgroundColor": color_a, "datalabels": bar_labels},
            {"label": label_b, "data": series_b, "backgroundColor": color_b, "datalabels": bar_labels},
        ]},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 11, "boxWidth": 14}},
            "scales": {
                "xAxes": [{"ticks": {"beginAtZero": True, "fontSize": 10}}],
                "yAxes": [{"ticks": {"fontSize": 11}}],
            },
        },
    }
    if title:
        cfg["options"]["title"] = {"display": True, "text": title, "fontSize": 14, "fontColor": "#1a3a6b"}
    return qc_url(cfg, w, max(h, 34 * n + 80))


def grouped_stacked_horizontal_bar(labels, cur_sct, cur_inc, prev_sct, prev_inc,
                                   label_cur="Atual", label_prev="Anterior",
                                   title="", w=540, h=380):
    """Generates a grouped-stacked horizontal bar chart comparing Current Period vs Previous Period per analyst.
    Each analyst gets TWO horizontal bars:
    - Bar 1: Current Period (Stacked: Ocean Teal #06B6D4 = SCTASK, Electric Violet #8B5CF6 = INC)
    - Bar 2: Previous Period (Stacked: Soft Sky #67E8F9 = SCTASK, Soft Lavender #C4B5FD = INC)
    """
    labels = [_sanitize(l, limit=22) for l in labels]
    labels, cur_sct = _pad(labels, cur_sct)
    _, cur_inc = _pad(labels, cur_inc)
    _, prev_sct = _pad(labels, prev_sct)
    _, prev_inc = _pad(labels, prev_inc)
    n = max(len(labels), 1)

    dl_cur = {
        "display": True, "color": "#ffffff", "anchor": "center", "align": "center",
        "font": {"weight": "bold", "size": 10},
        "formatter": "function(v){ return v > 0 ? v : ''; }"
    }
    dl_prev = {
        "display": True, "color": "#0f172a", "anchor": "center", "align": "center",
        "font": {"weight": "bold", "size": 10},
        "formatter": "function(v){ return v > 0 ? v : ''; }"
    }

    cfg = {
        "type": "horizontalBar",
        "data": {
            "labels": labels,
            "datasets": [
                {
                    "label": f"{label_cur} (SCTASK)", "data": cur_sct, "backgroundColor": "#06B6D4",
                    "stack": "cur", "datalabels": dl_cur
                },
                {
                    "label": f"{label_cur} (INC)", "data": cur_inc, "backgroundColor": "#8B5CF6",
                    "stack": "cur", "datalabels": dl_cur
                },
                {
                    "label": f"{label_prev} (SCTASK)", "data": prev_sct, "backgroundColor": "#67E8F9",
                    "stack": "prev", "datalabels": dl_prev
                },
                {
                    "label": f"{label_prev} (INC)", "data": prev_inc, "backgroundColor": "#C4B5FD",
                    "stack": "prev", "datalabels": dl_prev
                },
            ]
        },
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 10, "boxWidth": 12}},
            "scales": {
                "xAxes": [{"stacked": True, "ticks": {"beginAtZero": True, "fontSize": 10}}],
                "yAxes": [{"stacked": True, "ticks": {"fontSize": 11}}],
            },
        }
    }
    if title:
        cfg["options"]["title"] = {"display": True, "text": title, "fontSize": 13, "fontColor": "#1a3a6b"}
    return qc_url(cfg, w, max(h, 45 * n + 90))


def _heat_color(value, vmin, vmax, reverse=False):
    """Interpolates red -> yellow -> green (or the reverse, for metrics
    where LOWER is better, like MTTR) based on where `value` falls in
    [vmin, vmax]. Used to color each bar of a heat-intensity chart
    individually, rather than one flat color per series."""
    if vmax <= vmin:
        t = 0.5
    else:
        t = (value - vmin) / (vmax - vmin)
        t = max(0.0, min(1.0, t))
    if reverse:
        t = 1.0 - t
    stops = [(231, 76, 60), (241, 196, 15), (39, 174, 96)]  # red -> yellow -> green
    if t <= 0.5:
        a, b, local_t = stops[0], stops[1], t / 0.5
    else:
        a, b, local_t = stops[1], stops[2], (t - 0.5) / 0.5
    r = round(a[0] + (b[0] - a[0]) * local_t)
    g = round(a[1] + (b[1] - a[1]) * local_t)
    bl = round(a[2] + (b[2] - a[2]) * local_t)
    return f"rgb({r},{g},{bl})"


def heat_intensity_bar(labels, values, title="", reverse=False, value_suffix="", w=1000, h=None):
    """Horizontal bar chart where each bar's fill color is individually
    computed on a red->yellow->green heat scale based on that analyst's
    OWN value relative to the team's range for this metric - a "who's hot,
    who's cold" read at a glance, instead of a flat single-color bar chart.
    `reverse=True` for metrics where lower is better (e.g. MTTR: a fast
    resolver should show green, not red)."""
    labels = [_sanitize(l, limit=24) for l in labels]
    labels, values = _pad(labels, values)
    numeric = [v for v in values if isinstance(v, (int, float))]
    vmin, vmax = (min(numeric), max(numeric)) if numeric else (0, 1)
    colors = [_heat_color(v, vmin, vmax, reverse=reverse) for v in values]
    n = max(len(labels), 1)
    cfg = {
        "type": "horizontalBar",
        "data": {"labels": labels, "datasets": [{
            "label": title or "Value", "data": values, "backgroundColor": colors,
            "datalabels": {"display": True, "color": "#ffffff", "anchor": "end", "align": "start",
                            "font": {"weight": "bold", "size": 11},
                            "formatter": "function(v){return v + '" + value_suffix + "';}"},
        }]},
        "options": {
            "legend": {"display": False},
            "scales": {
                "xAxes": [{"ticks": {"beginAtZero": True, "fontSize": 10}}],
                "yAxes": [{"ticks": {"fontSize": 11}}],
            },
        },
    }
    if title:
        cfg["options"]["title"] = {"display": True, "text": title, "fontSize": 14, "fontColor": "#1a3a6b"}
    return qc_url(cfg, w, h or max(320, 30 * n + 90))


def donut_composition(labels, values, colors, center_label="", w=480, h=380):
    """Donut with a colored legend and a bold center total - used for
    backlog composition / status-breakdown views.
    Includes high-contrast white text with black outline so numbers are 100% readable.
    """
    total = sum(values)
    center_text = center_label or "TOTAL"
    cfg = {
        "type": "doughnut",
        "data": {"labels": labels, "datasets": [{"data": values, "backgroundColor": colors[:len(labels)],
                                                    "borderWidth": 2, "borderColor": "#ffffff"}]},
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 10, "boxWidth": 12}},
            "cutoutPercentage": 62,
            "plugins": {"doughnutlabel": {"labels": [
                {"text": str(total), "font": {"size": 26, "weight": "bold"}, "color": "#1e293b"},
                {"text": center_text, "font": {"size": 11, "weight": "bold"}, "color": "#64748b"},
            ]}},
            "datalabels": {"display": True, "color": "#ffffff",
                            "textStrokeColor": "#000000", "textStrokeWidth": 2,
                            "font": {"weight": "bold", "size": 12},
                            "formatter": "function(v,ctx){var t=ctx.chart.data.datasets[0].data.reduce(function(a,b){return a+b;},0); var pct=t?(v/t*100).toFixed(0):0; return v>0 ? v + ' (' + pct + '%)' : '';}"},
        },
    }
    return qc_url(cfg, w, h)


def consistency_range_chart(labels, mins, maxs, means, cvs=None, w=1000, h=None):
    """Renders TWO distinct horizontal bars per analyst with modern colors:
    - Bar 1: Mínimo Diário (#06B6D4 - Ocean Teal)
    - Bar 2: Máximo Diário (#8B5CF6 - Electric Violet)
    """
    display_labels = [f"{_sanitize(l, limit=18)} (Média: {m:.1f})" for l, m in zip(labels, means)]
    n = max(len(display_labels), 1)

    dl_min = {
        "display": True, "color": "#ffffff", "anchor": "center", "align": "center",
        "font": {"weight": "bold", "size": 11},
        "textStrokeColor": "#000000", "textStrokeWidth": 2,
        "formatter": "function(v){ return v > 0 ? v : ''; }"
    }
    dl_max = {
        "display": True, "color": "#ffffff", "anchor": "center", "align": "center",
        "font": {"weight": "bold", "size": 11},
        "textStrokeColor": "#000000", "textStrokeWidth": 2,
        "formatter": "function(v){ return v > 0 ? v : ''; }"
    }

    cfg = {
        "type": "horizontalBar",
        "data": {
            "labels": display_labels,
            "datasets": [
                {
                    "label": "Mínimo Diário", "data": mins, "backgroundColor": "#06B6D4",
                    "datalabels": dl_min
                },
                {
                    "label": "Máximo Diário", "data": maxs, "backgroundColor": "#8B5CF6",
                    "datalabels": dl_max
                },
            ]
        },
        "options": {
            "legend": {"display": True, "position": "bottom", "labels": {"fontSize": 10, "boxWidth": 12}},
            "scales": {
                "xAxes": [{"ticks": {"beginAtZero": True, "fontSize": 10},
                            "scaleLabel": {"display": True, "labelString": "Tickets Fechados por Dia"}}],
                "yAxes": [{"ticks": {"fontSize": 10}}],
            },
        }
    }
    return qc_url(cfg, w, h or max(300, 36 * n + 80))


def self_history_bar(labels, deltas, w=1000, h=None):
    """Each analyst's This Month vs THEIR OWN trailing personal average -
    colored Ocean Teal (#06B6D4) for positive delta or Electric Violet (#8B5CF6) for negative delta.
    """
    labels = [_sanitize(l, limit=24) for l in labels]
    n = max(len(labels), 1)
    colors = ["#06B6D4" if d >= 0 else "#8B5CF6" for d in deltas]
    cfg = {
        "type": "horizontalBar",
        "data": {"labels": labels, "datasets": [{
            "label": "vs personal average", "data": deltas, "backgroundColor": colors,
            "datalabels": {"display": True, "color": "#2c3e50", "anchor": "end", "align": "right",
                            "font": {"weight": "bold", "size": 11},
                            "formatter": "function(v){return (v>=0?'+':'') + v + '%';}"},
        }]},
        "options": {
            "legend": {"display": False},
            "scales": {
                "xAxes": [{"ticks": {"fontSize": 10},
                            "scaleLabel": {"display": True, "labelString": "% vs own trailing average"}}],
                "yAxes": [{"ticks": {"fontSize": 11}}],
            },
        },
    }
    return qc_url(cfg, w, h or max(320, 30 * n + 90))

"""
Módulo de compatibilidade: Redireciona chamadas para o serviço centralizado em tools/smtp.py
para garantir modularidade e reuso do código em toda a aplicação.
"""
from tools.smtp import (
    enviar_email_automatico,
    send_outlook_windows,
    send_outlook_mac,
    SmtpMailer,
    IS_WINDOWS,
    IS_MAC
)

__all__ = [
    "enviar_email_automatico",
    "send_outlook_windows",
    "send_outlook_mac",
    "SmtpMailer",
    "IS_WINDOWS",
    "IS_MAC"
]

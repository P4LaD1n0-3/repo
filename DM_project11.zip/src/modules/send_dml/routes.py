import os
import logging
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from src.models import db, SendDmlConfig
from src.modules.send_dml.dml_mailer import (
    AMBIENTES,
    detectar_scripts_por_ambiente,
    detectar_ambiente_execucao,
    gerar_perguntas,
)
from src.modules.send_dml.send_dml_mailer import DmlMailer
from src.modules.send_dml.dml_change_finder import buscar_change_do_dia

logger = logging.getLogger("SendDml")

current_dir = os.path.dirname(os.path.abspath(__file__))
send_dml_bp = Blueprint('send_dml', __name__, template_folder=current_dir)


def _ensure_sqlite_columns():
    """Garante a integridade do schema de 'send_dml_configs', adicionando as colunas do
    monitor de Change (change_monitor_ambiente / change_monitor_mailbox) se necessário -
    mesmo padrão usado em 'release_task.routes._ensure_sqlite_columns'."""
    try:
        from sqlalchemy import inspect, text
        inspector = inspect(db.engine)
        if 'send_dml_configs' in inspector.get_table_names():
            existing_cols = [c['name'] for c in inspector.get_columns('send_dml_configs')]
            with db.engine.connect() as conn:
                if 'change_monitor_ambiente' not in existing_cols:
                    conn.execute(text("ALTER TABLE send_dml_configs ADD COLUMN change_monitor_ambiente VARCHAR(20) DEFAULT 'EBAO'"))
                if 'change_monitor_mailbox' not in existing_cols:
                    conn.execute(text("ALTER TABLE send_dml_configs ADD COLUMN change_monitor_mailbox VARCHAR(255) DEFAULT ''"))
                conn.commit()
    except Exception as e_col:
        logger.warning(f"⚠️ Verificação/migração de colunas SQLite em send_dml_configs: {e_col}")

# Rótulo de exibição de cada ambiente reconhecido (ver dml_mailer.AMBIENTES).
AMBIENTE_LABELS = {
    'EBAOGS': 'EBAO - GS',
    'EBAOGC': 'EBAO - GC',
    'EBAOST': 'EBAO - ST',
    'EBAORP': 'EBAO - RP',
    'GEPRODB': 'GEPRO DB',
    'PORTALDB': 'Portal DB',
    'CIRCULARDB': 'Circular DB',
}

CONFIG_FIELDS = ('change', 'ritm', 'send_to', 'copia', 'change_monitor_ambiente', 'change_monitor_mailbox')


@send_dml_bp.route('/send_dml')
@login_required
def index():
    _ensure_sqlite_columns()
    config = SendDmlConfig.get_or_create(current_user.id)
    return render_template(
        'send_dml.html', user=current_user, active_page='send_dml',
        config=config, ambiente_labels=AMBIENTE_LABELS,
    )


@send_dml_bp.route('/send_dml/fetch_change', methods=['POST'])
@login_required
def fetch_change():
    """
    "Puxar Change": busca no Outlook (Inbox + Sent Items) o e-mail de aprovação de
    Release/Change do dia para o ambiente escolhido (EBAO/PORTAL) e extrai o número
    da CHG do assunto (ver dml_change_finder.buscar_change_do_dia).
    """
    data = request.get_json() or {}
    ambiente = (data.get('ambiente') or '').strip().upper()
    mailbox = (data.get('mailbox') or '').strip()

    sucesso, chg, mensagem = buscar_change_do_dia(ambiente, mailbox)
    if sucesso:
        logger.info(f"✅ Change encontrada via monitor de e-mail ({ambiente}): {chg}")
        return jsonify({'status': 'success', 'change': chg, 'message': mensagem})

    logger.warning(f"⚠️ Busca de Change via e-mail ({ambiente}) sem resultado: {mensagem}")
    return jsonify({'status': 'error', 'message': mensagem}), 404


@send_dml_bp.route('/send_dml/scan', methods=['POST'])
@login_required
def scan():
    """
    Detecta dinamicamente, a partir dos nomes dos arquivos .sql selecionados no
    navegador, quais ambientes têm script(s) de DML (equivalente a 'montar_email()'
    em mail_sender.txt, porém sem depender de uma pasta fixa em disco).
    """
    data = request.get_json() or {}
    filenames = data.get('filenames') or []
    if not isinstance(filenames, list) or not filenames:
        return jsonify({'status': 'error', 'message': "Selecione ao menos um arquivo '.sql' para detectar os ambientes."}), 400

    scripts_por_ambiente, lista = detectar_scripts_por_ambiente(filenames)
    if not scripts_por_ambiente:
        return jsonify({
            'status': 'error',
            'message': 'Nenhum ambiente reconhecido nos nomes dos arquivos selecionados (esperado no nome: ' + ', '.join(AMBIENTES) + ').',
        }), 400

    ambiente_execucao = detectar_ambiente_execucao(lista)
    perguntas = gerar_perguntas(scripts_por_ambiente)

    ambientes_out = [
        {
            'key': amb,
            'label': AMBIENTE_LABELS.get(amb, amb),
            'count': len(scripts_por_ambiente[amb]),
            'scripts': scripts_por_ambiente[amb],
        }
        for amb in AMBIENTES if amb in scripts_por_ambiente
    ]

    return jsonify({
        'status': 'success',
        'ambiente_execucao': ambiente_execucao,
        'ambientes': ambientes_out,
        'perguntas': perguntas,
    })


@send_dml_bp.route('/send_dml/save_config', methods=['POST'])
@login_required
def save_config():
    try:
        data = request.get_json() or {}
        config = SendDmlConfig.get_or_create(current_user.id)
        for campo in CONFIG_FIELDS:
            if campo in data:
                setattr(config, campo, data[campo])
        db.session.commit()
        return jsonify({'status': 'success', 'message': 'Configuração salva com sucesso!'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'status': 'error', 'message': str(e)}), 500


@send_dml_bp.route('/send_dml/send', methods=['POST'])
@login_required
def send():
    try:
        data = request.get_json() or {}
        change = (data.get('change') or '').strip()
        ritm = (data.get('ritm') or '').strip()
        send_to = (data.get('send_to') or '').strip()
        copia = (data.get('copia') or '').strip()
        filenames = data.get('filenames') or []
        respostas = data.get('respostas') or {}
        observacao = (data.get('observacao') or '').strip()

        if not change or not ritm or not send_to:
            return jsonify({'status': 'error', 'message': "Preencha 'Change', 'RITM' e 'Send to' antes de enviar."}), 400
        if not isinstance(filenames, list) or not filenames:
            return jsonify({'status': 'error', 'message': "Nenhum script carregado. Selecione os arquivos '.sql' e detecte os ambientes novamente."}), 400

        scripts_por_ambiente, lista = detectar_scripts_por_ambiente(filenames)
        if not scripts_por_ambiente:
            return jsonify({'status': 'error', 'message': 'Nenhum ambiente reconhecido nos scripts informados.'}), 400

        # O front detecta um valor padrão (substring 'HOMOLOGACAO' no nome do script),
        # mas o usuário pode alternar manualmente no toggle PROD/MODEL antes de enviar -
        # honra a escolha explícita quando ela vier preenchida e válida no payload.
        ambiente_execucao = (data.get('ambiente_execucao') or '').strip().upper()
        if ambiente_execucao not in ('PROD', 'MODEL'):
            ambiente_execucao = detectar_ambiente_execucao(lista)

        faltando = [amb for amb in scripts_por_ambiente if not (respostas.get(amb) or {}).get('justificativa', '').strip()]
        if faltando:
            labels = ', '.join(AMBIENTE_LABELS.get(a, a) for a in faltando)
            return jsonify({'status': 'error', 'message': f"Preencha a justificativa para: {labels}."}), 400

        config = SendDmlConfig.get_or_create(current_user.id)
        config.change = change
        config.ritm = ritm
        config.send_to = send_to
        config.copia = copia
        db.session.commit()

        mailer = DmlMailer()
        sucesso, mensagem = mailer.send_approval_email(
            change=change,
            ritm=ritm,
            send_to_valor=send_to,
            assinatura_nome=current_user.display_signature_name,
            assinatura_email=current_user.email,
            scripts_por_ambiente=scripts_por_ambiente,
            lista=lista,
            ambiente_execucao=ambiente_execucao,
            respostas=respostas,
            copia=copia,
            observacao=observacao,
        )

        if sucesso:
            logger.info(f"✅ E-mail de aprovação de DML enviado. {change} / {ritm} ({ambiente_execucao})")
            return jsonify({'status': 'success', 'message': mensagem, 'ambiente_execucao': ambiente_execucao})

        logger.error(f"❌ Erro ao enviar e-mail de aprovação de DML: {mensagem}")
        return jsonify({'status': 'error', 'message': mensagem}), 500

    except Exception as e:
        logger.exception(f"Erro no envio de DML: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

"""
================================================================================
ARQUIVO MODELO E REFERÊNCIA: AUTOMAÇÃO DE CADASTRO DE USUÁRIO
================================================================================
Este arquivo fica localizado dentro da pasta do módulo 'src/modules/portal_task/'
e serve como REFERÊNCIA ARQUITETURAL para a implementação das demais ações do sistema.

CONCEITOS CHAVE ILUSTRADOS NESTE ARQUIVO:
1. HERANÇA POO: 'CadastroUsuarioService' herda de 'PortalTaskUpmService'
   (tools/portal_task_base_service.py), que por sua vez reúne por herança
   múltipla ServiceNowDriver + UpmDriver + DatabaseMixin. Isso é o que dá a
   esta classe, de graça, o laço de lote com Semáforo, o login/cadastro/reset
   no UPM e as consultas de banco - nenhuma dessas coisas é reimplementada
   aqui, só orquestrada.
2. EXECUÇÃO INDIVIDUAL (1 PÁGINA): 'executar_individual' lida com o fluxo de
   uma única página/URL do ServiceNow.
3. MÁQUINA DE ESTADOS DO CADASTRO: após cada tentativa de cadastro no UPM,
   'processar_resultado_cadastro_upm' (herdado) interpreta a mensagem de
   retorno e aplica o tratamento correto - sucesso, já existe, CPF já usado
   por outro usuário, ou organização/corretora ainda não cadastrada - fiel ao
   'novoRegistro' do script de referência 'cadastro_usuario.txt'.
"""

import os
import logging
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import Page
from tools.portal_task_base_service import PortalTaskUpmService
from tools.base_automation import SelectorManager
from tools.chamado import Chamado
from tools.usuario import Usuario
from tools.planilha_cadastro import ler_planilha_cadastro


# Configuração de Logger dedicado para este serviço
logger = logging.getLogger("CadastroUsuarioService")


class ChamadoCadastro(Chamado):
    """
    Especialização de 'Chamado' exclusiva do fluxo 'Cadastro de usuário'.
    REUSO POR HERANÇA: aproveita sctask/ritm/requester/assignment_group e o
    anexo/texto já resolvidos pelo 'Chamado' base, adicionando apenas o que é
    específico deste serviço (usuários lidos da planilha .xlsx da RITM, prontos
    para o cadastro no Portal UPM).
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.usuarios: List[Usuario] = []
        self.linhas_invalidas: List[Dict[str, Any]] = []

    def to_dict(self) -> Dict[str, Any]:
        dados = super().to_dict()
        dados["usuarios"] = [u.to_dict() for u in self.usuarios]
        dados["linhas_invalidas"] = self.linhas_invalidas
        return dados


class CadastroUsuarioService(PortalTaskUpmService):
    """
    Classe especialista responsável pela automação de 'Cadastro de usuário'.
    Herda de PortalTaskUpmService (ServiceNowDriver + UpmDriver + DatabaseMixin
    por herança múltipla) - ver tools/portal_task_base_service.py.
    """

    def __init__(
        self,
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def executar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        ========================================================================
        FLUXO DE EXECUÇÃO DE 1 PÁGINA / URL INDIVIDUAL — CADASTRO DE USUÁRIO
        ========================================================================
        1. VARREDURA: percorre a fila em 'url' e monta o array de chamados
           (SCTASK, RITM, Requester, Assignment group) via método herdado
           'varrer_chamados' (regex + deduplicação, sem repetir chamados já capturados).
        2. Para cada chamado, acessa a RITM diretamente (sc_req_item.do?sys_id=<ritm>):
           baixa o anexo .xlsx (salvo na pasta temporária 'path_temp', preservada em
           caso de falha) se existir, ou extrai o texto da RITM quando não há anexo.
        3. Lê a planilha .xlsx DINAMICAMENTE pelo nome das colunas (Email_Master,
           Usuario (Nome Completo), CPF_Master, Celular (Opcional), Razao Social,
           CNPJ, SUSEP, SENHA), ignorando linhas com dado BLOQUEANTE faltando
           (email/nome/CPF inválidos, ou CNPJ e SUSEP ambos vazios) e seguindo a
           automação normalmente para as demais.
        3.5. Confirma cada usuário no banco do Portal (herdado de DatabaseMixin):
           corrige razão social abreviada/digitada errado e preenche automaticamente
           o CNPJ ou o SUSEP quando só um dos dois veio na planilha. Falha de
           conexão/consulta NUNCA derruba a automação - vira uma pendência
           registrada em 'usuario.pendencias'.
        4. Cadastra cada usuário válido no Portal UPM/PUMA. Em seguida, a
           MÁQUINA DE ESTADOS herdada ('processar_resultado_cadastro_upm')
           interpreta a mensagem de retorno do UPM e trata os 4 cenários
           possíveis, fiel ao 'novoRegistro' de cadastro_usuario.txt:
             a) "Usuário registrado com êxito" / "Usuário já existe no sistema"
                -> reseta a senha (reativando a conta se necessário).
             b) "CPF existe com o usuário diferente" -> localiza o e-mail antigo
                pelo CPF na planilha histórica, inativa a conta antiga e a
                reaproveita com os dados novos (resolver_cpf_existente).
             c) "Adicionar Organização para o usuário" -> consulta o eBao
                (Oracle) e CRIA a corretora automaticamente no UPM, depois
                tenta o reset de senha (criar_organizacao_a_partir_do_ebao).
             d) Qualquer outra mensagem -> fica registrada em 'usuario.retorno'.

        REGRA DE NEGÓCIO OBRIGATÓRIA: 'Realizar cadastro' NUNCA preenche nem
        encerra a SCTASK no ServiceNow. Encerrar o chamado é responsabilidade
        exclusiva da ação "Encerrar" (TaskEncerrarService) e deve ser disparada
        manualmente pelo usuário somente depois de validar o cadastro.
        """
        logger.info(f"👤 [CadastroUsuarioService] Iniciando processamento da URL: {url}")

        resultado: Dict[str, Any] = {
            "url": url,
            "acao": "Cadastro de usuário",
            "chamados": [],
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            # PASSO 1: Varredura de chamados da fila -> array de 'ChamadoCadastro' (herda de Chamado)
            # Método herdado de ServiceNowDriver: aplica regex e não repete chamados já capturados.
            chamados: List[ChamadoCadastro] = await self.varrer_chamados(
                page=page, url=url, chamado_cls=ChamadoCadastro
            )

            # PASSO 2 e 3: para cada chamado, acessa a RITM diretamente, baixa o anexo
            # (ou extrai texto quando não há anexo) e lê a planilha .xlsx dinamicamente.
            for chamado in chamados:
                if not chamado.ritm:
                    logger.warning(
                        f"⚠️ [CadastroUsuarioService] Chamado {chamado.sctask_number} sem RITM identificada, "
                        f"não é possível acessar a RITM diretamente."
                    )
                    continue

                dados_ritm = await self.acessar_ritm_e_obter_anexo_ou_texto(page=page, ritm=chamado.ritm)
                chamado.anexos = dados_ritm.get("anexos", [])
                chamado.texto_extraido = dados_ritm.get("texto_extraido")

                arquivos_xlsx = [a for a in chamado.anexos if a.lower().endswith(".xlsx")]
                if not arquivos_xlsx:
                    logger.info(
                        f"ℹ️ [CadastroUsuarioService] Chamado {chamado.sctask_number or chamado.ritm_number} "
                        f"sem planilha .xlsx para processar."
                    )
                    continue

                for caminho_planilha in arquivos_xlsx:
                    usuarios, linhas_invalidas = ler_planilha_cadastro(caminho_planilha)
                    chamado.usuarios.extend(usuarios)
                    chamado.linhas_invalidas.extend(linhas_invalidas)

                    if linhas_invalidas:
                        logger.warning(
                            f"⚠️ [CadastroUsuarioService] {len(linhas_invalidas)} linha(s) ignorada(s) em "
                            f"'{os.path.basename(caminho_planilha)}' (linhas: {[li['linha'] for li in linhas_invalidas]}) "
                            f"por dado obrigatório faltando — automação segue normalmente."
                        )

            # PASSO 3.5: Confirmação de corretora no banco do Portal (herdado de DatabaseMixin).
            # Corrige razão social abreviada/digitada errado e preenche CNPJ ou SUSEP quando
            # apenas um dos dois veio preenchido na planilha - NUNCA derruba a automação: se o
            # banco estiver indisponível, apenas registra uma pendência em 'usuario.pendencias'
            # e segue com os dados originais da planilha.
            for chamado in chamados:
                for usuario in chamado.usuarios:
                    await self.confirmar_dados_corretora_async(usuario)
                    if usuario.pendencias:
                        logger.warning(
                            f"⚠️ [CadastroUsuarioService] Pendência(s) para '{usuario.email_master}' "
                            f"(linha {usuario.linha}): {usuario.pendencias}"
                        )

            # PASSO 4: Cadastro efetivo no Portal UPM/PUMA. Login e métodos de cadastro/reset
            # são herdados diretamente (self.login_upm / self.cadastrar_usuario_upm / etc.) -
            # não é mais necessário instanciar UpmDriver à parte.
            login_realizado = False

            for chamado in chamados:
                if not chamado.usuarios:
                    continue

                if not login_realizado:
                    await self.login_upm(page=page)
                    login_realizado = True

                for usuario in chamado.usuarios:
                    resultado_cadastro = await self.cadastrar_usuario_upm(page=page, dados_usuario=usuario.to_dict())

                    # MÁQUINA DE ESTADOS (herdada de PortalTaskUpmService): interpreta a
                    # mensagem do UPM e trata sucesso/já existe/CPF existente/organização
                    # faltando, atualizando 'usuario.senha'/'usuario.retorno'/'usuario.pendencias'.
                    await self.processar_resultado_cadastro_upm(page, usuario, resultado_cadastro)

                    if usuario.pendencias:
                        logger.warning(
                            f"⚠️ [CadastroUsuarioService] Cadastro de '{usuario.email_master}' (linha {usuario.linha}) "
                            f"finalizado com pendência(s): {usuario.pendencias}"
                        )

            resultado["chamados"] = [c.to_dict() for c in chamados]
            resultado["sctasks"] = [c.sctask_number or c.sctask for c in chamados if c.sctask_number or c.sctask]
            resultado["ritm"] = (chamados[0].ritm_number or chamados[0].ritm) if chamados else None

            # IMPORTANTE: nenhuma escrita/encerramento é feita na SCTASK neste serviço.
            # Ver docstring do método acima e TaskEncerrarService para o encerramento manual.

            logger.info(
                f"✅ [CadastroUsuarioService] Concluído com sucesso em {url}. "
                f"Chamados capturados: {resultado['sctasks']}"
            )

        except Exception as e:
            logger.error(f"❌ [CadastroUsuarioService] Erro ao cadastrar usuário na URL {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

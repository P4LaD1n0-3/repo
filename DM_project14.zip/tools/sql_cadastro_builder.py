"""
================================================================================
GERADOR DE SCRIPT SQL: CADASTRO DE USUÁRIO / CORRETORA (via TEMPLATE EXTERNO)
================================================================================
Porta de 'gerarScript' e 'gerarScriptCorretora' em cadastro_usuario.txt.

O CONTEÚDO REAL dos templates ('Script_Cadastro_Usuario.sql' /
'Script_Cadastro_Corretora.sql') não faz parte deste repositório - é
informação sensível/proprietária do usuário, assim como a query completa do
eBao em 'tools.database.consultar_dados_completos_ebao' já é tratada como
placeholder configurável neste projeto. O que foi portado aqui é só a LÓGICA
de manipulação do arquivo (as mesmas faixas de linha e os mesmos nomes de
variável SET do script de referência).

COMO ATIVAR: coloque os 2 arquivos (o(s) que você tiver) dentro de
'TEMPLATES_SQL_DIR' (por padrão 'config/sql_templates/', configurável via a
variável de ambiente 'SQL_TEMPLATES_DIR'). Enquanto o arquivo não existir, a
geração é PULADA com um aviso claro - nunca derruba o cadastro, que já foi
concluído no UPM (e a senha já resetada) antes deste passo.

MELHORIAS SOBRE O LEGADO (mesma lógica/estrutura, execução mais robusta):
  1. TEMPLATE CONFIGURÁVEL: caminho fixo e quebrado no legado
     ('src/documents/Script_Cadastro_Usuario.sql', que não existe nesta
     estrutura de projeto) trocado por diretório configurável.
  2. SUBSTITUIÇÃO POR REGEX NOMEADA, NÃO POR ÍNDICE DE LINHA: o legado
     localizava as 4 linhas de identificação do usuário por POSIÇÃO fixa
     ('vetor[16]', 'vetor[17]'...) - um espaço extra ou uma linha em branco a
     mais no template já quebrava a substituição (o '.replace()' simplesmente
     não encontrava o texto exato e a linha saía vazia, sem erro nenhum). Aqui
     a busca é pelo NOME da variável ('SET @email_contato_master = ...') em
     qualquer lugar da linha, o que tolera espaçamento diferente.
  3. ESCAPE DE ASPAS SIMPLES: o legado interpolava os valores direto na string
     SQL (f"...= '{valor}'") - um nome como "D'Angelo" quebraria a instrução.
     Aqui toda substituição escapa aspas simples (' -> '').
  4. VALIDAÇÃO DE TAMANHO: se o template tiver menos linhas que as faixas
     esperadas (ver constantes 'LINHAS_*' abaixo), falha com uma mensagem
     clara dizendo QUAL faixa não bateu, em vez de um erro de índice opaco.
  5. NUNCA DERRUBA A AUTOMAÇÃO: qualquer falha na geração do script vira uma
     pendência (devolvida no dict de retorno) para o chamador registrar em
     'usuario.pendencias' - o cadastro no UPM e o reset de senha já
     aconteceram ANTES deste passo e não devem ser desfeitos por causa disto.

Se o formato do SEU template usar faixas de linha diferentes das configuradas
abaixo (extraídas do script de referência 'cadastro_usuario.txt'), ajuste as
constantes 'LINHAS_*' / 'LINHA_CORRETORA_FINAL_INICIO' - é o único lugar que
precisa mudar.
"""

import os
import re
import logging
from typing import Any, Dict, List, Optional, TYPE_CHECKING

logger = logging.getLogger("SqlCadastroBuilder")

if TYPE_CHECKING:
    from tools.usuario import Usuario

# Diretório onde os templates .sql devem ser colocados (configurável via .env).
TEMPLATES_SQL_DIR = os.getenv("SQL_TEMPLATES_DIR") or os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config", "sql_templates"
)

TEMPLATE_CADASTRO_USUARIO = "Script_Cadastro_Usuario.sql"
TEMPLATE_CADASTRO_CORRETORA = "Script_Cadastro_Corretora.sql"

# --- Faixas de linha do template (0-based, fiel a 'cadastro_usuario.txt') ---
# 'gerarScript' (cadastro de usuário):
LINHAS_USUARIO_INICIO = (0, 16)      # vetor[0:16]   -> preâmbulo (1x, início do script)
LINHAS_USUARIO_IDENTIFICACAO = (16, 20)  # vetor[16:20]  -> 4 linhas SET (email/cpf/nome/cnpj), 1x por usuário
LINHAS_USUARIO_CORPO = (21, 100)     # vetor[21:100] -> corpo repetido, 1x por usuário (linha 20 é pulada, fiel ao legado)
LINHAS_USUARIO_FINAL = (101, 104)    # vetor[101:104] -> fechamento (1x, fim do script)

# 'gerarScriptCorretora' (cadastro de corretora):
LINHAS_CORRETORA_INICIO = (0, 26)    # vetor[0:26] -> preâmbulo (1x)
LINHA_CORRETORA_FINAL_INICIO = 30    # vetor[30::] -> fechamento (1x)


def _ler_template(nome_arquivo: str) -> Optional[List[str]]:
    caminho = os.path.join(TEMPLATES_SQL_DIR, nome_arquivo)
    if not os.path.exists(caminho):
        logger.warning(
            f"⚠️ [SqlCadastroBuilder] Template '{nome_arquivo}' não encontrado em '{TEMPLATES_SQL_DIR}'. "
            f"Coloque o arquivo original nesse diretório (ou aponte 'SQL_TEMPLATES_DIR' no .env) para habilitar "
            f"a geração automática do script - a geração foi PULADA, o cadastro em si não foi afetado."
        )
        return None
    with open(caminho, "r", encoding="utf-8") as f:
        return f.readlines()


def _escapar_sql(valor: Any) -> str:
    """Escapa aspas simples para não quebrar a instrução SQL gerada (ver item 3 do docstring do módulo)."""
    return str(valor if valor is not None else "").replace("'", "''")


def _substituir_variavel(texto: str, variavel: str, valor: Any) -> str:
    """
    Substitui 'SET @variavel = ...' pelo valor informado, localizando a
    declaração PELO NOME da variável via regex (não por posição de linha) -
    tolera espaçamento diferente do template original.
    """
    padrao = re.compile(rf"SET\s+@{re.escape(variavel)}\s*=\s*'[^']*'", re.IGNORECASE)
    substituicao = f"SET @{variavel} = '{_escapar_sql(valor)}'"
    novo_texto, n = padrao.subn(substituicao, texto, count=1)
    if n == 0:
        logger.warning(
            f"⚠️ [SqlCadastroBuilder] Variável '@{variavel}' não encontrada no template - "
            f"confira se o template usa exatamente 'SET @{variavel} = ...'."
        )
    return novo_texto


def gerar_sql_cadastro_usuario(
    ritm: str,
    usuarios: List["Usuario"],
    destino_dir: str,
    is_assessoria: bool = False,
) -> Optional[str]:
    """
    Porta de 'gerarScript': monta o INSERT de 1 ou mais usuários no MESMO
    script (1 bloco de identificação + corpo por usuário), salva em
    'destino_dir' e devolve o caminho do arquivo gerado (ou None se o
    template não estiver disponível/for inválido - nunca lança exceção).

    NOTA DE FIDELIDADE (preservada do legado, não é bug desta adaptação): a
    variável SQL '@cpf_contato_master' é preenchida com o CNPJ do usuário
    (usuario.cnpj), não com o CPF - assim está em 'gerarScript' no script de
    referência, mantido aqui por fidelidade.
    """
    linhas = _ler_template(TEMPLATE_CADASTRO_USUARIO)
    if linhas is None or not usuarios:
        return None

    fim_esperado = max(LINHAS_USUARIO_IDENTIFICACAO[1], LINHAS_USUARIO_CORPO[1], LINHAS_USUARIO_FINAL[1])
    if len(linhas) < fim_esperado:
        logger.error(
            f"❌ [SqlCadastroBuilder] Template '{TEMPLATE_CADASTRO_USUARIO}' tem {len(linhas)} linha(s), "
            f"menos que as {fim_esperado} esperadas pelas faixas configuradas - ajuste as constantes 'LINHAS_USUARIO_*' "
            f"em tools/sql_cadastro_builder.py para o formato real do seu template."
        )
        return None

    partes: List[str] = ["".join(linhas[LINHAS_USUARIO_INICIO[0]:LINHAS_USUARIO_INICIO[1]])]
    corpo_base = "".join(linhas[LINHAS_USUARIO_CORPO[0]:LINHAS_USUARIO_CORPO[1]])

    for usuario in usuarios:
        identificacao = "".join(linhas[LINHAS_USUARIO_IDENTIFICACAO[0]:LINHAS_USUARIO_IDENTIFICACAO[1]])
        for variavel, valor in (
            ("email_contato_master", usuario.email_master),
            ("cpf_contato_master", usuario.cnpj),  # fiel ao legado - ver docstring
            ("nome_contato_master", usuario.nome_completo),
            ("cnpj", usuario.cnpj),
        ):
            identificacao = _substituir_variavel(identificacao, variavel, valor)

        corpo_usuario = corpo_base
        if is_assessoria:
            corpo_usuario = corpo_usuario.replace(
                "SET @id_perfil = 53", "SET @id_perfil = 51"
            ).replace(
                "ds_organizacao_cpf_cnpj = @cnpj;", "ds_organizacao_cpf_cnpj = @cnpj and id_organizacao_tipo = 2;"
            )

        partes.append(identificacao)
        partes.append(corpo_usuario)

    partes.append("".join(linhas[LINHAS_USUARIO_FINAL[0]:LINHAS_USUARIO_FINAL[1]]))

    sufixo = "CadastroAssessoria" if is_assessoria else "CadastroUsuario"
    os.makedirs(destino_dir, exist_ok=True)
    caminho_saida = os.path.join(destino_dir, f"PORTALDB_{ritm}_{sufixo}.sql")
    with open(caminho_saida, "w", encoding="utf-8") as f:
        f.writelines(partes)

    logger.info(f"📄 [SqlCadastroBuilder] Script de cadastro de usuário gerado: {caminho_saida}")
    return caminho_saida


def gerar_sql_cadastro_corretora(
    ritm: str,
    cnpj: str,
    razao_social: str,
    nome_contato_master: str,
    susep: str,
    dados_ebao: Dict[str, Any],
    destino_dir: str,
) -> Optional[str]:
    """
    Porta de 'gerarScriptCorretora': script SQL manual (para revisão/execução
    de um DBA) usado quando a corretora foi cadastrada no UPM mas ainda não
    está sincronizada no banco do Portal (ver 'criar_organizacao_a_partir_do_ebao'
    em tools/portal_task_base_service.py).

    :param dados_ebao: dict devolvido por
        'DatabaseMixin.consultar_dados_completos_ebao' - usa as chaves
        'telefone', 'email_contato_master', 'agent_code' e 'agreement_code'.
    """
    linhas = _ler_template(TEMPLATE_CADASTRO_CORRETORA)
    if linhas is None:
        return None

    if len(linhas) < LINHA_CORRETORA_FINAL_INICIO:
        logger.error(
            f"❌ [SqlCadastroBuilder] Template '{TEMPLATE_CADASTRO_CORRETORA}' tem {len(linhas)} linha(s), "
            f"menos que as {LINHA_CORRETORA_FINAL_INICIO} esperadas - ajuste 'LINHAS_CORRETORA_INICIO'/"
            f"'LINHA_CORRETORA_FINAL_INICIO' em tools/sql_cadastro_builder.py para o formato real do seu template."
        )
        return None

    partes: List[str] = ["".join(linhas[LINHAS_CORRETORA_INICIO[0]:LINHAS_CORRETORA_INICIO[1]])]
    partes.append(f"\nSET @cpf_cnpj = '{_escapar_sql(cnpj)}'")
    partes.append(f"\nSET @razao_social = '{_escapar_sql(razao_social)}'")
    partes.append(f"\nSET @nome_contato_master = '{_escapar_sql(nome_contato_master)}'")
    partes.append(f"\nSET @telefone_contato = '{_escapar_sql(dados_ebao.get('telefone'))}'")
    partes.append(f"\nSET @email_contato_master = '{_escapar_sql(dados_ebao.get('email_contato_master'))}'")
    partes.append(f"\nSET @Susep = '{_escapar_sql(susep)}'")
    partes.append(f"\nSET @agent_code_ebao = '{_escapar_sql(dados_ebao.get('agent_code'))}'")
    partes.append(f"\nSET @agreement_code_ebao = '{_escapar_sql(dados_ebao.get('agreement_code'))}'\n\n")
    partes.append("".join(linhas[LINHA_CORRETORA_FINAL_INICIO:]))

    os.makedirs(destino_dir, exist_ok=True)
    caminho_saida = os.path.join(destino_dir, f"PORTALDB_{ritm}_CadastroCorretora_{cnpj}.sql")
    with open(caminho_saida, "w", encoding="utf-8") as f:
        f.writelines(partes)

    logger.info(f"📄 [SqlCadastroBuilder] Script de cadastro de corretora gerado: {caminho_saida}")
    return caminho_saida

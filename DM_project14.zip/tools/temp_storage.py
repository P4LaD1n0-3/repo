"""
================================================================================
PASTA TEMPORÁRIA DA AUTOMAÇÃO ('path_temp')
================================================================================
Centraliza a criação da pasta 'path_temp' na raiz do projeto (mesmo padrão do
'cadastro_exemplo': create_path_temp() vindo de src.Commons). Todo arquivo
baixado (ex: anexo .xlsx do ServiceNow) ou gerado durante a automação (ex:
screenshot de evidência do reset de senha) deve ser salvo aqui.

Por ser uma pasta FIXA na raiz do projeto (e não um diretório temporário do
SO que se autodestrói), os arquivos permanecem disponíveis para consulta e
diagnóstico manual caso a automação falhe no meio do processamento.
"""

import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATH_TEMP = os.path.join(PROJECT_ROOT, "path_temp")


def create_path_temp() -> str:
    """Garante a existência da pasta temporária 'path_temp' e retorna seu caminho absoluto."""
    os.makedirs(PATH_TEMP, exist_ok=True)
    return PATH_TEMP

"""
================================================================================
DOWNLOAD COMPARTILHADO DE EXPORTS DO SERVICENOW (SCTASK / INC / PRB .xlsx)
================================================================================
Classe reutilizável por QUALQUER tela que precise baixar as planilhas de
exportação do ServiceNow (Dashboard hoje - ver 'src/modules/system/routes.py'
e 'src/modules/dash/routes.py' -, Email Report no futuro) sem duplicar a
lógica de autenticação/download em cada módulo.

POR QUE PLAYWRIGHT (E NÃO HTTP DIRETO): a instância de ServiceNow deste
projeto exige login via Okta com MFA (aprovação por notificação push no
celular) - não aceita usuário/senha direto (Basic Auth) nos links de export.
Por isso esta classe reaproveita EXATAMENTE o mesmo mecanismo já usado por
Portal Task/Release Task:
  - 'tools.base_automation.BaseAutomation.launch_persistent_context()' abre
    um navegador com perfil PERSISTENTE (mesma pasta './playwright_user_data'
    usada pelas demais automações) - se o usuário já autenticou no Okta em
    QUALQUER automação deste app, a sessão já está no cache local e nenhum
    login interativo é necessário aqui.
  - 'tools.okta_auth.OktaAuthManager.wait_for_okta_login_if_needed()' checa
    se a sessão está válida; só ESSA etapa tem um timeout grande (até 3 min,
    só quando realmente precisa de login/MFA no celular). Depois de
    autenticado, cada download individual usa um timeout pequeno
    (DOWNLOAD_TIMEOUT_MS) - a expectativa é responder em segundos.

Cada URL configurada é aberta numa aba e o download é capturado de duas formas
(nessa ordem):
  1. Direto: a navegação para a URL já dispara o download (caso comum quando a
     URL é um link de exportação puro, ex.: '...&CSV'/'...&excel').
  2. Fallback via iFrame: se a URL só carregou uma página normal do ServiceNow
     (dentro do iFrame 'gsft_main', como as demais telas do sistema), procura
     um link de exportação óbvio (.xlsx/.csv/'Export') nela e clica.
"""

import os
import logging
from pathlib import Path
from typing import Dict, Optional

from playwright.async_api import async_playwright, Page, TimeoutError as PlaywrightTimeoutError

from tools.base_automation import BaseAutomation
from tools.okta_auth import OktaAuthManager

logger = logging.getLogger("ServiceNowExportDownloader")

# Nome de arquivo fixo por tipo de export - mesma convenção já usada em todo o
# app (src/modules/email_report/config.py CONFIG default paths, find_excel_by_pattern
# em src/modules/dash/email_bridge.py, e a detecção por nome de arquivo do próprio
# dashboard em src/modules/dash/index.html:parseExcelBlob) - garante que qualquer
# tela consumidora reconheça os arquivos sem nenhuma mudança na detecção.
FILENAMES = {
    "SCTASK": "sc_task.xlsx",
    "INC": "incident.xlsx",
    "PRB": "problem_task.xlsx",
}

# Timeouts pequenos DE PROPÓSITO: depois do login (que tem seu próprio timeout de
# até 3 min, só quando REALMENTE precisa de MFA - ver OktaAuthManager), o usuário
# já está autenticado e cada download deve ser questão de segundos, não minutos.
DOWNLOAD_TIMEOUT_MS = int(os.environ.get("SERVICENOW_DOWNLOAD_TIMEOUT_MS", "20000"))
IFRAME_CHECK_TIMEOUT_MS = int(os.environ.get("SERVICENOW_IFRAME_CHECK_TIMEOUT_MS", "8000"))

# Seletor genérico usado só no FALLBACK (quando a URL não disparou download direto),
# para localizar um link de exportação óbvio dentro da página/iFrame.
EXPORT_LINK_SELECTOR = (
    "a[href*='CSV'], a[href*='.xlsx'], a[href*='.xls'], a[href*='export'], "
    "a:has-text('Export'), a:has-text('Excel')"
)


class ServiceNowExportDownloader(BaseAutomation):
    """Baixa planilhas de exportação do ServiceNow via Playwright, reaproveitando
    a sessão Okta persistida (ver docstring do módulo)."""

    async def _tentar_download_direto(self, page: Page, url: str, dest_path: Path) -> bool:
        """Navega até a URL e tenta capturar um download disparado diretamente
        pela própria navegação (caso comum: a URL já é um link de exportação puro)."""
        try:
            async with page.expect_download(timeout=DOWNLOAD_TIMEOUT_MS) as download_info:
                try:
                    await page.goto(url, wait_until="commit", timeout=DOWNLOAD_TIMEOUT_MS)
                except Exception as e_goto:
                    # ESPERADO quando a URL É o link de export: o Playwright aborta a
                    # NAVEGAÇÃO com "Download is starting" assim que o browser detecta
                    # que a resposta é um arquivo (Content-Disposition), não uma página -
                    # não é falha real, é só como o Playwright sinaliza "virou download".
                    # O download em si já disparou e é capturado abaixo via
                    # 'download_info.value'; só re-propaga qualquer OUTRO erro (rede,
                    # DNS, etc.) que não seja esse.
                    if "download is starting" not in str(e_goto).lower():
                        raise
            download = await download_info.value
            await download.save_as(str(dest_path))
            return True
        except PlaywrightTimeoutError:
            return False

    async def _tentar_download_via_iframe(self, page: Page, dest_path: Path) -> bool:
        """
        Fallback: a URL carregou uma página normal (não disparou download direto) -
        procura, dentro do iFrame 'gsft_main' (se existir - cai para a própria
        página se não houver, ver 'get_iframe_scope') um link de exportação
        (.xlsx/.csv/'Export') e clica nele.
        """
        scope = await self.get_iframe_scope(page, timeout=IFRAME_CHECK_TIMEOUT_MS)
        link = scope.locator(EXPORT_LINK_SELECTOR).first
        if await link.count() == 0:
            return False
        try:
            async with page.expect_download(timeout=DOWNLOAD_TIMEOUT_MS) as download_info:
                await link.click()
            download = await download_info.value
            await download.save_as(str(dest_path))
            return True
        except PlaywrightTimeoutError:
            return False

    async def _baixar_um(self, label: str, url: str, dest_path: Path, context) -> Dict:
        page = await context.new_page()
        try:
            if await self._tentar_download_direto(page, url, dest_path):
                logger.info(f"[{label}] OK (download direto): {dest_path}")
                return {"status": "success", "path": str(dest_path)}

            logger.info(f"[{label}] Navegação não disparou download direto - verificando iFrame/links de exportação...")
            if await self._tentar_download_via_iframe(page, dest_path):
                logger.info(f"[{label}] OK (via link na página/iFrame): {dest_path}")
                return {"status": "success", "path": str(dest_path)}

            return {
                "status": "error",
                "error": (
                    f"A URL não disparou um download nem foi encontrado um link de exportação "
                    f"óbvio na página (URL atual: {page.url}). Verifique se a URL configurada é "
                    f"realmente um link direto de exportação do ServiceNow."
                ),
            }
        except Exception as e:
            logger.error(f"[{label}] Erro ao baixar: {e}")
            return {"status": "error", "error": str(e)}
        finally:
            try:
                await page.close()
            except Exception:
                pass

    async def baixar_planilhas(
        self,
        urls: Dict[str, str],
        dest_dir: str,
        job_id: Optional[str] = None,
        headless: bool = False,
        validation_url: Optional[str] = None,
    ) -> Dict[str, Dict]:
        """
        Abre um navegador persistente (perfil './playwright_user_data', mesmo das
        demais automações do app), garante a sessão Okta (aguardando MFA no celular
        só se realmente necessário) e baixa cada URL de 'urls' (chaves esperadas:
        "SCTASK"/"INC"/"PRB") para 'dest_dir', com o nome de arquivo fixo de
        FILENAMES. 'job_id', se informado, registra o navegador no JobRegistry
        compartilhado - permite que o botão "Cancelar" de qualquer tela encerre
        esta automação (ver tools/job_registry.py).

        'validation_url', se configurada (ver ServiceNowExportConfig.validation_url),
        é visitada ANTES dos links de export para validar/renovar a sessão Okta - um
        link de export .xlsx puro nem sempre dispara o fluxo de login corretamente,
        então uma URL "normal" do ServiceNow (ex.: a home) é mais confiável para essa
        checagem. Sem ela, cai no comportamento anterior (usa a 1ª URL de export).
        """
        dest_dir_path = Path(dest_dir)
        dest_dir_path.mkdir(parents=True, exist_ok=True)

        resultados: Dict[str, Dict] = {}
        urls_validas: Dict[str, str] = {}
        for label, url in urls.items():
            url = (url or "").strip()
            if url:
                urls_validas[label] = url
            else:
                resultados[label] = {"status": "error", "error": f"Nenhuma URL configurada para '{label}'."}

        if not urls_validas:
            return resultados

        async with async_playwright() as p:
            context = await self.launch_persistent_context(p, headless=headless, job_id=job_id)
            try:
                url_validacao = (validation_url or "").strip() or next(iter(urls_validas.values()))
                check_page = await context.new_page()
                await OktaAuthManager.wait_for_okta_login_if_needed(check_page, url_validacao)
                await check_page.close()

                for label, url in urls_validas.items():
                    filename = FILENAMES.get(label, f"{label.lower()}.xlsx")
                    resultados[label] = await self._baixar_um(label, url, dest_dir_path / filename, context)
            finally:
                await self.close_context(context)

        return resultados

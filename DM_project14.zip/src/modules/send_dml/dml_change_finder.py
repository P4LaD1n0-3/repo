"""
================================================================================
BUSCA DA CHANGE (CHG) NO E-MAIL DE APROVAÇÃO JÁ ENVIADO (tela 'send_dml')
================================================================================
Localiza, em Inbox + Sent Items do Outlook, o e-mail de aprovação de
Release/Change do dia (assunto disparado pelo 'release_task' - ver
'release_mailer.ReleaseMailer.send_approval_email') para o ambiente escolhido
(EBAO/PORTAL) e extrai o número da CHG do assunto, evitando copiar/colar
manualmente o número entre as duas telas.
"""

import re
import platform
import logging
from datetime import datetime, time as dtime

logger = logging.getLogger("DmlChangeFinder")

IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"

CHG_REGEX = re.compile(r'CHG\d+', re.IGNORECASE)

# Trecho fixo do assunto gerado por 'ReleaseMailer.send_approval_email' -
# "Aprovação Requerida - Execução DML - Produção - {rlse} - {chg} ({ambiente}) - OO Approval".
ASSUNTO_BASE = "Aprovação Requerida - Execução DML - Produção"

AMBIENTE_MARCADORES = {
    'EBAO': '(EBAO)',
    'PORTAL': '(PORTAL)',
}


def _assunto_bate(assunto: str, ambiente: str) -> bool:
    marcador = AMBIENTE_MARCADORES.get(ambiente, f"({ambiente})")
    return ASSUNTO_BASE in (assunto or "") and marcador in assunto


def _buscar_change_windows(ambiente: str, mailbox_email: str = ""):
    import win32com.client
    import pythoncom

    # Mesma causa raiz do erro "CoInitialize has not been called" corrigida em
    # 'tools/smtp.py' - toda chamada COM precisa inicializar/desinicializar a
    # apartment da THREAD atual (cada requisição Flask pode cair em thread nova).
    pythoncom.CoInitialize()
    try:
        outlook = win32com.client.Dispatch("outlook.application")
        namespace = outlook.GetNamespace("MAPI")

        hoje_meia_noite = datetime.combine(datetime.now().date(), dtime.min)
        filtro_data = hoje_meia_noite.strftime('%m/%d/%Y %I:%M %p')

        raiz = None
        if mailbox_email:
            try:
                raiz = namespace.Folders(mailbox_email)
            except Exception as e:
                logger.warning(f"⚠️ Caixa de e-mail '{mailbox_email}' não encontrada no perfil do Outlook: {e}")

        pastas = []  # (pasta, campo_de_data_DASL)
        try:
            inbox = raiz.Folders("Inbox") if raiz else namespace.GetDefaultFolder(6)  # olFolderInbox
            pastas.append((inbox, "ReceivedTime"))
        except Exception as e:
            logger.warning(f"⚠️ Não foi possível abrir a Caixa de Entrada: {e}")

        try:
            sent = raiz.Folders("Sent Items") if raiz else namespace.GetDefaultFolder(5)  # olFolderSentMail
            pastas.append((sent, "SentOn"))
        except Exception as e:
            logger.warning(f"⚠️ Não foi possível abrir 'Itens Enviados': {e}")

        if not pastas:
            return False, "", "Não foi possível acessar nenhuma pasta do Outlook para a busca."

        melhor_assunto = ""
        melhor_data = None

        for pasta, campo_data in pastas:
            try:
                itens = pasta.Items.Restrict(f"[{campo_data}] >= '{filtro_data}'")
            except Exception as e:
                logger.warning(f"⚠️ Erro ao filtrar itens de hoje: {e}")
                continue

            for item in itens:
                try:
                    assunto = getattr(item, "Subject", "") or ""
                    if not _assunto_bate(assunto, ambiente):
                        continue
                    data_item = getattr(item, campo_data, None)
                    if data_item is None:
                        continue
                    data_naive = datetime(data_item.year, data_item.month, data_item.day,
                                           data_item.hour, data_item.minute, data_item.second)
                    if melhor_data is None or data_naive > melhor_data:
                        melhor_data = data_naive
                        melhor_assunto = assunto
                except Exception:
                    continue

        if not melhor_assunto:
            return False, "", (
                f"Nenhum e-mail '{ASSUNTO_BASE} - ... {AMBIENTE_MARCADORES.get(ambiente, ambiente)} - OO Approval' "
                f"encontrado hoje ({hoje_meia_noite.strftime('%d/%m/%Y')})."
            )

        match = CHG_REGEX.search(melhor_assunto)
        if not match:
            return False, "", f"E-mail encontrado ('{melhor_assunto}'), mas sem número de CHG no assunto."

        return True, match.group(0).upper(), f"CHG extraída do e-mail: '{melhor_assunto}'."
    finally:
        pythoncom.CoUninitialize()


def _buscar_change_mac(ambiente: str, mailbox_email: str = ""):
    """
    Melhor esforço via AppleScript (Outlook Mac) - o alvo principal desta busca é o Outlook
    Windows/COM, único ambiente reportado com o e-mail de aprovação do 'release_task'.
    """
    import subprocess

    marcador = AMBIENTE_MARCADORES.get(ambiente, f"({ambiente})").replace('"', '\\"')
    assunto_base_esc = ASSUNTO_BASE.replace('"', '\\"')

    # NÃO usar 'date "MM/DD/YYYY"' aqui: o parser de string do AppleScript
    # interpreta a data conforme o formato curto do SISTEMA (region/locale do
    # Mac) - num Mac configurado em pt-BR (DD/MM/YYYY), "08/10/2026" vira 8 de
    # outubro em vez de 10 de agosto, e a busca "hoje" some silenciosamente
    # (falso negativo, sem erro visível). 'current date' + zerar a hora é
    # locale-safe: sempre meia-noite do dia real, em qualquer região.
    as_script = f'''
    set hojeData to current date
    set time of hojeData to 0
    tell application "Microsoft Outlook"
        set assuntoAlvo to ""
        repeat with m in (messages of inbox whose time received is greater than or equal to hojeData)
            set assuntoM to subject of m
            if assuntoM contains "{assunto_base_esc}" and assuntoM contains "{marcador}" then
                set assuntoAlvo to assuntoM
            end if
        end repeat
        if assuntoAlvo is "" then
            repeat with m in (messages of sent items whose time sent is greater than or equal to hojeData)
                set assuntoM to subject of m
                if assuntoM contains "{assunto_base_esc}" and assuntoM contains "{marcador}" then
                    set assuntoAlvo to assuntoM
                end if
            end repeat
        end if
        return assuntoAlvo
    end tell
    '''
    try:
        resultado = subprocess.run(['osascript', '-e', as_script], check=True, capture_output=True, text=True)
        assunto = (resultado.stdout or "").strip()
    except subprocess.CalledProcessError as e:
        err = e.stderr.strip() if e.stderr else str(e)
        return False, "", f"Erro ao buscar e-mail no Outlook (Mac): {err}"

    if not assunto:
        return False, "", f"Nenhum e-mail '... {marcador} - OO Approval' encontrado hoje."

    match = CHG_REGEX.search(assunto)
    if not match:
        return False, "", f"E-mail encontrado ('{assunto}'), mas sem número de CHG no assunto."

    return True, match.group(0).upper(), f"CHG extraída do e-mail: '{assunto}'."


def buscar_change_do_dia(ambiente: str, mailbox_email: str = ""):
    """
    Busca (Inbox + Sent Items) o e-mail de aprovação de Release/Change mais recente
    ENVIADO/RECEBIDO HOJE para o ambiente informado (EBAO/PORTAL) e extrai o número da
    CHG do assunto. Retorna (sucesso: bool, chg: str, mensagem: str).
    """
    ambiente = (ambiente or "EBAO").strip().upper()
    if ambiente not in AMBIENTE_MARCADORES:
        return False, "", f"Ambiente '{ambiente}' inválido. Use EBAO ou PORTAL."

    if IS_WINDOWS:
        return _buscar_change_windows(ambiente, mailbox_email)
    elif IS_MAC:
        return _buscar_change_mac(ambiente, mailbox_email)
    else:
        return False, "", f"Sistema operacional não suportado ({platform.system()}) para busca no Outlook."

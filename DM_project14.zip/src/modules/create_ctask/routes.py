import os
import asyncio
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from tools.servicenow_driver import ServiceNowDriver

current_dir = os.path.dirname(os.path.abspath(__file__))
create_ctask_bp = Blueprint('create_ctask', __name__, template_folder=current_dir)

@create_ctask_bp.route('/create_ctask', methods=['GET', 'POST'])
@login_required
def index():
    results = None
    if request.method == 'POST':
        urls_input = request.form.get('urls', '').strip()
        headless = True if request.form.get('headless') else False
        
        if urls_input:
            urls = [url.strip() for url in urls_input.split('\n') if url.strip()]
            driver = ServiceNowDriver()
            # Executa o loop assíncrono do Playwright dentro do Flask
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                results = loop.run_until_complete(
                    driver.run_extraction(urls, headless=headless, max_concurrency=3)
                )
            finally:
                loop.close()

    return render_template('create_ctask.html', user=current_user, active_page='create_ctask', results=results)

@create_ctask_bp.route('/api/servicenow/extract', methods=['POST'])
@login_required
def api_extract():
    data = request.get_json() or {}
    urls = data.get('urls', [])
    headless = data.get('headless', True)

    if not urls:
        return jsonify({'status': 'error', 'message': 'Nenhuma URL fornecida'}), 400

    driver = ServiceNowDriver()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        results = loop.run_until_complete(
            driver.run_extraction(urls, headless=headless, max_concurrency=3)
        )
    finally:
        loop.close()

    return jsonify({'status': 'success', 'data': results})

"""
================================================================================
BASE COMPARTILHADA: RESET DE SENHA e RESET DE MFA
================================================================================
'Reset de senha' e 'Reset de mfa' são o MESMO fluxo no script de referência
(reset_senha_mfa_usuario.txt: 'reset_list'/'resetEmails'/'resetRegistro' com
um parâmetro 'type_reset' = "reset" ou "mfa") - por isso, em vez de duplicar
a leitura de planilha/texto e o laço de reset em 2 arquivos, este módulo
concentra tudo por HERANÇA em 'ResetUpmServiceBase'. 'PasswordResetService' e
'MfaResetService' viram subclasses de 1 linha, cada uma só declarando o
'TIPO_RESET' ("reset"/"mfa") e o rótulo da ação.
"""

import logging
from typing import Any, Dict, List, Optional

from playwright.async_api import Page

from tools.chamado import Chamado
from tools.portal_task_base_service import PortalTaskUpmService
from tools.planilha_cadastro import ler_planilha_emails
from tools.validators import extrair_emails_de_texto

logger = logging.getLogger("ResetUpmServiceBase")


class ChamadoReset(Chamado):
    """
    Especialização de 'Chamado' exclusiva do fluxo de Reset (senha/MFA).
    REUSO POR HERANÇA: aproveita sctask/ritm/requester/anexo/texto já
    resolvidos pelo 'Chamado' base, adicionando apenas os e-mails a resetar e
    os resultados individuais de cada reset.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.emails: List[str] = []
        self.resultados: List[Dict[str, Any]] = []

    def to_dict(self) -> Dict[str, Any]:
        dados = super().to_dict()
        dados["emails"] = self.emails
        dados["resultados"] = self.resultados
        return dados


class ResetUpmServiceBase(PortalTaskUpmService):
    """
    Classe-base comum a 'Reset de senha' e 'Reset de mfa'. Subclasses só
    precisam definir 'TIPO_RESET' ("reset"/"mfa") e 'ACAO' (rótulo exibido).
    """

    TIPO_RESET: str = "reset"
    ACAO: str = "Reset de senha"

    async def executar_individual(self, page: Page, url: str, dados_formulario: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        ========================================================================
        FLUXO DE RESET DE SENHA/MFA (fiel a 'reset_list' de reset_senha_mfa_usuario.txt)
        ========================================================================
        1. Varre os chamados da fila (mesmo método herdado do Cadastro).
        2. Para cada chamado, tenta baixar a planilha .xlsx anexada com a lista
           de e-mails (ler_planilha_emails); se não houver anexo, cai no
           fallback do script original: extrai e-mails direto do TEXTO da RITM
           via regex (extrair_emails_de_texto).
        3. Faz login no UPM uma única vez e executa o reset (senha ou MFA,
           conforme 'TIPO_RESET') para cada e-mail único encontrado, reutilizando
           'resetar_senha_mfa_upm' (herdado de UpmDriver) - já contempla o laço
           de repetição até obter uma senha válida (não a sentinela 'n_gerou_senha').

        Diferente do script legado, este serviço NÃO comenta nem encerra a
        SCTASK automaticamente (mesma decisão de arquitetura já adotada pelo
        Cadastro de usuário) - fica com a ação manual "Encerrar"
        (TaskEncerrarService), disparada só depois de o operador validar os
        resultados do reset.
        """
        logger.info(f"🔑 [{self.__class__.__name__}] Iniciando '{self.ACAO}' em: {url}")

        resultado: Dict[str, Any] = {
            "url": url,
            "acao": self.ACAO,
            "chamados": [],
            "sctasks": [],
            "status": "success",
            "error": None,
        }

        try:
            chamados: List[ChamadoReset] = await self.varrer_chamados(
                page=page, url=url, chamado_cls=ChamadoReset
            )

            for chamado in chamados:
                if not chamado.ritm:
                    logger.warning(
                        f"⚠️ [{self.__class__.__name__}] Chamado {chamado.sctask_number} sem RITM identificada."
                    )
                    continue

                dados_ritm = await self.acessar_ritm_e_obter_anexo_ou_texto(page=page, ritm=chamado.ritm)
                chamado.anexos = dados_ritm.get("anexos", [])
                chamado.texto_extraido = dados_ritm.get("texto_extraido")

                emails: List[str] = []
                arquivos_xlsx = [a for a in chamado.anexos if a.lower().endswith(".xlsx")]
                if arquivos_xlsx:
                    for caminho_planilha in arquivos_xlsx:
                        emails.extend(ler_planilha_emails(caminho_planilha))
                elif chamado.texto_extraido:
                    emails.extend(extrair_emails_de_texto(chamado.texto_extraido))
                    logger.info(
                        f"📝 [{self.__class__.__name__}] Sem planilha anexada - "
                        f"{len(emails)} e-mail(s) extraído(s) do texto da RITM."
                    )

                # Deduplica preservando ordem (mesmo 'list(set(...))' do original, mas
                # determinístico - a ordem de execução fica previsível entre execuções).
                vistos = []
                for email in emails:
                    email_normalizado = (email or "").strip().lower()
                    if email_normalizado and email_normalizado not in vistos:
                        vistos.append(email_normalizado)
                chamado.emails = vistos

                if not chamado.emails:
                    logger.info(
                        f"ℹ️ [{self.__class__.__name__}] Chamado {chamado.sctask_number or chamado.ritm_number} "
                        f"sem e-mail(s) para resetar."
                    )

            login_realizado = False
            for chamado in chamados:
                if not chamado.emails:
                    continue

                if not login_realizado:
                    await self.login_upm(page=page)
                    login_realizado = True

                for email in chamado.emails:
                    resultado_reset = await self.resetar_senha_mfa_upm(
                        page=page, email=email, type_reset=self.TIPO_RESET
                    )
                    chamado.resultados.append({"email": email, **resultado_reset})

                    if resultado_reset.get("status") != "success":
                        logger.warning(
                            f"⚠️ [{self.__class__.__name__}] Reset de '{email}' retornou: "
                            f"{resultado_reset.get('error') or resultado_reset.get('senha_gerada')}"
                        )

            resultado["chamados"] = [c.to_dict() for c in chamados]
            resultado["sctasks"] = [c.sctask_number or c.sctask for c in chamados if c.sctask_number or c.sctask]
            resultado["ritm"] = (chamados[0].ritm_number or chamados[0].ritm) if chamados else None

            logger.info(f"✅ [{self.__class__.__name__}] Concluído em {url}. SCTASKs: {resultado['sctasks']}")

        except Exception as e:
            logger.error(f"❌ [{self.__class__.__name__}] Erro em {url}: {e}")
            resultado["status"] = "error"
            resultado["error"] = str(e)

        return resultado

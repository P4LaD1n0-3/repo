@echo off
REM Full pipeline: authenticate + download the 3 ServiceNow exports, build
REM and send the executive dashboard (main.py), THEN build and send the
REM Analyst Performance Comparison (main_analyst_report.py) as a second,
REM separate e-mail. Ideal for Task Scheduler (e.g. run every morning at
REM 8am) - no manual steps, no browser window ever opens.

setlocal
cd /d "%~dp0"

echo ============================================================
echo  Step 1/3 - Authenticating and downloading ServiceNow data
echo ============================================================
python download_data.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Download step failed - aborting before sending e-mails with stale data.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Step 2/3 - Building and sending the executive dashboard
echo ============================================================
python main.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Executive dashboard step failed - see messages above.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Step 3/3 - Building and sending the Analyst Performance Comparison
echo ============================================================
python main_analyst_report.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Analyst comparison step failed - see messages above.
    pause
    exit /b 1
)

echo.
echo All done - both e-mails sent.
endlocal

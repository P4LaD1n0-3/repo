import os
import base64
import platform
import subprocess
from datetime import datetime

# Detect OS
IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"

def send_outlook_windows(to, cc, subject, html_body, screenshot_base64=None):
    """
    Envia e-mail de forma silenciosa no Windows via Outlook COM.
    Segue o modelo robusto.
    """
    import win32com.client
    try:
        # Tratamento de segurança para os parâmetros
        safe_to = str(to) if to else ""
        safe_cc = str(cc) if cc else ""
        safe_subject = str(subject) if subject else "Relatório Dashboard - " + datetime.now().strftime('%d/%m/%Y')
        
        print(f"--- Preparando envio de E-mail Silencioso via Outlook (Windows) ---")
        outlook = win32com.client.Dispatch("outlook.application")
        mail = outlook.CreateItem(0)
        
        if safe_to:
            mail.To = safe_to
        else:
            print("⚠️ Aviso: Destinatário vazio. O envio pode falhar.")
            
        mail.Subject = safe_subject
        mail.HTMLBody = html_body
        mail.Importance = 2 # Normal
        
        if safe_cc:
            mail.CC = safe_cc
            
        # Handle Screenshot Attachment
        if screenshot_base64:
            temp_path = os.path.join(os.getcwd(), "temp_screenshot_mail.png")
            try:
                img_data = base64.b64decode(screenshot_base64.split(",")[1])
                with open(temp_path, "wb") as f:
                    f.write(img_data)
                mail.Attachments.Add(os.path.abspath(temp_path))
            except Exception as e_img:
                print(f"⚠️ Erro ao anexar screenshot: {e_img}")

        # DISPARO SILENCIOSO
        mail.Send()
        print(f"✅ E-mail enviado com sucesso para {safe_to}!")
        return True, f"E-mail enviado silenciosamente via Outlook (Windows) para {safe_to}."
    except Exception as e:
        print(f"❌ Erro crítico ao enviar e-mail (Windows): {e}")
        return False, str(e)

def send_outlook_mac(to, cc, subject, html_body):
    """
    Envia e-mail via AppleScript (Outlook Mac).
    Usa a propriedade 'content' do Outlook, que aceita HTML.
    HTML é compactado em linha única para evitar problemas no literal de string do AppleScript.
    """
    try:
        safe_to  = str(to).strip() if to else ""
        safe_cc  = str(cc).strip() if cc else ""
        safe_subj = (str(subject) if subject else "Relatório Dashboard") \
            .replace('\\', '\\\\').replace('"', '\\"')

        # Compactar HTML em linha única + escapar para string AppleScript
        compact = html_body.replace('\r\n', ' ').replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        compact = compact.replace('\\', '\\\\').replace('"', '\\"')

        safe_to_esc = safe_to.replace('\\', '\\\\').replace('"', '\\"')

        as_script = (
            'tell application "Microsoft Outlook"\n'
            f'    set newMsg to make new outgoing message with properties'
            f' {{subject:"{safe_subj}", content:"{compact}"}}\n'
            f'    make new to recipient at newMsg with properties'
            f' {{email address:{{address:"{safe_to_esc}"}}}}\n'
        )

        if safe_cc:
            safe_cc_esc = safe_cc.replace('\\', '\\\\').replace('"', '\\"')
            as_script += (
                f'    make new cc recipient at newMsg with properties'
                f' {{email address:{{address:"{safe_cc_esc}"}}}}\n'
            )

        as_script += '    send newMsg\nend tell'

        subprocess.run(['osascript', '-e', as_script], check=True, capture_output=True)
        print(f"✅ E-mail HTML enviado com sucesso (Mac) para {safe_to}!")
        return True, f"E-mail enviado silenciosamente via Outlook (Mac) para {safe_to}."
    except subprocess.CalledProcessError as e:
        err = e.stderr.decode('utf-8', errors='replace') if e.stderr else str(e)
        print(f"❌ Erro AppleScript ao enviar e-mail (Mac): {err}")
        return False, err
    except Exception as e:
        print(f"❌ Erro crítico ao enviar e-mail (Mac): {e}")
        return False, str(e)


def enviar_email_automatico(to, cc, subject, html_body, screenshot_base64=None):
    """
    Função principal que identifica o sistema operacional automaticamente 
    e dispara o e-mail via Outlook (sem pedir senhas).
    """
    if IS_WINDOWS:
        return send_outlook_windows(to, cc, subject, html_body, screenshot_base64)
    elif IS_MAC:
        return send_outlook_mac(to, cc, subject, html_body)
    else:
        err = f"Sistema Operacional não suportado ({platform.system()}) para envio via Outlook."
        print(f"❌ {err}")
        return False, err


if __name__ == "__main__":
    # Teste de execução direta
    teste_to = "rolim.r@icloud.com"
    teste_subj = "Teste de Integração Outlook OS-Aware"
    teste_body = "<h2>Teste Automático</h2><p>Identificando o SO para disparar via Outlook localmente e silenciosamente (sem pedir senhas).</p>"
    
    print(f"Sistema Operacional Identificado: {platform.system()} {platform.release()}")
    enviar_email_automatico(teste_to, "", teste_subj, teste_body)

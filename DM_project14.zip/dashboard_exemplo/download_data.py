# -*- coding: utf-8 -*-
"""
ServiceNow Direct Download (HTTP, no browser)
================================================
Downloads incident.xlsx / sc_task.xlsx / problem_task.xlsx straight from
ServiceNow via authenticated HTTP requests - no Selenium, no browser at
all. A full browser automation round-trip (launch Chrome, wait for the
page/JS to load, click through the UI, wait for the download) typically
costs 10-30+ seconds *per file*. A direct HTTP GET against the exact same
export URL, with the same credentials, finishes in 1-3 seconds because
there's no rendering engine involved - just the request/response.

Destination paths are read from config.py's CONFIG (INC_PATH / SCTASK_PATH
/ PRB_PATH) - the SAME values main.py uses to read the files back - so
there is exactly one place that decides where these files live
(DOWNLOAD_DIR / the individual *_PATH overrides in .env), never two
diverging path calculations to keep in sync by hand.

Two-step token authentication
------------------------------
If your environment's internal protection requires visiting a site first
to obtain/validate a token BEFORE the 3 export links will respond (rather
than accepting Basic Auth directly on the export URLs themselves), set
AUTH_URL in .env. When it's set, this script:
  1. Calls AUTH_URL first (GET or POST, configurable) with your
     credentials, and pulls a token out of the JSON response (or just
     relies on whatever cookie that call sets - both are supported).
  2. Reuses that same authenticated `requests.Session` for the 3 export
     downloads, attaching the token as a header, a cookie, or a URL query
     parameter - whichever your site expects (also configurable).
If AUTH_URL is left blank, this step is skipped entirely and the script
behaves exactly as before (Basic Auth / cookie straight on the export
URLs) - fully backward compatible.

Setup
-----
1. Copy `.env.example` to `.env` and fill in:
   - INC_EXPORT_URL / SCTASK_EXPORT_URL / PRB_EXPORT_URL: the 3 export
     links you currently open by hand / via Selenium.
   - SERVICENOW_USER / SERVICENOW_PASSWORD: a service account.
   - AUTH_URL (+ AUTH_* settings below) ONLY if your instance needs the
     two-step token flow described above - leave blank otherwise.
2. Run:  python download_data.py   (or double-click download_data.bat)
"""
import os
import sys
import time
from pathlib import Path

import requests
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

from config import CONFIG  # noqa: E402 (must load .env first, see above)

SN_USER = os.environ.get("SERVICENOW_USER", "")
SN_PASSWORD = os.environ.get("SERVICENOW_PASSWORD", "")
# Optional fallback for SSO-protected instances where Basic Auth is not
# available: paste the session cookie string from an already-authenticated
# browser tab (DevTools -> Application/Storage -> Cookies) here. Whatever
# is pasted is sent verbatim as the Cookie header.
SN_SESSION_COOKIE = os.environ.get("SERVICENOW_SESSION_COOKIE", "")

# --- Two-step token auth (see module docstring) ---
AUTH_URL = os.environ.get("AUTH_URL", "").strip()
AUTH_METHOD = os.environ.get("AUTH_METHOD", "POST").strip().upper()
AUTH_USERNAME = os.environ.get("AUTH_USERNAME", "") or SN_USER
AUTH_PASSWORD = os.environ.get("AUTH_PASSWORD", "") or SN_PASSWORD
# How credentials are sent to AUTH_URL: "json" (POST body {"username":...,
# "password":...}), "form" (POST form-encoded, same fields), or "basic"
# (HTTP Basic Auth on the auth request itself, no body).
AUTH_CREDENTIALS_AS = os.environ.get("AUTH_CREDENTIALS_AS", "json").strip().lower()
AUTH_USERNAME_FIELD = os.environ.get("AUTH_USERNAME_FIELD", "username")
AUTH_PASSWORD_FIELD = os.environ.get("AUTH_PASSWORD_FIELD", "password")
# Dotted path to the token inside the JSON response, e.g. "access_token"
# or "data.token" for a nested {"data": {"token": "..."}} response.
AUTH_TOKEN_FIELD = os.environ.get("AUTH_TOKEN_FIELD", "access_token")
# Where the token goes on the 3 download requests that follow:
# "header" | "cookie" | "query_param" | "none" (rely on the session cookie
# the auth call already set automatically, e.g. a classic Set-Cookie login).
AUTH_TOKEN_LOCATION = os.environ.get("AUTH_TOKEN_LOCATION", "header").strip().lower()
AUTH_TOKEN_HEADER_NAME = os.environ.get("AUTH_TOKEN_HEADER_NAME", "Authorization")
AUTH_TOKEN_HEADER_PREFIX = os.environ.get("AUTH_TOKEN_HEADER_PREFIX", "Bearer ")
AUTH_TOKEN_COOKIE_NAME = os.environ.get("AUTH_TOKEN_COOKIE_NAME", "session_token")
AUTH_TOKEN_QUERY_PARAM = os.environ.get("AUTH_TOKEN_QUERY_PARAM", "token")

TIMEOUT = int(os.environ.get("DOWNLOAD_TIMEOUT_SECONDS", "60") or 60)
RETRIES = int(os.environ.get("DOWNLOAD_RETRIES", "2") or 2)

# (label, env var holding the URL, destination path - straight from CONFIG)
SOURCES = [
    ("INC", "INC_EXPORT_URL", CONFIG["INC_PATH"]),
    ("SCTASK", "SCTASK_EXPORT_URL", CONFIG["SCTASK_PATH"]),
    ("PRB", "PRB_EXPORT_URL", CONFIG["PRB_PATH"]),
]


def _dig(data, dotted_path):
    """Reads data["a"]["b"] from dotted_path "a.b" - supports the common
    case of a token nested a level or two deep in the auth response."""
    node = data
    for part in dotted_path.split("."):
        if not isinstance(node, dict) or part not in node:
            return None
        node = node[part]
    return node


def authenticate():
    """Performs the optional two-step token auth (see module docstring)
    and returns a requests.Session ready to use for the 3 downloads below.
    If AUTH_URL isn't configured, returns a plain session unchanged - fully
    backward compatible with the single-step Basic Auth / cookie flow."""
    session = requests.Session()
    session.headers.update({
        "Accept": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, "
                  "application/vnd.ms-excel, application/octet-stream, */*",
        "User-Agent": "Mozilla/5.0 (compatible; IT-Dashboard-Downloader/1.0)",
    })
    if SN_SESSION_COOKIE:
        session.headers["Cookie"] = SN_SESSION_COOKIE

    if not AUTH_URL:
        return session, None  # no two-step flow configured - use as-is

    print(f"[auth] Step 1/2 - requesting a token from {AUTH_URL} ...")
    try:
        if AUTH_CREDENTIALS_AS == "basic":
            resp = session.request(AUTH_METHOD, AUTH_URL,
                                    auth=(AUTH_USERNAME, AUTH_PASSWORD), timeout=TIMEOUT)
        elif AUTH_CREDENTIALS_AS == "form":
            payload = {AUTH_USERNAME_FIELD: AUTH_USERNAME, AUTH_PASSWORD_FIELD: AUTH_PASSWORD}
            resp = session.request(AUTH_METHOD, AUTH_URL, data=payload, timeout=TIMEOUT)
        else:  # "json" (default)
            payload = {AUTH_USERNAME_FIELD: AUTH_USERNAME, AUTH_PASSWORD_FIELD: AUTH_PASSWORD}
            resp = session.request(AUTH_METHOD, AUTH_URL, json=payload, timeout=TIMEOUT)
        resp.raise_for_status()
    except requests.exceptions.RequestException as e:
        print(f"[auth] FAILED to reach AUTH_URL: {e}")
        print("[auth] proceeding without a token - the 3 downloads below will likely fail too.")
        return session, None

    token = None
    try:
        data = resp.json()
        token = _dig(data, AUTH_TOKEN_FIELD)
    except ValueError:
        pass  # not a JSON response - fine if the login just set a cookie instead

    if token:
        print(f"[auth] token acquired, attaching it via '{AUTH_TOKEN_LOCATION}' for the downloads.")
        if AUTH_TOKEN_LOCATION == "header":
            session.headers[AUTH_TOKEN_HEADER_NAME] = f"{AUTH_TOKEN_HEADER_PREFIX}{token}"
        elif AUTH_TOKEN_LOCATION == "cookie":
            session.cookies.set(AUTH_TOKEN_COOKIE_NAME, token)
        # "query_param" is applied per-request in download_one() below,
        # since it has to be added to each individual export URL.
        # "none" intentionally does nothing further here.
    else:
        print("[auth] no token found in the response body (checked field "
              f"'{AUTH_TOKEN_FIELD}'). If your flow sets a cookie instead of "
              "returning a token, that's already captured on the session "
              "automatically and this warning is harmless. Otherwise, check "
              "AUTH_TOKEN_FIELD matches your endpoint's actual response shape.")

    print("[auth] Step 1/2 done.\n")
    token_for_query = token if (token and AUTH_TOKEN_LOCATION == "query_param") else None
    return session, token_for_query


def _looks_like_login_page(content, content_type):
    """Heuristic: if we asked for a spreadsheet and got back HTML that
    smells like a login/SSO redirect, the download silently failed even
    though the HTTP status was 200."""
    if content_type and "html" in content_type.lower():
        head = content[:500].lower()
        if b"<html" in head or b"<!doctype html" in head:
            return True
    return False


def download_one(label, url, dest_path, session, query_token=None):
    if not url:
        print(f"   -> SKIP {label}: no URL configured ({label}_EXPORT_URL is empty in .env)")
        return False

    dest_path = Path(dest_path)
    dest_path.parent.mkdir(parents=True, exist_ok=True)

    request_url = url
    if query_token:
        sep = "&" if "?" in url else "?"
        request_url = f"{url}{sep}{AUTH_TOKEN_QUERY_PARAM}={query_token}"

    # Basic Auth is only meaningful when no token-based auth step ran.
    auth = (SN_USER, SN_PASSWORD) if (SN_USER and SN_PASSWORD and not AUTH_URL) else None

    last_error = None
    for attempt in range(1, RETRIES + 2):
        try:
            t0 = time.time()
            resp = session.get(request_url, auth=auth, timeout=TIMEOUT, allow_redirects=True)
            elapsed = time.time() - t0
            resp.raise_for_status()

            content_type = resp.headers.get("Content-Type", "")
            if _looks_like_login_page(resp.content, content_type):
                print(f"   -> WARNING {label}: got an HTML page back, not a spreadsheet. "
                      f"This usually means the auth step above didn't produce something this "
                      f"link accepts - see README 'Why this might not work out of the box'.")
                return False

            if len(resp.content) < 100:
                raise ValueError(f"response body too small ({len(resp.content)} bytes) - likely not a real file")

            with open(dest_path, "wb") as f:
                f.write(resp.content)

            print(f"   -> OK {label}: {dest_path} ({len(resp.content) / 1024:.1f} KB, {elapsed:.1f}s)")
            return True

        except (requests.exceptions.RequestException, ValueError) as e:
            last_error = e
            if attempt <= RETRIES:
                print(f"   -> retry {attempt}/{RETRIES} for {label} after error: {e}")
                time.sleep(1.5)
            continue

    print(f"   -> FAILED {label}: {last_error}")
    return False


def main():
    print("=" * 70)
    print("ServiceNow Direct Download (HTTP, no browser)")
    print("=" * 70)
    if not AUTH_URL and not (SN_USER and SN_PASSWORD) and not SN_SESSION_COOKIE:
        print("\nWARNING: no AUTH_URL, no SERVICENOW_USER/SERVICENOW_PASSWORD and no "
              "SERVICENOW_SESSION_COOKIE set in .env - requests will be sent "
              "unauthenticated and will likely fail or return a login page.")

    session, query_token = authenticate()

    print(f"[{'auth done, ' if AUTH_URL else ''}Step 2/2 - downloading files]" if AUTH_URL
          else "Downloading files (single-step auth)")
    results = []
    for label, url_env, dest in SOURCES:
        url = os.environ.get(url_env, "")
        print(f"\n[{label}] {'-> ' + url if url else '(no URL configured)'}")
        ok = download_one(label, url, dest, session, query_token=query_token)
        results.append((label, ok))

    print("\n" + "=" * 70)
    ok_count = sum(1 for _, ok in results if ok)
    print(f"{ok_count}/{len(results)} files downloaded successfully.")
    if ok_count < len(results):
        print("Some downloads failed - check the messages above, then see")
        print("README.md -> 'Why this might not work out of the box' for the")
        print("most common causes (SSO-protected instances, or the token auth")
        print("step needing its field names adjusted to match your endpoint).")
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()

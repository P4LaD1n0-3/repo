# -*- coding: utf-8 -*-
"""
IT Executive Dashboard - Main Orchestrator
============================================
Loads INC / SCTASK / PRB exports from ServiceNow, computes every metric
(aging, SLA breach, backlog, cross-type conversions, rankings), renders the
full HTML dashboard and sends it by e-mail through Outlook via `smtp.py`.

Usage
-----
1. Place INC.xlsx, SCTASK.xlsx and PRB.xlsx in this same folder
   (or edit the paths in config.py).
2. Edit CONFIG["EMAIL_TO"] / CONFIG["EMAIL_CC"] in config.py.
3. Run:  python main.py
4. Read the "[3/5] Chart image delivery" summary in the console - it tells
   you exactly how the charts were embedded (or why they weren't).
"""
import sys
import traceback

# Bump this whenever report_builder.py / charts.py changes materially, and
# check it in the console banner / e-mail subject to confirm you are
# actually running the version you think you are.
BUILD_VERSION = "2026-07-backlog-focus-inline-charts"

from config import CONFIG
from data_loader import load_all
from report_builder import build_report
import charts

try:
    from smtp import enviar_email_automatico
except ImportError:
    enviar_email_automatico = None


def main():
    print("=" * 70)
    print(f"IT Executive Dashboard - SCTASK / INC / PRB  (build: {BUILD_VERSION})")
    print("=" * 70)

    print("\n[1/5] Loading ServiceNow exports...")
    try:
        sctask, inc, prb = load_all(CONFIG)
    except FileNotFoundError as e:
        print(f"File not found: {e}")
        print("Check the paths in config.py (SCTASK_PATH / INC_PATH / PRB_PATH).")
        sys.exit(1)
    print(f"   -> SCTASK: {len(sctask)} | INC: {len(inc)} | PRB: {len(prb)} records loaded.")

    print("\n[2/5] Computing metrics and building the HTML dashboard...")
    charts.reset_delivery_stats()
    html, kpis, ref = build_report(sctask, inc, prb, CONFIG)
    print(f"   -> Period: {kpis['period_label']} | Reference date: {ref.strftime('%d/%m/%Y %H:%M')}")
    print(f"   -> Open SCTASK (REQ): {kpis['open_sctask']} | Open UAM: {kpis['open_uam']} | Open INC: {kpis['open_inc']} "
          f"| Open PRB: {kpis['open_prb']} | Total backlog: {kpis['total_backlog']} | MTTR: {kpis['mttr_overall']}d")

    print("\n[3/5] Chart image delivery summary:")
    stats = charts.get_delivery_stats()
    total_charts = sum(stats.values())
    print(f"   -> {stats['base64']} embedded inline (base64, most reliable)")
    print(f"   -> {stats['short_url']} via QuickChart short URL")
    print(f"   -> {stats['long_url']} via long GET URL (known to break in Outlook if it happens)")
    if total_charts == 0:
        print("   -> WARNING: no charts were generated at all - check the data/report logic.")
    elif stats["base64"] == total_charts:
        print("   -> All charts embedded inline. They WILL render in Outlook regardless of")
        print("      the recipient's internet access or 'block external images' setting.")
    elif stats["base64"] == 0 and stats["short_url"] == 0:
        print("   -> ALL charts fell back to long URLs. This machine could not reach")
        print("      quickchart.io when main.py ran (offline, proxy, or firewall blocking it).")
        print("      Fix internet/proxy access to quickchart.io on THIS machine and re-run -")
        print("      that is what generates the report, not Outlook.")
    else:
        print("   -> Mixed delivery: some charts embedded, some fell back. Re-running often")
        print("      clears transient failures (timeouts). Consider raising")
        print("      CONFIG['SHORT_URL_TIMEOUT_SECONDS'] if this happens consistently.")

    if CONFIG.get("SAVE_LOCAL_COPY"):
        with open(CONFIG["OUTPUT_HTML"], "w", encoding="utf-8") as f:
            f.write(html)
        print(f"\n[4/5] Local copy saved to: {CONFIG['OUTPUT_HTML']}")
        print("   -> IMPORTANT DEBUG STEP: open this file directly in Chrome/Edge (double-click")
        print("      it, or drag it into the browser) BEFORE checking Outlook. If the charts")
        print("      render there, the problem is Outlook-specific (see README). If they don't")
        print("      render there either, it's a chart-generation issue on this machine.")

    if not CONFIG.get("SEND_EMAIL", True):
        print("\n[5/5] Email sending disabled (SEND_EMAIL=False). Done.")
        return

    print("\n[5/5] Sending e-mail via Outlook (smtp.py)...")
    if enviar_email_automatico is None:
        print("   -> smtp.py not found/importable. Copy smtp.py into this folder.")
        sys.exit(1)

    subject = f"{CONFIG['EMAIL_SUBJECT_PREFIX']} - {ref.strftime('%d/%m/%Y')} [{BUILD_VERSION}]"
    ok, msg = enviar_email_automatico(
        to=CONFIG["EMAIL_TO"],
        cc=CONFIG.get("EMAIL_CC", ""),
        subject=subject,
        html_body=html,
    )

    print("\nSend result:")
    if ok:
        print(f"   -> SUCCESS: {msg}")
        print("   -> The subject line includes the build tag above - confirm the e-mail you")
        print("      receive shows that exact tag, so you know you're looking at THIS run.")
    else:
        print(f"   -> FAILED: {msg}")
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("\nUnexpected error while generating/sending the dashboard:")
        traceback.print_exc()
        sys.exit(1)

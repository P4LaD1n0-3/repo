@echo off
REM Downloads the 3 ServiceNow exports via direct HTTP (no browser/Selenium).
REM If AUTH_URL is set in .env, this first authenticates against that site
REM to obtain a token, then uses it for the 3 export links - see .env.example
REM and README.md ("Two-step token authentication") for details.
REM Double-click this file, or run it from Task Scheduler.

setlocal
cd /d "%~dp0"

echo ============================================================
echo  Downloading ServiceNow data (incident / sc_task / problem_task)
echo  (authenticates against AUTH_URL first if configured in .env)
echo ============================================================

python download_data.py
set EXIT_CODE=%ERRORLEVEL%

if %EXIT_CODE% NEQ 0 (
    echo.
    echo Download finished with errors - see messages above.
    pause
    exit /b %EXIT_CODE%
)

echo.
echo Download complete.
endlocal

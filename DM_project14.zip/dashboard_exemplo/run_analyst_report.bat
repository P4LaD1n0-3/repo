@echo off
REM Builds and sends ONLY the Analyst Performance Comparison e-mail
REM (today x yesterday, this week x last week, this month x last month,
REM per analyst). Uses the same ServiceNow data files as main.py - run
REM download_data.bat first if they need refreshing.

setlocal
cd /d "%~dp0"

echo ============================================================
echo  Analyst Performance Comparison
echo ============================================================

python main_analyst_report.py
set EXIT_CODE=%ERRORLEVEL%

if %EXIT_CODE% NEQ 0 (
    echo.
    echo Failed - see messages above.
    pause
    exit /b %EXIT_CODE%
)

echo.
echo Done.
endlocal

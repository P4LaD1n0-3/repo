# -*- coding: utf-8 -*-
"""
Analyst Performance Comparison - Orchestrator
=================================================
Sends the SECOND e-mail (the first is main.py's executive dashboard):
today vs yesterday, this week vs last week, this month (MTD) vs the same
elapsed period last month - all broken down per analyst, focused on
closure throughput, with a "Needs Attention" panel to help spot
bottlenecks and a "Top Performers" leaderboard.

Usage
-----
Run this AFTER main.py (see run_all.bat, which now runs both in order).
It reads the SAME data files as main.py (INC/SCTASK/PRB via config.py),
so there's nothing extra to download or configure beyond what main.py
already needs - just:  python main_analyst_report.py
"""
import sys
import traceback

from config import CONFIG
from data_loader import load_all
import metrics as m
from analyst_report_builder import build_analyst_report

try:
    from smtp import enviar_email_automatico
except ImportError:
    enviar_email_automatico = None


def main():
    print("=" * 70)
    print("Analyst Performance Comparison - Today x Yesterday x Week x Month")
    print("=" * 70)

    print("\n[1/4] Loading ServiceNow exports...")
    try:
        sctask, inc, prb = load_all(CONFIG)
    except FileNotFoundError as e:
        print(f"File not found: {e}")
        print("Check the paths in config.py / .env (SCTASK_PATH / INC_PATH / PRB_PATH).")
        sys.exit(1)
    print(f"   -> SCTASK: {len(sctask)} | INC: {len(inc)} | PRB: {len(prb)} records loaded.")

    df_req, df_uam = m.split_uam(sctask, CONFIG)
    ref = m.get_reference_date(CONFIG)

    print("\n[2/4] Computing analyst comparisons (day / week / month)...")
    html, kpis = build_analyst_report(df_req, df_uam, inc, prb, CONFIG, ref)
    t = kpis["totals"]
    print(f"   -> Reference: {ref.strftime('%d/%m/%Y %H:%M')}")
    print(f"   -> Closed today: {t['today']} (yesterday: {t['yesterday']}) | "
          f"This week: {t['this_week']} (last week: {t['last_week']}) | "
          f"This month MTD: {t['this_month']} (same period last month: {t['last_month']})")
    print(f"   -> Active analysts today: {t['active_analysts_today']} | Flagged for attention: {kpis['flag_count']}")

    if CONFIG.get("SAVE_LOCAL_COPY"):
        with open(CONFIG["ANALYST_OUTPUT_HTML"], "w", encoding="utf-8") as f:
            f.write(html)
        print(f"\n[3/4] Local copy saved to: {CONFIG['ANALYST_OUTPUT_HTML']}")

    if not CONFIG.get("ANALYST_SEND_EMAIL", True):
        print("\n[4/4] Email sending disabled (ANALYST_SEND_EMAIL=False). Done.")
        return

    print("\n[4/4] Sending e-mail via Outlook (smtp.py)...")
    if enviar_email_automatico is None:
        print("   -> smtp.py not found/importable. Copy smtp.py into this folder.")
        sys.exit(1)

    subject = f"{CONFIG['ANALYST_EMAIL_SUBJECT_PREFIX']} - {ref.strftime('%d/%m/%Y')}"
    ok, msg = enviar_email_automatico(
        to=CONFIG["ANALYST_EMAIL_TO"],
        cc=CONFIG.get("ANALYST_EMAIL_CC", ""),
        subject=subject,
        html_body=html,
    )

    print("\nSend result:")
    if ok:
        print(f"   -> SUCCESS: {msg}")
    else:
        print(f"   -> FAILED: {msg}")
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("\nUnexpected error while generating/sending the analyst comparison report:")
        traceback.print_exc()
        sys.exit(1)

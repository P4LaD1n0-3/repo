# -*- coding: utf-8 -*-
"""
Data loading & normalization for INC / SCTASK / PRB ServiceNow exports.

Column names are matched flexibly (case/whitespace-insensitive, with a list
of accepted aliases per field) so the same code keeps working even if your
export has slightly different headers - the same resilience pattern used in
the production dashboard's `_pick_col` helper.
"""
import os
import pandas as pd


def pick_column(df, candidates):
    """Return the first column in `df` matching any name in `candidates`."""
    for c in candidates:
        if c in df.columns:
            return c
    normalized = {str(col).strip().lower(): col for col in df.columns}
    for c in candidates:
        key = c.strip().lower()
        if key in normalized:
            return normalized[key]
    return None


def _dedupe_columns(df):
    if df.columns.duplicated().any():
        df = df.loc[:, ~df.columns.duplicated()].copy()
    return df


def _to_datetime(df, col):
    if col and col in df.columns:
        return pd.to_datetime(df[col], dayfirst=True, errors="coerce")
    return pd.Series(pd.NaT, index=df.index)


def _to_str(df, col, default=""):
    if col and col in df.columns:
        return df[col].astype(str).fillna(default).replace("nan", default)
    return pd.Series(default, index=df.index)


def _extract_reopen_count(df):
    """Looks for a reopen-count field under any of ServiceNow's common
    export names. Returns None (not a column of zeros) when nothing
    matches, so downstream code can distinguish "reopen tracking isn't in
    this export" from "genuinely zero reopens" - fabricating zeros would
    silently misrepresent a metric this report doesn't actually have data
    for yet."""
    col = pick_column(df, ["Reopen Count", "Reopen count", "Reopens", "Reopened Count",
                             "Number of Reopens", "reopen_count"])
    if col is None:
        return None
    return pd.to_numeric(df[col], errors="coerce").fillna(0)


def _completion_date(df, primary_names, secondary_names):
    """Coalesces two possible 'done' date columns (e.g. Resolved + Closed).

    ServiceNow's Incident (and Problem) tables keep these as two distinct
    fields: a ticket reaches "Resolved" first (the actual fix/completion),
    then "Closed" later - often automatically, after a grace period, once
    nobody reopens it. For operational reporting, whichever of the two is
    populated first is what actually matters: a resolved-but-not-yet-
    auto-closed incident must NOT be counted as still open, or the backlog
    number balloons with tickets that are actually already done.
    """
    primary_col = pick_column(df, primary_names)
    secondary_col = pick_column(df, secondary_names)
    primary_dates = _to_datetime(df, primary_col)
    secondary_dates = _to_datetime(df, secondary_col)
    return primary_dates.fillna(secondary_dates)


def load_sctask(path):
    """Load SCTASK.xlsx (service catalog tasks - equivalent to 'REQ')."""
    df = _dedupe_columns(pd.read_excel(path))

    opened_col = pick_column(df, ["Opened", "Open", "Created"])
    state_col = pick_column(df, ["State", "Status"])
    priority_col = pick_column(df, ["Impact", "Priority"])
    group_col = pick_column(df, ["Assignment group", "Assignment Group"])
    assignee_col = pick_column(df, ["Assigned to", "Assignee"])
    requester_col = pick_column(df, ["Requester", "Requested for", "Caller"])
    item_col = pick_column(df, ["Item", "Short description"])
    short_desc_col = pick_column(df, ["Short description"])
    tags_col = pick_column(df, ["Tags"])
    reason_col = pick_column(df, ["Reason"])
    close_notes_col = pick_column(df, ["Close notes"])
    work_notes_col = pick_column(df, ["Work notes"])
    add_comments_col = pick_column(df, ["Additional comments"])
    number_col = pick_column(df, ["Number"])

    out = pd.DataFrame(index=df.index)
    out["Number"] = _to_str(df, number_col)
    out["Opened"] = _to_datetime(df, opened_col)
    out["Closed"] = _completion_date(df, ["Closed", "Close"], ["Resolved", "Resolved at"])
    out["State"] = _to_str(df, state_col, "N/A")
    out["Priority"] = _to_str(df, priority_col, "N/A")
    out["Assignment group"] = _to_str(df, group_col, "\u2014")
    out["Assigned to"] = _to_str(df, assignee_col, "\u2014")
    out["Requester"] = _to_str(df, requester_col, "\u2014")
    out["Item"] = _to_str(df, item_col, "General")
    out["Short description"] = _to_str(df, short_desc_col)
    out["Tags"] = _to_str(df, tags_col)
    out["Reason"] = _to_str(df, reason_col)
    out["Close notes"] = _to_str(df, close_notes_col)
    out["Work notes"] = _to_str(df, work_notes_col)
    out["Additional comments"] = _to_str(df, add_comments_col)
    out["ReopenCount"] = _extract_reopen_count(df)
    out["IsOpen"] = out["Closed"].isna()
    out["TicketType"] = "SCTASK"
    return out


def load_inc(path):
    """Load INC.xlsx (incidents)."""
    df = _dedupe_columns(pd.read_excel(path))

    opened_col = pick_column(df, ["Opened", "Open", "Created"])
    state_col = pick_column(df, ["State", "Status"])
    priority_col = pick_column(df, ["Priority"])
    group_col = pick_column(df, ["Assignment group", "Assignment Group"])
    assignee_col = pick_column(df, ["Assigned to", "Assignee"])
    caller_col = pick_column(df, ["Caller", "Requester", "Requested for"])
    ci_col = pick_column(df, ["Configuration item", "Short description"])
    close_code_col = pick_column(df, ["Close code", "Close Code"])
    close_notes_col = pick_column(df, ["Close notes"])
    add_comments_col = pick_column(df, ["Additional comments"])
    number_col = pick_column(df, ["Number"])
    on_hold_reason_col = pick_column(df, ["On hold reason", "On Hold Reason"])
    problem_col = pick_column(df, ["Problem"])
    assignee_email_col = pick_column(df, ["Email", "Assigned to Email", "Analyst Email"])

    out = pd.DataFrame(index=df.index)
    out["Number"] = _to_str(df, number_col)
    out["Opened"] = _to_datetime(df, opened_col)
    out["Closed"] = _completion_date(df, ["Resolved", "Resolved at"], ["Closed", "Close"])
    out["State"] = _to_str(df, state_col, "N/A")
    out["Priority"] = _to_str(df, priority_col, "N/A")
    out["Assignment group"] = _to_str(df, group_col, "\u2014")
    out["Assigned to"] = _to_str(df, assignee_col, "\u2014")
    out["Assigned to Email"] = _to_str(df, assignee_email_col, "").str.lower()
    out["Caller"] = _to_str(df, caller_col, "\u2014")
    out["Configuration item"] = _to_str(df, ci_col, "General")
    out["Close code"] = _to_str(df, close_code_col)
    out["Close notes"] = _to_str(df, close_notes_col)
    out["Additional comments"] = _to_str(df, add_comments_col)
    out["On hold reason"] = _to_str(df, on_hold_reason_col)
    out["Problem"] = _to_str(df, problem_col)
    out["ReopenCount"] = _extract_reopen_count(df)
    out["IsOpen"] = out["Closed"].isna()
    out["TicketType"] = "INC"
    return out


def load_prb(path):
    """Load PRB.xlsx (problems / problem tasks - equivalent to 'PTASK')."""
    df = _dedupe_columns(pd.read_excel(path))

    opened_col = pick_column(df, ["Opened", "Open", "Created"])
    state_col = pick_column(df, ["State", "Status"])
    priority_col = pick_column(df, ["Priority"])
    group_col = pick_column(df, ["Assignment group", "Assignment Group"])
    assignee_col = pick_column(df, ["Assigned to", "Assignee"])
    problem_col = pick_column(df, ["Problem"])
    close_notes_col = pick_column(df, ["Close notes"])
    due_date_col = pick_column(df, ["Due Date"])
    number_col = pick_column(df, ["Number"])

    out = pd.DataFrame(index=df.index)
    out["Number"] = _to_str(df, number_col)
    out["Opened"] = _to_datetime(df, opened_col)
    out["Closed"] = _completion_date(df, ["Resolved", "Resolved at"], ["Closed", "Close"])
    out["DueDate"] = _to_datetime(df, due_date_col)
    out["State"] = _to_str(df, state_col, "N/A")
    out["Priority"] = _to_str(df, priority_col, "N/A")
    out["Assignment group"] = _to_str(df, group_col, "\u2014")
    out["Assigned to"] = _to_str(df, assignee_col, "\u2014")
    out["Problem"] = _to_str(df, problem_col, "General")
    out["Close notes"] = _to_str(df, close_notes_col)
    out["ReopenCount"] = _extract_reopen_count(df)
    out["IsOpen"] = out["Closed"].isna()
    out["TicketType"] = "PRB"
    return out


def load_email_log(path):
    """Loads an email correspondence log (e.g. an export of the shared
    mailbox / Outlook Sent Items) for the "emails sent per analyst"
    feature. Returns None - not an empty DataFrame - when no path is
    configured or the file doesn't exist, so downstream code can tell
    "this feature isn't set up" apart from "the log is genuinely empty",
    and show an honest N/A instead of fabricating a 0.
    Expected columns (flexible naming, case-insensitive-ish via
    pick_column): a sender address ("From"/"Sender"/"De"/"Remetente") and
    a sent timestamp ("Date"/"Sent"/"Data"/"Data Envio"/"Enviado em")."""
    if not path or not os.path.exists(path):
        return None
    try:
        df = pd.read_excel(path) if str(path).lower().endswith((".xlsx", ".xls")) else pd.read_csv(path)
    except Exception:
        return None

    from_col = pick_column(df, ["From", "Sender", "De", "Remetente", "From Address", "Sender Email"])
    date_col = pick_column(df, ["Date", "Sent", "Sent Date", "Data", "Data Envio", "Enviado em", "DateTime", "Datetime"])
    if from_col is None or date_col is None:
        return None

    out = pd.DataFrame(index=df.index)
    out["From"] = df[from_col].astype(str).str.strip().str.lower()
    out["SentAt"] = pd.to_datetime(df[date_col], errors="coerce", dayfirst=True)
    out = out.dropna(subset=["SentAt"])
    return out if not out.empty else None


def load_all(config):
    """Load the three sources. Returns (df_sctask, df_inc, df_prb)."""
    df_sctask = load_sctask(config["SCTASK_PATH"])
    df_inc = load_inc(config["INC_PATH"])
    df_prb = load_prb(config["PRB_PATH"])

    for df in (df_sctask, df_inc, df_prb):
        df.dropna(subset=["Opened"], inplace=True)

    return df_sctask, df_inc, df_prb

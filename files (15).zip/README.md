# IT Executive Dashboard (SCTASK x INC x PRB)

**v2 - visual redesign.** Same analytics as before, but the look now follows
the reference `relatorio_email.html` template exactly (soft color palette,
white cards with colored top borders, gradient section headers) instead of
the previous dark-navy "ELITE MASTER" chrome. SCTASK and INC each get their
own clearly color-coded section (blue vs red) with an identical structure,
so the two are easy to compare side by side. The old 25-row "critical
tickets" wall of text was replaced with a compact panel: 3 small stat cards
that surface the key numbers (how many, how old, the average) plus a short
6-row table — not a giant list.

A merge of your production "ELITE MASTER" dashboard (KPI cards, critical
aging tables, SLA breach charts, offender/conversion analysis, monthly
throughput tables with accumulated backlog) with the chart set from the
previous report (daily/weekly evolution, today-vs-yesterday, week-over-week).
Everything is in English and reads directly from the ServiceNow exports
`INC.xlsx` / `SCTASK.xlsx` / `PRB.xlsx`.

## Terminology mapping

Your legacy script used `REQ` / `INC` / `PTASK`. This ServiceNow export uses:

| Legacy name | This export | Meaning |
|---|---|---|
| REQ | **SCTASK** | Service catalog tasks / requests |
| INC | **INC** | Incidents |
| PTASK | **PRB** | Problems / problem tasks |

## Files

| File | Purpose |
|---|---|
| `config.py` | Paths, email settings, SLA targets, aging thresholds, windows |
| `data_loader.py` | Flexible column-matching loader for INC/SCTASK/PRB |
| `metrics.py` | Aging, SLA breach, backlog, monthly/daily throughput, conversions, rankings |
| `charts.py` | QuickChart.io URL builders (donut, pie, bar, dual-axis trend+backlog) |
| `report_builder.py` | Assembles the full HTML dashboard |
| `main.py` | Orchestrates everything and sends the e-mail via `smtp.py` |
| `smtp.py` | Your existing Outlook sender (Windows/Mac) — unchanged |

## How to run

1. Put `INC.xlsx`, `SCTASK.xlsx`, `PRB.xlsx` in this folder (or edit the
   paths in `config.py`).
2. Edit in `config.py`:
   - `EMAIL_TO` / `EMAIL_CC`
   - `SLA_DAYS` per ticket type (defaults: SCTASK=10, INC=7, PRB=10 — same
     numbers as your legacy `SLA_DAYS_REQS/INCS/PTASK`)
   - `CRITICAL_AGING_THRESHOLD` (defaults: SCTASK=20, INC=7, PRB=15)
   - `REFERENCE_DATE` — leave `None` in production
3. Run:
   ```bash
   pip install pandas openpyxl pywin32   # pywin32 only on Windows
   python main.py
   ```

## What's included (mapped to what you asked for)

**KPIs & critical call-outs**
- KPI cards: total open backlog, SCTASK open, INC open, PRB total/open,
  cross-type conversions, overall MTTR
- ⚠️ **Critical SCTASKs** (aging 20+ days, 30+ highlighted in red)
- ⚠️ **Critical INCs** (aging 7+ days) — new table, mirrors the SCTASK one

**Distribution & SLA**
- 1A/1B Top Analysts (SCTASK / INC) — donut charts
- SCTASK / INC — Inside vs Outside SLA — pie charts

**Status & Aging (bar charts)**
- 3A/3B Aging Detail (SCTASK / INC) — horizontal bars
- SCTASK / INC — Status of open tickets — horizontal bars
- Top Requesters (SCTASK → INC) and (INC → SCTASK) — current-month
  misclassification / cancellation offenders (see note below)

**Monthly & daily trend**
- 2A/2B Monthly Entry x Exit x Accumulated Backlog (dual-axis bar+line,
  SCTASK / INC)
- Daily Entry x Exit tracking for the current month, same dual-axis style
  with the backlog line (SCTASK / INC)
- Monthly Tracking Table (Opened x Resolved x Backlog) with totals row,
  for both SCTASK and INC (Throughput tables)

**Bonus sections** (kept from the previous report, since you asked for
"much more complete")
- Problems (PRB) overview: opened/resolved this month, priority mix,
  oldest open problems
- Today vs Yesterday comparison
- Current week vs previous week + weekly evolution chart

## About the offender/conversion detection

`SCTASK → INC` looks for SCTASKs closed as incomplete whose `Reason` field
mentions misclassification keywords (configurable in
`CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]`), then tries to extract a
referenced `INC` number from the close/work notes.

`INC → SCTASK` looks for cancelled incidents (`Close code` or `State`
containing "cancelled"/"canceled") and tries to extract a referenced
`SCTASK`/`RITM` number from the notes.

Both are **pattern-based on your free-text fields** — if your analysts
don't reference the linked ticket number in the notes, or don't use those
exact keywords, the tables will legitimately come back empty (shown as a
green "no data" message rather than an error). Adjust the keyword list and
regex prefixes in `metrics.py` (`_extract_ref`,
`sctask_to_inc_conversions`, `inc_to_sctask_conversions`) to match your
team's actual wording.

## Notes

- Charts use the public QuickChart.io API (same technique as your legacy
  dashboard) — the person opening the e-mail needs internet access to load
  the chart images.
- `smtp.py` was kept exactly as you provided it; `main.py` calls its
  `enviar_email_automatico(to, cc, subject, html_body)` function.
- `example_dashboard_report.html` in this package is a live preview built
  from test data, so you can see the visual before running it yourself.

## Cross-Type Conversions (SCTASK ↔ INC) — replicates "Classification Errors"

This section is a direct port of the "Classification Errors" tab logic from
your analytical dashboard (`index.html`), rebuilt for the static e-mail
report:

- **Detection is evidence-based, not just "cancelled".** A ticket only
  counts as a genuine misclassification when there's BOTH an abnormal
  closure (incomplete/cancelled/rejected) AND textual proof of it:
  - `SCTASK → INC`: State is incomplete/cancelled/rejected **and**
    `Reason` names a classification problem (keywords configurable in
    `CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]`). The linked `INC` number
    is extracted from the close/work notes when present.
  - `INC → SCTASK`: State is cancelled **and** the close/additional
    notes explicitly reference a `RITM`/`SCTASK` number (this mirrors the
    reference tool's `closeNotes.includes('RITM')` check) — a plain
    cancellation with no linked ticket is NOT counted as a reclassification.
- **Canceled Reconciliation panel**: shows the full universe of
  cancelled/incomplete tickets per type this month, how many of those were
  *confirmed* misclassifications, and how many were cancelled for some
  other reason ("Other Reasons") — so leadership can see what fraction
  of cancellations is actually a routing problem.
- **Both directions tracked explicitly** (`INC → SCTASK` and
  `SCTASK → INC` mini-KPIs), plus a historical monthly trend chart,
  Top Offending Group, Monthly MTTR (average correction time) and Maximum
  Delay — same insights as the reference tab's summary cards.
- **Breakdown tables** by Requester, by Group, by Analyst (current month)
  and a Historical Consolidated table (all months, with % of total).
- **Detailed list**: the most critical misclassified tickets this month
  (capped at `CRITICAL_TABLE_COMPACT_ROWS`, oldest first), with a note when
  there are more than shown.

Like the other offender detection in this report, this only surfaces
results when your analysts' `Reason`/close-notes wording actually matches
the configured keywords/patterns — adjust
`CONFIG["MISCLASSIFICATION_REASON_KEYWORDS"]` and the regex prefixes in
`metrics.py` (`sctask_misclassified`, `inc_reclassified`, `_extract_ref`)
to fit your team's real vocabulary.

## Fixes: broken chart images in Outlook + backlog-first focus

**1. Charts weren't rendering in Outlook (critical bug, now fixed).**
Complex dual-axis chart configs produced `<img src="https://quickchart.io/chart?...">`
URLs over 2000-2800 characters. Outlook's rendering engine (inherited from
Word) silently fails to load `<img>` tags past roughly that length — you'd
see all the numbers/tables but no chart images, exactly as reported.

Fix: `charts.py` now asks QuickChart to host each chart
(`POST /chart/create`) and embeds the short URL it returns
(`https://quickchart.io/chart/render/<id>`, well under 100 characters)
instead of the long GET URL. This requires internet access when you run
`main.py` (not at send time). If that request fails for any reason — offline,
timeout, QuickChart hiccup — it automatically falls back to the long GET
URL so the script never breaks; you'd just be back to the original bug for
that one chart. Toggle via `CONFIG["USE_SHORT_CHART_URLS"]` /
`CONFIG["SHORT_URL_TIMEOUT_SECONDS"]` in `config.py`.

**2. Responsiveness.** Added a viewport meta tag and strengthened the
`@media (max-width: 768px)` rules so cards, tables and chart images reflow
on narrower screens. Important caveat: **Outlook for Windows desktop
(the classic Word-based rendering engine) does not support CSS media
queries at all** — this is a long-standing Microsoft limitation, not
something fixable from the HTML/CSS side. The responsive layout *will*
work in Outlook Mobile (iOS/Android), Outlook for Mac, Outlook on the web,
and virtually every other modern mail client — just not the Windows
desktop app, which will always render the fixed desktop layout there.

**3. Backlog-first, current-month-only.** This report is a day-to-day
operations snapshot, so:
- Every headline KPI (Overview, and each SCTASK/INC section) is now the
  **live open backlog** — never an all-time count of closed tickets.
- Wherever a resolved/closed number does appear (Opened/Resolved this
  month, MTTR, the Classification Errors KPIs), it is strictly scoped to
  the **current month** via `metrics.current_month_flow()` /
  `metrics.mttr_days_month()` — never blended with older history.
- Removed the two sections that showed a rolling 6-month history
  (*Monthly Evolution & Trend* and the combined *Monthly Tracking Table*),
  since a multi-month resolved-ticket trend doesn't belong in a
  current-month operations report. The *Daily Evolution by Ticket Type*
  section (day-by-day, current month only) remains as the trend view.
- Classification Errors dropped its historical trend chart and
  all-time "Historical Consolidated" table for the same reason; the
  reconciliation panel, direction cards, KPI cards and breakdown tables
  were already current-month-scoped and are unchanged.

## "Ainda não funcionou" — how to actually pin down the cause

If you ran the updated script and the e-mail still looks unchanged (same
numbers, no charts), it's almost certainly one of these three things, in
order of likelihood:

**1. The e-mail you're looking at wasn't regenerated.**
Every run of `main.py` builds a brand-new e-mail and sends it as a new
message — it can never edit an e-mail already sitting in your inbox. If
you're re-opening an old message from an earlier test, of course nothing
changed. Fix: run `python main.py` again, and check the **subject line**
of the new e-mail — it now ends with a build tag like
`[2026-07-backlog-focus-inline-charts]`. If the e-mail you're looking at
doesn't have that tag, it's not from this version.

**2. Not all files were replaced, so old code is still running.**
The console banner now prints `(build: 2026-07-backlog-focus-inline-charts)`
on the very first line. If your terminal doesn't show that exact string
when you run `python main.py`, you're running stale `.py` files — replace
the **entire folder**, not individual files, and delete any `__pycache__`
folder next to the scripts before re-running.

**3. QuickChart isn't reachable from the machine that runs `main.py`.**
This is the most likely real fix needed. Read the new
**"[3/5] Chart image delivery summary"** the console prints after every
run:
- `X embedded inline (base64)` — these charts are bulletproof; they will
  show up in Outlook no matter what.
- `X via long GET URL` — if this is where ALL your charts land, this
  machine could not reach `https://quickchart.io` (corporate proxy,
  firewall, no internet) when `main.py` ran. That's independent of
  Outlook entirely — fixing internet/proxy access to quickchart.io on the
  machine that *generates* the report is what fixes this, not anything in
  Outlook's settings.

**Also worth checking directly in Outlook**, since it's a very common and
completely unrelated cause of "I see numbers but no pictures": Outlook
blocks automatically downloading external images by default in many
corporate configurations, and shows a bar like *"Content blocked. Click
here to download pictures."* at the top of the e-mail. If you see that bar
and haven't clicked it, that alone explains missing images — regardless of
anything in this script. With `EMBED_CHARTS_AS_BASE64` charts (base64
delivery, item 1 above), this doesn't apply, because there's no external
image to block in the first place — it's already inline in the HTML.

**Fastest way to isolate it yourself:** open the local file at
`CONFIG["OUTPUT_HTML"]` (path printed in `[4/5]`) directly in Chrome/Edge.
If the charts show up there, the issue is 100% on the Outlook/e-mail side,
not in this script. If they don't show up there either, it's a
chart-generation problem on this machine — check step 3 above.

## Fix: cards had no color / charts overflowed / INC backlog was wildly wrong

Three separate root causes, all fixed at the source:

**1. Backlog count was inflated (e.g. showing 942 instead of ~85).**
ServiceNow's Incident table keeps two *separate* completion-date fields:
`Resolved` (the actual fix) and `Closed` (a later, often automatic,
administrative step). `data_loader.py` was only reading the `Closed`
column, so any incident that was already resolved but not yet
auto-closed was still counted as open. Fixed with
`_completion_date()`, which now prefers `Resolved` for INC/PRB (falling
back to `Closed` if `Resolved` is empty) and prefers `Closed` for SCTASK
(falling back to `Resolved`) — matching how each ServiceNow table
actually behaves.

**2. Cards showed no color/borders at all.**
Outlook's `HTMLBody`/MAPI pipeline (used by `smtp.py` via `win32com`) is
known to drop or mangle `<style>` blocks — especially compound class
selectors like `.kpi-card.blue` — which is exactly what strips all the
card styling. Every visual element (KPI cards, stat cards, section
headers, mini-KPI badges, tables, chart cards) now carries its **full
styling as inline `style="..."` attributes** directly on the element, not
just via CSS classes. The `<style>` block and `class="..."` attributes are
still there too, as a progressive enhancement for clients that do honor
them (Outlook Mobile/Mac/Web, Gmail, Apple Mail) — but the inline styles
are what Outlook Windows desktop will actually render, and they're
self-sufficient on their own.

**3. Chart images were oversized and didn't shrink with the window.**
Outlook's Word-based engine largely ignores `max-width:100%` in CSS
unless the `<img>` tag also has an explicit `width="100%"` **HTML
attribute** — without it, the image renders at its native pixel size
(e.g. 780px or 1180px wide) regardless of the container. Every `<img>` in
the report now has both `width="100%"` as an attribute and the matching
inline CSS, so it scales down to fit its cell reliably.

## Fixes: mini-KPI badges, "Current" card, centered chart numbers, MTTR clipping

**1. Mini-KPI badges ("Opened (month)559Resolved (month)547..." running
together, no visible card).** Root cause: `mini_kpi_row` used `<span
style="border:...; padding:...; background-color:...">` pills — but
Outlook's Word engine reliably ignores box-model CSS (border, padding,
background-color) on inline elements like `<span>`. It only honors those
properties on table cells. Rewrote it as a small `<table>` of badges (same
pattern already used for KPI/stat cards), wrapping to a new row every 3
items so it doesn't force the table wider than the container. Also
reordered to: Open Backlog, Inside SLA, Outside SLA, Opened (month),
Resolved (month), MTTR (month), as requested.

**2. Added the missing "Current" card.** The Daily Evolution panels
(SCTASK/INC) now show 4 stat cards instead of 3: **Current** (live open
backlog for that type, right now) + Opened / Closed / Net Balance for the
month — so you see the snapshot and the period's flow side by side.

**3. Centered, larger numbers on every chart.**
- Donut charts (Top Analysts) and the SLA charts (now donuts instead of
  solid pies) show the grand total in bold, large text right in the
  hole — via QuickChart's `doughnutlabel` plugin.
- Horizontal bars (Aging Detail, Status) now anchor their datalabel to the
  **center** of each bar in bold white, size 15 (was: dark gray, right-aligned,
  size 11).
- The daily trend bars already centered their white datalabels; bumped the
  font size (10 &rarr; 13) for more emphasis, per your request.

One deliberate adjustment: for the donut/pie center totals specifically,
literal white text would be invisible (the hole's background is white) —
so those use a bold, high-contrast accent color (the section's blue/red)
instead of white, while everywhere else (bars) uses white exactly as
requested, since those *do* sit on a colored background.

**4. MTTR assertiveness.** Added `.clip(lower=0)` to every MTTR
calculation so a bad data entry (a `Closed` date earlier than `Opened`)
can't silently pull the average down with a negative duration.

## Replicated the 4-series trend charts from your reference dashboard

Ported the exact chart structure and colors from your JS tool's own
"Tabelas Evolução e Tendência" sections:

- **4 series per chart, not 3**: Opened (light blue) + Resolved (dark navy
  for SCTASK / green for INC) + a distinct **Closed Incomplete** (SCTASK,
  gray) or **Canceled** (INC, tan) bar + accumulated Backlog as an orange
  line on the secondary axis. Previously "Resolved" silently absorbed
  incomplete/cancelled closures — now they're their own bar, matching your
  reference tool and giving a truer picture of how tickets actually leave
  the queue.
- **Both views restored, side by side**: **"1A/1B" Monthly Evolution and
  Trend** (last 6 months, SCTASK next to INC) and **"2A/2B" Daily
  Evolution** (current month, day by day). The monthly view had been
  removed in an earlier pass under a stricter "current-month-only" reading
  of your instructions — you've since confirmed you want it back
  alongside the daily one, so both are here now, clearly separated and
  labeled.
- Colors matched to your screenshots: Opened `rgb(52,152,219)`, SCTASK
  Resolved `rgb(26,35,126)` (dark navy), INC Resolved `rgb(46,204,113)`
  (green), Closed Incomplete `rgb(149,165,166)` (gray), Canceled
  `rgb(230,180,100)` (tan), Backlog line `rgb(211,84,0)` (burnt orange).
- Each panel keeps the stat cards above the chart (Current backlog /
  Opened / Resolved / secondary bucket / Net Balance), and the chart
  itself carries a `TOTAL OPENED: X | TOTAL CLOSED: Y` title, matching your
  reference tool's own chart headers.

## Fixes: backlog curve, badge alignment, new analyst charts, colored tables

**1. Backlog curve was mathematically wrong.** It summed net flow forward
from zero at the start of the visible window, silently assuming the queue
was empty before that - never true for a live queue. Now it's **anchored
to the real, current open count** on the last period and walks *backward*
(`backlog[k] = backlog[k+1] - net[k+1]`), exactly like your reference tool
(e.g. starting at 61 in Feb, not 0). Applies to both the monthly and daily
trend charts.

**2. Mini-KPI badges now sit in a single, unbroken row** (`Open Backlog |
Inside SLA | Outside SLA | Opened (month) | Resolved (month) | MTTR
(month)`) - no more wrapping to a second line - with a stronger, clearly
visible card style (light-blue fill, blue border) so they read as
distinct badges, not plain text.

**3. Added the missing analyst charts**, English-labeled, varied colors:
- **Top Analysts (SCTASK + INC Combined)** - stacked horizontal bar per
  analyst, navy for SCTASK + orange for INC, with the combined total in
  the title - this view didn't exist before.
- **Top Analysts - SCTASK / INC (Bar View)** - horizontal-bar rankings
  where every bar gets its own color from the varied palette, alongside
  the existing donuts (kept both, since the donut's centered total is
  still useful).

**4. Data tables now have visible zebra striping.** Rows alternate white
and a light blue-gray (`#dce8f7`) instead of two near-identical off-white
shades, and headers default to a solid blue instead of pale gray.

## Fixes: backlog axis scale, stacked bars, title prefixes, card alignment

**1. Backlog axis no longer forced to start at 0.** With a large left-axis
range (bar quantities up to 160) and the backlog line hovering in a much
narrower band (e.g. 55-70), a 0-based right axis flattened the line into
an almost-straight strip. The backlog axis now auto-zooms to the data's
own range with a small buffer, so its actual shape is visible.

**2. Bars are now grouped/stacked, not three side-by-side bars.** Each
period shows two bars: **Opened** on its own, and a single **stacked
"Closed" bar** combining the Resolved segment and the secondary segment
(Closed Incomplete for SCTASK, Canceled for INC) - applies identically to
both SCTASK and INC charts.

**3. Removed all "1A./1B./2A./2B./3A./3B." style prefixes.** Every chart
and section title is now plain text (e.g. "Top Analysts - SCTASK" instead
of "1A. Top Analysts - SCTASK").

**4. Fixed card alignment/padding on narrower screens.** The mobile
breakpoint previously tried to force table cells into `inline-block;
width:48%` for a 2-per-row layout - a pattern that renders inconsistently
across clients (uneven wrapping, cards landing alone on their own row,
exactly what showed up in your screenshot). Replaced it with the same
reliable full-width, single-column stacking already used elsewhere in the
report, and increased the padding between cards so they're no longer
touching edge-to-edge.

## Configuration now lives in `.env` (not hardcoded)

**Setup:**
```bash
cp .env.example .env
# edit .env with your real paths / URLs / credentials / recipients
pip install -r requirements.txt
```

`config.py` calls `load_dotenv()` automatically - nothing else needs to
change. If `.env` is missing entirely, everything falls back to sensible
defaults (paths under `dates/`, matching the real ServiceNow table names:
`incident.xlsx`, `sc_task.xlsx`, `problem_task.xlsx`), so the script still
runs out of the box for testing.

A note on naming: you asked to "use pyenv" for this - the library that
actually does it is **python-dotenv** (`pip install python-dotenv`,
`from dotenv import load_dotenv`). `pyenv` is a different, unrelated tool
that manages which *Python version* is installed on your machine, not
environment variables/config. I used python-dotenv since that's what
actually reads `.env` files - let me know if you meant something else.

**Group e-mail recipients:** `EMAIL_TO` and `EMAIL_CC` in `.env` accept a
comma-separated list (`EMAIL_TO=alice@company.com,bob@company.com,it-leads@company.com`).
`config.py` splits that list and rejoins it with semicolons
(`CONFIG["EMAIL_TO"]`), which is the separator Outlook expects for
multiple recipients in a single `To`/`Cc` field - `smtp.py` didn't need
any changes. `CONFIG["EMAIL_TO_LIST"]`/`EMAIL_CC_LIST"]` are also
available as plain Python lists if you ever need them individually.

Every other setting that used to be hardcoded in `config.py` (SLA
targets, aging thresholds, analysis windows, chart delivery options) is
now also overridable from `.env` - see `.env.example` for the full list.
Nothing *requires* changing them; the defaults match what was hardcoded
before.

## Automated download - `download_data.py` (replaces Selenium)

Selenium launches an entire browser (Chrome/Edge), waits for the page and
its JavaScript to fully render, then simulates clicking through the UI to
trigger a download - typically 10-30+ seconds per file, and fragile
(breaks when ServiceNow tweaks its UI). `download_data.py` instead makes
a **direct authenticated HTTP request** to the same export URL your
browser would hit, and saves the raw response - no browser, no rendering,
no clicking. 1-3 seconds per file in the common case.

**Setup:**
1. In `.env`, paste your 3 existing export URLs (the ones you currently
   open via Selenium) into `INC_EXPORT_URL` / `SCTASK_EXPORT_URL` /
   `PRB_EXPORT_URL`.
2. Set `SERVICENOW_USER` / `SERVICENOW_PASSWORD` to a service account.
3. Run `python download_data.py` or double-click `download_data.bat`.
   `run_all.bat` chains download → build report → send e-mail in one go
   (good for Task Scheduler).

Files land exactly where `config.py`'s `INC_PATH`/`SCTASK_PATH`/`PRB_PATH`
expect them (same `.env` values drive both) - `download_data.py` imports
`CONFIG` directly rather than recalculating paths itself, so there's no
way for the two to drift out of sync.

### Why this might not work out of the box

This is the one part I can't fully guarantee without seeing your
ServiceNow instance's auth setup, so please read this before assuming
it's broken:

- **If your instance allows Basic Authentication** for a service account
  (common in many corporate setups specifically to support scripted
  integrations like this one) - this will just work, and will be *much*
  faster than Selenium.
- **If your instance is SSO/SAML-only** (very common in larger
  enterprises), a plain username/password HTTP request can't complete the
  login flow - ServiceNow will redirect to your identity provider instead
  of returning the file, and `download_data.py` will detect this (it
  checks for an HTML/login-page response instead of a spreadsheet) and
  print a clear warning rather than silently saving a broken file.
  Two ways forward if that happens:
  1. Ask your ServiceNow admin to enable Basic Auth for one dedicated
     integration/service account (this is a normal, common request -
     it doesn't affect SSO for regular users).
  2. Use the `SERVICENOW_SESSION_COOKIE` fallback in `.env`: log in
     normally in a browser once, copy the session cookie from DevTools
     (Application/Storage → Cookies), and paste it in. This works until
     that browser session expires, so it needs periodic refreshing -
     not ideal for a fully unattended daily run, but still far faster
     than Selenium for the sessions where it's valid, and a fine bridge
     while you get Basic Auth enabled.
- **Longer-term, more robust alternative**: migrate from the legacy
  `.do?XLS` list-export links to ServiceNow's official **Table API**
  (`/api/now/table/<table>?sysparm_query=...`), which returns JSON and is
  the supported, documented integration path (Basic Auth or OAuth,
  stable across ServiceNow upgrades, doesn't depend on the browser-era
  export UI staying unchanged). I didn't build this out fully since it
  needs your exact field/filter mapping to replicate your current 3
  exports precisely - happy to build it if you share the field list and
  filters your 3 saved exports use.

## Fixes: legend alignment + new INC columns (On Hold Reason, Linked Problem)

**1. Donut chart legends moved to the bottom.** The "Top Analysts" donuts
used a right-side legend, which is what caused the misalignment/cut-off
names you saw (long analyst names getting truncated, chart+legend not
lining up with the rest of the card). Every donut now uses the same
bottom-positioned, wrapping legend the SLA charts already used correctly
- consistent across all donut/pie charts in the report.

**2. Two new columns on the Critical INCs table.**
- **On Hold Reason**: shown for every INC row, populated only when
  `State` is "On Hold" (dash everywhere else, so the column doesn't
  imply a reason that doesn't apply).
- **Linked Problem**: shown for every INC row, populated whenever that
  incident references a Problem record (dash if none).

Both fields (`On hold reason` and `Problem`) were already present in your
ServiceNow `incident.xlsx` export's column list from the very start of
this project - `data_loader.py` just wasn't extracting them yet. Fixed in
`load_inc()`, and surfaced only in the INC critical table (SCTASK's table
is unaffected - it has no such columns, and none were added there).
Verified with an isolated test using synthetic rows in both states (On
Hold with a reason, and a row with a linked Problem) - both populate
correctly, and blank out to "—" everywhere else.

Note: your current `dates/incident.xlsx` sample data doesn't have any
rows with a populated `Problem` field (it's empty in every row), so the
"Linked Problem" column will show "—" throughout in the example
export until you point the report at data that actually has Problem
links populated - that's a property of the sample data, not a code issue.

## Fixes: chart colors + new "big card" style for the Overview KPIs

**1. Top Analysts (Combined) stacked bar recolored.** The dark
navy/orange pairing looked muddy - switched to the same bright blue/red
(`rgb(52,152,219)` / `rgb(231,76,60)`) used everywhere else in the report
for SCTASK/INC, so it's both more vivid and visually consistent with the
rest of the dashboard.

**2. "Canceled" bar (INC trend charts) recolored.** The tan/beige color
blended into the background and didn't stand out. Replaced with a vivid
magenta/pink (`rgb(231,30,119)`) that reads clearly against the blue
Opened bars, green Resolved bars, and orange Backlog line.

**3. Overview KPI cards restyled to the reference "big card" look.**
Total Backlog / SCTASK Open / INC Open / PRB Open / MTTR now render as a
neutral light-gray icon+label header strip on top of a color-tinted body
(e.g. light blue body with a navy value for the blue cards, light red
body with a red value for the red cards) - all wrapped in a single
color-matched border, exactly like the reference screenshot. This applies
**only** to the 5 main Overview cards, as requested - the smaller stat
cards elsewhere (critical panel stats, mini-KPI badges, trend-panel
stats) intentionally keep their existing simpler single-tone style.

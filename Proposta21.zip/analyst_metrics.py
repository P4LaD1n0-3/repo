# -*- coding: utf-8 -*-
"""
Analyst Performance Comparison - Metrics
===========================================
Everything needed to answer "who closed how many tickets, today vs
yesterday / this week vs last week / this month vs the same point last
month" - across SCTASK (REQ), UAM, INC and PRB combined, grouped by the
"Assigned to" analyst.

Design choices worth knowing about:
- A ticket "counts" for an analyst on the day/week/month its Closed date
  falls in - NOT the day it was opened. This report is about closure
  throughput (who's actually getting tickets done), not intake.
- Week/month comparisons use a fair "same elapsed period" basis rather
  than comparing a partial current period to a full previous one: if
  today is Wednesday, "this week" is Mon-Wed and "last week" is also
  Mon-Wed of the prior week (not the full Mon-Sun) - otherwise a
  same-week comparison always looks artificially low. Same idea for
  months: "this month" is the 1st-through-today, compared against the
  1st-through-the-same-day-number of the previous month.
"""
import pandas as pd

UNKNOWN_ANALYST = "(Unassigned)"


def build_analyst_universe(sctask, uam, inc, prb):
    """Combines all 4 ticket types into one lightweight dataframe with
    just what's needed here: Assigned to / Opened / Closed / TicketType /
    IsOpen. Unassigned tickets are kept (grouped under "(Unassigned)")
    rather than silently dropped, since an unusually large/growing
    unassigned pile is itself useful signal."""
    frames = []
    for df, ttype in ((sctask, "REQ"), (uam, "UAM"), (inc, "INC"), (prb, "PRB")):
        if df is None or df.empty:
            continue
        d = pd.DataFrame({
            "Assigned to": df["Assigned to"].astype(str).replace(
                {"": UNKNOWN_ANALYST, "nan": UNKNOWN_ANALYST, "\u2014": UNKNOWN_ANALYST}),
            "Opened": df["Opened"],
            "Closed": df["Closed"],
            "TicketType": ttype,
        })
        frames.append(d)
    if not frames:
        return pd.DataFrame(columns=["Assigned to", "Opened", "Closed", "TicketType", "IsOpen"])
    combined = pd.concat(frames, ignore_index=True)
    combined["IsOpen"] = combined["Closed"].isna()
    return combined


def _day_bounds(day):
    """[start, end) for a single calendar day."""
    start = pd.Timestamp(day.date())
    return start, start + pd.Timedelta(days=1)


def _week_bounds_elapsed(ref, weeks_back=0):
    """Monday of the target week through the same weekday as `ref`,
    inclusive - i.e. the "elapsed" portion of that week, so a Wednesday
    run compares Mon-Wed this week against Mon-Wed last week, not a full
    week against a partial one."""
    monday_this_week = ref.normalize() - pd.Timedelta(days=ref.weekday())
    target_monday = monday_this_week - pd.Timedelta(weeks=weeks_back)
    start = target_monday
    end = target_monday + pd.Timedelta(days=ref.weekday() + 1)
    return start, end


def _month_bounds_elapsed(ref, months_back=0):
    """1st of the target month through the same day-of-month as `ref`
    (capped at that month's actual last day) - the "elapsed" portion, for
    a fair month-to-date vs month-to-date comparison."""
    year, month = ref.year, ref.month
    for _ in range(months_back):
        month -= 1
        if month == 0:
            month = 12
            year -= 1
    start = pd.Timestamp(year=year, month=month, day=1)
    days_in_month = (start + pd.offsets.MonthEnd(0)).day
    day_num = min(ref.day, days_in_month)
    end = pd.Timestamp(year=year, month=month, day=day_num) + pd.Timedelta(days=1)
    return start, end


def closed_count_by_analyst(df, start, end):
    """Series indexed by analyst: count of tickets whose Closed date falls
    in [start, end)."""
    mask = df["Closed"].notna() & (df["Closed"] >= start) & (df["Closed"] < end)
    return df.loc[mask].groupby("Assigned to").size()


def open_backlog_by_analyst(df):
    """Series indexed by analyst: count of currently-open tickets assigned
    to them (used for the "sitting on assigned work" attention flag)."""
    return df.loc[df["IsOpen"]].groupby("Assigned to").size()


def comparison_table(df, cur_range, prev_range, cur_label, prev_label):
    """Analyst-level comparison table for one pair of periods.
    Returns a DataFrame: Analyst | <cur_label> | <prev_label> | Delta | DeltaPct
    sorted by <cur_label> descending. DeltaPct is None when prev is 0 and
    cur is 0 (no change to speak of) or shown as a large number when prev
    is 0 and cur > 0 (a fresh start, not a literal "infinite % increase").
    """
    cur = closed_count_by_analyst(df, *cur_range)
    prev = closed_count_by_analyst(df, *prev_range)
    analysts = sorted(set(cur.index) | set(prev.index))
    rows = []
    for a in analysts:
        c = int(cur.get(a, 0))
        p = int(prev.get(a, 0))
        delta = c - p
        if p == 0:
            delta_pct = None if c == 0 else float("inf")
        else:
            delta_pct = (delta / p) * 100
        rows.append({"Analyst": a, cur_label: c, prev_label: p, "Delta": delta, "DeltaPct": delta_pct})
    out = pd.DataFrame(rows)
    if out.empty:
        out = pd.DataFrame(columns=["Analyst", cur_label, prev_label, "Delta", "DeltaPct"])
    else:
        out = out.sort_values(cur_label, ascending=False).reset_index(drop=True)
    return out


def build_all_comparisons(df, ref):
    """Builds the 3 comparison tables (daily/weekly/monthly) plus the
    team-wide totals used in the Overview KPI row. `ref` is the reference
    "now" timestamp (today = ref.date())."""
    today_range = _day_bounds(ref)
    yesterday_range = _day_bounds(ref - pd.Timedelta(days=1))
    daily = comparison_table(df, today_range, yesterday_range, "Today", "Yesterday")

    this_week_range = _week_bounds_elapsed(ref, weeks_back=0)
    last_week_range = _week_bounds_elapsed(ref, weeks_back=1)
    weekly = comparison_table(df, this_week_range, last_week_range, "This Week", "Last Week")

    this_month_range = _month_bounds_elapsed(ref, months_back=0)
    last_month_range = _month_bounds_elapsed(ref, months_back=1)
    monthly = comparison_table(df, this_month_range, last_month_range, "This Month (MTD)", "Last Month (same days)")

    totals = {
        "today": int(daily["Today"].sum()) if not daily.empty else 0,
        "yesterday": int(daily["Yesterday"].sum()) if not daily.empty else 0,
        "this_week": int(weekly["This Week"].sum()) if not weekly.empty else 0,
        "last_week": int(weekly["Last Week"].sum()) if not weekly.empty else 0,
        "this_month": int(monthly["This Month (MTD)"].sum()) if not monthly.empty else 0,
        "last_month": int(monthly["Last Month (same days)"].sum()) if not monthly.empty else 0,
        "active_analysts_today": int((daily["Today"] > 0).sum()) if not daily.empty else 0,
    }
    ranges = {
        "today": today_range, "yesterday": yesterday_range,
        "this_week": this_week_range, "last_week": last_week_range,
        "this_month": this_month_range, "last_month": last_month_range,
    }
    return daily, weekly, monthly, totals, ranges


def detect_attention_flags(daily, weekly, open_backlog, config):
    """Factual, non-judgmental flags for analysts whose closure pattern
    stands out from the team - the report presents the numbers, a human
    reader decides what (if anything) they mean. Three independent
    triggers, an analyst can carry more than one:
      1. Zero closures today despite currently having open assigned work.
      2. This-week closures well below the team's own average this week
         (threshold configurable, default 50%), again only flagged if
         they have open assigned work (someone genuinely idle with an
         empty queue isn't a bottleneck - that's a workload/assignment
         question, not a performance one).
      3. Sharp week-over-week drop (this week under half of last week),
         only when last week's volume was itself meaningful (>=3), to
         avoid flagging noise on small numbers.
    """
    threshold_pct = config.get("ANALYST_ATTENTION_THRESHOLD_PCT", 0.5)
    drop_ratio = config.get("ANALYST_ATTENTION_DROP_RATIO", 0.5)
    min_baseline = config.get("ANALYST_ATTENTION_MIN_BASELINE", 3)

    week_map = {row["Analyst"]: row for _, row in weekly.iterrows()}
    active_week = weekly[weekly["This Week"] > 0]["This Week"] if not weekly.empty else pd.Series(dtype=float)
    team_avg_week = float(active_week.mean()) if len(active_week) else 0.0

    today_map = {row["Analyst"]: int(row["Today"]) for _, row in daily.iterrows()} if not daily.empty else {}

    all_analysts = sorted(set(week_map.keys()) | set(open_backlog.index))
    flags = []
    for analyst in all_analysts:
        if analyst == "(Unassigned)":
            continue
        backlog = int(open_backlog.get(analyst, 0))
        if backlog == 0:
            continue  # nothing currently assigned to them - not a throughput question
        reasons = []
        today_count = today_map.get(analyst, 0)
        if today_count == 0:
            reasons.append(f"No tickets closed today, {backlog} currently assigned and open")

        wk = week_map.get(analyst)
        this_wk = int(wk["This Week"]) if wk is not None else 0
        last_wk = int(wk["Last Week"]) if wk is not None else 0
        if team_avg_week > 0 and this_wk < team_avg_week * threshold_pct:
            reasons.append(f"This week: {this_wk} closed vs team average {team_avg_week:.1f}")
        if last_wk >= min_baseline and this_wk < last_wk * drop_ratio:
            reasons.append(f"Sharp week-over-week drop: {last_wk} \u2192 {this_wk}")

        if reasons:
            flags.append({"Analyst": analyst, "OpenBacklog": backlog, "Today": today_count,
                           "ThisWeek": this_wk, "LastWeek": last_wk, "Reasons": reasons})

    flags.sort(key=lambda f: (len(f["Reasons"]), f["OpenBacklog"]), reverse=True)
    return flags, team_avg_week


def top_performers(daily, weekly, monthly, top_n=5):
    """Simple leaderboards - the positive counterpart to the attention
    flags, so the report isn't one-sided."""
    def _top(df, col):
        if df.empty:
            return [], []
        ranked = df[df[col] > 0].sort_values(col, ascending=False).head(top_n)
        return list(ranked["Analyst"]), list(ranked[col])

    return {
        "today": _top(daily, "Today"),
        "week": _top(weekly, "This Week"),
        "month": _top(monthly, "This Month (MTD)"),
    }

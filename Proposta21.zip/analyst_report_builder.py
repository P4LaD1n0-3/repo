# -*- coding: utf-8 -*-
"""
Analyst Performance Comparison - Report Builder
====================================================
Builds the full HTML for the second e-mail: today vs yesterday, this week
vs last week, this month (MTD) vs the same elapsed period last month -
all broken down per analyst, plus a "Needs Attention" panel for anyone
whose closure pattern stands out from the team, and a "Top Performers"
leaderboard as the positive counterpart.

Reuses report_builder.py's visual language (CSS, card styles, table
styles, color palette) so this reads as a companion to the main
dashboard, not a different tool.
"""
from datetime import datetime

import pandas as pd

import charts as c
import analyst_metrics as am
import report_builder as rb
from config import Colors

FONT_STACK = rb.FONT_STACK
CSS = rb.CSS

CARD_STYLE = {
    "blue": {"border": "#0B1E40", "body_bg": Colors.PRIMARY_LIGHT, "value_color": "#0B1E40"},
    "green": {"border": "#27AE60", "body_bg": Colors.SUCCESS_LIGHT, "value_color": "#27AE60"},
    "red": {"border": "#C0392B", "body_bg": Colors.DANGER_LIGHT, "value_color": "#C0392B"},
    "orange": {"border": "#E67E22", "body_bg": Colors.ORANGE_LIGHT, "value_color": "#E67E22"},
    "purple": {"border": "#6A1B9A", "body_bg": Colors.PURPLE_LIGHT, "value_color": "#6A1B9A"},
}

SECTION_COLORS = {
    1: ("Daily Comparison \u2014 Today x Yesterday", "#1976D2", "\U0001F4C5"),
    2: ("Weekly Comparison \u2014 This Week x Last Week", "#283593", "\U0001F4C6"),
    3: ("Monthly Comparison \u2014 This Month x Last Month", "#0277BD", "\U0001F5D3\ufe0f"),
    4: ("Needs Attention", "#C0392B", "\u26A0\ufe0f"),
    5: ("Top Performers", "#27AE60", "\U0001F3C6"),
}


def _delta_html(delta, delta_pct):
    if delta > 0:
        color = "#27AE60"
        arrow = "\u25B2"
    elif delta < 0:
        color = "#C0392B"
        arrow = "\u25BC"
    else:
        color = "#7f8c8d"
        arrow = "\u2013"
    if delta_pct is None:
        pct_txt = ""
    elif delta_pct == float("inf"):
        pct_txt = " (new)"
    else:
        pct_txt = f" ({delta_pct:+.0f}%)"
    return f'<span style="color:{color}; font-weight:bold;">{arrow} {delta:+d}{pct_txt}</span>'


def kpi_card(color_class, icon, title, value, subtitle):
    style = CARD_STYLE.get(color_class, CARD_STYLE["blue"])
    return f"""<table width="100%" height="128" cellpadding="0" cellspacing="0" border="0"
               style="border:1.5px solid {style['border']}; border-radius:6px; border-collapse:separate; height:128px;">
        <tr><td align="left" valign="middle" height="36" style="height:36px; background-color:{Colors.GRAY_LIGHT}; padding:0 12px; border-bottom:1px solid {style['border']}; border-radius:5px 5px 0 0; font-family:{FONT_STACK};">
            <span style="color:#37474F; font-size:11px; text-transform:uppercase; font-weight:bold; letter-spacing:0.3px; font-family:{FONT_STACK};">{icon}&nbsp; {title}</span>
        </td></tr>
        <tr><td align="center" valign="middle" height="92" style="height:92px; background-color:{style['body_bg']}; padding:8px 10px; border-radius:0 0 5px 5px; font-family:{FONT_STACK};">
            <div style="color:{style['value_color']}; font-size:28px; font-weight:bold; margin-bottom:6px; font-family:{FONT_STACK}; line-height:1.1;">{value}</div>
            <div style="font-size:11px; color:#5a6b78; font-family:{FONT_STACK}; line-height:1.3;">{subtitle}</div>
        </td></tr>
    </table>"""


def kpi_row(cards):
    n = len(cards)
    spacer = (n - 1) * 2
    w = (100 - spacer) / n
    cells = []
    for i, (color_class, icon, title, value, subtitle) in enumerate(cards):
        cells.append(f'<td width="{w:.1f}%" class="kpi-responsive-td" style="padding:0 6px 12px 6px;">'
                      f'{kpi_card(color_class, icon, title, value, subtitle)}</td>')
        if i < n - 1:
            cells.append('<td width="2%" class="spacer-hide-mobile kpi-spacer">&nbsp;</td>')
    return f'<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:20px;"><tr>{"".join(cells)}</tr></table>'


def section_header(number, text=None, color=None, icon=None):
    if text is None:
        text, color, icon = SECTION_COLORS[number][0], SECTION_COLORS[number][1], SECTION_COLORS[number][2]
    badge = (f'<td width="42" valign="middle" style="padding:11px 0 11px 14px;">'
              f'<table cellpadding="0" cellspacing="0" border="0"><tr>'
              f'<td width="26" height="26" align="center" valign="middle" '
              f'style="width:26px; height:26px; min-width:26px; background-color:#ffffff; border-radius:13px; '
              f'color:{color}; font-size:13px; font-weight:bold; font-family:{FONT_STACK};">{number}</td>'
              f'</tr></table></td>')
    return (f'<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-bottom:15px;">'
            f'<tr><td style="background-color:{color}; border-radius:6px;">'
            f'<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>{badge}'
            f'<td valign="middle" style="color:#ffffff; padding:11px 16px 11px 8px; '
            f'font-size:14px; font-weight:bold; text-transform:uppercase; letter-spacing:0.5px; '
            f'font-family:{FONT_STACK};">{icon}&nbsp; {text}</td>'
            f'</tr></table></td></tr></table>')


def comparison_section(number, df, cur_label, prev_label, color_a, color_b, top_n=15):
    """Chart + full data table for one comparison period."""
    _, title, color, icon = number, SECTION_COLORS[number][0], SECTION_COLORS[number][1], SECTION_COLORS[number][2]
    html = section_header(number)
    if df.empty:
        return html + rb.data_table(pd.DataFrame(), empty_message="No closed tickets in either period.")

    chart_df = df.head(top_n)
    img = c.grouped_horizontal_bar(
        chart_df["Analyst"], chart_df[cur_label], chart_df[prev_label], cur_label, prev_label,
        color_a, color_b, w=1100, h=max(320, 32 * len(chart_df) + 90))
    html += (f'<img class="chart-img" src="{img}" width="100%" '
             f'style="max-width:100%; width:100%; height:auto; display:block; border:0; margin-bottom:16px;">')

    render = df.copy()
    render["Change"] = [_delta_html(d, p) for d, p in zip(render["Delta"], render["DeltaPct"])]
    render = render[["Analyst", cur_label, prev_label, "Change"]]
    html += rb.data_table(render)
    return html


def attention_section(flags, team_avg_week):
    html = section_header(4)
    html += (f'<div style="font-size:11px; color:#999999; margin-bottom:12px; font-family:{FONT_STACK};">'
              f'Team average this week: <b>{team_avg_week:.1f}</b> closed tickets/analyst. '
              f'Flags below are purely descriptive - they surface where the numbers stand out, not a verdict. '
              f'Only analysts with currently assigned open work are considered.</div>')
    if not flags:
        html += rb.data_table(pd.DataFrame(), empty_message="No analysts currently flagged - closure activity looks even across the team.")
        return html

    rows = ""
    for i, f in enumerate(flags):
        row_bg = "#fdecea" if i % 2 == 0 else "#ffffff"
        reasons_html = "<br>".join(f"\u2022 {reason}" for reason in f["Reasons"])
        rows += (f"<tr style='background-color:{row_bg};'>"
                 f"<td style='padding:8px; border:1px solid #f0c8c4; text-align:left; font-weight:bold;'>{f['Analyst']}</td>"
                 f"<td style='padding:8px; border:1px solid #f0c8c4; text-align:center;'>{f['OpenBacklog']}</td>"
                 f"<td style='padding:8px; border:1px solid #f0c8c4; text-align:center;'>{f['Today']}</td>"
                 f"<td style='padding:8px; border:1px solid #f0c8c4; text-align:center;'>{f['ThisWeek']}</td>"
                 f"<td style='padding:8px; border:1px solid #f0c8c4; text-align:center;'>{f['LastWeek']}</td>"
                 f"<td style='padding:8px; border:1px solid #f0c8c4; text-align:left; font-size:11px; color:#7a3b36;'>{reasons_html}</td></tr>")
    html += (f"<table class='data-table' width='100%' cellpadding='0' cellspacing='0' border='0' "
             f"style='border-collapse:collapse; font-size:12px; font-family:{FONT_STACK};'><thead><tr>"
             f"<th style='background-color:#C0392B; color:#fff; padding:8px; border:1px solid #f0c8c4; text-align:left;'>Analyst</th>"
             f"<th style='background-color:#C0392B; color:#fff; padding:8px; border:1px solid #f0c8c4;'>Open Backlog</th>"
             f"<th style='background-color:#C0392B; color:#fff; padding:8px; border:1px solid #f0c8c4;'>Today</th>"
             f"<th style='background-color:#C0392B; color:#fff; padding:8px; border:1px solid #f0c8c4;'>This Week</th>"
             f"<th style='background-color:#C0392B; color:#fff; padding:8px; border:1px solid #f0c8c4;'>Last Week</th>"
             f"<th style='background-color:#C0392B; color:#fff; padding:8px; border:1px solid #f0c8c4; text-align:left;'>Why it's flagged</th>"
             f"</tr></thead><tbody>{rows}</tbody></table>")
    return html


def _leaderboard_card(title, names, values, color):
    if not names:
        return (f'<div style="border:1px solid #eeeeee; border-radius:6px; padding:14px; background-color:#ffffff; height:100%;">'
                f'<div style="font-size:12px; font-weight:bold; color:#585858; margin-bottom:10px; font-family:{FONT_STACK};">{title}</div>'
                f'<div style="font-size:12px; color:#999999; font-family:{FONT_STACK};">No closures in this period.</div></div>')
    rows = ""
    medals = ["\U0001F947", "\U0001F948", "\U0001F949"]
    for i, (name, val) in enumerate(zip(names, values)):
        medal = medals[i] if i < 3 else f"{i+1}."
        rows += (f'<tr><td style="padding:6px 4px; font-size:12px; color:#333; font-family:{FONT_STACK};">{medal} {name}</td>'
                  f'<td style="padding:6px 4px; font-size:13px; font-weight:bold; color:{color}; text-align:right; font-family:{FONT_STACK};">{val}</td></tr>')
    return (f'<div style="border:1px solid #eeeeee; border-top:3px solid {color}; border-radius:6px; padding:14px; background-color:#ffffff; height:100%;">'
            f'<div style="font-size:12px; font-weight:bold; color:#585858; margin-bottom:8px; font-family:{FONT_STACK};">{title}</div>'
            f'<table width="100%" cellpadding="0" cellspacing="0" border="0">{rows}</table></div>')


def top_performers_section(tp):
    html = section_header(5)
    today_names, today_vals = tp["today"]
    week_names, week_vals = tp["week"]
    month_names, month_vals = tp["month"]
    cards = [
        _leaderboard_card("Top Closers \u2014 Today", today_names, today_vals, "#1976D2"),
        _leaderboard_card("Top Closers \u2014 This Week", week_names, week_vals, "#283593"),
        _leaderboard_card("Top Closers \u2014 This Month", month_names, month_vals, "#27AE60"),
    ]
    return html + rb.grid_row(cards)


def build_analyst_report(sctask, uam, inc, prb, config, ref):
    universe = am.build_analyst_universe(sctask, uam, inc, prb)
    daily, weekly, monthly, totals, ranges = am.build_all_comparisons(universe, ref)
    open_backlog = am.open_backlog_by_analyst(universe)
    flags, team_avg_week = am.detect_attention_flags(daily, weekly, open_backlog, config)
    tp = am.top_performers(daily, weekly, monthly)

    def _delta_pct(cur, prev):
        if prev == 0:
            return "new" if cur > 0 else "0%"
        return f"{(cur - prev) / prev * 100:+.0f}%"

    overview = kpi_row([
        ("blue", "\U0001F4C5", "Closed Today", totals["today"],
         f"vs {totals['yesterday']} yesterday ({_delta_pct(totals['today'], totals['yesterday'])})"),
        ("blue", "\U0001F465", "Active Analysts Today", totals["active_analysts_today"], "closed at least 1 ticket"),
        ("purple", "\U0001F4C6", "This Week", totals["this_week"],
         f"vs {totals['last_week']} last week ({_delta_pct(totals['this_week'], totals['last_week'])})"),
        ("orange", "\U0001F5D3\ufe0f", "This Month (MTD)", totals["this_month"],
         f"vs {totals['last_month']} same period ({_delta_pct(totals['this_month'], totals['last_month'])})"),
        ("red", "\u26A0\ufe0f", "Flagged Analysts", len(flags), "see Needs Attention below"),
    ])

    daily_html = comparison_section(1, daily, "Today", "Yesterday", "#1976D2", "#90CAF9")
    weekly_html = comparison_section(2, weekly, "This Week", "Last Week", "#283593", "#9FA8DA")
    monthly_html = comparison_section(3, monthly, "This Month (MTD)", "Last Month (same days)", "#0277BD", "#81D4FA")
    attn_html = attention_section(flags, team_avg_week)
    top_html = top_performers_section(tp)

    divider = ('<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
               '<td style="border-top:2px solid #e8ecf0; font-size:1px; line-height:1px;">&nbsp;</td></tr></table>'
               '<div style="height:20px; line-height:20px;">&nbsp;</div>')

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analyst Performance Comparison</title>
    <style>{CSS}</style>
</head>
<body style="font-family:{FONT_STACK}; background-color:#f4f4f4; margin:0; padding:20px 10px;">
    <table class="email-container" width="100%" cellpadding="0" cellspacing="0" border="0" align="center"
           style="max-width:1300px; margin:0 auto; background-color:#ffffff; border-radius:8px;">
        <tr><td>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
            <tr><td align="center" style="background-color:#0B1E40; color:#ffffff; padding:18px 20px; border-radius:8px 8px 0 0; font-family:{FONT_STACK};">
                <h2 style="margin:0 0 6px 0; font-size:22px; letter-spacing:0.3px; color:#ffffff; font-family:{FONT_STACK};">Analyst Performance Comparison</h2>
                <p style="margin:0; color:#9BBAD2; font-size:13px; font-family:{FONT_STACK};">
                   Reference: {ref.strftime('%d/%m/%Y %H:%M')} &nbsp;|&nbsp; Ticket closures across REQ + UAM + INC + PRB, by analyst</p>
            </td></tr>
        </table>
        <div class="content" style="padding:22px;">

            {overview}

            {daily_html}
            {divider}
            {weekly_html}
            {divider}
            {monthly_html}
            {divider}
            {attn_html}
            {divider}
            {top_html}

        </div>
        <table width="100%" cellpadding="0" cellspacing="0" border="0" class="footer">
            <tr><td align="center" style="padding:15px; font-size:12px; color:#888888; background-color:#f4f4f4; border-top:1px solid #dddddd; border-radius:0 0 8px 8px; font-family:{FONT_STACK};">
                Automated report generated by the IT Metrics Dashboard script &middot; {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
            </td></tr>
        </table>
        </td></tr>
    </table>
</body>
</html>"""

    kpis = {"totals": totals, "flag_count": len(flags)}
    return html, kpis

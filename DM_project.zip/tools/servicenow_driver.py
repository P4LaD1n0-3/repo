import re
import asyncio
import logging
from typing import List, Dict, Any, Optional, Union
from playwright.async_api import async_playwright, BrowserContext, Page, FrameLocator
from tools.base_automation import BaseAutomation, SelectorManager
from tools.okta_auth import OktaAuthManager

logger = logging.getLogger("ServiceNowDriver")

class ServiceNowDriver(BaseAutomation):
    """
    Driver especializado para automações no ServiceNow.
    Herda todos os métodos utilitários de BaseAutomation e adiciona
    regras e métodos específicos para ServiceNow (Slushbuckets, Reference Fields, iFrames, SCTASKs e Okta SSO).
    """

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)

    async def select_servicenow_slushbucket(
        self, 
        scope: Union[Page, FrameLocator], 
        values: List[str], 
        available_key: str = "slushbucket_available", 
        add_btn_key: str = "slushbucket_add_btn"
    ) -> bool:
        """
        Método especializado para selecionar múltiplas opções no menu Slushbucket do ServiceNow.
        (Componente visual do ServiceNow com 2 caixas de seleção e botões de adicionar/remover).
        :param scope: Escopo (Page ou FrameLocator gsft_main).
        :param values: Lista de valores ou rótulos dos itens a serem selecionados.
        :param available_key: Chave do dicionário de paths para o <select> de itens disponíveis.
        :param add_btn_key: Chave do dicionário de paths para o botão de adicionar (> / Add).
        """
        logger.info(f"📋 [ServiceNow] Selecionando itens no Slushbucket: {values}")
        try:
            available_select_key = self.get_selector(available_key)
            # Seleciona as opções desejadas no menu da esquerda
            await scope.locator(available_select_key).select_option(values=values)
            await asyncio.sleep(0.5)
            # Clica no botão de adicionar (Add / >)
            await self.click_element(scope, add_btn_key)
            logger.info("✅ Itens adicionados no Slushbucket com sucesso.")
            return True
        except Exception as e:
            logger.error(f"❌ Erro ao manipular o Slushbucket do ServiceNow: {e}")
            raise e

    async def fill_reference_field(
        self, 
        scope: Union[Page, FrameLocator], 
        selector_key: str, 
        search_text: str, 
        confirm_with_enter: bool = True
    ):
        """
        Preenche um campo de referência/lupa do ServiceNow e aguarda auto-complete ou confirma com Enter.
        :param scope: Escopo (Page ou FrameLocator gsft_main).
        :param selector_key: Chave do dicionário de paths referente ao campo input.
        :param search_text: Texto para buscar na referência.
        :param confirm_with_enter: Se True, envia a tecla Enter após digitar.
        """
        logger.info(f"🔎 [ServiceNow] Preenchendo campo de referência [{selector_key}] com '{search_text}'...")
        selector = self.get_selector(selector_key)
        locator = scope.locator(selector).first
        await locator.click()
        await locator.fill(search_text)
        await asyncio.sleep(0.5)
        if confirm_with_enter:
            await locator.press("Enter")
            await asyncio.sleep(1)

    async def click_form_button(
        self, 
        scope: Union[Page, FrameLocator], 
        button_key: str = "form_save_button"
    ):
        """Clica em um botão de formulário do ServiceNow (como Salvar, Atualizar, Inserir)."""
        logger.info(f"🔘 [ServiceNow] Clicando no botão de formulário [{button_key}]...")
        await self.click_element(scope, button_key)

    async def process_servicenow_page(self, page: Page, url: str) -> Dict[str, Any]:
        """
        Processa uma página individual do ServiceNow:
        1. Acessa a URL.
        2. Identifica e altera o contexto para o iFrame 'gsft_main' (com fallback seguro).
        3. Extrai códigos e textos contendo 'SCTASK'.
        """
        logger.info(f"📄 [ServiceNowDriver] Processando URL: {url}")

        result: Dict[str, Any] = {
            "url": url,
            "sctasks": [],
            "status": "success",
            "error": None
        }

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            # Utiliza o método herdado de BaseAutomation com suporte ao dicionario de paths
            target_scope = await self.get_iframe_scope(
                page=page, 
                iframe_key_or_selector="gsft_main", 
                timeout=20000
            )

            await page.wait_for_timeout(3000)

            found_texts = set()

            # Estratégia 1: Busca por seletores de texto do Playwright
            try:
                sctask_locators = target_scope.locator("text=/SCTASK\\d*/")
                count = await sctask_locators.count()
                for i in range(count):
                    text = await sctask_locators.nth(i).inner_text()
                    clean_text = text.strip()
                    if clean_text:
                        found_texts.add(clean_text)
            except Exception as ex_loc:
                logger.warning(f"Aviso na Estratégia 1 de busca: {ex_loc}")

            # Estratégia 2: Regex direto no HTML / Corpo do DOM
            try:
                if target_scope == page:
                    body_text = await page.inner_text("body")
                else:
                    body_text = await target_scope.locator("body").inner_text()

                matches = re.findall(r"SCTASK\d+", body_text)
                for m in matches:
                    found_texts.add(m)
            except Exception as ex_body:
                logger.warning(f"Aviso na Estratégia 2 (body regex): {ex_body}")

            result["sctasks"] = sorted(list(found_texts))
            logger.info(f"✅ [ServiceNowDriver] {len(result['sctasks'])} SCTASK(s) encontrados em {url}: {result['sctasks']}")

        except Exception as e:
            logger.error(f"❌ [ServiceNowDriver] Erro ao processar a página {url}: {e}")
            result["status"] = "error"
            result["error"] = str(e)

        return result

    async def capturar_sctask_pagina_unica(
        self, 
        page: Page, 
        url: str, 
        download_dir: str = "./downloads"
    ) -> Dict[str, Any]:
        """
        ========================================================================
        PONTO 1: CAPTURA E EXTRAÇÃO DE SCTASK EM PÁGINA ÚNICA (SEM ABRIR 3 ABAS)
        ========================================================================
        Navega até a URL do chamado ServiceNow (RITM/SCTASK) em 1 página única Playwright,
        muda para o escopo do iFrame 'gsft_main', extrai RITM, SCTASK, Solicitante e realiza
        o download de eventuais anexos (.xlsx/.txt) sem abrir janelas extras.
        """
        logger.info(f"📌 [ServiceNowDriver] Capturando dados e SCTASK em PÁGINA ÚNICA: {url}")
        res: Dict[str, Any] = {
            "url": url,
            "ritm": None,
            "sctasks": [],
            "requester": None,
            "description": None,
            "downloaded_files": [],
            "status": "success",
            "error": None
        }

        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)
            await page.wait_for_timeout(2000)

            # 1. Extração do número RITM / SCTASK principal do formulário
            try:
                ritm_locator = scope.locator("input#sys_readonly\\.sc_req_item\\.number, input#sys_readonly\\.sc_task\\.number").first
                if await ritm_locator.count() > 0:
                    res["ritm"] = (await ritm_locator.input_value()).strip()
            except Exception as e_num:
                logger.debug(f"Não foi possível ler o campo de número direto: {e_num}")

            # 2. Extração do Solicitante (Requested For)
            try:
                req_locator = scope.locator("input#sys_display\\.sc_req_item\\.u_requested_for, input#sys_display\\.sc_task\\.u_requested_for").first
                if await req_locator.count() > 0:
                    res["requester"] = (await req_locator.input_value()).strip()
            except Exception as e_req:
                logger.debug(f"Não foi possível ler o solicitante: {e_req}")

            # 3. Identificação de SCTASKs associadas na página (Regex + Text Locators)
            dados_raspagem = await self.process_servicenow_page(page, url)
            res["sctasks"] = dados_raspagem.get("sctasks", [])

            # 4. Download de anexos (ex: tabelas .xlsx ou instruções .txt) diretamente na mesma página
            try:
                attachment_links = scope.locator("a[href*='sys_attachment'], a:has-text('.xlsx'), a:has-text('.txt')")
                att_count = await attachment_links.count()
                if att_count > 0:
                    os.makedirs(download_dir, exist_ok=True)
                    for idx in range(att_count):
                        link_loc = attachment_links.nth(idx)
                        link_text = (await link_loc.inner_text()).strip()
                        if link_text:
                            try:
                                async with page.expect_download(timeout=10000) as download_info:
                                    await link_loc.click()
                                download = await download_info.value
                                saved_path = os.path.join(download_dir, download.suggested_filename)
                                await download.save_as(saved_path)
                                res["downloaded_files"].append(saved_path)
                                logger.info(f"💾 Anexo baixado com sucesso em página única: {saved_path}")
                            except Exception as ex_dl:
                                logger.warning(f"Aviso ao tentar baixar anexo #{idx}: {ex_dl}")
            except Exception as e_att:
                logger.debug(f"Aviso na verificação de anexos: {e_att}")

            logger.info(f"✅ [Captura Página Única] RITM={res['ritm']} | SCTASKs={res['sctasks']} | Anexos={len(res['downloaded_files'])}")

        except Exception as e:
            logger.error(f"❌ [Captura Página Única] Erro ao capturar em {url}: {e}")
            res["status"] = "error"
            res["error"] = str(e)

        return res

    async def preencher_e_encerrar_sctask(
        self,
        page: Page,
        sctask_id_ou_url: str,
        configuration_item: str = "Portal Corretor",
        state: str = "Closed Complete",
        assignment_group: Optional[str] = None,
        work_notes: Optional[str] = None,
        evidence_files: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        ========================================================================
        PONTO 2: AUTOMAPREENCHIMENTO E ENCERRAMENTO DE SCTASK VIA HERANÇA
        ========================================================================
        Método reutilizável por TODAS as classes especialistas que herdam de ServiceNowDriver
        (CadastroUsuarioService, MfaResetService, PasswordResetService, TaskEncerrarService, etc.).
        
        Preenche os campos padrão da SCTASK (Item de Configuração, Grupo de Atribuição, Estado,
        comentários de trabalho) e anexa arquivos de evidência antes de salvar/fechar.
        """
        url = sctask_id_ou_url if sctask_id_ou_url.startswith("http") else f"https://aig.service-now.com/sc_task.do?sys_id={sctask_id_ou_url}"
        logger.info(f"🛠️ [ServiceNowDriver] Preenchendo e encerrando SCTASK em: {url} (Estado='{state}')")

        res: Dict[str, Any] = {
            "sctask_url": url,
            "state": state,
            "status": "success",
            "error": None
        }

        try:
            # 1. Acessa a SCTASK no escopo da mesma página
            if page.url != url:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)

            scope = await self.get_iframe_scope(page=page, iframe_key_or_selector="gsft_main", timeout=20000)

            # 2. Configura o Item de Configuração (ex: "Portal Corretor")
            if configuration_item:
                try:
                    await self.fill_reference_field(
                        scope=scope, 
                        selector_key="configuration_item", 
                        search_text=configuration_item,
                        confirm_with_enter=True
                    )
                except Exception as e_ci:
                    logger.warning(f"Aviso ao preencher Item de Configuração '{configuration_item}': {e_ci}")

            # 3. Configura Grupo de Atribuição se fornecido
            if assignment_group:
                try:
                    await self.fill_reference_field(
                        scope=scope,
                        selector_key="assignment_group",
                        search_text=assignment_group,
                        confirm_with_enter=True
                    )
                except Exception as e_ag:
                    logger.warning(f"Aviso ao preencher Grupo de Atribuição '{assignment_group}': {e_ag}")

            # 4. Insere comentários / Notas de Trabalho (Work Notes)
            if work_notes:
                try:
                    text_selector = self.get_selector("activity_stream_textarea")
                    notes_locator = scope.locator(text_selector).first
                    if await notes_locator.count() > 0:
                        await notes_locator.click()
                        await notes_locator.fill(work_notes)
                        await asyncio.sleep(0.5)
                        try:
                            post_btn_selector = self.get_selector("post_comments_btn")
                            if await scope.locator(post_btn_selector).count() > 0:
                                await self.click_element(scope, "post_comments_btn")
                        except Exception:
                            pass
                except Exception as e_wn:
                    logger.warning(f"Aviso ao postar comentários/Work Notes: {e_wn}")

            # 5. Upload de Evidências / Anexos (.png / .xlsx)
            if evidence_files:
                for file_path in evidence_files:
                    if os.path.exists(file_path):
                        try:
                            logger.info(f"📎 Anexando evidência na SCTASK: {file_path}")
                            # Clica no ícone de anexo para expor o input file
                            att_btn = scope.locator(self.get_selector("attachment_button")).first
                            if await att_btn.count() > 0:
                                await att_btn.click()
                                await asyncio.sleep(0.5)

                            input_file = scope.locator(self.get_selector("attach_file_input")).first
                            await input_file.set_input_files(file_path)
                            await asyncio.sleep(1.5)
                        except Exception as e_att:
                            logger.warning(f"Aviso ao realizar upload de '{file_path}': {e_att}")

            # 6. Seleciona o Estado (State) da Tarefa
            try:
                state_selector = self.get_selector("task_state_select")
                state_loc = scope.locator(state_selector).first
                if await state_loc.count() > 0:
                    # Mapeia rótulo/código de estado
                    state_val = "3" if "close" in state.lower() or "encerr" in state.lower() else "2" # 3 = Closed Complete, 2 = Work in Progress
                    await state_loc.select_option(value=state_val)
            except Exception as e_st:
                logger.warning(f"Aviso ao alterar o estado da SCTASK para '{state}': {e_st}")

            # 7. Submete/Salva a SCTASK (Update / Save / Close Task)
            try:
                btn_key = "close_task_button" if "close" in state.lower() else "update_stay_button"
                await self.click_element(scope, btn_key)
                await page.wait_for_timeout(2000)
            except Exception as e_sub:
                logger.warning(f"Aviso ao submeter a SCTASK: {e_sub}")

            logger.info(f"✅ [Preencher/Encerrar SCTASK] Tarefa {url} processada com sucesso!")

        except Exception as e:
            logger.error(f"❌ [Preencher/Encerrar SCTASK] Erro em {url}: {e}")
            res["status"] = "error"
            res["error"] = str(e)

        return res

    async def process_multiple_pages(
        self, 
        context: BrowserContext, 
        urls: List[str], 
        max_concurrency: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Processa múltiplas URLs do ServiceNow utilizando a infraestrutura de concorrência assíncrona herdada.
        """
        return await self.run_concurrent_tasks(context, urls, self.process_servicenow_page, max_concurrency)


    async def run_extraction(
        self, 
        urls: List[str], 
        headless: bool = False, 
        max_concurrency: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Método principal que gerencia o ciclo de vida da execução:
        Inicia contexto persistente -> Valida Okta -> Executa raspagem em paralelo -> Retorna os dados.
        """
        async with async_playwright() as p:
            context = await self.launch_persistent_context(p, headless=headless)
            try:
                if urls:
                    check_page = await context.new_page()
                    await OktaAuthManager.wait_for_okta_login_if_needed(check_page, urls[0])
                    await check_page.close()

                logger.info(f"🚀 Iniciando processamento de {len(urls)} páginas no ServiceNow...")
                resultados = await self.process_multiple_pages(context, urls, max_concurrency=max_concurrency)
                return resultados
            finally:
                await self.close_context(context)

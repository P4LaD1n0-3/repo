import os
import asyncio
import logging
from typing import List, Dict, Any, Optional, Union
from dotenv import load_dotenv
from playwright.async_api import Page, FrameLocator
from tools.base_automation import BaseAutomation, SelectorManager

logger = logging.getLogger("UpmDriver")

class UpmDriver(BaseAutomation):
    """
    ============================================================================
    DRIVER ESPECIALIZADO: AUTOMAÇÕES NO PORTAL UPM / PUMA
    ============================================================================
    Classe orientada a objetos especialista responsável por todas as rotinas no UPM:
    1. Login de Administrador UPM (`login_upm`)
    2. Cadastro de Usuários (`cadastrar_usuario_upm`)
    3. Reset de Senha / MFA com evidência screenshot (`resetar_senha_mfa_upm`)
    4. Gerenciamento de Status de Usuário Ativo/Inativo (`gerenciar_status_usuario_upm`)
    5. Cadastro de Corretoras / Organizações (`cadastrar_corretora_upm`)

    Herda de BaseAutomation e utiliza seletores desacoplados do servicenow_paths.json.
    """

    DEFAULT_UPM_URL = "https://upm-int.aig.net/puma/"
    DEFAULT_RESET_URL = "https://upm-int.aig.net/puma/jsf/ext/lar/resetLarUserPwd.jspx"

    def __init__(
        self, 
        selectors: Optional[Union[Dict[str, str], SelectorManager, str]] = None,
        user_data_dir: Optional[str] = None
    ):
        super().__init__(selectors=selectors, user_data_dir=user_data_dir)
        load_dotenv("src/documents/.env")

    async def login_upm(
        self, 
        page: Page, 
        username: Optional[str] = None, 
        password: Optional[str] = None,
        url: Optional[str] = None
    ) -> bool:
        """
        Realiza a autenticação no portal UPM/PUMA com credenciais do .env ou parâmetros fornecidos.
        """
        login_url = url or self.DEFAULT_UPM_URL
        user = username or os.getenv("usuario_upm")
        pwd = password or os.getenv("senha_upm")

        logger.info(f"🔐 [UpmDriver] Efetuando login no UPM ({login_url}) com usuário: {user}")

        try:
            await page.goto(login_url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(1000)

            # Preenche login e senha via seletores desacoplados
            if user:
                await self.fill_input(page, "upm_username", user)
            if pwd:
                await self.fill_input(page, "upm_password", pwd)

            await self.click_element(page, "upm_login_btn")
            await page.wait_for_timeout(2000)

            logger.info("✅ [UpmDriver] Login efetuado no UPM com sucesso.")
            return True
        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao efetuar login no UPM: {e}")
            raise e

    async def cadastrar_usuario_upm(self, page: Page, dados_usuario: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cadastra um novo usuário no portal UPM (E-mail, CPF, Nome, Razão Social, SUSEP, Permissões).
        """
        email = dados_usuario.get("email_master", "").strip()
        cpf = dados_usuario.get("cpf", "").strip()
        nome_completo = dados_usuario.get("nome_completo", "").strip()
        razao_social = dados_usuario.get("razao_social", "").strip()
        susep = dados_usuario.get("susep", "").strip()
        is_assessoria = dados_usuario.get("is_assessoria", False)

        logger.info(f"👤 [UpmDriver] Cadastrando usuário UPM: Email='{email}' | CPF='{cpf}'")

        res: Dict[str, Any] = {
            "email": email,
            "cpf": cpf,
            "status": "success",
            "mensagem": None,
            "senha_gerada": None
        }

        try:
            # Navega até o menu 'Adicionar Usuário'
            await self.click_element(page, "upm_menu_add_user")
            await page.wait_for_timeout(1000)

            # Preenche E-mail e CPF
            await self.fill_input(page, "upm_user_email", email)
            await self.fill_input(page, "upm_user_cpf", cpf)

            # Divide Nome e Sobrenome
            parts = nome_completo.split(" ", 1)
            first_name = parts[0]
            last_name = parts[1] if len(parts) > 1 else ""

            await self.fill_input(page, "upm_user_first_name", first_name)
            await self.fill_input(page, "upm_user_last_name", last_name)

            # Busca e associa Organização / Corretora
            if razao_social:
                await self.fill_input(page, "upm_org_search", razao_social[:15])
                await self.click_element(page, "upm_org_find_btn")
                await page.wait_for_timeout(1000)
                try:
                    await self.click_element(page, "upm_org_select_result")
                except Exception as e_sel:
                    logger.warning(f"Aviso ao selecionar organização encontrada: {e_sel}")

            # Preenche SUSEP
            susep_val = "000000000" if is_assessoria else (susep or "000000000")
            await self.fill_input(page, "upm_susep_input", susep_val)
            await self.click_element(page, "upm_addsusep_btn")
            try:
                await self.click_element(page, "upm_addsusep_force_btn")
            except Exception:
                pass

            # Vincula permissões de empresa (Option 2)
            try:
                await self.click_element(page, "upm_designation_option")
                await self.click_element(page, "upm_designation_add_btn")
            except Exception as e_desig:
                logger.warning(f"Aviso ao vincular empresa ao usuário: {e_desig}")

            # Salva o cadastro
            await self.click_element(page, "upm_save_btn")
            await page.wait_for_timeout(2000)

            # Obtém a mensagem de retorno do UPM
            try:
                msg = await self.get_text(page, "upm_message_result")
                res["mensagem"] = msg
                logger.info(f"📢 [UpmDriver] Mensagem do UPM: {msg}")
            except Exception:
                res["mensagem"] = "Usuário cadastrado"

            logger.info(f"✅ [UpmDriver] Cadastro de usuário finalizado para {email}")

        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao cadastrar usuário {email}: {e}")
            res["status"] = "error"
            res["mensagem"] = str(e)

        return res

    async def resetar_senha_mfa_upm(
        self, 
        page: Page, 
        email: str, 
        type_reset: str = "reset",
        save_screenshot: bool = True
    ) -> Dict[str, Any]:
        """
        Executa a troca/reset de senha ou reset de MFA no UPM para o e-mail informado e tira screenshot de evidência.
        """
        logger.info(f"🔑 [UpmDriver] Executando Reset ('{type_reset}') no UPM para: {email}")
        res: Dict[str, Any] = {
            "email": email,
            "type_reset": type_reset,
            "senha_gerada": None,
            "screenshot_path": None,
            "status": "success",
            "error": None
        }

        try:
            # Navega até a página de reset de senha do LAR/UPM
            await page.goto(self.DEFAULT_RESET_URL, wait_until="domcontentloaded", timeout=30000)
            await self.fill_input(page, "upm_reset_email_input", email)
            await self.click_element(page, "upm_reset_search_btn")
            await page.wait_for_timeout(1500)

            # Executa a ação de reset de MFA ou geração de Senha
            if type_reset.lower() == "reset":
                # Clica no botão de Reset MFA primeiro
                try:
                    await self.click_element(page, "upm_reset_mfa_btn")
                    await page.wait_for_timeout(1000)
                except Exception:
                    pass

                # Clica no botão de Confirmação de Gerar Nova Senha
                await self.click_element(page, "upm_reset_confirm_pwd_btn")
                await page.wait_for_timeout(1500)

                try:
                    raw_text = await self.get_text(page, "upm_message_result")
                    if ": " in raw_text:
                        res["senha_gerada"] = raw_text.split(": ", 1)[1].strip()
                    else:
                        res["senha_gerada"] = raw_text.strip()
                except Exception:
                    res["senha_gerada"] = "Senha_Gerada_Sucesso"
            else:
                # Reset exclusivo de MFA
                await self.click_element(page, "upm_reset_mfa_btn")
                await page.wait_for_timeout(1000)
                res["senha_gerada"] = "MFA_Resetado"

            # Salva screenshot de evidência
            if save_screenshot:
                ss_path = f"path_temp/{email.replace('@', '_at_')}.png"
                await self.take_screenshot(page, ss_path)
                res["screenshot_path"] = ss_path

            logger.info(f"✅ [UpmDriver] Reset de {email} concluído. Resultado: {res['senha_gerada']}")

        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao resetar {email}: {e}")
            res["status"] = "error"
            res["error"] = str(e)

        return res

    async def gerenciar_status_usuario_upm(self, page: Page, email: str, status: str = "A") -> Dict[str, Any]:
        """
        Altera o status da conta do usuário no UPM ("A" = Ativo, "I" = Inativo).
        """
        logger.info(f"⚙️ [UpmDriver] Alterando status da conta de '{email}' para '{status}'...")
        res: Dict[str, Any] = {"email": email, "status": status, "resultado": "success"}

        try:
            await self.click_element(page, "upm_menu_manage_user")
            await page.wait_for_timeout(1000)

            await self.fill_input(page, "upm_manage_email_search", email)
            await self.click_element(page, "upm_manage_search_btn")
            await page.wait_for_timeout(1000)

            await self.click_element(page, "upm_select_user_result")
            await self.select_option(page, "upm_account_status_select", status)
            await self.click_element(page, "upm_save_btn")
            await page.wait_for_timeout(1500)

            logger.info(f"✅ [UpmDriver] Status do usuário {email} alterado para '{status}' com sucesso.")
        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao alterar status de {email}: {e}")
            res["resultado"] = "error"
            res["error"] = str(e)

        return res

    async def cadastrar_corretora_upm(self, page: Page, dados_corretora: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cadastra uma nova Corretora / Organização no portal UPM.
        """
        nome = dados_corretora.get("nome_organizacao", "")
        endereco_1 = dados_corretora.get("endereco_1", "")
        endereco_2 = dados_corretora.get("endereco_2", "")
        cidade = dados_corretora.get("cidade", "")
        cep = dados_corretora.get("cep", "")

        logger.info(f"🏢 [UpmDriver] Cadastrando Corretora/Organização no UPM: {nome}")
        res: Dict[str, Any] = {"nome": nome, "status": "success"}

        try:
            await self.click_element(page, "upm_menu_add_org")
            await page.wait_for_timeout(1000)

            await self.fill_input(page, "upm_org_name_input", nome)
            await self.fill_input(page, "upm_org_address1_input", endereco_1)
            await self.fill_input(page, "upm_org_address2_input", endereco_2)
            await self.fill_input(page, "upm_org_city_input", cidade)
            await self.fill_input(page, "upm_org_cep_input", cep)

            await self.click_element(page, "upm_save_btn")
            await page.wait_for_timeout(2000)

            logger.info(f"✅ [UpmDriver] Corretora '{nome}' cadastrada no UPM com sucesso.")
        except Exception as e:
            logger.error(f"❌ [UpmDriver] Erro ao cadastrar corretora {nome}: {e}")
            res["status"] = "error"
            res["error"] = str(e)

        return res
